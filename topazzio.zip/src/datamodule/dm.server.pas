unit DM.Server;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, FileUtil, ZConnection, ZDataset, DB, SQLDB;

type

  { TDMServer }

  TDMServer = class(TDataModule)
    Connection: TZConnection;
    procedure DataModuleCreate(Sender: TObject);
    procedure DataModuleDestroy(Sender: TObject);
  private
    FMsgErro: string;
    FPathDLL, FPathBanco : String;
    FCriarTabelas: Boolean;
    procedure ChecaTabelas;
  public
    property GetMsgErro: string read FMsgErro;
    procedure Desconectar;
    procedure ChecaConexao;
    procedure TransactionPrepare;
    procedure TransactionCommit;
    procedure TransactionRollback;
    function LastInsertedID: Integer;
    function NewQuery(): TZQuery;
  end;

var
  DMServer: TDMServer;

implementation

{$R *.lfm}

{ TDMServer }

procedure TDMServer.DataModuleCreate(Sender: TObject);
//estabelece a conexão
begin
  FMsgErro      := '';
  FPathBanco    := ExtractFileDir( ParamStr(0) ) + PathDelim + 'topazzio.db';
  FPathDLL      := ExtractFileDir( ParamStr(0) ) + PathDelim + 'sqlite3.dll'; //windows
  FCriarTabelas := not FileExists( FPathBanco );

  try
    with Connection do begin
     Protocol   := 'sqlite';
     AutoCommit := True;
     Database   := FPathBanco;

     {$IFDEF WINDOWS}
        LibraryLocation := FPathDLL;
     {$ENDIF}

     Connect;
    end;

    ChecaTabelas;
  except
    on E: Exception do
       FMsgErro := E.Message;
  end;
end;

procedure TDMServer.DataModuleDestroy(Sender: TObject);
// desconecta do banco de daddos ao destruir este módulo
begin
  try
    if Connection.Connected then
       Connection.Disconnect;
  except
    on e: Exception do
      FMsgErro := e.Message;
  end;
end;

procedure TDMServer.ChecaTabelas;
// Cria as tabelas se não existir
begin
  if not FCriarTabelas then Exit;

  ChecaConexao;

  try
    // cria as tabelas
    Connection.ExecuteDirect('CREATE TABLE IF NOT EXISTS crud_projeto (' +
                             'idprojeto INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ' +
                             'projeto varchar (100), ' +
                             'descricao varchar (200), ' +
                             'idtipo_banco integer default (0), ' +
                             'tipo_banco varchar (50), ' +
                             'host_servidor varchar (50), ' +
                             'porta varchar (6), ' +
                             'banco_dados varchar (300), ' +
                             'username varchar (50), ' +
                             'senha varchar (50), ' +
                             'novo_id_sql varchar (50), ' +
                             'pathprojeto TEXT, ' +
                             'form_cor integer default (15263978), ' +
                             'form_font_name varchar (50) default (''Sans,default''), ' +
                             'form_titulo_corfundo integer default (4571095) ' +
                             '); ');

    Connection.ExecuteDirect('CREATE TABLE IF NOT EXISTS crud_tabela (' +
                             'idtabela INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ' +
                             'idprojeto INTEGER REFERENCES crud_projeto (idprojeto) ON DELETE CASCADE NOT NULL, ' +
                             'tabela varchar (100), ' +
                             'nome_objeto varchar (100), ' +
                             'criar_dbgrid_form integer default (1), ' +
                             'criar_form_pesquisa integer default (1), ' +
                             'criar_report integer not null default (0), ' +
                             'script_tabela text, ' +
                             'descricao varchar (200) '+
                             '); ');

    Connection.ExecuteDirect('CREATE TABLE IF NOT EXISTS crud_campo (' +
                             'idcampo INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, ' +
                             'idtabela INTEGER REFERENCES crud_tabela (idtabela) ON DELETE CASCADE NOT NULL, ' +
                             'campo varchar (100), ' +
                             'tipo varchar (50), ' +
                             'tamanho varchar (10), ' +
                             'precisao varchar (10), ' +
                             'escala varchar (10), ' +
                             'chave_primaria Integer not null default (0), ' +
                             'chave_estrangeira Integer not null default (0), ' +
                             'tipo_fp varchar (50), ' +
                             'objeto varchar(100), ' +
                             'currency_field integer default (0), ' +
                             'componente varchar (20), ' +
                             'fk_tabela varchar (50), ' +
                             'fk_codigo varchar (50), ' +
                             'fk_texto varchar (50), ' +
                             'combo_lista TEXT, ' +
                             'incluir_na_grid integer not null default (0), ' +
                             'requerido integer not null default (0), ' +
                             'excluir_do_insert_update integer not null default (0), ' +
                             'rpt_sum integer not null default (0), ' +
                             'ordem integer not null default (1), ' +
                             'campo_cep integer not null default (0) ' +
                             '); ');

    Connection.ExecuteDirect('CREATE INDEX IF NOT EXISTS idx_crud_projeto ON crud_projeto (idprojeto); ');
    Connection.ExecuteDirect('CREATE INDEX IF NOT EXISTS idx_crud_tabela ON crud_tabela (idtabela, idprojeto); ');
    Connection.ExecuteDirect('CREATE INDEX IF NOT EXISTS idx_crud_campo ON crud_campo (idcampo, idtabela); ');
  except
  end;
end;

procedure TDMServer.Desconectar;
// desconecta do banco de dados
begin
  try
    if Connection.Connected then
       Connection.Disconnect;
  except
    on e: Exception do
      FMsgErro := e.Message;
  end;
end;

procedure TDMServer.ChecaConexao;
// se a conexão não estiver aberta, então tenta conectar no servidor/banco
begin
   FMsgErro := '';

   try
     if not Connection.Connected then Connection.Connect;
   except
    on e: Exception do
      FMsgErro := e.Message;
   end;
end;

procedure TDMServer.TransactionPrepare;
//inicia o transatction
begin
  Connection.AutoCommit := False;
  if not Connection.InTransaction then
    Connection.StartTransaction;
end;

procedure TDMServer.TransactionCommit;
//comita o transaction
begin
  if Connection.InTransaction then
    Connection.Commit;
  Connection.AutoCommit := True;
end;

procedure TDMServer.TransactionRollback;
//rolback do transaction
begin
  if Connection.InTransaction then
    Connection.Rollback;
  Connection.AutoCommit := True;
end;

function TDMServer.NewQuery(): TZQuery;
// retorna a instância de uma nova query
begin
  ChecaConexao;

  Result := TZQuery.Create(nil);

  if FMsgErro.IsEmpty then begin
    try
      Result.Connection := Connection;
      Result.Close;
      Result.SQL.Clear;
    except
      on e: Exception do
        FMsgErro := e.Message;
    end;
  end;
end;

function TDMServer.LastInsertedID: Integer;
// retorna o último ID inserido, independente da tabela
begin
  Result := 0;

  try
    with NewQuery() do begin
      SQL.Add('select last_insert_rowid() as id; ');
      Open;

      if RecordCount > 0 then
         Result := FieldByName('id').AsInteger;

      Close;
    end;
  except
  end;
end;

end.


