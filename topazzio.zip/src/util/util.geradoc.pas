unit Util.GeraDoc;

// Gera a documentação da API

{$mode ObjFPC}{$H+}

interface

uses
   Classes, SysUtils, StrUtils, ExtCtrls,
   DB, SQLDB, ZDataset, fpjson, DateUtils, Math,
   Service.Projeto, Service.RestApi, Service.Tabela, Service.Campo;

type

  { TUtilGeraDoc }

  TUtilGeraDoc = class
  private
    FListaTabelasID: string;
    FErroMsg: String;
    FParamtersCount: Integer;
    { header e footer do documento da api}
    function BodyFields(qry: TZQuery; ABreakLine: Boolean; AQdeCampos: Integer;
      AExcluirPrimayKey, AExibirValorExtrangeiro: Boolean): string;
    function GetDocOperadores: String;
    function ResponseBody(AMethod: string; ASucesso, ABreakLine: Boolean): string;
    function GetDocHeader(api: TServiceRestApi): String;
    function GetDocFooter(api: TServiceRestApi): String;
    function GetDocRotaFields(qry: TZQuery): String;
    { rotas }
    function GetDocRotaHeader(qry: TZQuery): String;
    function GetDocRotaEndPoint(qry: TZQuery; AHost, APrefixo, AMethod: String; AIdEndPoint: Integer): String;
    function GetDocRotaFooter(qry: TZQuery): String;
    function GetResposta(ACode, AContentType, AResponse: string): String;
    function GetDetalhes(AOcultar: Boolean; ATitulo, AValor: String): String;
    function GetParametros(AOcultar: Boolean; AMetodo: string): String;
    function ResponseBodyList(qry: TZQuery; AQdeItens: Integer; ABreakLine: Boolean): string;
    function RotaAuth(AHost: string): string;
  public
    function GeraDocumento(const Projeto: TServiceRestApi; AListaTabelasID, APastaDoc: string): Boolean;
    property GetErroMsg: String read FErroMsg;
  end;

implementation

uses
   Util.ProjetoCommon;

{ TUtilGeraDoc }

function TUtilGeraDoc.GeraDocumento(const Projeto: TServiceRestApi; AListaTabelasID, APastaDoc: string): Boolean;
// gera a documentação da api indicada
var
  st: TServiceTabela;
  sc: TServiceCampo;
  tabelas, campos: TZQuery;
  docFile: TextFile;
  docPathNome, lFields, lHost: String;
  idEndPoint: Integer;
begin
  Result := False;
  FErroMsg := '';
  idEndPoint := 0;
  FListaTabelasID := AListaTabelasID;

  // informações da api indicada
  docPathNome := APastaDoc + PathDelim + 'index.html';

  // deleta o arquivo, se existir
  if FileExists(docPathNome) then
     DeleteFile(docPathNome);

  // Define o arquivo a ser criado
  AssignFile(docFile, docPathNome);
  // Use exceptions to catch errors (this is the default so not absolutely requried)
  {$I+}

  try
    st := TServiceTabela.Create( Projeto.IdProjeto );
    tabelas := st.QueryTabelas( FListaTabelasID.Trim, True ); //tabelas

    lHost := Projeto.ApiHost + ':' + Projeto.ApiPorta;

    if tabelas.RecordCount > 0 then begin

      // Cria/Sobrescreve o arquivo
      Rewrite(docFile);

      // cria o cabeçalho do documento
      WriteLn(docFile, GetDocHeader(Projeto));

      // rota de autenticação
      WriteLn(docFile, RotaAuth(lHost));

      // demais rotas
      while not tabelas.EOF do begin
        if tabelas.FieldByName('for_auth').AsInteger = 0 then begin  // não é rota de autenticação
          sc := TServiceCampo.Create( tabelas.FieldByName('idtabela').AsInteger );
          campos := sc.QueryCampos; // campos da tabela
          idEndPoint := idEndPoint + 1;

          if campos.RecordCount > 0 then begin
            // header da rota raiz
            WriteLn(docFile, GetDocRotaHeader(campos)); // OK

            // Fields da tabela para o método POST
            lFields := GetDocRotaFields(campos);
            if Length(lFields) > 0 then
              WriteLn(docFile, lFields);

            // endpoints

            // GET
            idEndPoint := idEndPoint + 1;
            WriteLn(docFile, GetDocRotaEndPoint(campos, lHost, Projeto.ApiVersao, 'get', idEndPoint));

            // GET PAGE
            idEndPoint := idEndPoint + 1;
            if campos.FieldByName('api_get').AsInteger = 1 then
              WriteLn(docFile, GetDocRotaEndPoint(campos, lHost, Projeto.ApiVersao, 'get_list', idEndPoint));

            // POST
            idEndPoint := idEndPoint + 1;
            if campos.FieldByName('api_post').AsInteger = 1 then
              WriteLn(docFile, GetDocRotaEndPoint(campos, lHost, Projeto.ApiVersao, 'post', idEndPoint));

            // PUT
            idEndPoint := idEndPoint + 1;
            if campos.FieldByName('api_put').AsInteger = 1 then
              WriteLn(docFile, GetDocRotaEndPoint(campos, lHost, Projeto.ApiVersao, 'put', idEndPoint));

            // PATCH
            idEndPoint := idEndPoint + 1;
            if campos.FieldByName('api_patch').AsInteger = 1 then
              WriteLn(docFile, GetDocRotaEndPoint(campos, lHost, Projeto.ApiVersao, 'patch', idEndPoint));

            // DELETE
            idEndPoint := idEndPoint + 1;
            if campos.FieldByName('api_delete').AsInteger = 1 then
              WriteLn(docFile, GetDocRotaEndPoint(campos, lHost, Projeto.ApiVersao, 'delete', idEndPoint));

            // footer da rota raiz
            WriteLn(docFile, GetDocRotaFooter(campos)); // OK
          end;

          campos.Close;
          campos.Free;
          sc.Free;
        end;

        // próxima tabela
        tabelas.Next;
      end;

      // cria o footer do documento
      WriteLn(docFile, GetDocFooter(Projeto));

      // fecha o arquivo
      CloseFile(docFile);

      Result := True;
    end;

    tabelas.Close;
    tabelas.Free;
    st.Free;
  except
    on E: EInOutError do
     FErroMsg := 'Erro no manuseio do arquivo.' + sLineBreak + E.ClassName + sLineBreak + E.Message;
  end;
end;

function TUtilGeraDoc.GetDocHeader(api: TServiceRestApi): String;
// retorna o cabeçalho do documento da api
begin
  Result := '';
  Result := Result + '<!DOCTYPE html> ' + sLineBreak;
  Result := Result + '<html lang="pt-br"> ' + sLineBreak;
  Result := Result + '<head> ' + sLineBreak;
  Result := Result + '    <meta charset="UTF-8"> ' + sLineBreak;
  Result := Result + '    <meta name="viewport" content="width=device-width, initial-scale=1.0"> ' + sLineBreak;
  Result := Result + '    <title>' + api.ApiTitulo + '</title> ' + sLineBreak;
  Result := Result + '    <style> ' + sLineBreak;
  Result := Result + '        body {  ' + sLineBreak;
  Result := Result + '            font-family: ''Arial'', sans-serif;  ' + sLineBreak;
  Result := Result + '            background-color: #f8f9fa;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        tr:hover {background-color: #fffff0;}' + sLineBreak;
  Result := Result + '        .param1 { ' + sLineBreak;
  Result := Result + '            width: 140px; ' + sLineBreak;
  Result := Result + '        		margin-left: 5px; ' + sLineBreak;
  Result := Result + '            background-color: #fff;  ' + sLineBreak;
  Result := Result + '            padding: 5px; ' + sLineBreak;
  Result := Result + '            border-radius: 5px; ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '        .param2 { ' + sLineBreak;
  Result := Result + '            width: 80px; ' + sLineBreak;
  Result := Result + '            margin-left: 5px; ' + sLineBreak;
  Result := Result + '            background-color: #fff;  ' + sLineBreak;
  Result := Result + '            padding: 5px; ' + sLineBreak;
  Result := Result + '            border-radius: 5px;   ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .param3 { ' + sLineBreak;
  Result := Result + '            margin-left: 5px; ' + sLineBreak;
  Result := Result + '            background-color: #fff;  ' + sLineBreak;
  Result := Result + '            padding: 5px; ' + sLineBreak;
  Result := Result + '            border-radius: 5px; ' + sLineBreak;
  Result := Result + '        }     ' + sLineBreak;
  Result := Result + '        .container {  ' + sLineBreak;
  Result := Result + '            margin-top: 8px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        h1, h2 {  ' + sLineBreak;
  Result := Result + '            color: #343a40;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        i { color: #444; }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .toggle-symbol { font-weight: bold; }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .container-one {  ' + sLineBreak;
  Result := Result + '            width: 70px;  ' + sLineBreak;
  Result := Result + '            height: 90%;  ' + sLineBreak;
  Result := Result + '            float: left;  ' + sLineBreak;
  Result := Result + '            align-content: center;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            font-size: 14px;  ' + sLineBreak;
  Result := Result + '            text-align: center;  ' + sLineBreak;
  Result := Result + '            color: #fff;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .container-two {  ' + sLineBreak;
  Result := Result + '            margin-left: 90px;              ' + sLineBreak;
  Result := Result + '            height: 90%;  ' + sLineBreak;
  Result := Result + '            align-content: center;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .container-one-post {  ' + sLineBreak;
  Result := Result + '            background-color: #49cc90;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .container-one-get {  ' + sLineBreak;
  Result := Result + '            background-color: #61affe;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .container-one-put {  ' + sLineBreak;
  Result := Result + '            background-color: #fca130;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .container-one-delete {  ' + sLineBreak;
  Result := Result + '            background-color: #f93e3e;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .container-one-patch {  ' + sLineBreak;
  Result := Result + '            background-color: #dbb735;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-post {  ' + sLineBreak;
  Result := Result + '            background-color: #e8f6f0;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #49cc90;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-get {  ' + sLineBreak;
  Result := Result + '            background-color: #ebf3fb;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #61affe;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-put {  ' + sLineBreak;
  Result := Result + '            background-color: #fbf1e6;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #fca130;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-delete {  ' + sLineBreak;
  Result := Result + '            background-color: #fae7e7;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #f93e3e;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .verb-patch {  ' + sLineBreak;
  Result := Result + '            background-color: #fdfcdb;  ' + sLineBreak;
  Result := Result + '            color: black;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #dbb735;  ' + sLineBreak;
  Result := Result + '            padding: 15px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .card-container {  ' + sLineBreak;
  Result := Result + '            width: 100%;  ' + sLineBreak;
  Result := Result + '            border: none;  ' + sLineBreak;
  Result := Result + '            background-color: #ffc16b;   ' + sLineBreak;
  Result := Result + '            cursor: pointer;  ' + sLineBreak;
  Result := Result + '            margin-bottom: 8px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .card-container-title {  ' + sLineBreak;
  Result := Result + '        	  padding: 5px 5px 5px 5px;  ' + sLineBreak;
  Result := Result + '            color: #41444e;  ' + sLineBreak;
  Result := Result + '            font-size: 14px;  ' + sLineBreak;
  Result := Result + '            vertical-align: middle;  ' + sLineBreak;
  Result := Result + '            border-bottom: 1px solid #888;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '                ' + sLineBreak;
  Result := Result + '        .card-container-body {  ' + sLineBreak;
  Result := Result + '        	  padding: 8px 5px 2px 5px;  ' + sLineBreak;
  Result := Result + '            background-color: #eee;  ' + sLineBreak;
  Result := Result + '            display: all;  ' + sLineBreak;
  Result := Result + '            transition: all 0.3s ease-in-out;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '	    .card {  ' + sLineBreak;
  Result := Result + '            margin: 4px 0px 4px 0px; //Top Right Bothon Left  ' + sLineBreak;
  Result := Result + '            border: none;  ' + sLineBreak;
  Result := Result + '            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);  ' + sLineBreak;
  Result := Result + '            border-radius: 10px;  ' + sLineBreak;
  Result := Result + '            padding-bottom: 2px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .card-header {  ' + sLineBreak;
  Result := Result + '            border-radius: 7px 7px 7px 7px;  ' + sLineBreak;
  Result := Result + '            padding: 4px 4px 2px 4px;  ' + sLineBreak;
  Result := Result + '            font-size: 18px;  ' + sLineBreak;
  Result := Result + '            cursor: pointer;  ' + sLineBreak;
  Result := Result + '            height: 30px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-header-open {  ' + sLineBreak;
  Result := Result + '            border-radius: 7px 7px 0 0;  ' + sLineBreak;
  Result := Result + '            padding: 4px 4px 2px 4px;  ' + sLineBreak;
  Result := Result + '            font-size: 18px;  ' + sLineBreak;
  Result := Result + '            cursor: pointer;  ' + sLineBreak;
  Result := Result + '            height: 30px;  ' + sLineBreak;
  Result := Result + '            border-bottom: 0px; ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .card-body {  ' + sLineBreak;
  Result := Result + '            padding: 5px 10px 10px 10px;  ' + sLineBreak;
  Result := Result + '            background-color: #ffffff;  ' + sLineBreak;
  Result := Result + '            border-radius: 0 0 10px 10px;  ' + sLineBreak;
  Result := Result + '            font-size: 14px;  ' + sLineBreak;
  Result := Result + '            display: none;  ' + sLineBreak;
  Result := Result + '            transition: all 0.3s ease-in-out;  ' + sLineBreak;
  Result := Result + '            cursor: default;  ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .card-body-post {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #49cc90;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-body-get {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #61affe;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-body-put {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #fca130;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-body-delete {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #f93e3e;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '        .card-body-patch {  ' + sLineBreak;
  Result := Result + '            border: 1px solid #dbb735;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '     .card-container-title:hover {  ' + sLineBreak;
  Result := Result + '            background-color: rgba(255, 170, 0, 0.5);  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .verb-post:hover { background-color: #cbf6e2; }  ' + sLineBreak;
  Result := Result + '        .verb-get:hover { background-color: #d1eafb; }  ' + sLineBreak;
  Result := Result + '        .verb-put:hover { background-color: #fbe5cd; }  ' + sLineBreak;
  Result := Result + '        .verb-delete:hover { background-color: #fad4d3; }  ' + sLineBreak;
  Result := Result + '        .verb-patch:hover { background-color: #fdfbb7; }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        pre {  ' + sLineBreak;
  Result := Result + '            background-color: #f1f3f5;  ' + sLineBreak;
  Result := Result + '            padding: 6px;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            font-size: 12px;  ' + sLineBreak;
  Result := Result + '            overflow-x: auto;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        .table th {  ' + sLineBreak;
  Result := Result + '            background-color: #f8f9fa;  ' + sLineBreak;
  Result := Result + '            color: #495057;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        button {  ' + sLineBreak;
  Result := Result + '            background-color: #ffffff;  ' + sLineBreak;
  Result := Result + '            border: 1px solid #ccc;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '            padding: 5px 10px;  ' + sLineBreak;
  Result := Result + '            cursor: pointer;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        button:hover {  ' + sLineBreak;
  Result := Result + '            background-color: #f1f3f5;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        header {  ' + sLineBreak;
  Result := Result + '        	  height: 140px; ' + sLineBreak;
  Result := Result + '           margin-top: 5px;  ' + sLineBreak;
  Result := Result + '           padding: 10px;  ' + sLineBreak;
  Result := Result + '           background-color: #343a40;  ' + sLineBreak;
  Result := Result + '           color: white;  ' + sLineBreak;
  Result := Result + '           text-align: center;  ' + sLineBreak;
  Result := Result + '           border-radius: 5px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        header h1 {  ' + sLineBreak;
  Result := Result + '            text-decoration: none;  ' + sLineBreak;
  Result := Result + '            color: white;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        footer {  ' + sLineBreak;
  Result := Result + '            margin-top: 50px;  ' + sLineBreak;
  Result := Result + '            padding: 10px;  ' + sLineBreak;
  Result := Result + '            background-color: #343a40;  ' + sLineBreak;
  Result := Result + '            color: white;  ' + sLineBreak;
  Result := Result + '            text-align: center;  ' + sLineBreak;
  Result := Result + '            border-radius: 5px;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        footer a {  ' + sLineBreak;
  Result := Result + '            color: #fff;  ' + sLineBreak;
  Result := Result + '            text-decoration: none;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '  ' + sLineBreak;
  Result := Result + '        footer a:hover {  ' + sLineBreak;
  Result := Result + '            text-decoration: underline;  ' + sLineBreak;
  Result := Result + '        }  ' + sLineBreak;
  Result := Result + '          ' + sLineBreak;
  Result := Result + '        .mb-4 {margin-bottom:1.1rem!important}  ' + sLineBreak;
  Result := Result + '        .linha {  ' + sLineBreak;
  Result := Result + '           display: flex;  ' + sLineBreak;
  Result := Result + '           justify-content: space-between;  ' + sLineBreak;
  Result := Result + '           align-items: center;  ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '        .linha a {  ' + sLineBreak;
  Result := Result + '    	  text-decoration: none;  ' + sLineBreak;
  Result := Result + '    	  margin-left: auto;  ' + sLineBreak;
  Result := Result + '	      }  ' + sLineBreak;
  Result := Result + '	   div { ' + sLineBreak;
  Result := Result + '    		display: block; ' + sLineBreak;
  Result := Result + '    		unicode-bidi: isolate; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		code { ' + sLineBreak;
  Result := Result + '         color: #444; ' + sLineBreak;
  Result := Result + '    		background-color: #f5f5f5; ' + sLineBreak;
  Result := Result + '         font: monospace, Consolas,"courier new"; ' + sLineBreak;
  Result := Result + '         font-size: 12px; ' + sLineBreak;
  Result := Result + '    		padding: 1px 4px; ' + sLineBreak;
  Result := Result + '    		border: 1px solid #cfcfcf; ' + sLineBreak;
  Result := Result + '         border-radius: 3px; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition { ' + sLineBreak;
  Result := Result + '    		margin-top: 12px; ' + sLineBreak;
  Result := Result + '    		margin-bottom: 12px; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .uri { ' + sLineBreak;
  Result := Result + '    		word-break: break-all; ' + sLineBreak;
  Result := Result + '    		word-wrap: break-word; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .hostname { ' + sLineBreak;
  Result := Result + '    		opacity: .6; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.get { ' + sLineBreak;
  Result := Result + '    		color: #61affe; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.post { ' + sLineBreak;
  Result := Result + '    		color: #49cc90; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.put { ' + sLineBreak;
  Result := Result + '    		color: #fca130; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.delete { ' + sLineBreak;
  Result := Result + '    		color: #f93e3e; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method.patch { ' + sLineBreak;
  Result := Result + '    		color: #dbb735; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.definition .method { ' + sLineBreak;
  Result := Result + '    		font-weight: bold; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.name { ' + sLineBreak;
  Result := Result + '    		float: right; ' + sLineBreak;
  Result := Result + '    		font-weight: normal; ' + sLineBreak;
  Result := Result + '    		padding: 6px 0; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.collapse-button { ' + sLineBreak;
  Result := Result + '    		float: right; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.collapse-button .close { ' + sLineBreak;
  Result := Result + '    		display: none; ' + sLineBreak;
  Result := Result + '    		color: #428bca; ' + sLineBreak;
  Result := Result + '    		cursor: pointer; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '		.collapse-button .open { ' + sLineBreak;
  Result := Result + '    		color: #428bca; ' + sLineBreak;
  Result := Result + '    		cursor: pointer; ' + sLineBreak;
  Result := Result + '		} ' + sLineBreak;
  Result := Result + '        .table-container-title {  ' + sLineBreak;
  Result := Result + '            padding: 5px 5px 5px 5px;  ' + sLineBreak;
  Result := Result + '            color: #041444e;  ' + sLineBreak;
  Result := Result + '            font-size: 14px;  ' + sLineBreak;
  Result := Result + '            vertical-align: middle;   ' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-container {' + sLineBreak;
  Result := Result + '            display: flex;' + sLineBreak;
  Result := Result + '            flex-direction: column;' + sLineBreak;
  Result := Result + '            border: 1px solid #ccc;' + sLineBreak;
  Result := Result + '            border-radius: 8px;' + sLineBreak;
  Result := Result + '            overflow: hidden;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-row {' + sLineBreak;
  Result := Result + '            display: flex;' + sLineBreak;
  Result := Result + '            border-bottom: 1px solid #ccc;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-row:first-child {' + sLineBreak;
  Result := Result + '            background-color: #f1f1f1;' + sLineBreak;
  Result := Result + '            font-weight: bold;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-cell {' + sLineBreak;
  Result := Result + '            flex: 1;' + sLineBreak;
  Result := Result + '            padding: 10px;' + sLineBreak;
  Result := Result + '            text-align: left;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '        .table-cell:not(:last-child) {' + sLineBreak;
  Result := Result + '            border-right: 1px solid #ccc;' + sLineBreak;
  Result := Result + '        }' + sLineBreak;
  Result := Result + '    </style> ' + sLineBreak;
  Result := Result + '</head> ' + sLineBreak;
  Result := Result + '<body> ' + sLineBreak;
  Result := Result + '    <div class="container"> ' + sLineBreak;
  Result := Result + '        <header class="mb-4"> ' + sLineBreak;
  Result := Result + '           <div class="container-one" style="height:140px; vertical-align:middle;"> ' + sLineBreak;

  Result := Result + '             <img src="/images/apidoc.png" width="128" height="128" border="0" alt="Logo">' + sLineBreak;

  Result := Result + '           </div>' + sLineBreak;
  Result := Result + '           <div class="container-two">' + sLineBreak;
  Result := Result + '             <h1>' + api.ApiHeader1 + '</h1> ' + sLineBreak;
  Result := Result + '             <p>' + api.ApiHeader2 + '</p> ' + sLineBreak;
  Result := Result + '             <p>' + api.ApiHeader3 + '</p> ' + sLineBreak;
  Result := Result + '           </div>' + sLineBreak;
  Result := Result + '        </header> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '        <section id="overview"> ' + sLineBreak;

  if Trim(api.ApiDescricao) <> '' then begin
    Result := Result + '            <h2>Visão Geral</h2> ' + sLineBreak;
    Result := Result + '            <p><font style="font-size:14px;">' + api.ApiDescricao + '</font></p> ' + sLineBreak;
  end;

  Result := Result + '        </section> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '        <section id="endpoints"> ' + sLineBreak;
  Result := Result + '            <div class="linha">' + sLineBreak;
  Result := Result + '    	    <h2>Endpoints da API</h2> ' + sLineBreak;
  Result := Result + '    	    <a href="#" onclick="minimizarRotas()" style="font-size: 12px;">Retrair tudo</a>&nbsp;&nbsp; ' + sLineBreak;
  Result := Result + '		  </div> ' + sLineBreak;
  Result := Result + '            <hr style="border: 1px solid #a0a0a0;"> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocFooter(api: TServiceRestApi): String;
// retorna o rodape do documento da api
begin
  Result := '';
  Result := Result + ' ' + sLineBreak;
  Result := Result + '          <hr style="border: 1px solid #a0a0a0;"> ' + sLineBreak;
  Result := Result + '        </section> ' + sLineBreak;
  Result := Result + '<section>' + sLineBreak;
  Result := Result + GetDocOperadores + sLineBreak;
  Result := Result + '          <hr style="border: 1px solid #a0a0a0;"> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '        <section id="errors" style="font-size: 10px;"> ' + sLineBreak;
  Result := Result + '            <h3>Repostas mais comuns (StatusCode)</h3> ' + sLineBreak;
  Result := Result + '            <table class="table">                 ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td><b>Código</b></td> ' + sLineBreak;
  Result := Result + '               <td width="20"></td>' + sLineBreak;
  Result := Result + '               <td><b>Mensagem</b></td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">200</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>OK</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">201</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Created</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">202</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Accepted</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">400</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Bad Request</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">401</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Unauthorized</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">403</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Forbidden</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">404</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Not Found</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '             <tr> ' + sLineBreak;
  Result := Result + '               <td align="center">500</td> ' + sLineBreak;
  Result := Result + '               <td></td>' + sLineBreak;
  Result := Result + '               <td>Internal Server Error</td> ' + sLineBreak;
  Result := Result + '             </tr> ' + sLineBreak;
  Result := Result + '            </table> ' + sLineBreak;
  Result := Result + '        </section> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '        <footer> ' + sLineBreak;
  Result := Result + '            <p>' + api.ApiFooter1 + '</p> ' + sLineBreak;

  if Trim(api.ApiFooter2) <> '' then
     Result := Result + '            <p>' + api.ApiFooter2 + '</p> ' + sLineBreak;

  Result := Result + '<font style="font-size:10px;">Criado via TOPAZZIO - ' + FormatDateTime('dd/mm/yyyy hh:nn:ss', now) + '</font>' + sLineBreak;

  Result := Result + '        </footer> ' + sLineBreak;
  Result := Result + '    </div> ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '     ' + sLineBreak;
  Result := Result + '    <script> ' + sLineBreak;
  Result := Result + '        function toggleVisibility(id) { ' + sLineBreak;
  Result := Result + '            var element = document.getElementById(id); ' + sLineBreak;
  Result := Result + '            var estiloAtual = window.getComputedStyle(element).display; ' + sLineBreak;
  Result := Result + '            var icon = document.getElementById("icon_" + id); ' + sLineBreak;
  Result := Result + '            var pai = document.getElementById("ch_" + id); ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '	 	  if (pai !== null){            ' + sLineBreak;
  Result := Result + '               var classe = pai.className; ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '               if (classe.indexOf("card-header-open") == 0) { ' + sLineBreak;
  Result := Result + '               	classe = classe.replace("card-header-open", "card-header"); ' + sLineBreak;
  Result := Result + '               } else if (classe.indexOf("card-header") == 0) { ' + sLineBreak;
  Result := Result + '            	classe = classe.replace("card-header", "card-header-open");            	 ' + sLineBreak;
  Result := Result + '               } ' + sLineBreak;
  Result := Result + '               document.getElementById("ch_" + id).className = classe; ' + sLineBreak;
  Result := Result + '            }             ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
  Result := Result + '            if (estiloAtual === "none") { ' + sLineBreak;
  Result := Result + '                element.style.display = "block"; ' + sLineBreak;
  Result := Result + '                icon.textContent = ''▼''; ' + sLineBreak;
  Result := Result + '            } else { ' + sLineBreak;
  Result := Result + '                element.style.display = "none"; ' + sLineBreak;
  Result := Result + '                icon.textContent = ''▶''; ' + sLineBreak;
  Result := Result + '            } ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '         ' + sLineBreak;
  Result := Result + '        function minimizarRotas() { ' + sLineBreak;
  Result := Result + '          document.querySelectorAll(''[id^="ep"]'').forEach(elemento => { ' + sLineBreak;
  Result := Result + '            elemento.style.display = ''none''; ' + sLineBreak;
  Result := Result + '            var icon = document.getElementById("icon_" + elemento.id); ' + sLineBreak;
  Result := Result + '            icon.textContent = ''▶''; ' + sLineBreak;
  Result := Result + '          }); ' + sLineBreak;
  Result := Result + '        } ' + sLineBreak;
  Result := Result + '    </script> ' + sLineBreak;
  Result := Result + '</body> ' + sLineBreak;
  Result := Result + '</html> ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocRotaEndPoint(qry: TZQuery; AHost, APrefixo, AMethod: String; AIdEndPoint: Integer): String;
// retorna o endpoint da rota do documento da api
var
  sEndPoint, sToggle, sMetodo, sCssVerbo: String;
  sDescricao, sDescricao_longa, sAlteracoes: String;
  sHeader, sBody: String;
  ARota, sExemploHost, sExemploEndpoint: string;
begin
  // ajustes na rota
  qry.First;

  ARota := Trim(qry.FieldByName('api_rota').AsString);
  if LeftStr(ARota, 1) = '/' then ARota := ARota.Substring(1);
  if RightStr(ARota, 1) = '/' then ARota := ARota.Substring(0, ARota.Length-1);

  // Prefixo da api ( ex: /api/v2/ ) se foi informado (não obrigatório)
  APrefixo := Trim(APrefixo);

  while RightStr(APrefixo, 1) = '/' do
    APrefixo := LeftStr(APrefixo, Length(APrefixo)-1);

  if (APrefixo <> '') and (LeftStr(APrefixo, 1) <> '/') then APrefixo := '/' + APrefixo;

  // caminho completo do endpoint
  sEndPoint := StringReplace('/' + Trim(ARota), '//', '/', [rfReplaceAll]);
  while RightStr(sEndPoint, 1) = '/' do
    sEndPoint := LeftStr(sEndPoint, Length(sEndPoint)-1);

  // ID do objeto para a função toggleVisibility()
  sToggle := Trim(ARota) + IntToStr(AIdEndPoint);

  //Verbo: POST, GET, PUT, DELETE
  if AMethod = 'get_list' then // get paginação
    sMetodo := 'GET'
  else
    sMetodo := AMethod.ToUpper;

  // para identificar a classe CSS
  sCssVerbo := LowerCase(sMetodo);

  // Exemplo de endpoint
  sExemploHost := AHost + APrefixo;

  if AMethod = 'get' then sEndPoint := sEndPoint + '/{id}';
  if AMethod = 'get_list' then sEndPoint := sEndPoint + '?page=1&limit=10';
  if AMethod = 'put' then sEndPoint := sEndPoint + '/{id}';
  if AMethod = 'patch' then sEndPoint := sEndPoint + '/{id}';
  if AMethod = 'delete' then sEndPoint := sEndPoint + '/{id}';

  while RightStr(sExemploHost, 1) = '/' do
    sExemploHost := LeftStr(sExemploHost, Length(sExemploHost)-1);

  sExemploEndpoint := '<b>' + StringReplace(sEndPoint, '{id}', '1', [rfReplaceAll]) + '</b>';

  // Descrição breve e longa do endpoint
  sDescricao := 'Detalhes desta rota'; // + Trim(qry.FieldByName('descricao').AsString);
  sDescricao_longa := Trim(qry.FieldByName('descricao').AsString);
  if sDescricao_longa = '' then sDescricao_longa := sDescricao;

  // Alterações do endpoint
  sAlteracoes := '';
  //if Trim(qry.FieldByName('motivo_alteracao').AsString) <> '' then
  //  sAlteracoes := '<p><b>Última alteração</b> - ' + FormatDateTime('dd/mm/yyyy hh:nn:ss', qry.FieldByName('dt_modificado').AsDateTime) + '<br><font style="font-size:12px">' + qry.FieldByName('motivo_alteracao').AsString + '</font></p>';

  // Request - Header
  sHeader := '<b>Authorization</b> ' + 'Bearer token_jwt';

  // Post Request - Body
  sBody := 'None';
  if sMetodo = 'POST' then
    sBody := BodyFields(qry, True, 0, True, False)
  else if sMetodo = 'PUT' then
    sBody := BodyFields(qry, True, 5, True, False)
  else if sMetodo = 'PATCH' then
    sBody := BodyFields(qry, True, 2, True, False);

  Result := '' + sLineBreak;
  Result := Result + '<!-- ' + UpperCase(sMetodo) + ' ' + ARota + ' --> ' + sLineBreak;
  Result := Result + '            <div class="card"> ' + sLineBreak;
  Result := Result + '                <div class="card-header verb-'+ sCssVerbo + '" id="ch_' + sToggle + '" onclick="toggleVisibility(''' + sToggle + ''')"> ' + sLineBreak;
  Result := Result + '                    <div class="container-one container-one-' + sCssVerbo + '">' + UpperCase(sMetodo) + '</div> ' + sLineBreak;
  Result := Result + '                    <div class="container-two"><code class="uri">' + APrefixo + sEndPoint + '</code>&nbsp;&nbsp;&nbsp;<i class="name" style="font-size:12px;">' + sDescricao + '</i></div> ' + sLineBreak;
  Result := Result + '                </div> ' + sLineBreak;
  Result := Result + '                <div class="card-body card-body-' + sCssVerbo + '" id="'+ sToggle + '"> ' + sLineBreak;

  // exemplo de chamada do endpoint
  if sExemploEndpoint <> '' then begin
    Result := Result + '                  <div class="definition"> ' + sLineBreak;
    //Result := Result + '                     <b style="padding-bottom:8px;">Exemplo:</b>&nbsp;<br> ' + sLineBreak;
    Result := Result + '			   <span class="method ' +sCssVerbo + '">' + UpperCase(sMetodo) + '</span>&nbsp;  ' + sLineBreak;
    Result := Result + ' 			     <span class="uri"> ' + sLineBreak;
    Result := Result + '  		             <span class="hostname">' + sExemploHost + '</span>' + sExemploEndpoint + sLineBreak;
    Result := Result + ' 			   </span> ' + sLineBreak;
    Result := Result + '			</div> ' + sLineBreak;
  end;

  //Result := Result + '                  <p><strong style="padding-bottom:8px;">Descrição: </strong><br>' + sDescricao_longa + '</p> ' + sLineBreak;
  if Trim(sDescricao_longa) <> '' then
    Result := Result + '                  ' + sDescricao_longa + '<br>' + sLineBreak;

  Result := Result + sAlteracoes + sLineBreak;

  //----------------------------------------------
  // Requests
  //----------------------------------------------
  Result := Result + '<br><div class="line" style="border-bottom: 1px solid #ddd; height:18px; margin: 10px 0px 5px 0px;"><p><b style="color: red; border: 1px solid #ddd; background-color:#efefef; border-radius: 5px;padding: 4px 4px 2px 4px;">Requests </b></p></div>' + sLineBreak;

  // tabela de requests
  Result := Result + '<table style="border: 1px solid #c0c0c0; width:100%" cellpadding=0 cellspacing=0>' + sLineBreak;
  Result := Result + '<tr><td style="text-align: center; background-color:#c0c0c0; width: 150px;">Nome</td><td style="background-color:#c0c0c0;">Descrição</td><td style="width:10px; background-color:#c0c0c0;">&nbsp;&nbsp;</td></tr>' + sLineBreak;

  // campos de parâmetros
  FParamtersCount := 0;
  Result := Result + GetDetalhes(False, 'Header', sHeader);
  Result := Result + GetParametros(False, AMethod);
  Result := Result + GetDetalhes(False, 'Body', sBody);

  // fechamento da tabela
  if FParamtersCount = 0 then
    Result := Result + '<tr><td style="text-align: center;">None</td><td><pre>None</pre></td><td style="width:10px;">&nbsp;&nbsp;</td></tr>' + sLineBreak;

  Result := Result + '</table>' + sLineBreak;

  //----------------------------------------------
  // Responses
  //----------------------------------------------
  Result := Result + '<br><div class="line" style="border-bottom: 1px solid #ddd; height:18px; margin: 5px 0px 5px 0px;"><p><b style="color: red; border: 1px solid #ddd; background-color:#efefef; border-radius: 5px;padding: 4px 4px 2px 4px;">Responses </b></p></div>' + sLineBreak;

  // tabela de respostas
  Result := Result + '<table style="border: 1px solid #c0c0c0; width:100%" cellpadding=0 cellspacing=0>' + sLineBreak;
  Result := Result + '<tr><td style="text-align: center; background-color:#c0c0c0; width: 150px;">Código</td><td style="background-color:#c0c0c0;">Descrição</td><td style="width:10px; background-color:#c0c0c0;">&nbsp;&nbsp;</td></tr>' + sLineBreak;

  if AMethod = 'get' then begin
    Result := Result + GetResposta('200-OK', 'application/json', BodyFields(qry, True, 0, False, True));
    Result := Result + GetResposta('400-Bad Request', 'application/json', ResponseBody(AMethod, False, True));
    Result := Result + GetResposta('401-Unauthorized', 'application/json', 'None');
  end
  else if AMethod = 'get_list' then begin
    Result := Result + GetResposta('200-OK', 'application/json', ResponseBodyList(qry, 2, True));
    Result := Result + GetResposta('400-Bad Request', 'application/json', 'None');
    Result := Result + GetResposta('401-Unauthorized', 'application/json', 'None');
  end
  else if AMethod = 'post' then begin
    Result := Result + GetResposta('200-OK', 'application/json',  ResponseBody(AMethod, True, True));
    Result := Result + GetResposta('400-Bad Request', 'application/json', 'None');
    Result := Result + GetResposta('401-Unauthorized', 'application/json', 'None');
  end
  else if AMethod = 'put' then begin
    Result := Result + GetResposta('200-OK', 'application/json', ResponseBody(AMethod, True, True));
    Result := Result + GetResposta('200-OK', 'application/json', ResponseBody(AMethod, False, True));
    Result := Result + GetResposta('400-Bad Request', 'application/json', 'None');
    Result := Result + GetResposta('401-Unauthorized', 'application/json', 'None');
  end
  else if AMethod = 'patch' then begin
    Result := Result + GetResposta('200-OK', 'application/json', ResponseBody(AMethod, True, True));
    Result := Result + GetResposta('200-OK', 'application/json', ResponseBody(AMethod, False, True));
    Result := Result + GetResposta('400-Bad Request', 'application/json', 'None');
    Result := Result + GetResposta('401-Unauthorized', 'application/json', 'None');
  end
  else if AMethod = 'delete' then begin
    Result := Result + GetResposta('200-OK', 'application/json', ResponseBody(AMethod, True, True));
    Result := Result + GetResposta('200-OK', 'application/json', ResponseBody(AMethod, False, True));
    Result := Result + GetResposta('400-Bad Request', 'application/json', 'None');
    Result := Result + GetResposta('401-Unauthorized', 'application/json', 'None');
  end;

  Result := Result + '</table>' + sLineBreak;
  Result := Result + '                </div> ' + sLineBreak;
  Result := Result + '            </div> ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocRotaHeader(qry: TZQuery): String;
// retorna o header da rota
var
  sRota, sDescricao, sToggle: String;
begin
  qry.First;
  sRota := qry.FieldByName('api_rota').AsString;
  if LeftStr(sRota, 1) = '/' then sRota := sRota.Substring(1);
  if RightStr(sRota, 1) = '/' then sRota := sRota.Substring(0, sRota.Length-1);

  sDescricao := 'Agrupamento de ' + sRota; //qry.FieldByName('descricao').AsString;
  sToggle := sRota + IntToStr(qry.FieldByName('idtabela').AsInteger);

  if Length(sDescricao) > 0 then
     sDescricao := '&nbsp;&nbsp;&nbsp;<i class="name" style="font-size:12px;">' + sDescricao + '</i>';

  Result := '' + sLineBreak;
  Result := Result + '            <!-- início da rota: ' + sRota + ' --> ' + sLineBreak;
  Result := Result + '            <div class="card-container"> ' + sLineBreak;
  Result := Result + '             <div class="card-container-title" onclick="toggleVisibility(''ep'+ sToggle +''')"><span id="icon_ep' + sToggle + '" class="toggle-symbol">▼</span>&nbsp;&nbsp;<strong>' + TUtilCommon.CapitalizaTexto(sRota) + '</strong>' + sDescricao + '</div> ' + sLineBreak;
  Result := Result + '             <div class="card-container-body" id="ep' + sToggle +'"> ' + sLineBreak;
  Result := Result + '             ' + sLineBreak;
  Result := Result + ' ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocRotaFooter(qry: TZQuery): String;
// retorna o footer da rota
var
  sRota: String;
begin
  qry.First;
  sRota  := qry.FieldByName('api_rota').AsString;
  Result := '' + sLineBreak;
  Result := Result + '           </div> <!-- card-container-body --> ' + sLineBreak;
  Result := Result + '           </div> <!-- card-container --> ' + sLineBreak;
  Result := Result + '           <!-- fim da rota: ' + sRota + ' --> ' + sLineBreak;
  Result := Result + '            ' + sLineBreak;
end;

function TUtilGeraDoc.GetDocRotaFields(qry: TZQuery): String;
// campos da tabela para uso com o método POST
var
  lCampo, lCampoAlias, lcampoDBTipo, lcampoTipo: string;
  bRequerido, bCampoAceito, bLimparMascara, bChaveEstrangeira, bChavePrimaria: Boolean;
  lCampoEspecial, lFK_Tabela, lFK_Codigo, lFK_Texto: string;
  sToggle, sRequired, lDescricao, sMaxLen: string;
  lMaxLen, lPrecisao, lScale: Integer;
begin
  Result := '';

  qry.First;
  sToggle := qry.FieldByName('api_rota').AsString + IntToStr(qry.FieldByName('idtabela').AsInteger);

  Result := Result + '<!-- descrição dos campos - início -->' + sLineBreak;
  Result := Result + '<div class="card" style="border: 1px solid #6e69ff; background-color: #e0e0ff; margin-bottom: 5px; padding-top: 5px;">' + sLineBreak;
  Result := Result + '<div class="card-header" id="ch_fields-' + sToggle + '" onclick="toggleVisibility(''fields-' + sToggle + ''')" style="font-size:12px; height:20px;">' + sLineBreak;
  Result := Result + '&nbsp;<strong>Fields</strong><i class="name">Descrição dos campos</i>' + sLineBreak;
  Result := Result + '</div>' + sLineBreak;
  Result := Result + ' <div class="card-body" id="fields-' + sToggle + '">' + sLineBreak;
  Result := Result + '  <div class="table-container">' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:200px;">Field Name</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:100px;">Field Type</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:80px;">Max Length</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:80px;">Required</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell">Description</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;

  while not qry.EOF do begin
    lCampo := qry.FieldByName('campo').AsString;
    lCampoAlias := qry.FieldByName('campo_alias').AsString;
    if Trim(lCampoAlias) = '' then lCampoAlias := lcampo;
    lcampoTipo := qry.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    //bCurrencyField := qry.FieldByName('currency_field').AsInteger = 1;
    bChavePrimaria := (qry.FieldByName('chave_primaria').AsInteger = 1);
    lFK_Tabela := Trim(qry.FieldByName('fk_tabela').AsString);
    lFK_Codigo := Trim(qry.FieldByName('fk_codigo').AsString);
    lFK_Texto := Trim(qry.FieldByName('fk_texto').AsString);
    //lcomboLista := Trim(qry.FieldByName('combo_lista').AsString);
    bChaveEstrangeira := ((qry.FieldByName('chave_estrangeira').AsInteger = 1) and (Length(lFK_Tabela) > 0));
    lMaxLen := StrToIntDef('0' + qry.FieldByName('tamanho').AsString, 50); //MaxLength do campo
    lPrecisao := StrToIntDef('0' + qry.FieldByName('precisao').AsString, 0); //tamanho o número
    lScale := StrToIntDef('0' + qry.FieldByName('escala').AsString, 2);   //casas decimais
    bRequerido := (qry.FieldByName('requerido').AsInteger = 1); //campo obrigatório
    //bToList := (qry.FieldByName('incluir_na_grid').AsInteger = 1); //exibir na paginação
    //bAceitaNull := (qry.FieldByName('aceita_null').AsInteger = 1); //campo aceita nulo ?
    lCampoEspecial := Trim(qry.FieldByName('campo_especial').AsString); //cpf, cnpj, Cep, celular, etc
    bLimparMascara := (qry.FieldByName('remove_mask').AsInteger = 1); // remover máscara do valor

    ldescricao := Trim(qry.FieldByName('cmp_descricao').AsString);
    if ldescricao = '' then ldescricao := 'Undefined';

    if (ldescricao <> 'Undefined') and (lCampoEspecial <> '') and (lFK_Tabela <> '') then
      ldescricao := ldescricao + ' (' + lCampoEspecial + ')';

    if bRequerido then sRequired := 'yes' else sRequired := 'no';

    lCampoEspecial := LowerCase(lCampoEspecial.ToLower);

    if bChaveEstrangeira then
      lCampoEspecial := lFK_Tabela + ',' + lFK_Codigo + ',' + lFK_Texto;

    sMaxLen := lMaxLen.ToString;
    bCampoAceito := True;

    case lcampoTipo.ToLower of
      'boolean':
        begin
          lcampoTipo := 'boolean';
        end;
      'string':
        begin
          lcampoTipo := 'string';
        end;
      'integer':
        begin
          lcampoTipo := 'integer';
        end;
      'currency':
        begin
          lcampoTipo := 'float';
          if (lPrecisao > 0) then
            sMaxLen := '(' + lPrecisao.ToString + ',' + lScale.ToString + ')';
        end;
      'double':
        begin
          lcampoTipo := 'float';
          if (lPrecisao > 0) then
            sMaxLen := '(' + lPrecisao.ToString + ',' + lScale.ToString + ')';
        end;
      'timage':
        begin
          bCampoAceito := False;
          lcampoTipo := 'image';
        end;
      'tdatetime':
        begin
          lcampoTipo := 'datetime';
        end;
      else
      begin
        lcampoTipo := 'string';
      end;
    end;

    if bCampoAceito then begin
      Result := Result + '    <div class="table-row">' + sLineBreak;
      Result := Result + '        <div class="table-cell" style="max-width:200px;">' + lCampoAlias + '</div>' + sLineBreak;
      Result := Result + '        <div class="table-cell" style="max-width:100px;">' + lcampoTipo + '</div>' + sLineBreak;
      Result := Result + '        <div class="table-cell" style="max-width:80px;">' + sMaxLen + '</div>' + sLineBreak;
      Result := Result + '        <div class="table-cell" style="max-width:80px;">' + sRequired + '</div>' + sLineBreak;
      Result := Result + '        <div class="table-cell">' + ldescricao + '</div>' + sLineBreak;
      Result := Result + '    </div>' + sLineBreak;
    end;

    qry.Next;
  end; //while

  Result := Result + '  </div>' + sLineBreak;
  Result := Result + ' </div>' + sLineBreak;
  Result := Result + '</div>' + sLineBreak;
  Result := Result + '<!-- descrição dos campos - fim -->' + sLineBreak;
end;

function TUtilGeraDoc.GetResposta(ACode, AContentType, AResponse: string): String;
// retorna uma tr com a response
var
  f: array of string;
  codigo, codigotxt: String;
begin
  f := ACode.Split(['-'], TStringSplitOptions.ExcludeEmpty); // 200-ok, 401-unauthorized
  if High(f) <> 1 then Exit('');

  codigo    := f[0]; // 200, 401
  codigotxt := f[1]; // ok , unauthorized

  Result := '<tr>' +
            '<td style="text-align: center; border-bottom: 1px solid #ddd;">' + codigo + '</td>' +
            '<td style="border-bottom: 1px solid #ddd;">' +
            ' <div class="linha" style="height:12px; margin: 6px 5px 0px 3px;">' +
            '  <p style="font-color:#ccc; font-size:11px;">' + codigotxt + '</p>' +
            '  <p style="font-color:#ccc; font-size:11px;">' + AContentType + '&nbsp;&nbsp;</p>' +
            ' </div>' +
            ' <pre>' + AResponse  +'</pre>' +
            '</td>' +
            '<td style="width:10px;">&nbsp;&nbsp;</td>' +
            '</tr>' + sLineBreak;
end;

function TUtilGeraDoc.GetDetalhes(AOcultar: Boolean; ATitulo, AValor: String): String;
// retorna dados do header e  body
begin
  Result := '<tr>' +
            '<td style="text-align: center; border-bottom: 1px solid #ddd;"><p>' + ATitulo + '</p></td> ' +
            '<td style="border-bottom: 1px solid #ddd;">' +
            //' <div class="linha" style="height:12px; margin: 6px 5px 0px 3px;">' +
            //'  <p style="font-color:#ccc; font-size:11px;">' + '' + '</p>' +
            //'  <p style="font-color:#ccc; font-size:11px;">' + '' + '&nbsp;&nbsp;</p>' +
            //' </div>' +
            ' <pre>' + AValor + '</pre>' +
            '</td>' +
            '<td style="width:10px;">&nbsp;&nbsp;</td>' +
            '</tr>' + sLineBreak;

  if AOcultar and (AValor = 'None') then
    Result := ''
  else
    FParamtersCount := FParamtersCount + 1;
end;

function TUtilGeraDoc.GetParametros(AOcultar: Boolean; AMetodo: string): String;
// retorna os parâmetros do entpoint
var
  s: String;
begin
  s := 'None';

  if AMetodo.ToLower = 'get' then begin
    s := '<table border="0" style="width:100%;">' +
         '<tr style="background-color: #f1f3f5;">' +
         '<td style="width: 200px;"><div class="param1">id</div></td>' +
         '<td style="width: 80px;"><div class="param2">integer</div></td>' +
         '<td style="width: 100%;"><div class="param3">Código do registro a ser consultado</div></td>' +
         '</tr>' +
         '</table>';
  end
  else if AMetodo.ToLower = 'get_list' then begin
    s := '<table border="0" style="width:100%;">' +
         '<tr style="background-color: #f1f3f5;">' +
         ' <td style="width: 200px;"><div class="param1">page</div></td>' +
         ' <td style="width: 80px;"><div class="param2">integer</div></td>' +
         ' <td style="width: 100%;"><div class="param3">Número da página a ser obtida</div></td>' +
         '</tr>' +
         '<tr style="background-color: #f1f3f5;">' +
         ' <td style="width: 200px;"><div class="param1">limit</div></td>' +
         ' <td style="width: 80px;"><div class="param2">integer</div></td>' +
         ' <td style="width: 100%;"><div class="param3">Quantidade de registros por página a serem exibidos</div></td>' +
         '</tr>' +
         '<tr style="background-color: #f1f3f5;">' +
         ' <td style="width: 200px;"><div class="param1">search_field</div></td>' +
         ' <td style="width: 80px;"><div class="param2">string</div></td>' +
         ' <td style="width: 100%;"><div class="param3">(opcional) Nome do campo de pesquisa</div></td>' +
         '</tr>' +
         '<tr style="background-color: #f1f3f5;">' +
         ' <td style="width: 200px;"><div class="param1">search_operator</div></td>' +
         ' <td style="width: 80px;"><div class="param2">string</div></td>' +
         ' <td style="width: 100%;"><div class="param3">(opcional) Operadores: * Lista no final deste documento</div></td>' +
         '</tr>' +
         '<tr style="background-color: #f1f3f5;">' +
         ' <td style="width: 200px;"><div class="param1">search</div></td>' +
         ' <td style="width: 80px;"><div class="param2">string</div></td>' +
         ' <td style="width: 100%;"><div class="param3">(opcional) Conteúdo a ser pesquisado</div></td>' +
         '</tr>' +
         '<tr style="background-color: #f1f3f5;">' +
         ' <td style="width: 200px;"><div class="param1">order_field</div></td>' +
         ' <td style="width: 80px;"><div class="param2">string</div></td>' +
         ' <td style="width: 100%;"><div class="param3">(opcional) Lista de campos para a ordenação</div></td>' +
         '</tr>' +
         '<tr style="background-color: #f1f3f5;">' +
         ' <td style="width: 200px;"><div class="param1">direction</div></td>' +
         ' <td style="width: 80px;"><div class="param2">string</div></td>' +
         ' <td style="width: 100%;"><div class="param3">(opcional) Sentido da ordenação (asc, desc)</div></td>' +
         '</tr>' +
         '</table>';
  end
  else  if AMetodo.ToLower = 'post' then begin
    s := 'None';
  end
  else  if AMetodo.ToLower = 'put' then begin
    s := '<table border="0" style="width:100%;">' +
         '<tr style="background-color: #f1f3f5;">' +
         '<td style="width: 200px;"><div class="param1">id</div></td>' +
         '<td style="width: 80px;"><div class="param2">integer</div></td>' +
         '<td style="width: 100%;"><div class="param3">Código do registro a ser alterado</div></td>' +
         '</tr>' +
         '</table>';
  end
  else if AMetodo.ToLower = 'patch' then begin
    s := '<table border="0" style="width:100%;">' +
         '<tr style="background-color: #f1f3f5;">' +
         '<td style="width: 200px;"><div class="param1">id</div></td>' +
         '<td style="width: 80px;"><div class="param2">integer</div></td>' +
         '<td style="width: 100%;"><div class="param3">Código do registro a ser alterado</div></td>' +
         '</tr>' +
         '</table>';
  end
  else if AMetodo.ToLower = 'delete' then begin
    s := '<table border="0" style="width:100%;">' +
         '<tr style="background-color: #f1f3f5;">' +
         '<td style="width: 200px;"><div class="param1">id</div></td>' +
         '<td style="width: 80px;"><div class="param2">integer</div></td>' +
         '<td style="width: 100%;"><div class="param3">Código do registro a ser deletado</div></td>' +
         '</tr>' +
         '</table>';
  end;

  Result := '<tr>' +
            '<td style="text-align: center; border-bottom: 1px solid #ddd;"><p>Parâmetros</p></td> ' +
            '<td style="border-bottom: 1px solid #ddd;">' +
            ' <pre>' + s + '</pre></td>' +
            '<td style="width:10px;">&nbsp;&nbsp;</td>' +
            '</tr>' + sLineBreak;


  if AOcultar then
    Result := ''
  else
    FParamtersCount := FParamtersCount + 1;
 end;

function TUtilGeraDoc.BodyFields(qry: TZQuery; ABreakLine: Boolean;
  AQdeCampos: Integer; AExcluirPrimayKey, AExibirValorExtrangeiro: Boolean): string;
// modelo do Body para o request e response
var
  j: TJSONObject;
  lCount: Integer;
  lCampo, lCampoAlias, lcampoTipo: string;
  bCampoAceito, bChavePrimaria, bChaveEstrangeira: Boolean;
begin
  Result := 'None';
  lCount := 0;
  j := TJSONObject.Create;

  qry.First;
  while not qry.EOF do begin
    lCampo := qry.FieldByName('campo').AsString;
    lCampoAlias := qry.FieldByName('campo_alias').AsString;
    if Trim(lCampoAlias) = '' then lCampoAlias := lcampo;
    lcampoTipo := qry.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    bChavePrimaria := (qry.FieldByName('chave_primaria').AsInteger = 1);
    bChaveEstrangeira := qry.FieldByName('chave_estrangeira').AsInteger = 1;

    bCampoAceito := True;
    if AExcluirPrimayKey and bChavePrimaria then bCampoAceito := False;

    case lcampoTipo.ToLower of
      'boolean': lcampoTipo := 'boolean';
      'string':  lcampoTipo := 'string';
      'integer': lcampoTipo := 'integer';
      'currency':lcampoTipo := 'float';
      'double':  lcampoTipo := 'float';
      'tdatetime': lcampoTipo := 'datetime';
      'timage':
        begin
          bCampoAceito := False;
          lcampoTipo := 'image';
        end;
      else begin
        lcampoTipo := 'string';
      end;
    end;

    if bCampoAceito then begin
      lCount := lCount + 1;
      if (AQdeCampos > 0) and (lCount > AQdeCampos) then Break;

      case lcampoTipo.ToLower of
        'boolean':  j.Add(lCampoAlias, True);
        'datetime': j.Add(lCampoAlias, Format('%s', [DateToISO8601(now + lCount)]));
        'float':    j.Add(lCampoAlias, 71.50 * lCount);
        'integer':  j.Add(lCampoAlias, lCount);
        'string':   j.Add(lCampoAlias, 'abc ' + IntToStr(lCount));
      end;

      if bChaveEstrangeira and AExibirValorExtrangeiro then
        j.Add(lCampoAlias + '_value', 'abcde ' + IntToStr(lCount));
    end;

    qry.Next;
  end; //while

  if j.Count > 0 then begin
    if ABreakLine then
      Result := j.FormatJSON()
    else
      Result := j.AsJSON;
  end else
    Result := 'None';

  j.Free;
end;

function TUtilGeraDoc.ResponseBody(AMethod: string; ASucesso, ABreakLine: Boolean): string;
// modelo do response
var
  j: TJSONObject;
  lMessage: string;
begin
  if AMethod = 'get' then begin //ID not provided
    if ASucesso then lMessage := 'None' else lMessage := 'ID not provided';
  end
  else if AMethod = 'get_list' then begin
    Exit('None');
  end
  else if AMethod = 'post' then begin
    if ASucesso then lMessage := 'Record created successfully. ID = 1' else lMessage := 'Descrição do erro.';
  end
  else if AMethod = 'put' then begin
    if ASucesso then lMessage := 'Record updated successfully.' else lMessage := 'Descrição do erro';
  end
  else if AMethod = 'patch' then begin
    if ASucesso then lMessage := 'Record updated successfully.' else lMessage := 'Descrição do erro';
  end
  else if AMethod = 'delete' then begin
    if ASucesso then lMessage := 'Record deleted successfully. ID = 1' else lMessage := 'Descrição do erro';
  end;

  j := TJSONObject.Create;
  j.Add('success', ASucesso);
  j.Add('message', lMessage);

  if ABreakLine then
      Result := j.FormatJSON()
    else
      Result := j.AsJSON;

  j.Free;
end;

function TUtilGeraDoc.ResponseBodyList(qry: TZQuery; AQdeItens: Integer; ABreakLine: Boolean): string;
// modelo do Body para o response get paginação
var
  j, jobj: TJSONObject;
  jarr: TJSONArray;
  i: Integer;
  lCampo, lCampoAlias, lcampoTipo: string;
  bCampoAceito, bIncluirNaLista, bChaveEstrangeira: Boolean;
begin
  Result := 'None';
  if AQdeItens < 1 then AQdeItens := 1;
  if AQdeItens > 5 then AQdeItens := 5;

  j := TJSONObject.Create;
  jarr := TJSONArray.Create;

  for i := 1 to AQdeItens do begin
    jobj := TJSONObject.Create;
    qry.First;
    while not qry.EOF do begin
      lCampo := qry.FieldByName('campo').AsString;
      lCampoAlias := qry.FieldByName('campo_alias').AsString;
      if Trim(lCampoAlias) = '' then lCampoAlias := lcampo;
      lcampoTipo := qry.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
      bIncluirNaLista := qry.FieldByName('incluir_na_grid').AsInteger = 1;
      bChaveEstrangeira := qry.FieldByName('chave_estrangeira').AsInteger = 1;

      bCampoAceito := True;

      case lcampoTipo.ToLower of
        'boolean': lcampoTipo := 'boolean';
        'string':  lcampoTipo := 'string';
        'integer': lcampoTipo := 'integer';
        'currency':lcampoTipo := 'float';
        'double':  lcampoTipo := 'float';
        'tdatetime': lcampoTipo := 'datetime';
        'timage':
          begin
            bCampoAceito := False;
            lcampoTipo := 'image';
          end;
        else begin
          lcampoTipo := 'string';
        end;
      end;

      if bCampoAceito and bIncluirNaLista then begin
        case lcampoTipo.ToLower of
          'boolean':  jobj.Add(lCampoAlias, True);
          'datetime': jobj.Add(lCampoAlias, Format('%s', [DateToISO8601(now + i)]));
          'float':    jobj.Add(lCampoAlias, 71.50 * i);
          'integer':  jobj.Add(lCampoAlias, i);
          'string':   jobj.Add(lCampoAlias, 'abc ' + IntToStr(i));
        end;

        if bChaveEstrangeira then
          jobj.Add(lCampoAlias + '_value', 'abcde ' + IntToStr(i));
      end;

      qry.Next;
    end; //while

    jarr.Add(jobj);
  end;

  j.Add('page', 1);
  j.Add('per_page', AQdeItens);
  j.Add('total_pages', 10);
  j.Add('total_records', Trunc(Power(10, AQdeItens)));
  j.Add('data', jArr);

  Result := j.AsJSON;

  if j.Count > 0 then begin
    if ABreakLine then
      Result := j.FormatJSON()
    else
      Result := j.AsJSON;
  end else
    Result := 'None';

  j.Free;
end;

function TUtilGeraDoc.RotaAuth(AHost: string): string;
// rota padrão de autenticação
begin
  Result :=
  '<!-- início da rota: Auth -->' + sLineBreak +
  '<div class="card-container">' + sLineBreak +
  '<div class="card-container-title" onclick="toggleVisibility(''epAuth1'')"><span id="icon_epAuth1" class="toggle-symbol">▼</span>&nbsp;&nbsp;<strong>Autenticação</strong>&nbsp;&nbsp;&nbsp;<i class="name" style="font-size:12px;">Agrupamento de Autenticação</i></div>' + sLineBreak +
  '<div class="card-container-body" id="epAuth1">' + sLineBreak +
  '' + sLineBreak +
  '<!-- descrição dos campos - início -->' + sLineBreak +
  '<div class="card" style="border: 1px solid #6e69ff; background-color: #e0e0ff; margin-bottom: 5px; padding-top: 5px;">' + sLineBreak +
  '<div class="card-header" id="ch_fields-Auth1" onclick="toggleVisibility(''fields-Auth1'')" style="font-size:12px; height:20px;">' + sLineBreak +
  '&nbsp;<strong>Fields</strong><i class="name">Descrição dos campos</i>' +
  ' </div>' +
  '<div class="card-body" id="fields-Auth1">' + sLineBreak +
  '<div class="table-container">' + sLineBreak +
  '<div class="table-row">' + sLineBreak +
  '<div class="table-cell" style="max-width:200px;">Field Name</div>' + sLineBreak +
  '<div class="table-cell" style="max-width:100px;">Field Type</div>' + sLineBreak +
  '<div class="table-cell" style="max-width:80px;">Max Length</div>' + sLineBreak +
  '<div class="table-cell" style="max-width:80px;">Required</div>' + sLineBreak +
  '<div class="table-cell">Description</div>' + sLineBreak +
  '</div>' + sLineBreak +
  '<div class="table-row">' + sLineBreak +
  '<div class="table-cell" style="max-width:200px;">username</div>' + sLineBreak +
  '<div class="table-cell" style="max-width:100px;">string</div>' + sLineBreak +
  '<div class="table-cell" style="max-width:80px;">50</div>' + sLineBreak +
  '<div class="table-cell" style="max-width:80px;">yes</div>' + sLineBreak +
  '<div class="table-cell">Login do usuário</div>' + sLineBreak +
  '</div>' + sLineBreak +
  '<div class="table-row">' + sLineBreak +
  '<div class="table-cell" style="max-width:200px;">password</div>' + sLineBreak +
  '<div class="table-cell" style="max-width:100px;">string</div>' + sLineBreak +
  '<div class="table-cell" style="max-width:80px;">50</div>' + sLineBreak +
  '<div class="table-cell" style="max-width:80px;">yes</div>' + sLineBreak +
  '<div class="table-cell">Senha do usuário</div>' + sLineBreak +
  '</div>' + sLineBreak +
  '</div>' + sLineBreak +
  '</div>' + sLineBreak +
  '</div>' + sLineBreak +
  '<!-- descrição dos campos - fim -->' + sLineBreak +
  '' + sLineBreak +
  '' + sLineBreak +
  '<!-- POST login -->' + sLineBreak +
  '<div class="card">' + sLineBreak +
  '<div class="card-header verb-post" id="ch_login1" onclick="toggleVisibility(''login1'')">' + sLineBreak +
  '<div class="container-one container-one-post">POST</div>' + sLineBreak +
  '<div class="container-two"><code class="uri">/login</code>&nbsp;&nbsp;&nbsp;<i class="name" style="font-size:12px;">Detalhes desta rota</i></div>' + sLineBreak +
  '</div>' + sLineBreak +
  '<div class="card-body card-body-post" id="login1">' + sLineBreak +
  '<div class="definition">' + sLineBreak +
  '<span class="method post">POST</span>&nbsp;' + sLineBreak +
  '<span class="uri">' + sLineBreak +
  '<span class="hostname">' + AHost + '</span><b>/login</b>' + sLineBreak +
  '</span>' + sLineBreak +
  '</div>' + sLineBreak +
  'Efetua login e recebe o token JWT<br>' + sLineBreak +
  '' + sLineBreak +
  '<br><div class="line" style="border-bottom: 1px solid #ddd; height:18px; margin: 10px 0px 5px 0px;"><p><b style="color: red; border: 1px solid #ddd; background-color:#efefef; border-radius: 5px;padding: 4px 4px 2px 4px;">Requests </b></p></div>' + sLineBreak +
  '<table style="border: 1px solid #c0c0c0; width:100%" cellpadding=0 cellspacing=0>' + sLineBreak +
  '<tr><td style="text-align: center; background-color:#c0c0c0; width: 150px;">Nome</td><td style="background-color:#c0c0c0;">Descrição</td><td style="width:10px; background-color:#c0c0c0;">&nbsp;&nbsp;</td></tr>' + sLineBreak +
  '<tr><td style="text-align: center; border-bottom: 1px solid #ddd;"><p>Header</p></td> <td style="border-bottom: 1px solid #ddd;"> <pre>None</pre></td><td style="width:10px;">&nbsp;&nbsp;</td></tr>' + sLineBreak +
  '<tr><td style="text-align: center; border-bottom: 1px solid #ddd;"><p>Parâmetros</p></td> <td style="border-bottom: 1px solid #ddd;"> <pre>None</pre></td><td style="width:10px;">&nbsp;&nbsp;</td></tr>' + sLineBreak +
  '<tr><td style="text-align: center; border-bottom: 1px solid #ddd;"><p>Body</p></td> <td style="border-bottom: 1px solid #ddd;"> <pre>{' + sLineBreak +
  '"username" : "abc",' + sLineBreak +
  '"password" : "abc"' + sLineBreak +
  '}</pre></td><td style="width:10px;">&nbsp;&nbsp;</td></tr>' + sLineBreak +
  '</table>' + sLineBreak +
  '<br><div class="line" style="border-bottom: 1px solid #ddd; height:18px; margin: 5px 0px 5px 0px;"><p><b style="color: red; border: 1px solid #ddd; background-color:#efefef; border-radius: 5px;padding: 4px 4px 2px 4px;">Responses </b></p></div>' + sLineBreak +
  '<table style="border: 1px solid #c0c0c0; width:100%" cellpadding=0 cellspacing=0>' + sLineBreak +
  '<tr><td style="text-align: center; background-color:#c0c0c0; width: 150px;">Código</td><td style="background-color:#c0c0c0;">Descrição</td><td style="width:10px; background-color:#c0c0c0;">&nbsp;&nbsp;</td></tr>' + sLineBreak +
  '<tr><td style="text-align: center; border-bottom: 1px solid #ddd;">200</td><td style="border-bottom: 1px solid #ddd;"> <div class="linha" style="height:12px; margin: 6px 5px 0px 3px;">  <p style="font-color:#ccc; font-size:11px;">OK</p>  <p style="font-color:#ccc; font-size:11px;"> application/json&nbsp;&nbsp;</p> </div> <pre>{' + sLineBreak +
  '"id" : 1,' + sLineBreak +
  '"name" : "Administrador",' + sLineBreak +
  '"exp" : 1778532167,' + sLineBreak +
  '"token" : "eyJhbGciOiJIUzI1NiIsInR5.bjU3fHE3NS81JDk1N3t0e.0cd91b86e94b2ed7152a304f3ff75f6cfc41806e"' + sLineBreak +
  '}</pre></td><td style="width:10px;">&nbsp;&nbsp;</td></tr>' + sLineBreak +
  '<tr><td style="text-align: center; border-bottom: 1px solid #ddd;">401</td><td style="border-bottom: 1px solid #ddd;"> <div class="linha" style="height:12px; margin: 6px 5px 0px 3px;">  <p style="font-color:#ccc; font-size:11px;">Unauthorized</p>  <p style="font-color:#ccc; font-size:11px;"> text/plain&nbsp;&nbsp;</p> </div> <pre>authentication failed, missing data' + sLineBreak +
  '</pre></td><td style="width:10px;">&nbsp;&nbsp;</td></tr>' + sLineBreak +
  '</table>' + sLineBreak +
  '</div>' + sLineBreak +
  '</div>' + sLineBreak +
  '' + sLineBreak +
  '' + sLineBreak +
  '</div> <!-- card-container-body -->' + sLineBreak +
  '</div> <!-- card-container -->' + sLineBreak +
  '<!-- fim da rota: Auth -->' + sLineBreak;
end;

function TUtilGeraDoc.GetDocOperadores: String;
// descrição dos operadores de paginação: search_operator
var
  sToggle: string;
begin
  sToggle := '15';
  Result := '<!-- descrição dos operadores de paginação - início -->' + sLineBreak;
  Result := Result + '<div class="card" style="border: 1px solid #91bad4; background-color: #91bad4; margin-bottom: 5px; padding-top: 5px;">' + sLineBreak;
  Result := Result + ' <div class="card-header" id="ch_operador-' + sToggle + '" onclick="toggleVisibility(''operador-' + sToggle + ''')" style="font-size:12px; height:20px;">' + sLineBreak;
  Result := Result + '&nbsp;<strong>Operadores de Paginação</strong><i class="name">Descrição dos operadores</i>' + sLineBreak;
  Result := Result + ' </div>'  + sLineBreak;
  Result := Result + ' <div class="card-body" id="operador-' + sToggle + '">' + sLineBreak;
  Result := Result + '  <div class="table-container">' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">search_operator</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">Operador SQL</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">Tipo de Campo</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">eq</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">=</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">texto, número, data</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">neq</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;"><></div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">texto, número, data</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">gt</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">></div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">número, data</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">gte</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">>=</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">número, data</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">lt</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;"><</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">número, data</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">lte</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;"><=</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">número, data</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">between</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">BETWEEN</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">número, data</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">contains</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">LIKE ''%valor%''</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">texto</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">starts</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">LIKE ''valor%''</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">texto</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '    <div class="table-row">' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">ends</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:150px;">LIKE ''%valor''</div>' + sLineBreak;
  Result := Result + '        <div class="table-cell" style="max-width:300px;">texto</div>' + sLineBreak;
  Result := Result + '    </div>' + sLineBreak;
  Result := Result + '  </div>' + sLineBreak;
  Result := Result + '  <br>' + sLineBreak;
  Result := Result + '  <table>' + sLineBreak;
  Result := Result + '    <tr><td>Igualdade ( <b>eq</b> ) </td>' + sLineBreak;
  Result := Result + '    <td>?page=1&limit=10&search_field=id&search_operator=<b>eq</b>&search=10</td></tr>' + sLineBreak;
  Result := Result + '    <tr><td>Maior ou igual  ( <b>gte</b> ) </td>' + sLineBreak;
  Result := Result + '    <td>?page=1&limit=10&search_field=price&search_operator=<b>gte</b>&search=100</td></tr>' + sLineBreak;
  Result := Result + '    <tr><td>Menor ou igual  ( <b>lte</b> ) </td>' + sLineBreak;
  Result := Result + '    <td>?page=1&limit=10&search_field=price&search_operator=<b>lte</b>&search=500</td></tr>' + sLineBreak;
  Result := Result + '    <tr><td>Intervalo  ( <b>between</b> ) </td>' + sLineBreak;
  Result := Result + '    <td>?page=1&limit=10&search_field=price&search_operator=<b>between</b>&search=<b>100;500</b></td></tr>' + sLineBreak;
  Result := Result + '    <tr><td>Contém  ( <b>contains</b> ) </td>' + sLineBreak;
  Result := Result + '    <td>?page=1&limit=10&search_field=name&search_operator=<b>contains</b>&search=bicicleta</td></tr>' + sLineBreak;
  Result := Result + '    <tr><td>Data  ( <b>gte</b> ) </td>' + sLineBreak;
  Result := Result + '    <td>?page=1&limit=10&search_field=date_created&search_operator=<b>gte</b>&search=2026-01-01</td></tr>' + sLineBreak;
  Result := Result + '  </table>' + sLineBreak;
  Result := Result + ' </div>' + sLineBreak; { tabela }
  Result := Result + '</div>' + sLineBreak;
  Result := Result + '<!-- descrição dos operadores de paginação- fim -->' + sLineBreak;
end;

end.

