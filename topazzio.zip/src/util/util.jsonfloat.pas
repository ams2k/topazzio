unit Util.JsonFloat;

{ 
 Created by Topazzio at 2026-05-13 13:05:29
 Developed by Aldo Márcio Soares  |  ams2kg@gmail.com  |  CopyLeft 2025
} 

// Evita exibir valores float com notação científica
{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, fpjson, jsonparser;

type

 { TJSONFloatToNumber }

 TJSONFloatToNumber = class(TJSONFloatNumber)
 protected
   function GetAsString: TJSONStringType; override;
 end;

 procedure JsonFloatNumber;

implementation

procedure JsonFloatNumber;
begin
  SetJSONInstanceType(jitNumberFloat, TJSONFloatToNumber);
end;

{ TJSONFloatToNumber }

function TJSONFloatToNumber.GetAsString: TJSONStringType;
// como usar:  SetJSONInstanceType(jitNumberFloat, TJSONFloat4Number);
var
  F: TJSONFloat;
  fs: TFormatSettings;
begin
  //Result := inherited GetAsString;
  F := GetAsFloat;
  fs := DefaultFormatSettings;
  fs.DecimalSeparator := '.';

  //Result := FormatFloat('0.00###############', F, fs); // format with your preferences
  Result := FormatFloat('0.00##########', F, fs); // format with your preferences
end;

end.


