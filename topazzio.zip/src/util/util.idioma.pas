unit Util.Idioma;

// Tradução via Google Tradutor, portanto se não estiver correto, não é minha culpa! 😁
// Translation via Google Translate, so if it's not correct, it's not my fault! 😁

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, DBGridPlus, IniFiles;

type
  TUtilIdiomas = (BR, EN, ES);

  { ProjetoInfo ( unit View.Splash ) }

  ProjetoInfo = class
    public
      class function Titulo: string;
      class function SubTitulo: string;
      class function Versao(AExtendida: Boolean = True): string;
  end;

  { ArquivoIdioma }

  ArquivoIdioma = class
    private
      class function NomeArquivo: string;
    public
      class function LerIdioma: TUtilIdiomas;
      class procedure SalvarIdioma(AIdioma: TUtilIdiomas);
  end;

  { PalavrasComuns }

  PalavrasComuns = class
    public
      class function Atencao: string;
      class function Sim: string;
      class function Nao: string;
      class function Cancelar: string;
      class function Sair: string;
      class function Salvar: string;
      class function Excluir: string;
      class function Novo: string;
      class function Abrir: string;
      class function Pesquisa: string;
      class function Tabelas: string;
      class function Rota: string;
      class function Campos: string;
      class function Host: string;
      class function Porta: string;
      class function DB: string;
      class function Protocolo: string;
      class function Usuario: string;
      class function Usuarios: string;
      class function Senha: string;
      class function LogOff: string;
      class function EditarTabelas: string;
      class function Ignorar: string;
      class function Corrigir: string;
      class function Confirmacao: string;
      class function CamposRequeridos: string;
      class function Configuracao: string;
      class function Desistir: string;
      class function Registros: string;
      class function Nome: string;
      class function GerarProjeto: string;
      class function Exibir: string;
      class function Ocultar: string;
  end;

  { QuestionDialog }

  QuestionDialog = class
    public
      class function Titulo: string;
      class function Sim: string;
      class function Nao: string;
      class function Cancelar: string;
      class function Atencao: string;
  end;

  { ViewMain ( unit View.Main ) }

  ViewMain = class
    public
      class function Titulo: string;
      class function SubTitulo: string;
      class function Descricao: string;
      class function SairSistema: string;
      class function MenuControle: string;
      class function MenuControleHint: string;
      class function MenuProjeto: string;
      class function MenuProjetoHint: string;
      class function MenuTabelas: string;
      class function MenuTabelasHint: string;
      class function MenuApiHint: string;
      class function MenuControleLabelSgdb: string;
      class function MenuControleLabelHintSgdb: string;
      class function MenuControleLabelGridTitulo: string;
      class function MenuControleLabelInformacoes: string;
      class function MenuControleLabelHost: string;
      class function MenuControleLabelPorta: string;
      class function MenuControleLabelDatabase: string;
      class function MenuControleLabelUsuario: string;
      class function MenuControleLabelSenha: string;
      class function MenuControleLabelSobreProjeto: string;
      class function MenuControleLabelSobreNomeProjeto: string;
      class function MenuControleLabelSobreDescricao: string;
      class function MenuControleEditPesquisa: string;
      class function MenuControleBotaoPathDatabaseHint: string;
      class function MenuControleBotaoSalvarText: string;
      class function MenuControleBotaoSalvarHint: string;
      class function MenuControleBotaoExcluirText: string;
      class function MenuControleBotaoExcluirHint: string;
      class function MenuControleBotaoNovoText: string;
      class function MenuControleBotaoNovoHint: string;
      class function MenuControleBotaoUsarProjetoText: string;
      class function MenuControleBotaoUsarProjetoHint: string;
      class function MenuControleSalvarMensagem1: string;
      class function MenuControleSalvarMensagem2: string;
      class function MenuControleSalvarMensagem3: string;
      class function MenuControleExcluirMensagem1: string;
      class function MenuControleExcluirMensagem2: string;
      class function MenuControleUsarProjetoMensagem1: string;
      class function MenuControleUsarProjetoMensagem2: string;
      class procedure MenuControleGridCampos(var g: TDBGridPlus);
      class function MenuControlePathBancoDadosMensagem1: string;
      class function MenuControlePathBancoDadosMensagem2: string;
      class function MenuControlePathBancoDadosMensagem3: string;
      class function MenuProjetoUsarModernUIText: string;
      class function MenuProjetoUsarModernUIHint: string;
      class function MenuProjetoGerarFormText: string;
      class function MenuProjetoGerarFormHint: string;
      class function MenuProjetoFormBarrraTitulo: string;
      class function MenuProjetoFormCor: string;
      class function MenuProjetoCorBarra: string;
      class function MenuProjetoFormFonte: string;
      class function MenuProjetoTabelasPreparadas: string;
      class function MenuProjetoTabelasPreparadasRefresh: string;
      class function MenuProjetoBotaoEditarTabelasText: string;
      class function MenuProjetoBotaoEditarTabelasHint: string;
      class function MenuProjetoBotaoGerarCrudText: string;
      class function MenuProjetoBotaoGerarCrudHint: string;
      class function MenuProjetoBotaoPastaRaiz: string;
      class function MenuProjetoBotaoCompilarText: string;
      class function MenuProjetoBotaoCompilarHint: string;
      class procedure MenuProjetoGridCampos(var g: TDBGridPlus);
      class function MenuProjetoBotaoGerarCrudMensagem1: string;
      class function MenuProjetoBotaoGerarCrudMensagem2: string;
      class function MenuProjetoBotaoGerarCrudMensagem3(AQde: Integer): string;
      class function MenuProjetoBotaoGerarCrudMensagem4: string;
      class function MenuProjetoBotaoGerarCrudMensagem5: string;
      class function MenuProjetoBotaoEditarTabelaMensagem1: string;
      class function MenuProjetoApenasFormChangeMsg1: string;
      class function MenuProjetoApenasFormChangeMsg2: string;
      class function MenuProjeto_MenuOpcionalText: string;
      class function MenuProjeto_MenuOpcionalHint: string;
      class function MenuProjeto_IncluirModuloChatText: string;
      class function MenuProjeto_IncluirModuloChatHint: string;
      class function MenuProjetoLabelLogoTipoCaption: string;
      class function MenuProjetoBotaoCarregarLogotipoHint: string;
      class function MenuProjetoBotaoRemoverLogotipoHint: string;
      class function MenuProjetoCarregarLogoMensagem1: string;
      class function MenuProjetoCarregarLogoMensagem2: string;
      class function MenuTabelasBotaoCarregarTabelasText: string;
      class function MenuTabelasBotaoCarregarTabelasHint: string;
      class function MenuTabelasLabelListagem: string;
      class procedure MenuTabelasGridCampos(var g: TDBGridPlus);
      class function MenuTabelasBotaoEditarText: string;
      class function MenuTabelasBotaoEditarHint: string;
      class function MenuTabelasLabelListaTabelas: string;
      class function MenuTabelasCheckCriarFormPesquisaText: string;
      class function MenuTabelasCheckCriarFormPesquisaHint: string;
      class function MenuTabelasCheckCriarGridText: string;
      class function MenuTabelasCheckCriarGridHint: string;
      class function MenuTabelasBotaoProcessarTabelasText: string;
      class function MenuTabelasBotaoProcessarTabelasHint: string;
      class function MenuTabelasBotaoProcessarTabelasMensagem1: string;
      class function MenuTabelasBotaoProcessarTabelasMensagem2(AQde: Integer): string;
      class function MenuTabelasBotaoProcessarTabelasMensagem3: string;
      class function MenuTabelasLabelScripts: string;
      class function MenuTabelasBotaoScriptText: string;
      class function MenuTabelasBotaoScriptHint: string;
      class function MenuTabelasBotaoScriptMensagem1: string;
      class function MenuTabelasBotaoScriptMensagem2: string;
      class function MenuTabelasBotaoScriptMensagem3: string;
      class function MenuTabelasScriptBox: string;
      class function MenuTabelasExemplo1Text: string;
      class function MenuTabelasExemplo1Hint: string;
      class function MenuTabelasExemplo2Text: string;
      class function MenuTabelasExemplo2Hint: string;
      class function MenuTabelasMemoLimpar: string;
      class function MenuTabelasBotaoEditarMensagem1: string;
      class function MenuTabelasInfoTabelasMensagem1: string;

      class function MenuApiSalvarMensagem1: string;
      class function MenuApiExcluirMensagem1: string;
      class function MenuApiLabelVersaoCaption: string;
      class function MenuApiLabelAdminCaption: string;
      class function MenuApiLabelAdminEmailCaption: string;
      class function MenuApiLabelApiNameCaption: string;
      class function MenuApiLabelApiTituloCaption: string;
      class function MenuApiLabelDescricaoCaption: string;
      class function MenuApiBotaoGerarApiCaption: string;
      class function MenuApiBotaoGerarApiHint: string;
      class function MenuApiBotaoPastaProjetoHint: string;
      class function MenuApiCheckBoxGerarServiceClasseCaption: string;
      class function MenuApiCheckBoxGerarServiceClasseHint: string;
      class function MenuApiCheckBoxAuditCaption: string;
      class function MenuApiCheckBoxAuditHint: string;
      class function MenuApiCheckBoxBoletoCaption: string;
      class function MenuApiCheckBoxBoletoHint: string;
      class function ApiNenhumaTabelaIndicada: string;
  end;

  { ViewEditarTabela ( unit View.EditarTabela ) }

  ViewEditarTabela = class
    public
      //menus
      class function Titulo: string;
      class function MenuTabelaText: string;
      class function MenuTabelaHint: string;
      class function MenuCampoText: string;
      class function MenuCampoHint: string;
      //menu tabelas
      class function MenuTabelaLabelTabelasPreparadas: string;
      class procedure MenuTabelaGrid(var g: TDBGridPlus);
      class function MenuTabelaLabelDados: string;
      class function MenuTabelaLabelNomeTabela: string;
      class function MenuTabelaLabelNomeObjeto: string;
      class function MenuTabelaLabelDescricao: string;
      class function MenuTabelaLabelScript: string;
      class function MenuTabelaCheckCriarFormText: string;
      class function MenuTabelaCheckCriarFormHint: string;
      class function MenuTabelaCheckCriarGridText: string;
      class function MenuTabelaCheckCriarGridHint: string;
      class function MenuTabelaCheckCriarReportText: string;
      class function MenuTabelaCheckCriarReportHint: string;
      class function MenuTabelaCheckCriarApiText: string;
      class function MenuTabelaCheckCriarApiHint: string;
      class function MenuTabelaCheckIsForAuthText: string;
      class function MenuTabelaCheckIsForAuthHint: string;
      class function MenuTabelaLabelApiRotaCaption: string;
      class function MenuTabelaBotaoSalvarText: string;
      class function MenuTabelaBotaoSalvarMensagem1: string;
      class function MenuTabelaBotaoSalvarMensagem2: string;
      class function MenuTabelaBotaoExcluirText: string;
      class function MenuTabelaBotaoExcluirMensagem1: string;
      class function MenuTabelaBotaoExcluirMensagem2: string;
      class function MenuTabelaBotaoNovoText: string;
      //menu campos
      class function MenuCampoLabelTabelas: string;
      class procedure MenuCampoGrid(var g: TDBGridPlus);
      class function MenuCampoTabelaSelecionada(ATabela: string): string;
      class function MenuCampoLabelDados: string;
      class function MenuCampoLabelFied: string;
      class function MenuCampoLabelFiedAliasCaption: string;
      class function MenuCampoLabelFiedAliasHint: string;
      class function MenuCampoLabelObjeto: string;
      class function MenuCampoLabelObjetoHint: string;
      class function MenuCampoLabelTipo: string;
      class function MenuCampoLabelTamanho: string;
      class function MenuCampoLabelPrecisao: string;
      class function MenuCampoLabelEscala: string;
      class function MenuCampoLabelTipoLazarus: string;
      class function MenuCampoLabelComponente: string;
      class function MenuCampoLabelCampoEspecial: string;
      class function MenuCampoLabelDescricao: string;
      class function MenuCampoLabelFonteDados: string;
      class function MenuCampoLabelComboTabela: string;
      class function MenuCampoLabelComboTabelaExemplo: string;
      class function MenuCampoLabelComboCodigo: string;
      class function MenuCampoLabelComboCodigoExemplo: string;
      class function MenuCampoLabelComboTexto: string;
      class function MenuCampoLabelComboTextoExemplo: string;
      class function MenuCampoLabelComboValores: string;
      class function MenuCampoLabelComboValoresHint: string;
      class function MenuCampoCheckChavePrimariaText: string;
      class function MenuCampoCheckChavePrimariaHint: string;
      class function MenuCampoCheckAceitaNuloText: string;
      class function MenuCampoCheckAceitaNuloHint: string;
      class function MenuCampoCheckChaveEstrangeiraText: string;
      class function MenuCampoCheckChaveEstrangeiraHint: string;
      class function MenuCampoCheckMonetarioText: string;
      class function MenuCampoCheckMonetarioHint: string;
      class function MenuCampoCheckExcluirCrudText: string;
      class function MenuCampoCheckExcluirCrudHint: string;
      class function MenuCampoCheckIncluirGridText: string;
      class function MenuCampoCheckIncluirGridHint: string;
      class function MenuCampoCheckRequeridoText: string;
      class function MenuCampoCheckRequeridoHint: string;
      class function MenuCampoCheckReportSomatorioText: string;
      class function MenuCampoCheckReportSomatorioHint: string;
      class function MenuCampoCheckRemoverMaskText: string;
      class function MenuCampoCheckRemoverMaskHint: string;
      class function MenuCampoBotaoSalvarText: string;
      class function MenuCampoBotaoExcluirText: string;
      class function MenuCampoBotaoNovoText: string;
      class function MenuCampoBotaoSalvarMensagem1: string;
      class function MenuCampoBotaoSalvarMensagem2: string;
      class function MenuCampoBotaoSalvarMensagem3: string;
      class function MenuCampoBotaoSalvarMensagem4: string;
      class function MenuCampoBotaoSalvarMensagem5: string;
      class function MenuCampoBotaoSalvarMensagem6: string;
      class function MenuCampoBotaoSalvarMensagem7: string;
      class function MenuCampoBotaoSalvarMensagem8: string;
      class function MenuCampoBotaoSalvarMensagem9: string;
      class function MenuCampoBotaoSalvarMensagem10: string;
      class function MenuCampoBotaoSalvarMensagem11: string;
      class function MenuCampoBotaoSalvarMensagem12: string;
      class function MenuCampoBotaoSalvarMensagem13: string;
      class function MenuCampoBotaoSalvarMensagem14: string;
      class function MenuCampoBotaoSalvarMensagem15: string;
      class function MenuCampoBotaoSalvarMensagem16: string;
      class function MenuCampoBotaoSalvarMensagem17: string;
      class function MenuCampoBotaoSalvarMensagem18: string;
  end;

  { ViewCompilador ( unit View.Compilador ) }

  ViewCompilador = class
    public
      class function Titulo: string;
      class function LazBuildLabel: string;
      class function LazBuildMessage: string;
      class function ModoCompilacaoLabel: string;
      class function BotaoCompilarText: string;
      class function BotaoExecutarText: string;
      class function LogCompilacaoLabel: string;
      class function BotaoCompilarMensagem1: string;
      class function BotaoExecutarMensagem1: string;
      class function Mensagem1: string;
      class function Mensagem2: string;
      class function Mensagem3: string;
      class function Mensagem4: string;
      class function Mensagem5: string;
      class function Mensagem6: string;
  end;

  { InfoTabelas ( unit Service.InfoTabelas ) }

  InfoTabelas = class
    public
      class function SalvaTabelaMensagem1: string;
      class function SalvaTabelaMensagem2: string;
      class function SalvaTabelaMensagem3: string;
  end;

  { ServiceCampo ( unit Service.Campo ) }

  ServiceCampo = class
    public
      class function Mensagem1: string;
      class function Mensagem2: string;
  end;

  { ServiceTabela ( unit Service.Tabela ) }

  ServiceTabela = class
    public
      class function Mensagem1: string;
      class function Mensagem2: string;
  end;

  { ServiceProjeto ( unit Service.Projeto ) }

  ServiceProjeto = class
    public
      class function Mensagem1: string;
  end;

  { UtilAbrirPastaProjeto ( unit Util.AbrirPastaProjeto ) }

  UtilAbrirPastaProjeto = class
    public
      class function Mensagem1: string;
  end;

  { UtilMessagePopup ( unit Util.MessagePopup ) }

  UtilMessagePopup = class
    public
      class function Mensagem1: string;
      class function Mensagem2: string;
  end;

  { UtilValidacaoCampos ( unit Util.ValidacaoCampos ) }

  UtilValidacaoCampos = class
    public
      class function Mensagem1: string;
      class function Mensagem2(Avalor: string): string;
      class function Mensagem3_1: string;
      class function Mensagem3_2: string;
  end;

  { UtilProjetoLazarus ( unit Util.ProjetoLazarus ) }

  UtilProjetoLazarus = class
    public
      class function Splash_Versao: string;
      class function PastaProjetos: string;
      class function GerarForm_BotaoAbrirMsg1: string;
      class function GerarForm_BotaoSalvarText: string;
      class function GerarForm_BotaoSalvarMsg1: string;
      class function GerarForm_BotaoSalvarMsg2: string;
      class function GerarForm_BotaoSalvarMsg3: string;
      class function GerarForm_BotaoSalvarMsg4: string;
      class function GerarForm_BotaoSalvarMsg5: string;
      class function GerarForm_BotaoSalvarMsg6: string;
      class function GerarForm_BotaoSalvarMsg7: string;
      class function GerarForm_BotaoSalvarMsg8: string;
      class function GerarForm_BotaoExcluirText: string;
      class function GerarForm_BotaoExcluirMsg1: string;
      class function GerarForm_BotaoExcluirMsg2: string;
      class function GerarForm_BotaoNovoText: string;
      class function GerarForm_BotaoNovoMsg1: string;
      class function GerarForm_ValidacaoMsg1: string;
      class function GerarForm_ValidacaoErroMsg1: string;
      class function GerarForm_ValidacaoErroMsg2(AMsg: string): string;
      class function GerarForm_BotaoCarregarFotoMsg1: string;
      class function GerarForm_BotaoExcluirFotoMsg1: string;
      class function GerarForm_FormatoData: string;
      class function GerarForm_FormatoDataCurta: string;
      class function GerarForm_FormatoMoeda: string;
      class function GerarForm_BotaoAbrirCaption: string;
      class function GerarForm_FormatoMoedaValor: string;
      class function GerarForm_LabelPesquisa: string;
      class function GerarForm_LabelRegistros: string;
      class function GerarForm_GridRefresh: string;
      class function GerarForm_CepMsg1: string;
      class function GerarForm_CepMsg2: string;
      class function GerarForm_CepMsg3: string;
      class function GerarForm_CepMsg4: string;

      //classe CRUD
      class function CRUD_DesconectadoMsg1: string;
      class function CRUD_SalvarMsg1: string;
      class function CRUD_SalvarMsg2: string;
      class function CRUD_ExcluirMsg1: string;
      class function CRUD_LerMsg1: string;
      class function CRUD_LerMsg2: string;

      //Configurações do Servidor no arquivo .INI
      class function ConfigDM_Titulo: string;
      class function ConfigDM_BotaoSalvarText: string;
      class function ConfigDM_BotaoSalvarMsg1: string;
      class function ConfigDM_BotaoCancelarText: string;
      class function ConfigDM_LabelDBNome: string;
      class function ConfigDM_LabelServidor: string;
      class function ConfigDM_LabelPorta: string;
      class function ConfigDM_LabelUsername: string;
      class function ConfigDM_LabelSenha: string;
      class function ConfigDM_LabelProtocolo: string;
      class function ConfigDM_LabelCriptografia: string;

      //classe CRUD View.Usuario
      class function ServiceUsuario_DesconectadoMsg1: string;
      class function ServiceUsuario_SalvarMsg1: string;
      class function ServiceUsuario_SalvarMsg2: string;
      class function ServiceUsuario_ExcluirMsg1: string;
      class function ServiceUsuario_LerMsg1: string;
      class function ServiceUsuario_LerMsg2: string;
      class function ServiceUsuario_LoginSucesso: string;
      class function ServiceUsuario_LoginNaoPermitido: string;
      class function ServiceUsuario_LoginInvalido: string;
      class function ServiceUsuario_AlteraSenhaSucesso: string;
      class function ServiceUsuario_AlteraSenhaFalhou: string;

      //form view.Usuario
      class function ViewUsuario_Titulo1: string;
      class function ViewUsuario_Titulo2: string;
      class function ViewUsuario_BotaoSalvarMsg1: string;
      class function ViewUsuario_BotaoSalvarMsg2: string;
      class function ViewUsuario_BotaoExcluirMsg1: string;
      class function ViewUsuario_BotaoExcluirMsg2: string;
      class function ViewUsuario_GridCampoNome: string;
      class function ViewUsuario_GridCampoAtivo: string;
      class function ViewUsuario_LabelPesquisaText: string;
      class function ViewUsuario_LabelRegistrosText: string;
      class function ViewUsuario_LabelIsAdmin: string;
      class function ViewUsuario_LabelCadastroLiberado: string;
      class function ViewUsuario_LabelNomeText: string;

      // form Login
      class function Login_Ola: string;
      class function Login_BemVindo: string;
      class function Login_PrimeiroAcesso: string;
      class function Login_UltimoAcesso: string;
      class function Login_Desistir: string;
      class function Login_NovaSenha: string;
      class function Login_NovaSenhaPlaceHolder: string;
      class function Login_NovaSenhaRepetirPlaceHolder: string;
      class function Login_SenhasDiferentes: string;
      class function Login_AlterarSenhaText: string;
      class function Login_NovaSenhaText: string;
      class function Login_LabelSenhaInvalida: string;
      class function Login_BotaoTentarNovamente: string;
      class function Login_BotaoDesistir: string;
      class function Login_InformeCredenciais: string;
      class function Login_BotaoEntrar: string;
      class function Login_UsernameText: string;
      class function Login_UsernamePlaceHolder: string;
      class function Login_SenhaText: string;
      class function Login_SenhaPlaceHolder: string;
      class function Login_BotaoConcluir: string;
      class function Login_LabelAlterarSenha: string;
      class function Login_LabelNovaSenha: string;
      class function Login_LabelNovaSenhaRepetir: string;

      // form View.Pesquisa
      class function Pesquisa_Mensagem1: string;
      class function Pesquisa_BotaoRetornarMsg1: string;

      //tela principal View.Main
      class function ViewMain_Titulo: string;
      class function ViewMain_SairText: string;
      class function ViewMain_SairTitulo: string;
      class function ViewMain_SairMsg: string;
      class function ViewMain_SairOpcaoSair: string;
      class function ViewMain_SairOpcaoLogOff: string;
      class function ViewMain_SairOpcaoCancelar: string;
      class function ViewMain_UsuariosAcesso: string;
      class function ViewMain_MenuOpcao: string;
      class function ViewMain_Conectado: string;
      class function ViewMain_Desconectado: string;
      class function ViewMain_Configuracao: string;
      class function ViewMain_Usuarios: string;
      class function ViewMain_MenuSistema: string;
      class function ViewMain_MenuChatHistorico: string;
      class function ViewMain_ChatIniciarConversa: string;

      //relatórios
      class function Rpt_RelatorioText: string;
      class function Rpt_RelatorioLabel: string;
      class function Rpt_PaginacaoAtual: string;
      class function Rpt_PaginacaoTotal: string;

      //form about
      class function About_Title: string;
  end;

  { TChatMessages }

  TChatMessages = class
    public
      class function ChatModule_ConexaoStatusON: string;
      class function ChatModule_ConexaoStatusOFF: string;
      class function ChatModule_LoginStatusOFF: string;
      class function ChatModule_ChatUserInfo_Msg1: string;
      class function ChatModule_ChatUserInfo_Msg2: string;
      class function ChatModule_ChatUserInfo_Msg3: string;
      class function ChatModule_ChatUserInfo_Msg4: string;
      class function ChatModule_ChatUserInfo_Msg5: string;
      class function ChatForm_Msg1: string;
      class function ChatForm_PedirAtencaoTitulo: string;
      class function ChatForm_PedirAtencaoMsg: string;
      class function ChatForm_Msg2: string;
      class function ChatForm_Msg3: string;
      class function ChatForm_Msg4: string;
      class function ChatForm_Msg5: string;
      class function ChatForm_Msg6: string;
      class function ChatForm_Msg7: string;
      class function ChatForm_Msg8: string;
      class function ChatForm_Convidado: string;
      class function ChatForm_Msg9: string;
      class function ChatForm_Msg10: string;
      class function ChatForm_ApagarMsgTitulo: string;
      class function ChatForm_ApagarMsgText: string;
      class function ChatForm_Msg11: string;
      class function ChatForm_Msg12: string;
      class function ChatForm_Msg13: string;
      class function ChatForm_Msg14: string;
      class function ChatForm_Msg15: string;
      class function ChatForm_Msg16: string;
      class function ChatForm_Msg17: string;
      class function ChatForm_Msg18: string;
      class function ChatForm_Msg19: string;
      class function ChatForm_Msg20: string;
      class function ChatForm_Msg21: string;
      class function ChatForm_Msg22: string;
      class function ChatForm_Msg23: string;
      class function ChatForm_Msg24: string;
      class function ChatForm_Msg25: string;
      class function ChatForm_Msg26: string;
      class function ChatForm_Msg27: string;
      class function ChatForm_Msg28: string;
      class function ChatForm_Msg29: string;
      class function ChatForm_Msg30: string;
      class function ChatCardMessage_Date(AHoje: Boolean): string;
      class function ChatCardMessage_DateLong: string;
      class function ChatCardMessage_Msg1: string;
      class function ChatCardMessage_Msg2: string;
      class function ChatCardMessage_Msg3: string;
      class function ChatFormHistorico_Msg1: string;
      class function ChatFormHistorico_Msg2: string;
      class function ChatFormHistorico_Msg3: string;
      class function ChatFormHistorico_Msg4: string;
      class function ChatFormHistorico_Msg5: string;
      class function ChatFormHistorico_Msg6: string;
      class function ChatFormHistorico_Msg7: string;
      class function ChatFormUsuarios_Msg1: string;
      class function ChatFormUsuarios_Msg2: string;
      class function ChatFormUsuarios_Msg3: string;
  end;

  { TApiMessages }

  TApiMessages = class
    public
      class function ServidorOuvindo: string;
      class function ServidorFirewall: string;
      class function ServidorSair: string;
  end;


var
  meu_idioma : TUtilIdiomas;

implementation

{ ArquivoIdioma }

class function ArquivoIdioma.NomeArquivo: string;
begin
  Result := ExtractFileDir( ParamStr(0)) + PathDelim + 'language.ini';
end;

class function ArquivoIdioma.LerIdioma: TUtilIdiomas;
//ler configurações do servidor
var
  ArqINI: TIniFile;
  codigo: integer;
begin
  Result := BR;
  ArqINI := TIniFile.Create( NomeArquivo );

  try
     codigo := ArqINI.ReadInteger('country','code', 0);
     if (codigo < 0) or (codigo > 2) then codigo := 0;
     Result := TUtilIdiomas( codigo );
  finally
    ArqINI.Free;
  end;
end;

class procedure ArquivoIdioma.SalvarIdioma(AIdioma: TUtilIdiomas);
//salva configurações do servidor
var
  ArqINI: TIniFile;
begin
  ArqINI := TIniFile.Create( NomeArquivo );

  try
    ArqINI.WriteInteger('country','code', Ord(AIdioma));
  finally
    ArqINI.Free;
  end;
end;

{ PalavrasComuns }

class function PalavrasComuns.Atencao: string;
begin
  Result := 'Atenção';
  if meu_idioma = EN then Result := 'Attention';
  if meu_idioma = ES then Result := 'Atención';
end;

class function PalavrasComuns.Sim: string;
begin
  Result := 'Sim';
  if meu_idioma = EN then Result := 'Yes';
  if meu_idioma = ES then Result := 'Sí';
end;

class function PalavrasComuns.Nao: string;
begin
  Result := 'Não';
  if meu_idioma = EN then Result := 'No';
  if meu_idioma = ES then Result := 'No';
end;

class function PalavrasComuns.Cancelar: string;
begin
  Result := 'Cancelar';
  if meu_idioma = EN then Result := 'Cancel';
  if meu_idioma = ES then Result := 'Cancelar';
end;

class function PalavrasComuns.Sair: string;
begin
  Result := 'Sair';
  if meu_idioma = EN then Result := 'Exit';
  if meu_idioma = ES then Result := 'Salir';
end;

class function PalavrasComuns.Salvar: string;
begin
  Result := 'Salvar';
  if meu_idioma = EN then Result := 'Save';
  if meu_idioma = ES then Result := 'Ahorrar';
end;

class function PalavrasComuns.Excluir: string;
begin
  Result := 'Excluir';
  if meu_idioma = EN then Result := 'Delete';
  if meu_idioma = ES then Result := 'Borrar';
end;

class function PalavrasComuns.Novo: string;
begin
  Result := 'Novo';
  if meu_idioma = EN then Result := 'New';
  if meu_idioma = ES then Result := 'Nuevo';
end;

class function PalavrasComuns.Abrir: string;
begin
  Result := 'Abrir';
  if meu_idioma = EN then Result := 'Open';
  if meu_idioma = ES then Result := 'Abreir';
end;

class function PalavrasComuns.Pesquisa: string;
begin
  Result := 'PESQUISA';
  if meu_idioma = EN then Result := 'SEARCH';
  if meu_idioma = ES then Result := 'BUSCAR';
end;

class function PalavrasComuns.Tabelas: string;
begin
  Result := 'TABELAS';
  if meu_idioma = EN then Result := 'TABLES';
  if meu_idioma = ES then Result := 'TABLAS';
end;

class function PalavrasComuns.Rota: string;
begin
  Result := 'ROTA';
  if meu_idioma = EN then Result := 'ROUTE';
  if meu_idioma = ES then Result := 'RUTA';
end;

class function PalavrasComuns.Campos: string;
begin
  Result := 'CAMPOS';
  if meu_idioma = EN then Result := 'FIELDS';
  if meu_idioma = ES then Result := 'CAMPOS';
end;

class function PalavrasComuns.Host: string;
begin
  Result := 'HOST';
  if meu_idioma = EN then Result := 'HOST';
  if meu_idioma = ES then Result := 'HOST';
end;

class function PalavrasComuns.Porta: string;
begin
  Result := 'PORTA';
  if meu_idioma = EN then Result := 'PORT';
  if meu_idioma = ES then Result := 'PUERTA';
end;

class function PalavrasComuns.DB: string;
begin
  Result := 'BANCO DADOS';
  if meu_idioma = EN then Result := 'DATABASE';
  if meu_idioma = ES then Result := 'BANCO DATOS';
end;

class function PalavrasComuns.Protocolo: string;
begin
  Result := 'PROTOCOL';
  if meu_idioma = EN then Result := 'PROTOCOL';
  if meu_idioma = ES then Result := 'PROTOCOL';
end;

class function PalavrasComuns.Usuario: string;
begin
  Result := 'USUÁRIO';
  if meu_idioma = EN then Result := 'USERNAME';
  if meu_idioma = ES then Result := 'USUARIO';
end;

class function PalavrasComuns.Usuarios: string;
begin
  Result := 'USUÁRIOS';
  if meu_idioma = EN then Result := 'USERS';
  if meu_idioma = ES then Result := 'USUARIOS';
end;

class function PalavrasComuns.Senha: string;
begin
  Result := 'SENHA';
  if meu_idioma = EN then Result := 'PASSWORD';
  if meu_idioma = ES then Result := 'CONTRASEÑA';
end;

class function PalavrasComuns.LogOff: string;
begin
  Result := 'LogOff';
  if meu_idioma = EN then Result := 'LogOff';
  if meu_idioma = ES then Result := 'LogOff';
end;

class function PalavrasComuns.EditarTabelas: string;
begin
  Result := 'Editar Tabelas';
  if meu_idioma = EN then Result := 'Edit Tables';
  if meu_idioma = ES then Result := 'Editar Tablas';
end;

class function PalavrasComuns.Ignorar: string;
begin
  Result := 'Ignorar';
   if meu_idioma = EN then Result := 'Ignore';
   if meu_idioma = ES then Result := 'Ignorar';
end;

class function PalavrasComuns.Corrigir: string;
begin
  Result := 'Corrigir';
  if meu_idioma = EN then Result := 'Fix It';
  if meu_idioma = ES then Result := 'Corregir';
end;

class function PalavrasComuns.Confirmacao: string;
begin
  Result := 'Confirmação';
  if meu_idioma = EN then Result := 'Confirmation';
  if meu_idioma = ES then Result := 'Confirmación';
end;

class function PalavrasComuns.CamposRequeridos: string;
begin
  Result := 'Campos requeridos';
  if meu_idioma = EN then Result := 'Required fields';
  if meu_idioma = ES then Result := 'Campos obligatorios';
end;

class function PalavrasComuns.Configuracao: string;
begin
  Result := 'CONFIGURAÇÃO';
  if meu_idioma = EN then Result := 'SETTINGS';
  if meu_idioma = ES then Result := 'AJUSTES';
end;

class function PalavrasComuns.Desistir: string;
begin
  Result := 'Desistir';
  if meu_idioma = EN then Result := 'To give up';
  if meu_idioma = ES then Result := 'Renunciar';
end;

class function PalavrasComuns.Registros: string;
begin
  Result := 'Registros';
  if meu_idioma = EN then Result := 'Records';
  if meu_idioma = ES then Result := 'Registros';
end;

class function PalavrasComuns.Nome: string;
begin
  Result := 'NOME';
  if meu_idioma = EN then Result := 'NAME';
  if meu_idioma = ES then Result := 'NOMRE';
end;

class function PalavrasComuns.GerarProjeto: string;
begin
  Result := 'Gerar Projeto';
  if meu_idioma = EN then Result := 'Generate Project';
  if meu_idioma = ES then Result := 'Generar proyecto';
end;

class function PalavrasComuns.Exibir: string;
begin
  Result := 'Exibir';
  if meu_idioma = EN then Result := 'Show';
  if meu_idioma = ES then Result := 'Mostrar';
end;

class function PalavrasComuns.Ocultar: string;
begin
  Result := 'Ocultar';
  if meu_idioma = EN then Result := 'Hide';
  if meu_idioma = ES then Result := 'Esconder';
end;

{ ProjetoInfo }

class function ProjetoInfo.Titulo: string;
begin
  Result := 'GERADOR DE PROJETO LAZARUS';
  if meu_idioma = EN then Result := 'LAZARUS PROJECT GENERATOR';
  if meu_idioma = ES then Result := 'GENERADOR DEL PROYECTO LAZARUS';
end;

class function ProjetoInfo.SubTitulo: string;
begin
  Result := 'Cria projeto Lazarus / Free Pascal';
  if meu_idioma = EN then Result := 'Creates Lazarus / Free Pascal project';
  if meu_idioma = ES then Result := 'Crear proyecto Lazarus / Free Pascal';
end;

class function ProjetoInfo.Versao(AExtendida: Boolean): string;
begin
  Result := 'Versão 3.0';
  if meu_idioma = EN then Result := 'Version 3.0';
  if meu_idioma = ES then Result := 'Versión 3.0';
  if not AExtendida then Result := '3.0';
end;

{ QuestionDialog }

class function QuestionDialog.Titulo: string;
begin
  Result := PalavrasComuns.Atencao;
end;

class function QuestionDialog.Sim: string;
begin
  Result := PalavrasComuns.Sim;
end;

class function QuestionDialog.Nao: string;
begin
  Result := PalavrasComuns.Nao;
end;

class function QuestionDialog.Cancelar: string;
begin
  Result := PalavrasComuns.Cancelar;
end;

class function QuestionDialog.Atencao: string;
begin
  Result := PalavrasComuns.Atencao;
end;

{ ViewMain }

class function ViewMain.Titulo: string;
begin
  Result := 'Gerador de Projetos Lazarus / Free Pascal';
  if meu_idioma = EN then Result := 'Lazarus / Free Pascal Projects Generator';
  if meu_idioma = ES then Result := 'Generador de proyectos Lazarus/Free Pascal';
end;

class function ViewMain.SubTitulo: string;
begin
  Result := ProjetoInfo.Versao + ' | (PIX) ams2kg@gmail.com | CopyLeft @ 2025';
  if meu_idioma = EN then Result := ProjetoInfo.Versao + ' | (PIX) ams2kg@gmail.com | CopyLeft @ 2025';
  if meu_idioma = ES then Result := ProjetoInfo.Versao + ' | (PIX) ams2kg@gmail.com | CopyLeft @ 2025';
end;

class function ViewMain.Descricao: string;
begin
  Result := '- Transforme suas tabelas, que podem ser importadas do seu banco de' + sLineBreak +
  '  dados, ou de script de criação de tabela, em telas prontas para acessar' + sLineBreak +
  '  os dados, com as classes de dados para cada tabela.' + sLineBreak +
  '- Gere o projeto, compile e execute seu aplicativo com alguns cliques!' + sLineBreak +
  '- Posteriormente, faça os ajustes necessários e compile em seu Lazarus.' + sLineBreak +
  '- Agora com módulo completo de Chat.';
  if meu_idioma = EN then
    Result := '- Transform your tables, which can be imported from your database or' + sLineBreak +
    '  from a table creation script, into ready-made screens for accessing' + sLineBreak +
    '  data, with data classes for each table.' + sLineBreak +
    '- Generate the project, compile, and run your app with just a few clicks!' + sLineBreak +
    '- Then, make the necessary adjustments and compile it in Lazarus.' + sLineBreak +
    '- Now with a complete Chat module.';
  if meu_idioma = ES then
    Result := '- Transforma tus tablas, que pueden ser importadas desde tu base de' + sLineBreak +
    '  datos o script de creación de tablas en pantallas listas para acceder' + sLineBreak +
    '  los datos, con las clases de datos para cada tabla.' + sLineBreak +
    '- ¡Genera el proyecto, compila y ejecuta tu aplicación con unos pocos clics!' + sLineBreak +
    '- Luego realiza los ajustes necesarios y compila en tu Lazarus.' + sLineBreak +
    '- Ahora con un módulo de Chat completo.';
end;

class function ViewMain.SairSistema: string;
begin
  Result := 'Fazer LogOff ou Sair do Sistema.';
  if meu_idioma = EN then Result := 'End Session Or Log Out';
  if meu_idioma = ES then Result := 'Cerrar Sesión o Salir del Sistema.';
end;

class function ViewMain.MenuControle: string;
begin
  Result := 'CONTROLE';
  if meu_idioma = EN then Result := 'CONTROL';
  if meu_idioma = ES then Result := 'CONTROL';
end;

class function ViewMain.MenuControleHint: string;
begin
  Result := 'Cadastro de Projetos';
  if meu_idioma = EN then Result := 'Projects Registration';
  if meu_idioma = ES then Result := 'Registro del proyecto';
end;

class function ViewMain.MenuProjeto: string;
begin
  Result := 'O PROJETO';
  if meu_idioma = EN then Result := 'THE PROJECT';
  if meu_idioma = ES then Result := 'EL PROYECTO';
end;

class function ViewMain.MenuProjetoHint: string;
begin
  Result := 'Projeto em evidência';
  if meu_idioma = EN then Result := 'Featured Project';
  if meu_idioma = ES then Result := 'Proyecto destacado';
end;

class function ViewMain.MenuTabelas: string;
begin
  Result := PalavrasComuns.Tabelas;
end;

class function ViewMain.MenuApiHint: string;
begin
  Result := 'Informações para criar a api';
  if meu_idioma = EN then Result := 'Information for creating the api';
  if meu_idioma = ES then Result := 'Información para crear la api';
end;

class function ViewMain.MenuTabelasHint: string;
begin
  Result := 'Ler tabelas do banco de dados';
  if meu_idioma = EN then Result := 'Read database tables';
  if meu_idioma = ES then Result := 'Leer tablas de bases de datos';
end;

class function ViewMain.MenuControleLabelSgdb: string;
begin
  Result := 'BANCO DE DADOS - SGDB';
  if meu_idioma = EN then Result := 'DATABASE - SGDB';
  if meu_idioma = ES then Result := 'BASE DE DATOS - SGDB';
end;

class function ViewMain.MenuControleLabelHintSgdb: string;
begin
  Result := 'Sistema de Gerenciamento de Banco de Dados';
  if meu_idioma = EN then Result := 'Database Management System';
  if meu_idioma = ES then Result := 'Sistema de Gestión de Bases de Datos';
end;

class function ViewMain.MenuControleLabelGridTitulo: string;
begin
  Result := 'PROJETOS CADASTRADOS:';
  if meu_idioma= EN then Result := 'REGISTERED PROJECTS:';
  if meu_idioma = ES then Result := 'PROYECTOS REGISTRADOS:';
end;

class function ViewMain.MenuControleLabelInformacoes: string;
begin
  Result := 'INFORMAÇÕES DO BANCO DE DADOS';
  if meu_idioma = EN then Result := 'DATABASE INFORMATION';
  if meu_idioma = ES then Result := 'INFORMACIÓN DE LA BASE DE DATOS';
end;

class function ViewMain.MenuControleLabelHost: string;
begin
  Result := PalavrasComuns.Host;
end;

class function ViewMain.MenuControleLabelPorta: string;
begin
  Result := PalavrasComuns.Porta;
end;

class function ViewMain.MenuControleLabelDatabase: string;
begin
  Result := 'NOME DO BANCO DE DADOS OU PASTA E ARQUIVO';
  if meu_idioma = EN then Result := 'DATABASE NAME OR FILE AND PATH';
  if meu_idioma = ES then Result := 'BASE DE DATOS O CARPETA Y NOMBRE DE ARCHIVO';
end;

class function ViewMain.MenuControleLabelUsuario: string;
begin
  Result := PalavrasComuns.Usuario;
end;

class function ViewMain.MenuControleLabelSenha: string;
begin
  Result := PalavrasComuns.Senha;
end;

class function ViewMain.MenuControleLabelSobreProjeto: string;
begin
  Result := 'SOBRE O PROJETO';
  if meu_idioma = EN then Result := 'ABOUT THE PROJECT';
  if meu_idioma = ES then Result := 'SOBRE EL PROYECTO';
end;

class function ViewMain.MenuControleLabelSobreNomeProjeto: string;
begin
  Result := 'NOME DO PROJETO / APLICAÇÃO (SEM ESPAÇOS)';
  if meu_idioma = EN then Result := 'PROJECT / APPLICATION NAME (NO SPACES)';
  if meu_idioma = ES then Result := 'NOMBRE DEL PROYECTO/APPLICACIÓN (SIN ESPACIOS)';
end;

class function ViewMain.MenuControleLabelSobreDescricao: string;
begin
  Result := 'DESCRIÇÃO DO PROJETO';
  if meu_idioma = EN then Result := 'PROJECT DESCRIPTION';
  if meu_idioma = ES then Result := 'DESCRIPCIÓN DEL PROYECTO';
end;

class function ViewMain.MenuControleEditPesquisa: string;
begin
  Result := PalavrasComuns.Pesquisa + '...';
end;

class function ViewMain.MenuControleBotaoPathDatabaseHint: string;
begin
  Result := 'Abrir local do arquivo do banco de dados';
  if meu_idioma = EN then Result := 'Open database file location';
  if meu_idioma = ES then Result := 'Abrir la ubicación del archivo de base de datos';
end;

class function ViewMain.MenuControleBotaoSalvarText: string;
begin
  Result := PalavrasComuns.Salvar;
end;

class function ViewMain.MenuControleBotaoSalvarHint: string;
begin
  Result := 'Salva o projeto';
  if meu_idioma = EN then Result := 'Saves the project';
  if meu_idioma = ES then Result := 'Guardar el proyecto';
end;

class function ViewMain.MenuControleBotaoExcluirText: string;
begin
  Result := PalavrasComuns.Excluir;
end;

class function ViewMain.MenuControleBotaoExcluirHint: string;
begin
  Result := 'Exclusão do projeto selecionado';
  if meu_idioma = EN then Result := 'Deleting the selected project';
  if meu_idioma = ES then Result := 'Eliminar el proyecto seleccionado';
end;

class function ViewMain.MenuControleBotaoNovoText: string;
begin
  Result := PalavrasComuns.Novo;
end;

class function ViewMain.MenuControleBotaoNovoHint: string;
begin
  Result := 'Prepara para entrada de novo projeto';
  if meu_idioma = EN then Result := 'Prepares for new project entry';
  if meu_idioma = ES then Result := 'Se prepara para la entrada en un nuevo proyecto';
end;

class function ViewMain.MenuControleBotaoUsarProjetoText: string;
begin
  Result := 'Trabalhar Neste Projeto';
  if meu_idioma = EN then Result := 'Work on This Project';
  if meu_idioma = ES then Result := 'Trabajar en este proyecto';
end;

class function ViewMain.MenuControleBotaoUsarProjetoHint: string;
begin
  Result := 'Iniciar trabalhos neste projeto';
  if meu_idioma = EN then Result := 'Start work on this project';
  if meu_idioma = ES then Result := 'Empieza a trabajar en este proyecto';
end;

class function ViewMain.MenuControleSalvarMensagem1: string;
begin
  Result := 'Campos Obrigatórios: ' + sLineBreak +'Host' + sLineBreak +
            'Porta' + sLineBreak + 'Nome do banco de dados' + sLineBreak +
            'Usuário' + sLineBreak + 'Senha';
  if meu_idioma = EN then
    Result := 'Required Fields: ' + sLineBreak +'Host' + sLineBreak +
              'Port' + sLineBreak + 'Database Name' + sLineBreak +
              'Username' + sLineBreak + 'Password';
  if meu_idioma = ES then
    Result := 'Campos obligatorios: ' + sLineBreak +'Host' + sLineBreak +
              'Puerta' + sLineBreak + 'Nombre de la base de datos' + sLineBreak +
              'Usuario' + sLineBreak + 'Contraseña';
end;

class function ViewMain.MenuControleSalvarMensagem2: string;
begin
  Result := 'Informe o nome do projeto!';
  if meu_idioma = EN then Result := 'Enter the project name!';
  if meu_idioma = ES then Result := '¡Ingresa el nombre del proyecto!';
end;

class function ViewMain.MenuControleSalvarMensagem3: string;
begin
  Result := 'Projeto salvo com sucesso!';
  if meu_idioma = EN then Result := 'Project saved successfully!';
  if meu_idioma = ES then Result := '¡Proyecto guardado exitosamente!';
end;

class function ViewMain.MenuControleExcluirMensagem1: string;
begin
  Result := 'Não há um projeto em exibição!';
  if meu_idioma = EN then Result := 'There is no project on display!';
  if meu_idioma = ES then Result := '¡No hay ningún proyecto en exposición!';
end;

class function ViewMain.MenuControleExcluirMensagem2: string;
begin
  Result := 'Deseja excluir este projeto ?';
  if meu_idioma = EN then Result := 'Do you want to delete this project?';
  if meu_idioma = ES then Result := '¿Quieres eliminar este proyecto?';
end;

class function ViewMain.MenuControleUsarProjetoMensagem1: string;
begin
  Result := 'Selecione um projeto na lista!';
  if meu_idioma = EN then Result := 'Select a project from the list!';
  if meu_idioma = ES then Result := '¡Selecciona un proyecto de la lista!';
end;

class function ViewMain.MenuControleUsarProjetoMensagem2: string;
begin
  Result := 'Já há um projeto selecionado.' + sLineBreak + sLineBreak +
            'Descarregar o projeto em andamento ?';
  if meu_idioma = EN then
    Result := 'There is already a project selected.' + sLineBreak + sLineBreak +
              'Unload the project in progress ?';
  if meu_idioma = ES then
    Result := 'Ya hay un proyecto seleccionado.' + sLineBreak + sLineBreak +
              '¿Descargar el proyecto en curso?';
end;

class procedure ViewMain.MenuControleGridCampos(var g: TDBGridPlus);
begin
  g.Columns[1].Title.Caption := 'PROJETO';
  g.Columns[2].Title.Caption := 'BANCO';
  if meu_idioma = EN then begin
    g.Columns[1].Title.Caption := 'PROJECT';
    g.Columns[2].Title.Caption := 'DATABASE';
  end;
  if meu_idioma = ES then begin
    g.Columns[1].Title.Caption := 'PROYECTO';
    g.Columns[2].Title.Caption := 'DATABASE';
  end;
end;

class function ViewMain.MenuControlePathBancoDadosMensagem1: string;
begin
  Result := 'Carregar banco de dados';
  if meu_idioma = EN then Result := 'Load database';
  if meu_idioma = ES then Result := 'Cargar base de datos';
end;

class function ViewMain.MenuControlePathBancoDadosMensagem2: string;
begin
  Result := 'Bancos de Dados';
  if meu_idioma = EN then Result := 'Databases';
  if meu_idioma = ES then Result := 'Bases de datos';
end;

class function ViewMain.MenuControlePathBancoDadosMensagem3: string;
begin
  Result := 'Todos os Arquivos';
  if meu_idioma = EN then Result := 'All Files';
  if meu_idioma = ES then Result := 'Todos los archivos';
end;

class function ViewMain.MenuProjetoUsarModernUIText: string;
begin
  Result := 'Usar componentes ModerUI';
  if meu_idioma = EN then Result := 'Use ModerUI components';
  if meu_idioma = ES then Result := 'Uso de componentes ModerUI';
end;

class function ViewMain.MenuProjetoUsarModernUIHint: string;
begin
  Result := 'Se ativado, serão utilizados componentes ModernUI';
  if meu_idioma = EN then Result := 'If enabled, ModernUI components will be used';
  if meu_idioma = ES then Result := 'Si está habilitado, se utilizarán los componentes de ModernUI';
end;

class function ViewMain.MenuProjetoGerarFormText: string;
begin
  Result := 'Gerar Apenas Form e Classe';
  if meu_idioma = EN then Result := 'Generate Only Form and Class';
  if meu_idioma = ES then Result := 'Generar solo formulario y clase';
end;

class function ViewMain.MenuProjetoGerarFormHint: string;
begin
  Result := 'Se ativado, não gerará o projeto completo';
  if meu_idioma = EN then Result := 'If enabled, it will not generate the complete project.';
  if meu_idioma = ES then Result := 'Si está habilitado, no generará el proyecto completo.';
end;

class function ViewMain.MenuProjetoFormBarrraTitulo: string;
begin
  Result := 'FORM E BARRA DO TÍTULO';
  if meu_idioma = EN then Result := 'FORM AND TITLE BAR';
  if meu_idioma = ES then Result := 'FORMULARIO Y BARRA DE TÍTULO';
end;

class function ViewMain.MenuProjetoFormCor: string;
begin
  Result := 'COR DO FORM';
  if meu_idioma = EN then Result := 'FORM COLOR';
  if meu_idioma = ES then Result := 'COLOR DEL FORM';
end;

class function ViewMain.MenuProjetoCorBarra: string;
begin
  Result := 'COR BARRA TÍTULO';
  if meu_idioma = EN then Result := 'TITLE BAR COLOR';
  if meu_idioma = ES then Result := 'COLOR BARRA TÍTULO';
end;

class function ViewMain.MenuProjetoFormFonte: string;
begin
  Result := 'FONTE DO FORM';
  if meu_idioma = EN then Result := 'FORM FONT NAME';
  if meu_idioma = ES then Result := 'FUENTE DEL FORM';
end;

class function ViewMain.MenuProjetoTabelasPreparadas: string;
begin
  Result := 'TABELAS PREPARADAS:';
  if meu_idioma = EN then Result := 'PREPARED TABLES:';
  if meu_idioma = ES then Result := 'TABLAS PREPARADAS:';
end;

class function ViewMain.MenuProjetoTabelasPreparadasRefresh: string;
begin
  Result := 'Atualizar a Lista';
  if meu_idioma = EN then Result := 'Update the List';
  if meu_idioma = ES then Result := 'Actualizar la lista';
end;

class function ViewMain.MenuProjetoBotaoEditarTabelasText: string;
begin
  Result := PalavrasComuns.EditarTabelas;
end;

class function ViewMain.MenuProjetoBotaoEditarTabelasHint: string;
begin
  Result := 'Permite editar Tabelas e caraterísticas dos campos antes  de gerar o projeto';
  if meu_idioma = EN then Result := 'Allows you to edit Tables and field characteristics before generating the project';
  if meu_idioma = ES then Result := 'Permite editar tablas y características de campos antes de generar el proyecto';
end;

class function ViewMain.MenuProjetoBotaoGerarCrudText: string;
begin
  Result := PalavrasComuns.GerarProjeto;
end;

class function ViewMain.MenuProjetoBotaoGerarCrudHint: string;
begin
  Result := 'Gerar o projeto  completo ou apenas form e classe';
  if meu_idioma = EN then Result := 'Generate the complete project or just form and class';
  if meu_idioma = ES then Result := 'Generar el proyecto completo o solo formulario y clase';
end;

class function ViewMain.MenuProjetoBotaoPastaRaiz: string;
begin
  Result := 'Abrir a pasta do projeto';
  if meu_idioma = EN then Result := 'Open the project folder';
  if meu_idioma = ES then Result := 'Abra la carpeta del proyecto';
end;

class function ViewMain.MenuProjetoBotaoCompilarText: string;
begin
  Result := 'Compilar o Projeto';
  if meu_idioma = EN then Result := 'Compile the Project';
  if meu_idioma = ES then Result := 'Compilar el proyecto';
end;

class function ViewMain.MenuProjetoBotaoCompilarHint: string;
begin
  Result := 'Compilar o projeto';
  if meu_idioma = EN then Result := 'Compile the project';
  if meu_idioma = ES then Result := 'Compilar el proyecto';
end;

class procedure ViewMain.MenuProjetoGridCampos(var g: TDBGridPlus);
begin
  g.Columns[1].Title.Caption := PalavrasComuns.Tabelas;
  g.Columns[2].Title.Caption := PalavrasComuns.Campos;
end;

class function ViewMain.MenuProjetoBotaoGerarCrudMensagem1: string;
begin
  Result := 'Não há tabelas na lista!';
  if meu_idioma = EN then Result := 'There are no tables in the list!';
  if meu_idioma = ES then Result := '¡No hay tablas en la lista!';
end;

class function ViewMain.MenuProjetoBotaoGerarCrudMensagem2: string;
begin
  Result := 'Iniciar a criação do projeto ?';
  if meu_idioma = EN then Result := 'Start project creation ?';
  if meu_idioma = ES then Result := '¿Iniciar la creación del proyecto?';
end;

class function ViewMain.MenuProjetoBotaoGerarCrudMensagem3(AQde:Integer): string;
begin
  Result := 'Gerar arquivos das tabelas selecionadas ?' + sLineBreak + sLineBreak +
            'Total de tabelas: ' + IntToStr(AQde);
  if meu_idioma = EN then
    Result := 'Generate files from selected tables ?' + sLineBreak + sLineBreak +
              'Total tables: ' + IntToStr(AQde);
  if meu_idioma = ES then
    Result := '¿Generar archivos a partir de tablas seleccionadas?' + sLineBreak + sLineBreak +
              'Tablas totales: ' + IntToStr(AQde);
end;

class function ViewMain.MenuProjetoBotaoGerarCrudMensagem4: string;
begin
  Result := 'Projeto gerado com sucesso!';
  if meu_idioma = EN then Result := 'Project generated successfully!';
  if meu_idioma = ES then Result := '¡Proyecto generado exitosamente!';
end;

class function ViewMain.MenuProjetoBotaoGerarCrudMensagem5: string;
begin
  Result := 'Processo concluído com sucesso!';
  if meu_idioma = EN then Result := 'Process completed successfully!';
  if meu_idioma = ES then Result := 'Proceso completado exitosamente';
end;

class function ViewMain.MenuProjetoBotaoEditarTabelaMensagem1: string;
begin
  Result := 'Não há tabelas para editar!';
  if meu_idioma = EN then Result := 'There are no tables to edit!';
  if meu_idioma = ES then Result := '¡No hay tablas para editar!';
end;

class function ViewMain.MenuProjetoApenasFormChangeMsg1: string;
begin
  Result := 'Gerar Arquivos';
  if meu_idioma = EN then Result := 'Generate Files';
  if meu_idioma = ES then Result := 'Generar archivos';
end;

class function ViewMain.MenuProjetoApenasFormChangeMsg2: string;
begin
  Result := PalavrasComuns.GerarProjeto;
end;

class function ViewMain.MenuProjeto_MenuOpcionalText: string;
begin
  Result := 'Menu de exemplo';
  if meu_idioma = EN then Result := 'Sample menu';
  if meu_idioma = ES then Result := 'Menu de mustra';
end;

class function ViewMain.MenuProjeto_MenuOpcionalHint: string;
begin
  Result := 'Indica se deve criar itens opcionais de exemplo no menu ';
  if meu_idioma = EN then Result := 'Indicates whether to create optional sample items in the menu';
  if meu_idioma = ES then Result := 'Indica si se deben crear elementos de muestra opcionales en el menú';
end;

class function ViewMain.MenuProjeto_IncluirModuloChatText: string;
begin
  Result := 'Módulo CHAT';
  if meu_idioma = EN then Result := 'CHAT Module';
  if meu_idioma = ES then Result := 'Módulo de CHAT';
end;

class function ViewMain.MenuProjeto_IncluirModuloChatHint: string;
begin
  Result := 'Indica se deve incluir módulo de Chat';
  if meu_idioma = EN then Result := 'Indicates whether to include a Chat module';
  if meu_idioma = ES then Result := 'Indica si se debe incluir un módulo de chat';
end;

class function ViewMain.MenuProjetoLabelLogoTipoCaption: string;
begin
  Result := 'LOGO  (256 x 256) PNG';
  if meu_idioma = EN then Result := 'LOGO  (256 x 256) PNG';
  if meu_idioma = ES then Result := 'LOGO  (256 x 256) PNG';
end;

class function ViewMain.MenuProjetoBotaoCarregarLogotipoHint: string;
begin
  Result := 'Carregar Logotipo';
  if meu_idioma = EN then Result := 'Load Logo';
  if meu_idioma = ES then Result := 'Cargar Logotipo';
end;

class function ViewMain.MenuProjetoBotaoRemoverLogotipoHint: string;
begin
  Result := 'Excluir Logotipo';
  if meu_idioma = EN then Result := 'Delete Logo';
  if meu_idioma = ES then Result := 'Eliminar logotipo';
end;

class function ViewMain.MenuProjetoCarregarLogoMensagem1: string;
begin
  Result := 'Não é um imagem PNG válida';
  if meu_idioma = EN then Result := 'This is not a valid PNG image';
  if meu_idioma = ES then Result := 'Esta no es una imagen PNG válida.';
end;

class function ViewMain.MenuProjetoCarregarLogoMensagem2: string;
begin
  Result := 'Imagem não encontrada';
  if meu_idioma = EN then Result := 'Image not found';
  if meu_idioma = ES then Result := 'Imagen no encontrada';
end;

class function ViewMain.MenuTabelasBotaoCarregarTabelasText: string;
begin
  Result := 'Obter Tabelas do Banco de Dados';
  if meu_idioma = EN then Result := 'Get Database Tables';
  if meu_idioma = ES then Result := 'Obtener tablas de bases de datos';
end;

class function ViewMain.MenuTabelasBotaoCarregarTabelasHint: string;
begin
  Result := 'Obter as tabelas do banco de dados';
  if meu_idioma = EN then Result := 'Get the database tables';
  if meu_idioma = ES then Result := 'Obtener tablas de bases de datos';
end;

class function ViewMain.MenuTabelasLabelListagem: string;
begin
  Result := 'LISTA DE TABELAS NO SERVIDOR (DB)';
  if meu_idioma = EN then Result := 'LIST OF TABLES ON THE SERVER (DB)';
  if meu_idioma = ES then Result := 'LISTA DE TABLAS EN EL SERVIDOR (BD)';
end;

class procedure ViewMain.MenuTabelasGridCampos(var g: TDBGridPlus);
begin
  g.Columns[0].Title.Caption := 'NOME DA TABELA';
  if meu_idioma = EN then
    g.Columns[0].Title.Caption := 'TABLE NAME';
  if meu_idioma = ES then
    g.Columns[0].Title.Caption := 'NOMBRE DE LA TABLA';
end;

class function ViewMain.MenuTabelasBotaoEditarText: string;
begin
  Result := PalavrasComuns.EditarTabelas;
end;

class function ViewMain.MenuTabelasBotaoEditarHint: string;
begin
  Result := 'Editar tabelas e campos';
  if meu_idioma = EN then Result := 'Edit tables and fields';
  if meu_idioma = ES then Result := 'Editar tablas y campos';
end;

class function ViewMain.MenuTabelasLabelListaTabelas: string;
begin
  Result := 'Tabelas da Lista';
  if meu_idioma = EN then Result := 'Tables Of The List';
  if meu_idioma = ES then Result := 'Tablas de listas';
end;

class function ViewMain.MenuTabelasCheckCriarFormPesquisaText: string;
begin
  Result := 'CRIAR FORM DE PESQUISA';
  if meu_idioma = EN then Result := 'CREATE SEARCH FORM';
  if meu_idioma = ES then Result := 'CREAR FORM DE BÚSQUEDA';
end;

class function ViewMain.MenuTabelasCheckCriarFormPesquisaHint: string;
begin
  Result := 'Diz se deve criar um form de pesquisa para a tabela';
  if meu_idioma = EN then Result := 'Tells whether to create a search form for the table';
  if meu_idioma = ES then Result := 'Indica si se debe crear un formulario de búsqueda para la tabla';
end;

class function ViewMain.MenuTabelasCheckCriarGridText: string;
begin
  Result := 'CRIAR DBGRID NO FORM';
  if meu_idioma = EN then Result := 'CREATE DBGRID IN FORM';
  if meu_idioma = ES then Result := 'CREAR DBGRID EN EL FORM';
end;

class function ViewMain.MenuTabelasCheckCriarGridHint: string;
begin
  Result := 'Diz se deverá criar uma Grid no Form para a tabela';
  if meu_idioma = EN then Result := 'Tells whether to create a Grid in the Form for the table';
  if meu_idioma = ES then Result := 'Indica si se debe crear una cuadrícula en el formulario para la tabla';
end;

class function ViewMain.MenuTabelasBotaoProcessarTabelasText: string;
begin
  Result := 'Processar Tabelas';
  if meu_idioma = EN then Result := 'Process Tables';
  if meu_idioma = ES then Result := 'Procesar Tablas';
end;

class function ViewMain.MenuTabelasBotaoProcessarTabelasHint: string;
begin
  Result := 'Extrair campos das tabelas da lista';
  if meu_idioma = EN then Result := 'Extract fields from list tables';
  if meu_idioma = ES then Result := 'Extraer campos de tablas de listas';
end;

class function ViewMain.MenuTabelasBotaoProcessarTabelasMensagem1: string;
begin
  Result := 'Não há tabelas na lista!';
  if meu_idioma = EN then Result := 'There are no tables in the list!';
  if meu_idioma = ES then Result := '¡No hay tablas en la lista!';
end;

class function ViewMain.MenuTabelasBotaoProcessarTabelasMensagem2(AQde: Integer): string;
begin
  Result := 'Processar as tabelas da lista ?' + sLineBreak + sLineBreak +
            'Total de tabelas: ' + IntToStr(AQde);
  if meu_idioma = EN then
    Result := 'Process the tables of the list ?' + sLineBreak + sLineBreak +
            'Total tables: ' + IntToStr(AQde);
  if meu_idioma = ES then
    Result := '¿Procesar las tablas de la lista?' + sLineBreak + sLineBreak +
            'Total de tablas: ' + IntToStr(AQde);
end;

class function ViewMain.MenuTabelasBotaoProcessarTabelasMensagem3: string;
begin
  Result := 'Tabelas processadas com sucesso!';
  if meu_idioma = EN then Result := 'Tables processed successfully!';
  if meu_idioma = ES then Result := '¡Tablas procesadas exitosamente!';
end;

class function ViewMain.MenuTabelasLabelScripts: string;
begin
  Result := 'Script de Tabela';
  if meu_idioma = EN then Result := 'Table Script';
  if meu_idioma = ES then Result := 'Script de Tabla';
end;

class function ViewMain.MenuTabelasBotaoScriptText: string;
begin
  Result := 'Processar Script';
  if meu_idioma = EN then Result := 'Process Script';
  if meu_idioma = ES then Result := 'Procesar Script';
end;

class function ViewMain.MenuTabelasBotaoScriptHint: string;
begin
  Result := 'Extrair campos da tabela do script';
  if meu_idioma = EN then Result := 'Extrair campos da tabela do script';
  if meu_idioma = ES then Result := 'Extraer campos de la tabla de scripts';
end;

class function ViewMain.MenuTabelasBotaoScriptMensagem1: string;
begin
  Result := 'Não há informações de script de criação de tabela';
  if meu_idioma = EN then Result := 'No table creation script information';
  if meu_idioma = ES then Result := 'No hay información del script de creación de tabla';
end;

class function ViewMain.MenuTabelasBotaoScriptMensagem2: string;
begin
  Result := 'Processar o script de criação de tabela ?';
  if meu_idioma = EN then Result := 'Process table creation script ?';
  if meu_idioma = ES then Result := '¿Script de creación de tabla de procesos?';
end;

class function ViewMain.MenuTabelasBotaoScriptMensagem3: string;
begin
  Result := 'Script processado com sucesso!';
  if meu_idioma = EN then Result := 'Script processed successfully!';
  if meu_idioma = ES then Result := '¡Script procesado exitosamente!';
end;

class function ViewMain.MenuTabelasScriptBox: string;
begin
  Result := 'SCRIPT DE CRIAÇÃO DA TEBELA';
  if meu_idioma = EN then Result := 'SCRIPT TO CREATE TABLE';
  if meu_idioma = ES then Result := 'SCRIPT DE CREACIÓN DE TABLA';
end;

class function ViewMain.MenuTabelasExemplo1Text: string;
begin
  Result := 'Exemplo-1';
  if meu_idioma = EN then Result := 'Example-1';
  if meu_idioma = ES then Result := 'Ejemplo-1';
end;

class function ViewMain.MenuTabelasExemplo1Hint: string;
begin
  Result := 'Modelo de script criação de tabela';
  if meu_idioma = En then Result := 'Table creation script template';
  if meu_idioma = ES then Result := 'Plantilla de script para crear tablas';
end;

class function ViewMain.MenuTabelasExemplo2Text: string;
begin
  Result := 'Exemplo-2';
  if meu_idioma = EN then Result := 'Example-2';
  if meu_idioma = ES then Result := 'Ejemplo-2';
end;

class function ViewMain.MenuTabelasExemplo2Hint: string;
begin
  Result := 'Modelo de script criação de múltiplas tabelas';
  if meu_idioma = En then Result := 'Multiple Table Creation Script Template';
  if meu_idioma = ES then Result := 'Plantilla de script para crear varias tablas';
end;

class function ViewMain.MenuTabelasMemoLimpar: string;
begin
  Result := 'Limpa o campo de script';
  if meu_idioma = EN then Result := 'Clears the script field';
  if meu_idioma = ES then Result := 'Borra el campo de script';
end;

class function ViewMain.MenuTabelasBotaoEditarMensagem1: string;
begin
  Result := 'Não há tabelas para editar!';
  if meu_idioma = EN then Result := 'There are no tables to edit!';
  if meu_idioma = ES then Result := '¡No hay tablas para editar!';
end;

class function ViewMain.MenuTabelasInfoTabelasMensagem1: string;
begin
  Result := 'Nenhuma tabela foi informada.';
  if meu_idioma = EN then Result := 'No table was provided.';
  if meu_idioma = ES then Result := 'No se proporcionó ninguna tabla.';
end;

class function ViewMain.MenuApiSalvarMensagem1: string;
begin
  Result := 'Informe os dados para criação do REST API';
  if meu_idioma = EN then Result := 'Provide the data for creating the REST API.';
  if meu_idioma = ES then Result := 'Proporcione los datos necesarios para crear la API REST.';
end;

class function ViewMain.MenuApiExcluirMensagem1: string;
begin
  Result := 'Deseja excluir esta API ?';
  if meu_idioma = EN then Result := 'Do you want to delete this API?';
  if meu_idioma = ES then Result := '¿Quieres eliminar esta API?';
end;

class function ViewMain.MenuApiLabelVersaoCaption: string;
begin
  Result := 'VERSÃO DA API  ( /api/v1 )';
  if meu_idioma = EN then Result := 'API VERSION  ( /api/v1 )';
  if meu_idioma = ES then Result := 'VERSIÓN DE LA API  ( /api/v1 )';
end;

class function ViewMain.MenuApiLabelAdminCaption: string;
begin
  Result := 'NOME DO ADMINSTRADOR';
  if meu_idioma = EN then Result := 'ADMINSTRADOR''S NAME';
  if meu_idioma = ES then Result := 'NOMBRE DEL ADMINISTRADOR';
end;

class function ViewMain.MenuApiLabelAdminEmailCaption: string;
begin
  Result := 'EMAIL DO ADMINSTRADOR';
  if meu_idioma = EN then Result := 'ADMINSTRADOR''S EMAIL';
  if meu_idioma = ES then Result := 'EMAIL DEL ADMINISTRADOR';
end;

class function ViewMain.MenuApiLabelApiNameCaption: string;
begin
  Result := 'NOME DA API';
  if meu_idioma = EN then Result := 'API NAME';
  if meu_idioma = ES then Result := 'NOMBRE DE LA API';
end;

class function ViewMain.MenuApiLabelApiTituloCaption: string;
begin
  Result := 'TÍTULO DA API';
  if meu_idioma = EN then Result := 'API TITLE';
  if meu_idioma = ES then Result := 'TÍTULO API';
end;

class function ViewMain.MenuApiLabelDescricaoCaption: string;
begin
  Result := 'DESCRIÇÃO DA API';
  if meu_idioma = EN then Result := 'API DESCRIPTION';
  if meu_idioma = ES then Result := 'DESCRIPCIÓN DE LA API';
end;

class function ViewMain.MenuApiBotaoGerarApiCaption: string;
begin
  Result := 'Gerar Projeto da API';
  if meu_idioma = EN then Result := 'Generate API Project';
  if meu_idioma = ES then Result := 'Generar proyecto de API';
end;

class function ViewMain.MenuApiBotaoGerarApiHint: string;
begin
  Result := 'Gerar o projeto completo da API';
  if meu_idioma = EN then Result := 'Generate the complete API project';
  if meu_idioma = ES then Result := 'Generar el proyecto API completo';
end;

class function ViewMain.MenuApiBotaoPastaProjetoHint: string;
begin
  Result := 'Abrir a pasta do projeto REST API';
  if meu_idioma = EN then Result := 'Open the REST API project folder';
  if meu_idioma = ES then Result := 'Abra la carpeta del proyecto de la API REST';
end;

class function ViewMain.MenuApiCheckBoxGerarServiceClasseCaption: string;
begin
  Result := 'GERAR CLASSE DE SERVIÇO';
  if meu_idioma = EN then Result := 'GENERATE SERVICE CLASS';
  if meu_idioma = ES then Result := 'GENERAR CLASSE DE SERVICIO';
end;

class function ViewMain.MenuApiCheckBoxGerarServiceClasseHint: string;
begin
  Result := 'Gera classe de operações nas tabelas (crud)';
  if meu_idioma = EN then Result := 'Generates a class of operations on tables (CRUD)';
  if meu_idioma = ES then Result := 'Genera una clase de operaciones en tablas (CRUD)';
end;

class function ViewMain.MenuApiCheckBoxAuditCaption: string;
begin
  Result := 'AUDITAR ROTAS';
  if meu_idioma = EN then Result := 'AUDIT ROUTES';
  if meu_idioma = ES then Result := 'RUTAS DE AUDITORÍA';
end;

class function ViewMain.MenuApiCheckBoxAuditHint: string;
begin
  Result := 'Registra ocorrências nas rotas (Post, Put, Patch, delete) para auditoria';
  if meu_idioma = EN then Result := 'Records occurrences on routes (Post, Put, Patch, delete) for auditing';
  if meu_idioma = ES then Result := 'Registra ocurrencias en rutas (publicar, colocar, parchear, eliminar) para auditoría';
end;

class function ViewMain.MenuApiCheckBoxBoletoCaption: string;
begin
  Result := 'MÓDULO BOLETO BANCÁRIO';
  if meu_idioma = EN then Result := 'BANK SLIP MODULE';
  if meu_idioma = ES then Result := 'MÓDULO DE COMPROBANTE BANCARIO';
end;

class function ViewMain.MenuApiCheckBoxBoletoHint: string;
begin
  Result := 'Cria os módulos para boleto bancário e PIX';
  if meu_idioma = EN then Result := 'Creates modules for bank slips and PIX.';
  if meu_idioma = ES then Result := 'Crea módulos para comprobantes bancarios y PIX.';
end;

class function ViewMain.ApiNenhumaTabelaIndicada: string;
begin
  Result := 'Nenhuma Tabela indicada para gerar a API';
  if meu_idioma = EN then Result := 'No table specified for generating the API.';
  if meu_idioma = ES then Result := 'No se ha especificado ninguna tabla para generar la API.';
end;

{ ViewEditarTabela }

class function ViewEditarTabela.Titulo: string;
begin
  Result := 'EDIÇÃO DE TABELAS E CAMPOS';
  if meu_idioma = EN then Result := 'EDITING TABLES AND FIELDS';
  if meu_idioma = ES then Result := 'EDICIÓN DE TABLAS Y CAMPOS';
end;

class function ViewEditarTabela.MenuTabelaText: string;
begin
  Result := PalavrasComuns.Tabelas;
end;

class function ViewEditarTabela.MenuTabelaHint: string;
begin
  Result := 'Edição de Tabelas';
  if meu_idioma = EN then Result := 'Table Editing';
  if meu_idioma = ES then Result := 'Edición de tablas';
end;

class function ViewEditarTabela.MenuTabelaLabelTabelasPreparadas: string;
begin
  Result := 'TABELAS PREPARADAS:';
  if meu_idioma = EN then Result := 'PREPARED TABLES:';
  if meu_idioma = ES then Result := 'TABLAS PREPARADAS:';
end;

class procedure ViewEditarTabela.MenuTabelaGrid(var g: TDBGridPlus);
begin
  g.Columns[1].Title.Caption := PalavrasComuns.Tabelas;
  g.Columns[2].Title.Caption := PalavrasComuns.Rota;
  g.Columns[3].Title.Caption := PalavrasComuns.Campos;
end;

class function ViewEditarTabela.MenuTabelaLabelDados: string;
begin
  Result := 'Dados da Tabela';
  if meu_idioma = EN then Result := 'Table Data';
  if meu_idioma = ES then Result := 'Datos de la tabla';
end;

class function ViewEditarTabela.MenuTabelaLabelNomeTabela: string;
begin
  Result := 'TABELA';
  if meu_idioma = EN then Result := 'TABLE';
  if meu_idioma = ES then Result := 'TABLA';
end;

class function ViewEditarTabela.MenuTabelaLabelNomeObjeto: string;
begin
  Result := 'NOME DO OBJETO';
  if meu_idioma = EN then Result := 'OBJECT NAME';
  if meu_idioma = ES then Result := 'NOMBRE DEL OBJETO';
end;

class function ViewEditarTabela.MenuTabelaLabelDescricao: string;
begin
  Result := 'DESCRIÇÃO';
  if meu_idioma = EN then Result := 'DESCRIPTION';
  if meu_idioma = ES then Result := 'DESCRIPCIÓN';
end;

class function ViewEditarTabela.MenuTabelaLabelScript: string;
begin
  Result := 'SCRIPT DE CRIAÇÃO DA TABELA  (OPCIONAL)';
  if meu_idioma = EN then Result := 'TABLE CREATION SCRIPT (OPTIONAL)';
  if meu_idioma = ES then Result := 'SCRIPT DE CREACIÓN DE TABLA (OPCIONAL)';
end;

class function ViewEditarTabela.MenuTabelaCheckCriarFormText: string;
begin
  Result := 'CRIAR FORM DE PESQUISA';
  if meu_idioma = EN then Result := 'CREATE SEARCH FORM';
  if meu_idioma = ES then Result := 'CREAR FORM DE BÚSQUEDA';
end;

class function ViewEditarTabela.MenuTabelaCheckCriarFormHint: string;
begin
  Result := 'Diz se deve criar um form de pesquisa para a tabela';
  if meu_idioma = EN then Result := 'Tells whether to create a search form for the table';
  if meu_idioma = ES then Result := 'Indica si se debe crear un formulario de búsqueda para la tabla';
end;

class function ViewEditarTabela.MenuTabelaCheckCriarGridText: string;
begin
  Result := 'CRIAR DBGRID NO FORM';
  if meu_idioma = EN then Result := 'CREATE DBGRID IN FORM';
  if meu_idioma = ES then Result := 'CREAR DBGRID EN EL FORM';
end;

class function ViewEditarTabela.MenuTabelaCheckCriarGridHint: string;
begin
  Result := 'Diz se deverá criar uma Grid no Form para a tabela';
  if meu_idioma = EN then Result := 'Tells whether to create a Grid in the Form for the table';
  if meu_idioma = ES then Result := 'Indica si se debe crear una cuadrícula en el formulario para la tabla';
end;

class function ViewEditarTabela.MenuTabelaCheckCriarReportText: string;
begin
  Result := 'CRIAR RELATÓRIO';
  if meu_idioma = EN then Result := 'CREATE REPORT';
  if meu_idioma = ES then Result := 'CREAR INFORME';
end;

class function ViewEditarTabela.MenuTabelaCheckCriarReportHint: string;
begin
  Result := 'Diz se deverá criar um relatório com Fortes Report CE,' + sLineBreak +
            'com base nos campos selecionados para o DBGrid.';
  if meu_idioma = EN then
    Result := 'Tells whether to create a report with Fortes Report CE,' + sLineBreak +
              'based on the fields selected for the DBGrid.';
  if meu_idioma = ES then
    Result := 'Especifica si se debe crear un informe con Fortes Report CE,' + sLineBreak +
              'basado en los campos seleccionados para DBGrid.';
end;

class function ViewEditarTabela.MenuTabelaCheckCriarApiText: string;
begin
  Result := 'CRIAR ROTA NA API';
  if meu_idioma = EN then Result := 'CREATE ROUTE IN API';
  if meu_idioma = ES then Result := 'CREAR RUTA EN LA API';
end;

class function ViewEditarTabela.MenuTabelaCheckCriarApiHint: string;
begin
  Result := 'Indica se deverá criar Rota na API';
  if meu_idioma = EN then Result := 'Indicates whether a route should be created in the API';
  if meu_idioma = ES then Result := 'Indica si se debe crear una ruta en la API.';
end;

class function ViewEditarTabela.MenuTabelaCheckIsForAuthText: string;
begin
  Result := 'TABELA DE AUTENTICAÇÃO';
  if meu_idioma = EN then Result := 'AUTHENTICATION TABLE';
  if meu_idioma = ES then Result := 'TABLA DE AUTENTICACIÓN';
end;

class function ViewEditarTabela.MenuTabelaCheckIsForAuthHint: string;
begin
  Result := 'Diz se esta tabela é para autenticação de usuário';
  if meu_idioma = EN then Result := 'It indicates whether this table is for user authentication.';
  if meu_idioma = ES then Result := 'Indica si esta tabla es para autenticación de usuarios.';
end;

class function ViewEditarTabela.MenuTabelaLabelApiRotaCaption: string;
begin
  Result := 'ROTA  (EX:  /produto, /cliente )';
  if meu_idioma = EN then Result := 'ROUTE  (EX:  /product, /customer )';
  if meu_idioma = ES then Result := 'RUTA  (EX:  /producto, /cliente )';
end;

class function ViewEditarTabela.MenuTabelaBotaoSalvarText: string;
begin
  Result := PalavrasComuns.Salvar;
end;

class function ViewEditarTabela.MenuTabelaBotaoSalvarMensagem1: string;
begin
  Result := 'Não há um tabela em edição!' + sLineBreak + 'Não pode criar uma nova tabela por aqui.';
  if meu_idioma = EN then Result := 'There is no table in editing!' + sLineBreak + 'No puedes crear una nueva tabla aquí.';
  if meu_idioma = ES then Result := '¡No hay tabla en la edición!' + sLineBreak + 'No puedes crear una nueva tabla aquí.';
end;

class function ViewEditarTabela.MenuTabelaBotaoSalvarMensagem2: string;
begin
  Result := 'Confirma a alteração de dados desta tabela ?';
  if meu_idioma = EN then Result := 'Confirm the data change in this table ?';
  if meu_idioma = ES then Result := '¿Confirmas el cambio de datos en esta tabla?';
end;

class function ViewEditarTabela.MenuTabelaBotaoExcluirText: string;
begin
  Result := PalavrasComuns.Excluir;
end;

class function ViewEditarTabela.MenuTabelaBotaoExcluirMensagem1: string;
begin
  Result := 'Não há um tabela em edição!';
  if meu_idioma = EN then Result := 'There is no table in editing!';
  if meu_idioma = ES then Result := '¡No hay tabla en la edición!';
end;

class function ViewEditarTabela.MenuTabelaBotaoExcluirMensagem2: string;
begin
   Result := 'Deseja excluir esta tabela e todos os seus campos ?';
   if meu_idioma = EN then Result := 'Do you want to delete this table and all its fields?';
   if meu_idioma = ES then Result := '';
end;

class function ViewEditarTabela.MenuTabelaBotaoNovoText: string;
begin
  Result := PalavrasComuns.Novo;
end;

class function ViewEditarTabela.MenuCampoText: string;
begin
  Result := PalavrasComuns.Campos;
end;

class function ViewEditarTabela.MenuCampoHint: string;
begin
  Result := 'Edição de Campos da Tabela';
  if meu_idioma = EN then Result := 'Editing Table Fields';
  if meu_idioma = ES then Result := 'Edición de campos de tabla';
end;

class function ViewEditarTabela.MenuCampoLabelTabelas: string;
begin
  Result := 'CAMPOS DA TABELA:';
  if meu_idioma = EN then Result := 'TABLE FIELDS:';
  if meu_idioma = ES then Result := 'CAMPOS DE LA TABLA:';
end;

class procedure ViewEditarTabela.MenuCampoGrid(var g: TDBGridPlus);
begin
  g.Columns[1].Title.Caption := 'CAMPO';
  g.Columns[2].Title.Caption := 'TIPO';
  g.Columns[3].Title.Caption := 'OBJETO';
  if meu_idioma = EN then begin
    g.Columns[1].Title.Caption := 'FIELD';
    g.Columns[2].Title.Caption := 'TYPE';
    g.Columns[3].Title.Caption := 'OBJECT';
  end;
  if meu_idioma = ES then begin
    g.Columns[1].Title.Caption := 'CAMPO';
    g.Columns[2].Title.Caption := 'TIPO';
    g.Columns[3].Title.Caption := 'OBJETO';
  end;
end;

class function ViewEditarTabela.MenuCampoTabelaSelecionada(ATabela: string): string;
begin
  Result := 'TABELA: [ ' + ATabela + ' ]';
  if meu_idioma = EN then Result := 'TABLE: [ ' + ATabela + ' ]';
  if meu_idioma = ES then Result := 'TABLA: [ ' + ATabela + ' ]';
end;

class function ViewEditarTabela.MenuCampoLabelDados: string;
begin
  Result := 'Dados do Campo';
  if meu_idioma = EN then Result := 'Field Data';
  if meu_idioma = ES then Result := 'Datos de campo';
end;

class function ViewEditarTabela.MenuCampoLabelFied: string;
begin
  Result := 'NOME DO CAMPO';
  if meu_idioma = EN then Result := 'FIELD NAME';
  if meu_idioma = ES then Result := 'NOMBRE DEL CAMPO';
end;

class function ViewEditarTabela.MenuCampoLabelFiedAliasCaption: string;
begin
  Result := 'CAMPO ALIAS';
  if meu_idioma = EN then Result := 'FIELD ALIAS';
  if meu_idioma = ES then Result := 'ALIAS DE CAMPO';
end;

class function ViewEditarTabela.MenuCampoLabelFiedAliasHint: string;
begin
  Result := 'Alias do campo para ser utilizado pelo usuário na API, não expondo o nome original do campo.';
  if meu_idioma = EN then Result := 'Alias for the field to be used by the user in the API, without exposing the original field name.';
  if meu_idioma = ES then Result := 'Alias para el campo que utilizará el usuario en la API, sin exponer el nombre original del campo.';
end;

class function ViewEditarTabela.MenuCampoLabelObjeto: string;
begin
  Result := 'NOME DO OBJETO';
  if meu_idioma = EN then Result := 'OBJECT NAME';
  if meu_idioma = ES then Result := 'NOMBRE DEL OBJETO';
end;

class function ViewEditarTabela.MenuCampoLabelObjetoHint: string;
begin
  Result := 'Nome do objeto identificador no Form e Classe';
  if meu_idioma = EN then Result := 'Name of the identifier object in the Form and Class';
  if meu_idioma = ES then Result := 'Nombre del objeto identificador en el Formulario y la Clase';
end;

class function ViewEditarTabela.MenuCampoLabelTipo: string;
begin
  Result := 'TIPO (Int, varchar, etc)';
  if meu_idioma = EN then Result := 'TYPE (Int, varchar, etc.)';
  if meu_idioma = ES then Result := 'TIPO (Int, varchar, etc)';
end;

class function ViewEditarTabela.MenuCampoLabelTamanho: string;
begin
  Result := 'TAMANHO (MaxLength)';
  if meu_idioma = EN then Result := 'MAXLENGTH';
  if meu_idioma = ES then Result := 'TAMAÑO (MaxLength)';
end;

class function ViewEditarTabela.MenuCampoLabelPrecisao: string;
begin
  Result := 'PRECISÃO';
  if meu_idioma = EN then Result := 'PRECISION';
  if meu_idioma = ES then Result := 'PRECISIÓN';
end;

class function ViewEditarTabela.MenuCampoLabelEscala: string;
begin
  Result := 'ESCALA';
  if meu_idioma = EN then Result := 'SCALE';
  if meu_idioma = EN then Result := 'ESCALA';
end;

class function ViewEditarTabela.MenuCampoLabelTipoLazarus: string;
begin
  Result := 'TIPO DE DADO NO LAZARUS';
  if meu_idioma = EN then Result := 'LAZARUS DATA TYPE';
  if meu_idioma = ES then Result := 'TIPO DE DATOS EN LAZARUS';
end;

class function ViewEditarTabela.MenuCampoLabelComponente: string;
begin
  Result := 'COMPONENTE A SER UTILIZADO';
  if meu_idioma = EN then Result := 'COMPONENT TO BE USED';
  if meu_idioma = ES then Result := 'COMPONENTE A UTILIZAR';
end;

class function ViewEditarTabela.MenuCampoLabelCampoEspecial: string;
begin
  Result := 'CAMPO ESPECIAL';
  if meu_idioma = EN then Result := 'SPECIAL FIELD';
  if meu_idioma = ES then Result := 'CAMPO ESPECIAL';
end;

class function ViewEditarTabela.MenuCampoLabelDescricao: string;
begin
   Result := 'DESCRIÇÃO DESTE CAMPO';
  if meu_idioma = EN then Result := 'DESCRIPTION OF THIS FIELD';
  if meu_idioma = ES then Result := 'DESCRIPCIÓN DE ESTE CAMPO';
end;

class function ViewEditarTabela.MenuCampoLabelFonteDados: string;
begin
  Result := 'FONTE DE DADOS EXTERNA';
  if meu_idioma = EN then Result := 'FOREIGN DATA SOURCE';
  if meu_idioma = ES then Result := 'FUENTE DE DATOS EXTRANJERA';
end;

class function ViewEditarTabela.MenuCampoLabelComboTabela: string;
begin
  Result := 'NOME DA TABELA';
  if meu_idioma = EN then Result := 'TABLE NAME';
  if meu_idioma = ES then Result := 'NOMBRE DE LA TABLA';
end;

class function ViewEditarTabela.MenuCampoLabelComboTabelaExemplo: string;
begin
  Result := 'cidades';
  if meu_idioma = EN then Result := 'cities';
  if meu_idioma = ES then Result := 'ciudades';
end;

class function ViewEditarTabela.MenuCampoLabelComboCodigo: string;
begin
  Result := 'CAMPO CÓDIGO';
  if meu_idioma = EN then Result := 'CODE FIELD';
  if meu_idioma = ES then Result := 'CAMPO CÓDIGO';
end;

class function ViewEditarTabela.MenuCampoLabelComboCodigoExemplo: string;
begin
  Result := 'idcidade';
  if meu_idioma = EN then Result := 'idcity';
  if meu_idioma = ES then Result := 'idciudad';
end;

class function ViewEditarTabela.MenuCampoLabelComboTexto: string;
begin
  Result := 'CAMPO TEXTO';
  if meu_idioma = EN then Result := 'TEXT FIELD';
  if meu_idioma = ES then Result := 'CAMPO TEXTO';
end;

class function ViewEditarTabela.MenuCampoLabelComboTextoExemplo: string;
begin
  Result := 'nome_cidade';
  if meu_idioma = EN then Result := 'city_name';
  if meu_idioma = ES then Result := 'nombre_ciudad';
end;

class function ViewEditarTabela.MenuCampoLabelComboValores: string;
begin
  Result := 'VALORES ALTERNATIVOS';
  if meu_idioma = EN then Result := 'ALTERNATIVE VALUES';
  if meu_idioma = ES then Result := 'VALORES ALTERNATIVOS';
end;

class function ViewEditarTabela.MenuCampoLabelComboValoresHint: string;
begin
  Result := 'VERDE' + sLineBreak + 'AMARELO' + sLineBreak + 'AZUL' + sLineBreak + 'BRANCO';
  if meu_idioma = ES then Result := 'GREEN' + sLineBreak + 'YELLO' + sLineBreak + 'BLUE' + sLineBreak + 'WHITE';
  if meu_idioma = ES then Result := 'VERDE' + sLineBreak + 'AMARILLO' + sLineBreak + 'AZUL' + sLineBreak + 'BLANCO';
end;

class function ViewEditarTabela.MenuCampoCheckChavePrimariaText: string;
begin
  Result := 'É CHAVE PRIMÁRIA';
  if meu_idioma = EN then Result := 'IT IS PRIMARY KEY';
  if meu_idioma = ES then Result := 'ES CLAVE PRINCIPAL';
end;

class function ViewEditarTabela.MenuCampoCheckChavePrimariaHint: string;
begin
  Result := 'Diz se este campo é chave primária';
  if meu_idioma = EN then Result := 'Indicates if this field is a primaty key';
  if meu_idioma = ES then Result := 'Indica si este campo es una clave principal';
end;

class function ViewEditarTabela.MenuCampoCheckAceitaNuloText: string;
begin
  Result := 'PERMITE NULO';
  if meu_idioma = EN then Result := 'ALLOW NULL';
  if meu_idioma = ES then Result := 'PERMITIR NULO';
end;

class function ViewEditarTabela.MenuCampoCheckAceitaNuloHint: string;
begin
  Result := 'Permite valor  nulo';
  if meu_idioma = EN then Result := 'Allows null value';
  if meu_idioma = ES then Result := 'Permite valor nulo';
end;

class function ViewEditarTabela.MenuCampoCheckChaveEstrangeiraText: string;
begin
  Result := 'É CHAVE ESTRANGEIRA';
  if meu_idioma = EN then Result := 'IT IS FOREIGN KEY';
  if meu_idioma = ES then Result := 'ES CLAVE EXTRANJERA';
end;

class function ViewEditarTabela.MenuCampoCheckChaveEstrangeiraHint: string;
begin
  Result := 'Diz se este campo é chave estrangeira';
  if meu_idioma = EN then Result := 'Indicates if this field is a foreign key';
  if meu_idioma = ES then Result := 'Indica si este campo es una clave extranjera';
end;

class function ViewEditarTabela.MenuCampoCheckMonetarioText: string;
begin
  Result := 'ESTE CAMPO É MONETÁRIO OU PERCENTUAL';
  if meu_idioma = EN then Result := 'THIS FIELD IS MONEY OR PERTCENT';
  if meu_idioma = ES then Result := 'ESTE CAMPO ES MONETARIO O PORCENTUAL';
end;

class function ViewEditarTabela.MenuCampoCheckMonetarioHint: string;
begin
  Result := 'Diz se este campo é para edição de valores monetário ou de porcentagem';
  if meu_idioma = EN then Result := 'Tells whether this field is for editing monetary or percentage values';
  if meu_idioma = ES then Result := 'Indica si este campo es para editar valores monetarios o porcentuales';
end;

class function ViewEditarTabela.MenuCampoCheckExcluirCrudText: string;
begin
  Result := 'EXCLUIR DO INSERT/UPDATE (EXIU)';
  if meu_idioma = EN then Result := 'EXCLUDE FROM INSERT/UPDATE (EXIU)';
  if meu_idioma = ES then Result := 'EXCLUIR DE INSERTAR/ACTUALIZAR (EXIU)';
end;

class function ViewEditarTabela.MenuCampoCheckExcluirCrudHint: string;
begin
  Result := 'Não incluir este campo na operação de Insert e Update';
  if meu_idioma = EN then Result := 'Exclude this field on CRUD operation';
  if meu_idioma = ES then Result := 'No incluya este campo en la operación Insertar y Actualizar';
end;

class function ViewEditarTabela.MenuCampoCheckIncluirGridText: string;
begin
  Result := 'INCLUIR NA LISTA DO DBGRID';
  if meu_idioma = EN then Result := 'INCLUDE ON DBGRID LIST';
  if meu_idioma = ES then Result := 'INCLUIR EN LA LISTA DBGRID';
end;

class function ViewEditarTabela.MenuCampoCheckIncluirGridHint: string;
begin
  Result := 'Este campo será adicionado à listagem no DBGrid';
  if meu_idioma = EN then Result := 'This field will be add to DBGRID list';
  if meu_idioma = ES then Result := 'Este campo se agregará al listado en DBGrid';
end;

class function ViewEditarTabela.MenuCampoCheckRequeridoText: string;
begin
  Result := PalavrasComuns.CamposRequeridos.ToUpper;
end;

class function ViewEditarTabela.MenuCampoCheckRequeridoHint: string;
begin
  Result := 'Diz se este campo é requerido para entrar no banco de dados';
  if meu_idioma = EN then Result := 'Indicates if this field is required to enter on database';
  if meu_idioma = ES then Result := 'Indica si este campo es obligatorio para ingresar a la base de datos';
end;

class function ViewEditarTabela.MenuCampoCheckReportSomatorioText: string;
begin
  Result := 'CAMPO SOMATÓRIO';
  if meu_idioma = EN then Result := 'SUM FIELD';
  if meu_idioma = ES then Result := 'CAMPO SUMA';
end;

class function ViewEditarTabela.MenuCampoCheckReportSomatorioHint: string;
begin
  Result := 'Diz se é campo somatório no relatório';
  if meu_idioma = EN then Result := 'Tells if it is a sum field in the report';
  if meu_idioma = ES then Result := 'Indica si es un campo de suma en el informe';
end;

class function ViewEditarTabela.MenuCampoCheckRemoverMaskText: string;
begin
  Result := 'REMOVER MÁSCARA';
  if meu_idioma = EN then Result := 'REMOVE MASK';
  if meu_idioma = ES then Result := 'SIN MASCARILLA';
end;

class function ViewEditarTabela.MenuCampoCheckRemoverMaskHint: string;
begin
  Result := 'Remover a máscara antes de salvar no banco de dados';
  if meu_idioma = EN then Result := 'Remove mask before saving to database';
  if meu_idioma = ES then Result := 'Retire la máscara antes de guardar en la base de datos';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarText: string;
begin
  Result := PalavrasComuns.Salvar;
end;

class function ViewEditarTabela.MenuCampoBotaoExcluirText: string;
begin
  Result := PalavrasComuns.Excluir;
end;

class function ViewEditarTabela.MenuCampoBotaoNovoText: string;
begin
  Result := PalavrasComuns.Novo;
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem1: string;
begin
  Result := 'Já existe uma chave primária!';
  if meu_idioma = EN then Result := 'Primary Key already exists';
  if meu_idioma = ES then Result := '¡Ya existe una clave principal!';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem2: string;
begin
  Result := 'Chave primária não pode ser excluída do Insert/Update!';
  if meu_idioma = EN then Result := 'Primary Key cannot be excluded on Insert/Update';
  if meu_idioma = ES then Result := '¡La clave principal no se puede excluir de Insertar/Actualizar!';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem3: string;
begin
  Result := 'Campo requerido não pode ser excluído do Insert/Update!';
  if meu_idioma = EN then Result := 'Required field cannot be excluded on Insert/Update!';
  if meu_idioma = ES then Result := '¡El campo obligatorio no se puede excluir de Insertar/Actualizar!';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem4: string;
begin
  Result := 'Campo requerido no dbgrid não pode ser excluído do Insert/Update!';
  if meu_idioma = EN then Result := 'Required field on dbgrid cannot be excluded on Insert/Update!';
  if meu_idioma = ES then Result := '¡El campo obligatorio en dbgrid no se puede excluir de Insertar/Actualizar!';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem5: string;
begin
  Result := 'Ignorar ou Corrigir os campos ?';
  if meu_idioma = EN then Result := 'Ignore or Correct the fields ?';
  if meu_idioma = ES then Result := '¿Ignorar o corregir los campos?';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem6: string;
begin
  Result := PalavrasComuns.CamposRequeridos;
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem7: string;
begin
   Result := PalavrasComuns.Ignorar;
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem8: string;
begin
  Result := PalavrasComuns.Corrigir;
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem9: string;
begin
  Result := 'Confirma a inclusão deste novo campo ?';
  if meu_idioma = EN then Result := 'Do you confirm the inclusion of this new field?';
  if meu_idioma = ES then Result := '¿Confirmas la inclusión de este nuevo campo?';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem10: string;
begin
  Result := 'Confirma a alteração das informações deste campo ?';
  if meu_idioma = EN then Result := 'Confirm the change of information in this field?';
  if meu_idioma = ES then Result := '¿Confirmas el cambio de información en este campo?';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem11: string;
begin
  Result := PalavrasComuns.Confirmacao;
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem12: string;
begin
  Result := 'Não há um campo em edição!';
  if meu_idioma = EN then Result := 'There is no field in edit!';
  if meu_idioma = ES then Result := '¡No hay ningún campo en edición!';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem13: string;
begin
  Result := 'Deseja excluir este campo ?';
  if meu_idioma = EN then Result := 'Do you want to delete this field?';
  if meu_idioma = ES then Result := '¿Quieres eliminar este campo?';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem14: string;
begin
  Result := 'Tabela alterada com sucesso!';
  if meu_idioma = EN then Result := 'Table changed successfully!';
  if meu_idioma = ES then Result := '¡Tabla cambiada exitosamente!';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem15: string;
begin
  Result := 'Tabela deletada com sucesso!';
  if meu_idioma = EN then Result := 'Table deleted successfully!';
  if meu_idioma = ES then Result := '¡Tabla eliminada exitosamente!';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem16: string;
begin
  Result := 'Campo salvo com sucesso!';
  if meu_idioma = EN then Result := 'Field saved successfully!';
  if meu_idioma = ES then Result := '¡Campo guardado exitosamente!';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem17: string;
begin
  Result := 'Campo deletado com sucesso!';
  if meu_idioma = EN then Result := 'Field deleted successfully!';
  if meu_idioma = ES then Result := '¡Campo eliminado exitosamente!';
end;

class function ViewEditarTabela.MenuCampoBotaoSalvarMensagem18: string;
begin
  Result := 'Valores permitidos: ' + sLineBreak;
  if meu_idioma = EN then Result := 'Allowed values' + sLineBreak;
  if meu_idioma = ES then Result := 'Valores permitidos' + sLineBreak;
end;

{ ViewCompilador }

class function ViewCompilador.Titulo: string;
begin
  Result := 'COMPILANADO O PROJETO';
  if meu_idioma = EN then Result := 'COMPILING THE PROJECT';
  if meu_idioma = ES then Result := 'COMPILANADO EL PROYECTO';
end;

class function ViewCompilador.LazBuildLabel: string;
begin
  Result := 'LAZBUILD  ( /opt/fpcupdeluxe/lazarus,  /home/user/lazarus, c:\lazarus )';
end;

class function ViewCompilador.LazBuildMessage: string;
begin
  Result := 'Path do compilador (lazbuild) é inválido!';
  if meu_idioma = EN then Result := 'The compiler path (lazbuild) is invalid!';
  if meu_idioma = ES then Result := '¡La ruta del compilador (lazbuild) no es válida!';
end;

class function ViewCompilador.ModoCompilacaoLabel: string;
begin
  Result := 'MODOS DE COMPILAÇÃO';
  if meu_idioma = EN then Result := 'COMPILATION MODES';
  if meu_idioma = ES then Result := 'MODOS DE COMPILACIÓN';
end;

class function ViewCompilador.BotaoCompilarText: string;
begin
  Result := 'Compilar o Projeto';
  if meu_idioma = EN then Result := 'Compile the Project';
  if meu_idioma = ES then Result := 'Compilar el proyecto';
end;

class function ViewCompilador.BotaoExecutarText: string;
begin
  Result := 'Executar o App';
  if meu_idioma = EN then Result := 'Run the App';
  if meu_idioma = ES then Result := 'Ejecutar App';
end;

class function ViewCompilador.LogCompilacaoLabel: string;
begin
  Result := 'LOG DA COMPILAÇÃO';
  if meu_idioma = EN then Result := 'COMPILATION LOG';
  if meu_idioma = ES then Result := 'LOG DE COMPILACIÓN';
end;

class function ViewCompilador.BotaoCompilarMensagem1: string;
begin
  Result := 'Selecione um modo de compilação';
  if meu_idioma = EN then Result := 'Select a compilation mode';
  if meu_idioma = ES then Result := 'Seleccione un modo de construcción';
end;

class function ViewCompilador.BotaoExecutarMensagem1: string;
begin
  Result := 'Executável não encontrado: ';
  if meu_idioma = EN then Result := 'Executable not found: ';
  if meu_idioma = ES then Result := 'Ejecutable no encontrado: ';
end;

class function ViewCompilador.Mensagem1: string;
begin
  Result := 'Arquivo LPI não encontrado!';
  if meu_idioma = EN then Result := 'LPI file not found!';
  if meu_idioma = ES then Result := '¡Archivo LPI no encontrado!';
end;

class function ViewCompilador.Mensagem2: string;
begin
  Result := 'Compilando com';
  if meu_idioma = EN then Result := 'Compiling with';
  if meu_idioma = ES then Result := 'Compilando con';
end;

class function ViewCompilador.Mensagem3: string;
begin
  Result := 'Compilação concluída com sucesso!';
  if meu_idioma = EN then Result := 'Compilation completed successfully!';
  if meu_idioma = ES then Result := '¡Compilación completada exitosamente!';
end;

class function ViewCompilador.Mensagem4: string;
begin
  Result := 'Erro na compilação';
  if meu_idioma = EN then Result := 'Compilation error';
  if meu_idioma = ES then Result := '¡Error de compilación!';
end;

class function ViewCompilador.Mensagem5: string;
begin
  Result := 'Aguarde a compilação do projeto!';
  if meu_idioma = EN then Result := 'Wait for the project to compile!';
  if meu_idioma = ES then Result := '¡Espera a que se compile el proyecto!';
end;

class function ViewCompilador.Mensagem6: string;
begin
  Result := 'Nenhum terminal compatível foi encontrado.';
  if meu_idioma = EN then Result := 'No compatible terminals were found.';
  if meu_idioma = ES then Result := 'No se encontraron terminales compatibles.';
end;

{ InfoTabelas }

class function InfoTabelas.SalvaTabelaMensagem1: string;
begin
  Result := 'Não informado o ID do projeto!';
  if meu_idioma = EN then Result := 'Project ID not provided!';
  if meu_idioma = ES then Result := '¡ID del proyecto no proporcionado!';
end;

class function InfoTabelas.SalvaTabelaMensagem2: string;
begin
  Result := 'Não foi extraído informações da tabela!';
  if meu_idioma = EN then Result := 'No information was extracted from the table!';
  if meu_idioma = ES then Result := '¡No se extrajo ninguna información de la tabla!';
end;

class function InfoTabelas.SalvaTabelaMensagem3: string;
begin
  Result := 'Não informado o ID da tabela!';
  if meu_idioma = EN then Result := 'Table ID not provided!';
  if meu_idioma = ES then Result := '¡ID de tabla no proporcionada!';
end;

{ ServiceCampo }

class function ServiceCampo.Mensagem1: string;
begin
  Result := 'ID da tabela não foi informado';
  if meu_idioma = EN then Result := 'Table ID not provided';
  if meu_idioma = ES then Result := '¡ID de tabla no proporcionada!';
end;

class function ServiceCampo.Mensagem2: string;
begin
  Result := 'Campos inválidos ou não informados!';
  if meu_idioma = EN then Result := 'Invalid or missing fields!';
  if meu_idioma = ES then Result := '¡Campos inválidos o faltantes!';
end;

{ ServiceTabela }

class function ServiceTabela.Mensagem1: string;
begin
  Result := 'ID do projeto não foi informado';
  if meu_idioma = EN then Result := 'Project ID not provided';
  if meu_idioma = ES then Result := 'ID del proyecto no proporcionado';
end;

class function ServiceTabela.Mensagem2: string;
begin
  Result := 'Campos inválidos';
  if meu_idioma = EN then Result := 'Invalid fields';
  if meu_idioma = ES then Result := 'Campos inválidos';
end;

{ ServiceProjeto }

class function ServiceProjeto.Mensagem1: string;
begin
  Result := 'Já existe um projeto com este nome e tipo de banco de dados!';
  if meu_idioma = EN then Result := 'There is already a project with this name and type of database!';
  if meu_idioma = ES then Result := '¡Ya existe un proyecto con este nombre y tipo de base de datos!';
end;

{ UtilAbrirPastaProjeto }

class function UtilAbrirPastaProjeto.Mensagem1: string;
begin
  Result := 'O diretório não existe!';
  if meu_idioma = EN then Result := 'Directory does not exist!';
  if meu_idioma = ES then Result := '¡El directorio no existe!';
end;

{ UtilMessagePopup }

class function UtilMessagePopup.Mensagem1: string;
begin
  Result := 'Processo concluído!';
  if meu_idioma = EN then Result := 'Process completed!';
  if meu_idioma = ES then Result := '¡Proceso completado!';
end;

class function UtilMessagePopup.Mensagem2: string;
begin
  Result := 'Algo deu errado!';
  if meu_idioma = EN then Result := 'Something went wrong!';
  if meu_idioma = ES then Result := '¡Algo salió mal!';
end;

{ UtilValidacaoCampos }

class function UtilValidacaoCampos.Mensagem1: string;
begin
  Result := 'Um campo requerido, marcado em vermelho!';
  if meu_idioma = EN then Result := 'A required field, marked in red!';
  if meu_idioma = ES then Result := '¡Un campo obligatorio, marcado en rojo!';
end;

class function UtilValidacaoCampos.Mensagem2(Avalor: string): string;
begin
  Result := 'Tem ' + AValor + ' campos requeridos, marcados em vermelho!';
  if meu_idioma = EN then Result := 'There are ' + AValor + ' required fields, marked in red!';
  if meu_idioma = ES then Result := '¡Tiene ' + AValor + ' campos obligatorios, marcados en rojo!';
end;

class function UtilValidacaoCampos.Mensagem3_1: string;
begin
  Result := 'Tem ';
  if meu_idioma = EN then Result := 'There are ';
  if meu_idioma = ES then Result := 'Tiene ';
end;

class function UtilValidacaoCampos.Mensagem3_2: string;
begin
  Result := ' campos requeridos, marcados em vermelho!';
  if meu_idioma = EN then Result := ' required fields, marked in red!';
  if meu_idioma = ES then Result := ' campos obligatorios, marcados en rojo!';
end;

{ UtilProjetoLazarus }

class function UtilProjetoLazarus.Splash_Versao: string;
begin
  Result := 'Versão 1.0';
  if meu_idioma = EN then Result := 'Version 1.0';
  if meu_idioma = ES then Result := 'Versión 1.0';
end;

class function UtilProjetoLazarus.PastaProjetos: string;
begin
  Result := 'projetos';
  if meu_idioma = EN then Result := 'projects';
  if meu_idioma = ES then Result := 'proyectos';
end;

class function UtilProjetoLazarus.GerarForm_BotaoAbrirMsg1: string;
begin
  Result := 'Código ID inválido!';
  if meu_idioma = EN then Result := 'Invalid ID code!';
  if meu_idioma = ES then Result := '¡Código de identificación no válido!';
end;

class function UtilProjetoLazarus.GerarForm_BotaoSalvarText: string;
begin
  Result := PalavrasComuns.Salvar;
end;

class function UtilProjetoLazarus.GerarForm_BotaoSalvarMsg1: string;
begin
  Result := PalavrasComuns.CamposRequeridos;
end;

class function UtilProjetoLazarus.GerarForm_BotaoSalvarMsg2: string;
begin
  Result := PalavrasComuns.Corrigir;
end;

class function UtilProjetoLazarus.GerarForm_BotaoSalvarMsg3: string;
begin
  Result := PalavrasComuns.Ignorar;
end;

class function UtilProjetoLazarus.GerarForm_BotaoSalvarMsg4: string;
begin
  Result := 'Informe o campo';
  if meu_idioma = EN then Result := 'Enter the field';
  if meu_idioma = ES then Result := 'Entrar al campo';
end;

class function UtilProjetoLazarus.GerarForm_BotaoSalvarMsg5: string;
begin
  Result := 'Inclusão';
  if meu_idioma = EN then Result := 'Inclusion';
  if meu_idioma = ES then Result := 'Inclusión';
end;

class function UtilProjetoLazarus.GerarForm_BotaoSalvarMsg6: string;
begin
  Result := 'Confirma a inclusão deste novo registro ?';
  if meu_idioma = EN then Result := 'Do you confirm the inclusion of this new record ?';
  if meu_idioma = ES then Result := '¿Confirmáis la inclusión de este nuevo disco?';
end;

class function UtilProjetoLazarus.GerarForm_BotaoSalvarMsg7: string;
begin
  Result := 'Alteração';
  if meu_idioma = EN then Result := 'Change';
  if meu_idioma = ES then Result := 'Cambiar';
end;

class function UtilProjetoLazarus.GerarForm_BotaoSalvarMsg8: string;
begin
  Result := 'Confirma as alterações deste registro ?';
  if meu_idioma = EN then Result := 'Do you confirm the changes to this record ?';
  if meu_idioma = ES then Result := '¿Confirmas los cambios en este registro?';
end;

class function UtilProjetoLazarus.GerarForm_BotaoExcluirText: string;
begin
  Result := PalavrasComuns.Excluir;
end;

class function UtilProjetoLazarus.GerarForm_BotaoExcluirMsg1: string;
begin
  Result := 'Não há um registro selecionado para excluir!';
  if meu_idioma = EN then Result := 'There is no record selected to delete!';
  if meu_idioma = ES then Result := '¡No hay ningún registro seleccionado para eliminar!';
end;

class function UtilProjetoLazarus.GerarForm_BotaoExcluirMsg2: string;
begin
  Result := 'Deseja excluir este registro ?';
  if meu_idioma = En then Result := 'Do you want to delete this record ?';
  if meu_idioma = ES then Result := '¿Quieres eliminar este registro?';
end;

class function UtilProjetoLazarus.GerarForm_BotaoNovoText: string;
begin
  Result := PalavrasComuns.Novo;
end;

class function UtilProjetoLazarus.GerarForm_BotaoNovoMsg1: string;
begin
  Result := 'Deseja salvar as alterações deste registro ?';
  if meu_idioma = EN then Result := 'Do you want to save changes to this registry?';
  if meu_idioma = ES then Result := '¿Quiere guardar los cambios en este registro?';
end;

class function UtilProjetoLazarus.GerarForm_ValidacaoMsg1: string;
begin
  Result := 'Ignorar ou Corrigir os campos ?';
  if meu_idioma = EN then Result := 'Ignore or Correct the fields ?';
  if meu_idioma = ES then Result := '¿Ignorar o corregir los campos?';
end;

class function UtilProjetoLazarus.GerarForm_ValidacaoErroMsg1: string;
begin
  Result := 'Um campo requerido, grifado em vermelho!';
  if meu_idioma = EN then Result := 'A required field, highlighted in red!';
  if meu_idioma = ES then Result := '¡Un campo obligatorio, resaltado en rojo!';
end;

class function UtilProjetoLazarus.GerarForm_ValidacaoErroMsg2(AMsg: string): string;
begin
  Result := 'Tem ' + AMsg + ' campos requeridos, grifados em vermelho!';
  if meu_idioma = EN then Result := 'It has ' + AMsg + ' required fields, highlighted in red!';
  if meu_idioma = ES then Result := 'Tiene ' + AMsg + ' campos obligatorios, resaltados en rojo!';
end;

class function UtilProjetoLazarus.GerarForm_BotaoCarregarFotoMsg1: string;
begin
  Result := 'CARREGAR FOTO';
  if meu_idioma = EN then Result := 'LOAD PHOTO';
  if meu_idioma = ES then Result := 'OBTENER FOTO';
end;

class function UtilProjetoLazarus.GerarForm_BotaoExcluirFotoMsg1: string;
begin
  Result := 'EXCLUIR FOTO';
  if meu_idioma = EN then Result := 'DELETE PHOTO';
  if meu_idioma = ES then Result := 'BORRAR FOTO';
end;

class function UtilProjetoLazarus.GerarForm_FormatoData: string;
begin
  Result := 'dd/mm/yyyy';  // dd/mm/yyyy hh:nn:ss
  if meu_idioma = EN then Result := 'yyyy-mm-dd';
  if meu_idioma = ES then Result := 'dd/mm/yyyy';
end;

class function UtilProjetoLazarus.GerarForm_FormatoDataCurta: string;
begin
  Result := 'edDMY';
  if meu_idioma = EN then Result := 'edYMD';
  if meu_idioma = ES then Result := 'edDMY';
end;

class function UtilProjetoLazarus.GerarForm_FormatoMoeda: string;
begin
  Result := 'R$';
  if meu_idioma = EN then Result := '$';
  if meu_idioma = ES then Result := '€';
end;

class function UtilProjetoLazarus.GerarForm_BotaoAbrirCaption: string;
begin
  Result := PalavrasComuns.Abrir;
end;

class function UtilProjetoLazarus.GerarForm_FormatoMoedaValor: string;
begin
  Result := '#,##0.00';
  if meu_idioma = EN then Result := '#,##0.00';
  if meu_idioma = ES then Result := '#,##0.00';
end;

class function UtilProjetoLazarus.GerarForm_LabelPesquisa: string;
begin
  Result := PalavrasComuns.Pesquisa;
end;

class function UtilProjetoLazarus.GerarForm_LabelRegistros: string;
begin
  Result := PalavrasComuns.Registros.ToUpper;
end;

class function UtilProjetoLazarus.GerarForm_GridRefresh: string;
begin
  Result := 'Atualizar';
  if meu_idioma = En then Result := 'Update';
  if meu_idioma = ES then Result := 'Actualizar';
end;

class function UtilProjetoLazarus.GerarForm_CepMsg1: string;
begin
   Result := 'Configure os campos para receber os dados do CEP';
  if meu_idioma = En then Result := 'Configure the fields to receive zip code data';
  if meu_idioma = ES then Result := 'Configurar los campos para recibir datos del código postal';
end;

class function UtilProjetoLazarus.GerarForm_CepMsg2: string;
begin
   Result := 'CEP inválido!';
  if meu_idioma = En then Result := 'Invalid zip code';
  if meu_idioma = ES then Result := 'Código postal no válido';
end;

class function UtilProjetoLazarus.GerarForm_CepMsg3: string;
begin
   Result := 'CEP não encontrado!';
  if meu_idioma = En then Result := 'Zip code not found!';
  if meu_idioma = ES then Result := '¡Código postal no encontrado!';
end;

class function UtilProjetoLazarus.GerarForm_CepMsg4: string;
begin
  Result := 'Pesquisando';
  if meu_idioma = En then Result := 'Searching';
  if meu_idioma = ES then Result := 'Búsqueda';
end;

class function UtilProjetoLazarus.CRUD_DesconectadoMsg1: string;
begin
  Result := 'Não está conectado ao servidor!';
  if meu_idioma = En then Result := 'Not connected to the server!';
  if meu_idioma = ES then Result := '¡No conectado al servidor!';
end;

class function UtilProjetoLazarus.CRUD_SalvarMsg1: string;
begin
  Result := 'Novo registro cadastrado do sucesso';
  if meu_idioma = EN then Result := 'New success record registered';
  if meu_idioma = ES then Result := '¡No conectado al servidor!';
end;

class function UtilProjetoLazarus.CRUD_SalvarMsg2: string;
begin
  Result := 'Registro atualizado com sucesso';
  if meu_idioma = EN then Result := 'Record updated successfully';
  if meu_idioma = ES then Result := 'Registro actualizado exitosamente';
end;

class function UtilProjetoLazarus.CRUD_ExcluirMsg1: string;
begin
  Result := 'Registro excluído com sucesso';
  if meu_idioma = EN then Result := 'Record deleted successfully';
  if meu_idioma = ES then Result := 'Registro eliminado exitosamente';
end;

class function UtilProjetoLazarus.CRUD_LerMsg1: string;
begin
  Result := 'Registro carregado com sucesso';
  if meu_idioma = EN then Result := 'Record loaded successfully';
  if meu_idioma = ES then Result := 'El registro se cargó correctamente';
end;

class function UtilProjetoLazarus.CRUD_LerMsg2: string;
begin
  Result := 'Registro não encontrado!';
  if meu_idioma = EN then Result := 'Record not found!';
  if meu_idioma = ES then Result := '¡Registro no encontrado!';
end;

class function UtilProjetoLazarus.ConfigDM_Titulo: string;
begin
  Result := PalavrasComuns.Configuracao;
end;

class function UtilProjetoLazarus.ConfigDM_BotaoSalvarText: string;
begin
  Result := PalavrasComuns.Salvar;
end;

class function UtilProjetoLazarus.ConfigDM_BotaoSalvarMsg1: string;
begin
  Result := 'Configuração salva com sucesso!';
  if meu_idioma = EN then Result := 'Configuration saved successfully!';
  if meu_idioma = ES then Result := '¡Configuración guardada exitosamente!';
end;

class function UtilProjetoLazarus.ConfigDM_BotaoCancelarText: string;
begin
  Result := PalavrasComuns.Cancelar;
end;

class function UtilProjetoLazarus.ConfigDM_LabelDBNome: string;
begin
  Result := 'NOME DO BANCO DE DADOS OU PATH/FILENAME';
  if meu_idioma = EN then Result := 'DATABASE NAME OR PATH/FILENAME';
  if meu_idioma = ES then Result := 'NOMBRE DE LA BASE DE DATO O PATH/FILENAME';
end;

class function UtilProjetoLazarus.ConfigDM_LabelServidor: string;
begin
  Result := 'SERVIDOR';
  if meu_idioma = EN then Result := 'SERVER';
  if meu_idioma = ES then Result := 'SERVIDOR';
end;

class function UtilProjetoLazarus.ConfigDM_LabelPorta: string;
begin
  Result := PalavrasComuns.Porta;
end;

class function UtilProjetoLazarus.ConfigDM_LabelUsername: string;
begin
  Result := PalavrasComuns.Usuario;
end;

class function UtilProjetoLazarus.ConfigDM_LabelSenha: string;
begin
  Result := PalavrasComuns.Senha;
end;

class function UtilProjetoLazarus.ConfigDM_LabelProtocolo: string;
begin
  Result := 'PROTOCOL (sqlite, mysql, postgresql, oracle, odbc)';
end;

class function UtilProjetoLazarus.ConfigDM_LabelCriptografia: string;
begin
  Result := 'Criptografar usuário e Senha';
  if meu_idioma = En then Result := 'Encrypt Username and Password';
  if meu_idioma = ES then Result := 'Cifrar nombre de usuario y contraseña';
end;

class function UtilProjetoLazarus.ServiceUsuario_DesconectadoMsg1: string;
begin
  Result := 'Não está conectado no banco de dados!';
  if meu_idioma = EN then Result := 'Not connected to the database!';
  if meu_idioma = ES then Result := '¡No conectado a la base de datos!';
end;

class function UtilProjetoLazarus.ServiceUsuario_SalvarMsg1: string;
begin
  Result := 'Novo usuário cadastrado do sucesso';
  if meu_idioma = En then Result := 'New registered user success';
  if meu_idioma = ES then Result := 'Nuevo usuario registrado de éxito';
end;

class function UtilProjetoLazarus.ServiceUsuario_SalvarMsg2: string;
begin
  Result := 'Registro do usuário atualizado com sucesso';
  if meu_idioma = EN then Result := 'User record updated successfully';
  if meu_idioma = ES then Result := 'Registro de usuario actualizado exitosamente';
end;

class function UtilProjetoLazarus.ServiceUsuario_ExcluirMsg1: string;
begin
  Result := 'Usuário excluído com sucesso';
  if meu_idioma = EN then Result := 'User deleted successfully';
  if meu_idioma = ES then Result := 'Usuario eliminado exitosamente';
end;

class function UtilProjetoLazarus.ServiceUsuario_LerMsg1: string;
begin
  Result := 'Usuário carregado com sucesso';
  if meu_idioma = EN then Result := 'User loaded successfully';
  if meu_idioma = ES then Result := 'El usuario se cargó correctamente';
end;

class function UtilProjetoLazarus.ServiceUsuario_LerMsg2: string;
begin
  Result := 'Usuário não encontrado!';
  if meu_idioma = EN then Result := 'User not found!';
  if meu_idioma = ES then Result := '¡Usuario no encontrado!';
end;

class function UtilProjetoLazarus.ServiceUsuario_LoginSucesso: string;
begin
  Result := 'Usuário logado com sucesso';
  if meu_idioma = EN then Result := 'User logged in successfully';
  if meu_idioma = ES then Result := 'El usuario ha iniciado sesión correctamente';
end;

class function UtilProjetoLazarus.ServiceUsuario_LoginNaoPermitido: string;
begin
  Result := 'Login não permitido. Procure seu supervisor.';
  if meu_idioma = EN then Result := 'Login not allowed. See your supervisor.';
  if meu_idioma = ES then Result := 'No se permite el acceso. Contacte a su supervisor.';
end;

class function UtilProjetoLazarus.ServiceUsuario_LoginInvalido: string;
begin
  Result := 'Usuário ou senha inválida!';
  if meu_idioma = EN then Result := 'Invalid username or password!';
  if meu_idioma = ES then Result := '¡Usuario o contraseña no válidos!';
end;

class function UtilProjetoLazarus.ServiceUsuario_AlteraSenhaSucesso: string;
begin
  Result := 'Senha alterada com sucesso!';
  if meu_idioma = EN then Result := 'Password changed successfully!';
  if meu_idioma = ES then Result := '¡Contraseña cambiada exitosamente!';
end;

class function UtilProjetoLazarus.ServiceUsuario_AlteraSenhaFalhou: string;
begin
  Result := 'Falhou a alteração da senha.';
  if meu_idioma = EN then Result := 'Password change failed.';
  if meu_idioma = ES then Result := 'Error en el cambio de contraseña';
end;

class function UtilProjetoLazarus.ViewUsuario_Titulo1: string;
begin
  Result := 'Controle de Usuários';
  if meu_idioma = EN then Result := 'User Control';
  if meu_idioma = ES then Result := 'Control de usuarios';
end;

class function UtilProjetoLazarus.ViewUsuario_Titulo2: string;
begin
  Result := PalavrasComuns.Usuarios;
end;

class function UtilProjetoLazarus.ViewUsuario_BotaoSalvarMsg1: string;
begin
  Result := 'Confirma a inclusão deste novo usuário ?';
  if meu_idioma = EN then Result := 'Confirm the inclusion of this new user?';
  if meu_idioma = ES then Result := 'Confirma la inclusión de este nuevo usuario';
end;

class function UtilProjetoLazarus.ViewUsuario_BotaoSalvarMsg2: string;
begin
  Result := 'Confirma as alterações deste usuário ?';
  if meu_idioma = EN then Result := 'Confirm this user''s changes?';
  if meu_idioma = ES then Result := '¿Confirmar los cambios de este usuario?';
end;

class function UtilProjetoLazarus.ViewUsuario_BotaoExcluirMsg1: string;
begin
  Result := 'Não há um usuário selecionado para excluir!';
  if meu_idioma = EN then Result := 'There is no user selected to delete!';
  if meu_idioma = ES then Result := '¡No hay ningún usuario seleccionado para eliminar!';
end;

class function UtilProjetoLazarus.ViewUsuario_BotaoExcluirMsg2: string;
begin
  Result := 'Deseja excluir este usuário ?';
  if meu_idioma = EN then Result := 'Do you want to delete this user ?';
  if meu_idioma = ES then Result := '¿Quieres eliminar este usuario?';
end;

class function UtilProjetoLazarus.ViewUsuario_GridCampoNome: string;
begin
  Result := PalavrasComuns.Nome;
end;

class function UtilProjetoLazarus.ViewUsuario_GridCampoAtivo: string;
begin
  Result := 'ATIVO';
  if meu_idioma = EN then Result := 'ACTIVE';
  if meu_idioma = ES then Result := 'ACTIVO';
end;

class function UtilProjetoLazarus.ViewUsuario_LabelPesquisaText: string;
begin
  Result := PalavrasComuns.Pesquisa;
end;

class function UtilProjetoLazarus.ViewUsuario_LabelRegistrosText: string;
begin
  Result := PalavrasComuns.Registros.ToUpper;
end;

class function UtilProjetoLazarus.ViewUsuario_LabelIsAdmin: string;
begin
  Result := 'É Administrador';
  if meu_idioma = EN then Result := 'Administrator';
  if meu_idioma = ES then Result := 'Administrador';
end;

class function UtilProjetoLazarus.ViewUsuario_LabelCadastroLiberado: string;
begin
  Result := 'Cadastro Liberado';
  if meu_idioma = En then Result := 'Registration Released';
  if meu_idioma = ES then Result := 'Cadastro Liberado';
end;

class function UtilProjetoLazarus.ViewUsuario_LabelNomeText: string;
begin
  Result := PalavrasComuns.Nome;
end;

class function UtilProjetoLazarus.Login_Ola: string;
begin
  Result := 'Olá, ';
  if meu_idioma = EN then Result := 'Hello, ';
  if meu_idioma = ES then Result := 'Hola, ';
end;

class function UtilProjetoLazarus.Login_BemVindo: string;
begin
  Result := 'Bem vindo(a).';
  if meu_idioma = EN then Result := 'Welcome.';
  if meu_idioma = ES then Result := 'Bienvenido.';
end;

class function UtilProjetoLazarus.Login_PrimeiroAcesso: string;
begin
  Result := 'Este é seu primeiro acesso.';
  if meu_idioma = EN then Result := 'This is your first access.';
  if meu_idioma = ES then Result := 'Este es tu primer acceso.';
end;

class function UtilProjetoLazarus.Login_UltimoAcesso: string;
begin
  Result := 'Seu último acesso foi em';
  if meu_idioma = EN then Result := 'Your last login was on';
  if meu_idioma = ES then Result := 'Su último acceso fue el';
end;

class function UtilProjetoLazarus.Login_Desistir: string;
begin
  Result := 'Desistir de entrar no sistema ?';
  if meu_idioma = EN then Result := 'Give up on entering the system?';
  if meu_idioma = ES then Result := 'Renunciar a entrar al sistema';
end;

class function UtilProjetoLazarus.Login_NovaSenha: string;
begin
  Result := 'Informe uma nova senha!';
  if meu_idioma = EN then Result := 'Enter a new password!';
  if meu_idioma = ES then Result := '¡Introduzca una nueva contraseña!';
end;

class function UtilProjetoLazarus.Login_NovaSenhaPlaceHolder: string;
begin
  Result := 'Informe a nova senha';
  if meu_idioma = EN then Result := 'Enter the new password';
  if meu_idioma = ES then Result := 'Introduzca la nueva contraseña';
end;

class function UtilProjetoLazarus.Login_NovaSenhaRepetirPlaceHolder: string;
begin
  Result := 'Repita sua nova senha';
  if meu_idioma = EN then Result := 'Repeat your new password';
  if meu_idioma = ES then Result := 'Repita su nueva contraseña';
end;

class function UtilProjetoLazarus.Login_SenhasDiferentes: string;
begin
  Result := 'As senhas não coincidem!';
  if meu_idioma = EN then Result := 'The passwords don''t match!';
  if meu_idioma = ES then Result := 'Las contraseñas no coinciden';
end;

class function UtilProjetoLazarus.Login_AlterarSenhaText: string;
begin
  Result := 'Alterar Senha';
  if meu_idioma = EN then Result := 'Change Password';
  if meu_idioma = ES then Result := 'Cambiar la contraseñ';
end;

class function UtilProjetoLazarus.Login_NovaSenhaText: string;
begin
  Result := 'Confirma a alteração da senha ?';
  if meu_idioma = EN then Result := 'Confirm password change?';
  if meu_idioma = ES then Result := '¿Confirmar cambio de contraseña?';
end;

class function UtilProjetoLazarus.Login_LabelSenhaInvalida: string;
begin
  Result := 'LOGIN OU SENHA INVÁLIDA!';
  if meu_idioma = EN then Result := 'INVALID LOGIN OR PASSWORD!';
  if meu_idioma = ES then Result := '¡USUARIO O CONTRASEÑA NO VÁLIDO!';
end;

class function UtilProjetoLazarus.Login_BotaoTentarNovamente: string;
begin
  Result := 'Tentar novamente';
  if meu_idioma = EN then Result := 'Try again';
  if meu_idioma = ES then Result := 'Intentar otra vez';
end;

class function UtilProjetoLazarus.Login_BotaoDesistir: string;
begin
  Result := PalavrasComuns.Desistir;
end;

class function UtilProjetoLazarus.Login_InformeCredenciais: string;
begin
  Result := 'INFORME SUAS CREDENCIAIS';
  if meu_idioma = EN then Result := 'ENTER YOUR CREDENTIALS';
  if meu_idioma = ES then Result := 'INGRESE SUS CREDENCIALES';
end;

class function UtilProjetoLazarus.Login_BotaoEntrar: string;
begin
  Result := 'Entrar';
  if meu_idioma = EN then Result := 'Enter';
  if meu_idioma = ES then Result := 'Entrar';
end;

class function UtilProjetoLazarus.Login_UsernameText: string;
begin
  Result := 'Usuário';
  if meu_idioma = EN then Result := 'Username';
  if meu_idioma = ES then Result := 'Usuario';
end;

class function UtilProjetoLazarus.Login_UsernamePlaceHolder: string;
begin
  Result := 'Informe seu usuário';
  if meu_idioma = EN then Result := 'Enter your username';
  if meu_idioma = ES then Result := 'Introduce tu nombre de usuario';
end;

class function UtilProjetoLazarus.Login_SenhaText: string;
begin
  Result := 'Senha';
  if meu_idioma = EN then Result := 'Password';
  if meu_idioma = ES then Result := 'Contraseña';
end;

class function UtilProjetoLazarus.Login_SenhaPlaceHolder: string;
begin
  Result := 'Informe sua Senha';
  if meu_idioma = EN then Result := 'Enter your Password';
  if meu_idioma = ES then Result := 'Ingrese su contraseña';
end;

class function UtilProjetoLazarus.Login_BotaoConcluir: string;
begin
  Result :=  'Concluir';
  if meu_idioma = EN then Result := 'Finish';
  if meu_idioma = ES then Result := 'Concluir';
end;

class function UtilProjetoLazarus.Login_LabelAlterarSenha: string;
begin
  Result := 'ALTERAÇÃO DE SENHA';
  if meu_idioma = EN then Result := 'CHANGE PASSWORD';
  if meu_idioma = ES then Result := 'CAMBIO DE CONTRASEÑA';
end;

class function UtilProjetoLazarus.Login_LabelNovaSenha: string;
begin
  Result := 'Nova Senha';
  if meu_idioma = EN then Result := 'New Password';
  if meu_idioma = ES then Result := 'Nueva contraseña';
end;

class function UtilProjetoLazarus.Login_LabelNovaSenhaRepetir: string;
begin
  Result := 'Repetir a Nova Senha';
  if meu_idioma = EN then Result := 'Repeat New Password';
  if meu_idioma = ES then Result := 'Repetir nueva contraseña';
end;

class function UtilProjetoLazarus.Pesquisa_Mensagem1: string;
begin
  Result := 'Selecione um item na grid!';
  if meu_idioma = EN then Result := 'Select an item in the grid!';
  if meu_idioma = ES then Result := '¡Selecciona un elemento en la cuadrícula!';
end;

class function UtilProjetoLazarus.Pesquisa_BotaoRetornarMsg1: string;
begin
  Result := 'Confirmar Seleção';
  if meu_idioma = En then Result := 'Confirm Selection';
  if meu_idioma = ES then Result := 'Confirmar selección';
end;

class function UtilProjetoLazarus.ViewMain_SairTitulo: string;
begin
  Result := 'Sair do Sistema';
  if meu_idioma = EN then Result := 'Exit System';
  if meu_idioma = ES then Result := 'Salir del sistema';
end;

class function UtilProjetoLazarus.ViewMain_SairMsg: string;
begin
  Result := 'Sair do Sistema ou fazer LogOff ?';
  if meu_idioma = EN then Result := 'Exit the System or LogOff ?';
  if meu_idioma = ES then Result := '¿Salir del sistema o cerrar sesión ?';
end;

class function UtilProjetoLazarus.ViewMain_SairOpcaoSair: string;
begin
  Result := PalavrasComuns.Sair;
end;

class function UtilProjetoLazarus.ViewMain_SairOpcaoLogOff: string;
begin
  Result := PalavrasComuns.LogOff;
end;

class function UtilProjetoLazarus.ViewMain_SairOpcaoCancelar: string;
begin
  Result := PalavrasComuns.Cancelar;
end;

class function UtilProjetoLazarus.ViewMain_UsuariosAcesso: string;
begin
  Result := 'Você não tem autorização para alterar usuários!';
  if meu_idioma = EN then Result := 'You are not authorized to change users!';
  if meu_idioma = ES then Result := '¡No estás autorizado a cambiar de usuario!';
end;

class function UtilProjetoLazarus.ViewMain_MenuOpcao: string;
begin
  Result := 'OPÇÃO';
  if meu_idioma = EN then Result := 'OPTION';
  if meu_idioma = ES then Result := 'OPCIÓN';
end;

class function UtilProjetoLazarus.ViewMain_Conectado: string;
begin
  Result := 'Conectado';
  if meu_idioma = EN then Result := 'Connected';
  if meu_idioma = ES then Result := 'Conectado';
end;

class function UtilProjetoLazarus.ViewMain_Desconectado: string;
begin
  Result := 'Desconectado';
  if meu_idioma = EN then Result := 'Disconnected';
  if meu_idioma = ES then Result := 'Desconectado';
end;

class function UtilProjetoLazarus.ViewMain_Configuracao: string;
begin
  Result := PalavrasComuns.Configuracao;
end;

class function UtilProjetoLazarus.ViewMain_Usuarios: string;
begin
  Result := PalavrasComuns.Usuarios;
end;

class function UtilProjetoLazarus.ViewMain_MenuSistema: string;
begin
  Result := 'SISTEMA';
  if meu_idioma = EN then Result := 'SYSTEM';
  if meu_idioma = ES then Result := 'SISTEMA';
end;

class function UtilProjetoLazarus.ViewMain_MenuChatHistorico: string;
begin
  Result := 'Histórico do Chat ';
  if meu_idioma = EN then Result := 'Chat Histor';
  if meu_idioma = ES then Result := 'Histórico de Chat';
end;

class function UtilProjetoLazarus.ViewMain_ChatIniciarConversa: string;
begin
  Result := 'Iniciar uma conversa';
  if meu_idioma = EN then Result := 'Start a conversation';
  if meu_idioma = ES then Result := 'Iniciar una conversación';
end;

class function UtilProjetoLazarus.Rpt_RelatorioText: string;
begin
  Result := 'Relatório de ';
  if meu_idioma = EN then Result := 'Report of ';
  if meu_idioma = ES then Result := 'Informe de ';
end;

class function UtilProjetoLazarus.Rpt_RelatorioLabel: string;
begin
  Result := 'RELATÓRIOS';
  if meu_idioma = EN then Result := 'REPORTS';
  if meu_idioma = ES then Result := 'INFORMES';
end;

class function UtilProjetoLazarus.Rpt_PaginacaoAtual: string;
begin
  Result := 'Página ';
  if meu_idioma = EN then Result := 'Page ';
  if meu_idioma = ES then Result := 'Página ';
end;

class function UtilProjetoLazarus.Rpt_PaginacaoTotal: string;
begin
  Result := 'de ';
  if meu_idioma = EN then Result := 'of ';
  if meu_idioma = ES then Result := 'de ';
end;

class function UtilProjetoLazarus.About_Title: string;
begin
  Result := 'SOBRE';
  if meu_idioma = EN then Result := 'ABOUT';
  if meu_idioma = ES then Result := 'ACERCA DE';
end;

class function UtilProjetoLazarus.ViewMain_Titulo: string;
begin
  Result := 'TELA INICIAL';
  if meu_idioma = EN then Result := 'MAIN SCREEN';
  if meu_idioma = ES then Result := 'PANTALLA DE INICIO';
end;

class function UtilProjetoLazarus.ViewMain_SairText: string;
begin
  Result := PalavrasComuns.Sair;
end;

{ TChatMessages }

class function TChatMessages.ChatModule_ConexaoStatusON: string;
begin
  Result := 'Conectado do servidor do chat!';
  if meu_idioma = EN then Result := 'Connected to the chat server!';
  if meu_idioma = ES then Result := '¡Conectado al servidor de chat!';
end;

class function TChatMessages.ChatModule_ConexaoStatusOFF: string;
begin
  Result := 'Desconectado do servidor do chat!';
  if meu_idioma = EN then Result := 'Disconnected from the chat server!';
  if meu_idioma = ES then Result := '¡Desconectado del servidor de chat!';
end;

class function TChatMessages.ChatModule_LoginStatusOFF: string;
begin
  Result := 'Você foi desconectado do servidor do chat!';
  if meu_idioma = EN then Result := 'You have been disconnected from the chat server!';
  if meu_idioma = ES then Result := '¡Se ha desconectado del servidor de chat!';
end;

class function TChatMessages.ChatModule_ChatUserInfo_Msg1: string;
begin
  Result := 'saiu da sala';
  if meu_idioma = EN then Result := 'left the room';
  if meu_idioma = ES then Result := 'salió de la habitación';
end;

class function TChatMessages.ChatModule_ChatUserInfo_Msg2: string;
begin
  Result := 'desconhecido';
  if meu_idioma = EN then Result := 'unknown';
  if meu_idioma = ES then Result := 'desconocido';
end;

class function TChatMessages.ChatModule_ChatUserInfo_Msg3: string;
begin
  Result := 'Erro ao conectar';
  if meu_idioma = EN then Result := 'Error connecting';
  if meu_idioma = ES then Result := 'Error al conectar';
end;

class function TChatMessages.ChatModule_ChatUserInfo_Msg4: string;
begin
  Result := 'Servidor indisponível!';
  if meu_idioma = EN then Result := 'Server unavailable!';
  if meu_idioma = ES then Result := '¡Servidor no disponible!';
end;

class function TChatMessages.ChatModule_ChatUserInfo_Msg5: string;
begin
  Result := 'Verifique as configurações no arquivo:  CHAT_CONFIG.INI';
  if meu_idioma = EN then Result := 'Check the settings in the file:  CHAT_CONFIG.INI';
  if meu_idioma = ES then Result := 'Verifique la configuración en el archivo:  CHAT_CONFIG.INI';
end;

class function TChatMessages.ChatForm_Msg1: string;
begin
  Result := 'Falha na autenticação do usuário';
  if meu_idioma = EN then Result := 'User authentication failed.';
  if meu_idioma = ES then Result := 'Error en la autenticación del usuario.';
end;

class function TChatMessages.ChatForm_PedirAtencaoTitulo: string;
begin
  Result := 'Pedir atenção';
  if meu_idioma = EN then Result := 'Ask for attention';
  if meu_idioma = ES then Result := 'Pedir atención';
end;

class function TChatMessages.ChatForm_PedirAtencaoMsg: string;
begin
  Result := 'Pedir atenção aos participantes da sala ?';
  if meu_idioma = EN then Result := 'Should I ask for the attention of the participants in the room?';
  if meu_idioma = ES then Result := '¿Debo solicitar la atención de los participantes en la sala?';
end;

class function TChatMessages.ChatForm_Msg2: string;
begin
  Result := 'Nome de arquivo inválido ou FTP não conectado!';
  if meu_idioma = EN then Result := 'Invalid filename or FTP not connected!';
  if meu_idioma = ES then Result := '¡Nombre de archivo no válido o FTP no conectado!';
end;

class function TChatMessages.ChatForm_Msg3: string;
begin
  Result := 'Não foi possível obter informações do arquivo!';
  if meu_idioma = EN then Result := 'Unable to retrieve any information from the file!';
  if meu_idioma = ES then Result := '¡No se puede recuperar ninguna información del archivo!';
end;

class function TChatMessages.ChatForm_Msg4: string;
begin
  Result := 'Remover Convidado';
  if meu_idioma = EN then Result := 'Remove Guest';
  if meu_idioma = ES then Result := 'Eliminar invitado';
end;

class function TChatMessages.ChatForm_Msg5: string;
begin
  Result := 'Remover o convidado do chat ?';
  if meu_idioma = EN then Result := 'Remove the guest from the chat?';
  if meu_idioma = ES then Result := '¿Eliminar al invitado del chat?';
end;

class function TChatMessages.ChatForm_Msg6: string;
begin
  Result := 'Você não está na lista de Convidados do chat!';
  if meu_idioma = EN then Result := 'You are not on the chat''s guest list!';
  if meu_idioma = ES then Result := '¡No estás en la lista de invitados del chat!';
end;

class function TChatMessages.ChatForm_Msg7: string;
begin
  Result := 'Adicione um Convidado ao chat!';
  if meu_idioma = EN then Result := 'Add a guest to the chat!';
  if meu_idioma = ES then Result := '¡Agrega un invitado al chat!';
end;

class function TChatMessages.ChatForm_Msg8: string;
begin
  Result := 'Você não está conectado no servidor de chat!';
  if meu_idioma = EN then Result := 'You are not connected to the chat server!';
  if meu_idioma = ES then Result := '¡No estás conectado al servidor de chat!';
end;

class function TChatMessages.ChatForm_Convidado: string;
begin
  Result := 'Convidado';
  if meu_idioma = EN then Result := 'Guest';
  if meu_idioma = ES then Result := 'Invitado';
end;

class function TChatMessages.ChatForm_Msg9: string;
begin
  Result := 'Você foi removido da sala!';
  if meu_idioma = EN then Result := 'You have been removed from the room!';
  if meu_idioma = ES then Result := '¡Te han sacado de la habitación!';
end;

class function TChatMessages.ChatForm_Msg10: string;
begin
  Result := 'Não foi possível apagar a mensagem!';
  if meu_idioma = EN then Result := 'The message could not be deleted!';
  if meu_idioma = ES then Result := '¡No se pudo eliminar el mensaje!';
end;

class function TChatMessages.ChatForm_ApagarMsgTitulo: string;
begin
  Result := 'Apagar Mensagem';
  if meu_idioma = EN then Result := 'Delete Message';
  if meu_idioma = ES then Result := 'Eliminar mensaje';
end;

class function TChatMessages.ChatForm_ApagarMsgText: string;
begin
  Result := 'Deseja APAGAR esta mensagem ?';
  if meu_idioma = EN then Result := 'Do you want to DELETE this message?';
  if meu_idioma = ES then Result := '¿Quieres ELIMINAR este mensaje?';
end;

class function TChatMessages.ChatForm_Msg11: string;
begin
  Result := 'Arquivos na rede não é permitido!';
  if meu_idioma = EN then Result := 'Files on the network are not allowed!';
  if meu_idioma = ES then Result := '¡No se permiten archivos en la red!';
end;

class function TChatMessages.ChatForm_Msg12: string;
begin
  Result := 'Permitido até %d arquivos!';
  if meu_idioma = EN then Result := 'Allowed up to %d files!';
  if meu_idioma = ES then Result := '¡Se permiten hasta %d archivos!';
end;

class function TChatMessages.ChatForm_Msg13: string;
begin
  Result := 'Arquivos excedem o tamanho máximo permitido de';
  if meu_idioma = EN then Result := 'Files exceed the maximum allowed size of';
  if meu_idioma = ES then Result := 'Los archivos exceden el tamaño máximo permitido de';
end;

class function TChatMessages.ChatForm_Msg14: string;
begin
  Result := 'Confirma o envio de %d arquivos ?';
  if meu_idioma = EN then Result := 'Confirm sending %d files?';
  if meu_idioma = ES then Result := '¿Confirmar envío de %d archivos?';
end;

class function TChatMessages.ChatForm_Msg15: string;
begin
  Result := 'Confirma o envio do arquivo ?';
  if meu_idioma = EN then Result := 'Can you confirm that you sent the file?';
  if meu_idioma = ES then Result := '¿Puedes confirmar que enviaste el archivo?';
end;

class function TChatMessages.ChatForm_Msg16: string;
begin
  Result := 'Enviar Arquivos';
  if meu_idioma = EN then Result := 'Send Files';
  if meu_idioma = ES then Result := 'Enviar archivos';
end;

class function TChatMessages.ChatForm_Msg17: string;
begin
  Result := 'Servidor FTP não está pronto!';
  if meu_idioma = EN then Result := 'The FTP server is not ready!';
  if meu_idioma = ES then Result := '¡El servidor FTP no está listo!';
end;

class function TChatMessages.ChatForm_Msg18: string;
begin
  Result := 'Abrir arquivo';
  if meu_idioma = EN then Result := 'Open file';
  if meu_idioma = ES then Result := 'Abrir archivo';
end;

class function TChatMessages.ChatForm_Msg19: string;
begin
  Result := 'Quer abrir o arquivo ?';
  if meu_idioma = EN then Result := 'Do you want to open the file?';
  if meu_idioma = ES then Result := '¿Quieres abrir el archivo?';
end;

class function TChatMessages.ChatForm_Msg20: string;
begin
  Result := 'Arquivo não encontrado!';
  if meu_idioma = EN then Result := 'File not found!';
  if meu_idioma = ES then Result := '¡Archivo no encontrado!';
end;

class function TChatMessages.ChatForm_Msg21: string;
begin
  Result := 'CONVIDADOS';
  if meu_idioma = EN then Result := 'GUESTS';
  if meu_idioma = ES then Result := 'INVITADOS';
end;

class function TChatMessages.ChatForm_Msg22: string;
begin
  Result := 'Convidar Usuário';
  if meu_idioma = EN then Result := 'Invite User';
  if meu_idioma = ES then Result := 'Invitar usuario';
end;

class function TChatMessages.ChatForm_Msg23: string;
begin
  Result := 'CONVERSA';
  if meu_idioma = EN then Result := 'CONVERSATION';
  if meu_idioma = ES then Result := 'CONVERSACIÓN';
end;

class function TChatMessages.ChatForm_Msg24: string;
begin
  Result := 'Enviar a mensagem';
  if meu_idioma = EN then Result := 'Send the message';
  if meu_idioma = ES then Result := 'Enviar el mensaje';
end;

class function TChatMessages.ChatForm_Msg25: string;
begin
  Result := 'Enviar arquivo';
  if meu_idioma = EN then Result := 'Send file';
  if meu_idioma = ES then Result := 'Enviar archivo';
end;

class function TChatMessages.ChatForm_Msg26: string;
begin
  Result := 'Pedir atenção';
  if meu_idioma = EN then Result := 'Ask for attention';
  if meu_idioma = ES then Result := 'pedir atencion';
end;

class function TChatMessages.ChatForm_Msg27: string;
begin
  Result := 'escrevendo';
  if meu_idioma = EN then Result := 'writing';
  if meu_idioma = ES then Result := 'escribiendo';
end;

class function TChatMessages.ChatForm_Msg28: string;
begin
  Result := 'LOG DE OCORRÊNCIAS';
  if meu_idioma = EN then Result := 'OCCURRENCE LOG';
  if meu_idioma = ES then Result := 'REGISTRO DE OCURRENCIAS';
end;

class function TChatMessages.ChatForm_Msg29: string;
begin
  Result := '''O''#10''C''#10''O''#10''R''#10''R''#10''Ê''#10''N''#10''C''#10''I''#10''A''#10''S''';
  if meu_idioma = EN then Result := '''O''#10''C''#10''C''#10''U''#10''R''#10''R''#10''E''#10''N''#10''C''#10''E''#10''S''';
  if meu_idioma = ES then Result := '''O''#10''C''#10''U''#10''R''#10''R''#10''E''#10''N''#10''C''#10''I''#10''A''#10''S''';
end;

class function TChatMessages.ChatForm_Msg30: string;
begin
  Result := 'Você não está conectado no servidor de chat.';
  if meu_idioma = EN then Result := 'You are not connected to the chat server.';
  if meu_idioma = ES then Result := 'No estás conectado al servidor de chat.';
end;

class function TChatMessages.ChatCardMessage_Date(AHoje: Boolean): string;
// 'yyyy-mm-dd"T"hh:nn:ss'	2026-08-30T13:45:38
// 'hh:nn am/pm'	        11:08 am
// 'dd/mm/yyyy hh:nn:ss'	23/05/2026 16:56:43
begin
  if AHoje then begin
    Result := 'Hoje';
    if meu_idioma = EN then Result := 'Today';
    if meu_idioma = ES then Result := 'Hoy';
  end else begin
    Result := 'dd mmm yyyy';
    if meu_idioma = EN then Result := 'mmm dd yyyy';
    if meu_idioma = ES then Result := 'dd mmm yyyy';
  end;
end;

class function TChatMessages.ChatCardMessage_DateLong: string;
begin
  Result := 'FormatDateTime(''dd'', ADate) + '' de '' + NomeMes(MonthOf(ADate)) + '' de '' + FormatDateTime(''yyyy'', ADate);';
  if meu_idioma = EN then Result := 'NomeMes(MonthOf(ADate)) + '' '' + FormatDateTime(''dd'', ADate) +  '', '' + FormatDateTime(''yyyy'', ADate);';
end;

class function TChatMessages.ChatCardMessage_Msg1: string;
begin
  Result := 'Deletado';
  if meu_idioma = EN then Result := 'Deleted';
  if meu_idioma = ES then Result := 'Eliminado';
end;

class function TChatMessages.ChatCardMessage_Msg2: string;
begin
  Result := 'Apagar esta mensagem';
  if meu_idioma = EN then Result := 'Delete this message';
  if meu_idioma = ES then Result := 'Eliminar este mensaje';
end;

class function TChatMessages.ChatCardMessage_Msg3: string;
begin
  Result := 'Enviado por';
  if meu_idioma = EN then Result := 'Sent by';
  if meu_idioma = ES then Result := 'Publicado por';
end;

class function TChatMessages.ChatFormHistorico_Msg1: string;
begin
  Result := 'HISTÓRICO';
  if meu_idioma = EN then Result := 'HISTORY';
  if meu_idioma = ES then Result := 'HISTORIA';
end;

class function TChatMessages.ChatFormHistorico_Msg2: string;
begin
  Result := 'Nenhuma ocorrência foi encontrada!';
  if meu_idioma = EN then Result := 'No occurrences were found!';
  if meu_idioma = ES then Result := '¡No se encontraron ocurrencias!';
end;

class function TChatMessages.ChatFormHistorico_Msg3: string;
begin
  Result := 'HISTÓRICO DO CHAT';
  if meu_idioma = EN then Result := 'CHAT HISTORY';
  if meu_idioma = ES then Result := 'HISTORIAL DE CHARLAS';
end;

class function TChatMessages.ChatFormHistorico_Msg4: string;
begin
  Result := 'DETALHES DAS CONVERSAS';
  if meu_idioma = EN then Result := 'CONVERSATION DETAILS';
  if meu_idioma = ES then Result := 'DETALLES DE LA CONVERSACIÓN';
end;

class function TChatMessages.ChatFormHistorico_Msg5: string;
begin
  Result := 'QUE CONTENHA ARQUIVOS';
  if meu_idioma = EN then Result := 'THAT CONTAINS FILES';
  if meu_idioma = ES then Result := 'QUE CONTIENE ARCHIVOS';
end;

class function TChatMessages.ChatFormHistorico_Msg6: string;
begin
  Result := 'PESQUISAR CONVIDADO';
  if meu_idioma = EN then Result := 'SEARCH GUEST';
  if meu_idioma = ES then Result := 'BUSCAR INVITADO';
end;

class function TChatMessages.ChatFormHistorico_Msg7: string;
begin
  Result := 'PESQUISAR';
  if meu_idioma = EN then Result := 'SEARCH';
  if meu_idioma = ES then Result := 'BUSCAR';
end;

class function TChatMessages.ChatFormUsuarios_Msg1: string;
begin
  Result := 'Selecione um usuário na lista!';
  if meu_idioma = EN then Result := 'Select a user from the list!';
  if meu_idioma = ES then Result := '¡Seleccione un usuario de la lista!';
end;

class function TChatMessages.ChatFormUsuarios_Msg2: string;
begin
  Result := 'USUÁRIOS';
  if meu_idioma = EN then Result := 'USERS';
  if meu_idioma = ES then Result := 'USUARIOS';
end;

class function TChatMessages.ChatFormUsuarios_Msg3: string;
begin
  Result := 'Confirmar Seleção';
  if meu_idioma = EN then Result := 'Confirm Selection';
  if meu_idioma = ES then Result := 'Confirmar selección';
end;

{ TApiMessages }

class function TApiMessages.ServidorOuvindo: string;
begin
  Result := 'Servidor trabalhando na porta %d';
  if meu_idioma = EN then Result := 'Server working on port %d';
  if meu_idioma = ES then Result := 'Servidor funcionando en el puerto %d';
end;

class function TApiMessages.ServidorFirewall: string;
begin
  Result := 'Libere a porta %d no firewall';
  if meu_idioma = EN then Result := 'Open port %d in the firewall.';
  if meu_idioma = ES then Result := 'Abra el puerto %d en el cortafuegos.';
end;

class function TApiMessages.ServidorSair: string;
begin
  Result := 'Pressione ''q'' para finalizar o servidor';
  if meu_idioma = EN then Result := 'Press ''q'' to terminate the server.';
  if meu_idioma = ES then Result := 'Pulsa ''q'' para finalizar el servidor.';
end;

end.

