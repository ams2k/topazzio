unit Util.GeraRestInfo;

// Gera a informações importação no programa Topazzio Rest API

{$mode ObjFPC}{$H+}

interface

uses
   Classes, SysUtils, StrUtils, ExtCtrls,
   DB, SQLDB, ZDataset, fpjson, DateUtils, Math,
   Service.Projeto, Service.RestApi, Service.Tabela, Service.Campo;

type

  { TUtilGeraRestInfo }

  TUtilGeraRestInfo = class
  private
    FListaTabelasID: string;
    FErroMsg: String;
    function BodyFieldsDescription(qry: TZQuery; AQdeCampos: Integer; AExcluirPrimayKey: Boolean): TJSONArray;
    function ResponseBody(AMethod: string; ASucesso: Boolean): TJSONObject;
    function GetDocRotaEndPoint(qry: TZQuery; AMethod, APrefix: String): TJSONObject;
    function GetParametros(AMetodo: string): TJSONArray;
    function BodyFieldsToSendOrReceive(qry: TZQuery; AQdeCampos: Integer; AExcluirPrimayKey: Boolean): TJSONObject;
    function ResponseBodyList(qry: TZQuery; AQdeItens: Integer): TJSONObject;
    function RotaAuth: TJSONArray;
  public
    function GeraDocumento(const Projeto: TServiceRestApi; AListaTabelasID, APastaDoc: string): Boolean;
    property GetErroMsg: String read FErroMsg;
  end;

implementation

uses
  Util.ProjetoCommon;

{ TUtilGeraRestInfo }

function TUtilGeraRestInfo.GeraDocumento(const Projeto: TServiceRestApi; AListaTabelasID, APastaDoc: string): Boolean;
// gera arquivo de informações da api para importação pelo programa Topazzio Rest API
var
  j, jobj: TJSONObject;
  jrotas: TJSONArray;
  st: TServiceTabela;
  sc: TServiceCampo;
  tabelas, campos: TZQuery;
  docPathNome: String;
  idEndPoint: Integer;
begin
  Result := False;
  FErroMsg := '';
  idEndPoint := 0;
  FListaTabelasID := AListaTabelasID;
  docPathNome := APastaDoc + PathDelim + 'API.topazzio_rest_collection.json';

  j := TJSONObject.Create;

  try
    st := TServiceTabela.Create( Projeto.IdProjeto );
    tabelas := st.QueryTabelas( FListaTabelasID.Trim, True ); //tabelas

    if tabelas.RecordCount > 0 then begin

      j.Add('apiname', Projeto.ApiTitulo);
      j.Add('host_root', Projeto.ApiHost + ':' + Projeto.ApiPorta);
      j.Add('versao', Projeto.ApiVersao);
      j.Add('basic_username', '');
      j.Add('basic_password', '');
      j.Add('token', '');
      j.Add('description', Projeto.ApiDescricao);
      j.Add('header_texto1', Projeto.ApiHeader1);
      j.Add('header_texto2', Projeto.ApiHeader2);
      j.Add('header_texto3', Projeto.ApiHeader3);
      j.Add('footer_texto1', Projeto.ApiFooter1);
      j.Add('footer_texto2', Projeto.ApiFooter2);

      // lista de rotas
      jrotas := TJSONArray.Create;

      // rota auth
      jobj := TJSONObject.Create;
      jobj.Add('rtgroup', 'Auth');
      jobj.Add('method', 'POST');
      jobj.Add('prefix', '');
      jobj.Add('route', '/login');
      jobj.Add('authmode', 'none');
      jobj.Add('contenttype', 'application/json');
      jobj.Add('table_fields', RotaAuth);  // array de objetos
      jobj.Add('headers', TJSONArray.Create); // array de objetos
      jobj.Add('parameters', TJSONArray.Create); // array de objetos
      jobj.Add('body', TJSONObject.Create(['username', 'admin','password', '123'])); // objeto {}
      jobj.Add('description', 'Efetua login e recebe o token JWT');
      jobj.Add('response_ok_code', '200-OK');
      jobj.Add('response_ok_type', 'application/json');
      jobj.Add('response_ok_text', TJSONObject.Create(['id',1,'name','Administrador','exp',1778866765,'token','eyJhbGciOiJIUzI1NiIsInR5.bjU3fHE3NS81JDk1N3t0e.0cd91b86e94b2ed7152a304f3ff75f6cfc41806e']));
      jobj.Add('response_neg_code', '401-Unauthorized');
      jobj.Add('response_neg_type', 'text/plain');
      jobj.Add('response_neg_text', 'authentication failed, missing data');

      jrotas.Add(jobj); // adiciona a rota à lista

      // demais rotas
      while not tabelas.EOF do begin
        if tabelas.FieldByName('for_auth').AsInteger = 0 then begin // rota comum
          sc := TServiceCampo.Create( tabelas.FieldByName('idtabela').AsInteger );
          campos := sc.QueryCampos; // campos da tabela
          idEndPoint := idEndPoint + 1;

          if campos.RecordCount > 0 then begin

            // endpoints

            // GET
            jrotas.Add(GetDocRotaEndPoint(campos, 'get', Projeto.ApiVersao)); // adiciona a rota à lista

            // GET PAGE
            if campos.FieldByName('api_get').AsInteger = 1 then
              jrotas.Add(GetDocRotaEndPoint(campos, 'get_list', Projeto.ApiVersao));

            // POST
            if campos.FieldByName('api_post').AsInteger = 1 then
              jrotas.Add(GetDocRotaEndPoint(campos, 'post', Projeto.ApiVersao));

            // PUT
            if campos.FieldByName('api_put').AsInteger = 1 then
              jrotas.Add(GetDocRotaEndPoint(campos, 'put', Projeto.ApiVersao));

            // PATCH
            if campos.FieldByName('api_patch').AsInteger = 1 then
              jrotas.Add(GetDocRotaEndPoint(campos, 'patch', Projeto.ApiVersao));

            // DELETE
            if campos.FieldByName('api_delete').AsInteger = 1 then
              jrotas.Add(GetDocRotaEndPoint(campos, 'delete', Projeto.ApiVersao));

          end;

          campos.Close;
          campos.Free;
          sc.Free;
        end;

        // próxima tabela
        tabelas.Next;
      end;

      j.Add('routes', jrotas);

      TUtilCommon.SalvarArquivo(docPathNome, j.FormatJSON());
      Result := True;
    end;

    tabelas.Close;
    tabelas.Free;
    st.Free;
  finally
    j.Free;
  end;
end;

function TUtilGeraRestInfo.GetDocRotaEndPoint(qry: TZQuery; AMethod, APrefix: String): TJSONObject;
// retorna o endpoint da rota do documento da api
var
  sEndPoint, sMetodo: String;
  sDescricao, ARota: String;
begin
  // ajustes na rota
  Result := TJSONObject.Create;
  qry.First;

  ARota := Trim(qry.FieldByName('api_rota').AsString);
  if LeftStr(ARota, 1) = '/' then ARota := ARota.Substring(1);
  if RightStr(ARota, 1) = '/' then ARota := ARota.Substring(0, ARota.Length-1);

   // caminho completo do endpoint
  sEndPoint := StringReplace('/' + Trim(ARota), '//', '/', [rfReplaceAll]);
  while RightStr(sEndPoint, 1) = '/' do
    sEndPoint := LeftStr(sEndPoint, Length(sEndPoint)-1);

  //Verbo: POST, GET, PUT, DELETE
  if AMethod = 'get_list' then // get paginação
    sMetodo := 'GET'
  else
    sMetodo := AMethod.ToUpper;

  if AMethod = 'get' then sEndPoint := sEndPoint + '/1';
  if AMethod = 'get_list' then sEndPoint := sEndPoint + '?page=1&limit=10';
  if AMethod = 'put' then sEndPoint := sEndPoint + '/1';
  if AMethod = 'patch' then sEndPoint := sEndPoint + '/1';
  if AMethod = 'delete' then sEndPoint := sEndPoint + '/1';

  // Descrição do endpoint
  sDescricao := Trim(qry.FieldByName('descricao').AsString);
  if sDescricao = '' then sDescricao := 'Detalhes desta rota';

  Result := TJSONObject.Create;
  Result.Add('rtgroup', UpperCase(Copy(ARota,1,1)) + Copy(ARota,2, Length(ARota)));
  Result.Add('method', sMetodo);
  Result.Add('prefix', APrefix);
  Result.Add('route', sEndPoint);
  Result.Add('authmode', 'JWT');
  Result.Add('contenttype', 'application/json');

  if AMethod = 'post' then begin
    Result.Add('table_fields', BodyFieldsDescription(qry, 0, True)); //lista de campos para inserir/altear
    Result.Add('headers', TJSONArray.Create); // array de objetos
    Result.Add('parameters', GetParametros(AMethod)); // array de objetos
    Result.Add('body', BodyFieldsToSendOrReceive(qry, 0, True)); // objeto json (dados para envio)
  end
  else if AMethod = 'put' then begin
    Result.Add('table_fields', BodyFieldsDescription(qry, 5, True));
    Result.Add('headers', TJSONArray.Create); // array de objetos
    Result.Add('parameters', GetParametros(AMethod)); // array de objetos
    Result.Add('body', BodyFieldsToSendOrReceive(qry, 5, True)); // objeto json (dados para envio)
  end
  else if AMethod = 'patch' then begin
    Result.Add('table_fields', BodyFieldsDescription(qry, 2, True));
    Result.Add('headers', TJSONArray.Create); // array de objetos
    Result.Add('parameters', GetParametros(AMethod)); // array de objetos
    Result.Add('body', BodyFieldsToSendOrReceive(qry, 2, True)); // objeto json (dados para envio)
  end
  else if AMethod = 'delete' then begin
    Result.Add('table_fields', TJSONArray.Create);
    Result.Add('headers', TJSONArray.Create); // array de objetos
    Result.Add('parameters', GetParametros(AMethod)); // array de objetos
    Result.Add('body', TJSONObject.Create);
  end
  else if AMethod = 'get' then begin
    Result.Add('table_fields', TJSONArray.Create);
    Result.Add('headers', TJSONArray.Create); // array de objetos
    Result.Add('parameters', GetParametros(AMethod)); // array de objetos
    Result.Add('body', TJSONObject.Create);
  end
  else if AMethod = 'get_list' then begin
    Result.Add('table_fields', TJSONArray.Create);
    Result.Add('headers', TJSONArray.Create); // array de objetos
    Result.Add('parameters', GetParametros(AMethod)); // array de objetos
    Result.Add('body', TJSONObject.Create);
  end;

  Result.Add('description', sDescricao);

  if AMethod = 'get' then begin
    Result.Add('response_ok_code', '200-OK');
    Result.Add('response_ok_type', 'application/json');
    Result.Add('response_ok_text', BodyFieldsToSendOrReceive(qry, 0, False));
    Result.Add('response_neg_code', '400-Bad Request');
    Result.Add('response_neg_type', 'application/json');
    Result.Add('response_neg_text', ResponseBody(AMethod, False));
  end
  else if AMethod = 'get_list' then begin
    Result.Add('response_ok_code', '200-OK');
    Result.Add('response_ok_type', 'application/json');
    Result.Add('response_ok_text', ResponseBodyList(qry, 2));
    Result.Add('response_neg_code', '400-Bad Request');
    Result.Add('response_neg_type', 'application/json');
    Result.Add('response_neg_text', ResponseBody(AMethod, False));
  end
  else begin { post, put, patch e delete são semelhantes }
    Result.Add('response_ok_code', '200-OK');
    Result.Add('response_ok_type', 'application/json');
    Result.Add('response_ok_text', ResponseBody(AMethod, True));
    Result.Add('response_neg_code', '400-Bad Request');
    Result.Add('response_neg_type', 'application/json');
    Result.Add('response_neg_text', ResponseBody(AMethod, False));
  end;
end;

function TUtilGeraRestInfo.GetParametros(AMetodo: string): TJSONArray;
// retorna os parâmetros do entpoint
begin
  Result := TJSONArray.Create;

  if AMetodo.ToLower = 'get' then begin
    Result.Add(TJSONObject.Create([
                                   'param_name', 'id',
                                   'param_type', 'integer',
                                   'param_description', 'Código do registro a ser consultado'
                                   ]));
  end
  else if AMetodo.ToLower = 'get_list' then begin
    Result.Add(TJSONObject.Create([
                                   'param_name', 'page',
                                   'param_type', 'integer',
                                   'param_description', 'Número da página a ser obtida'
                                   ]));

    Result.Add(TJSONObject.Create([
                                   'param_name', 'limit',
                                   'param_type', 'integer',
                                   'param_description', 'Quantidade de registros por página a serem exibidos'
                                   ]));

    Result.Add(TJSONObject.Create([
                                   'param_name', 'search_field',
                                   'param_type', 'string',
                                   'param_description', '(opcional) Nome do campo de pesquisa'
                                   ]));

    Result.Add(TJSONObject.Create([
                                   'param_name', 'search_operator',
                                   'param_type', 'string',
                                   'param_description', '(opcional) Operador para o campo de pesquisa: eq, neq, gt, gte, lt, lte, between, contains, starts, ends'
                                   ]));

    Result.Add(TJSONObject.Create([
                                   'param_name', 'search',
                                   'param_type', 'string',
                                   'param_description', '(opcional) Conteúdo ser pesquisado'
                                   ]));

    Result.Add(TJSONObject.Create([
                                   'param_name', 'order_field',
                                   'param_type', 'string',
                                   'param_description', '(opcional) Lista de campos de pesquisa: nome, idade'
                                   ]));
    Result.Add(TJSONObject.Create([
                                   'param_name', 'direction',
                                   'param_type', 'string',
                                   'param_description', '(opcional) Ordenação (asc, desc)'
                                   ]));
  end
  else  if AMetodo.ToLower = 'post' then begin
    Exit;
  end
  else  if AMetodo.ToLower = 'put' then begin
    Result.Add(TJSONObject.Create([
                                   'param_name', 'id',
                                   'param_type', 'integer',
                                   'param_description', 'Código do registro a ser alterado'
                                   ]));
  end
  else if AMetodo.ToLower = 'patch' then begin
    Result.Add(TJSONObject.Create([
                                   'param_name', 'id',
                                   'param_type', 'integer',
                                   'param_description', 'Código do registro a ser alterado'
                                   ]));
  end
  else if AMetodo.ToLower = 'delete' then begin
    Result.Add(TJSONObject.Create([
                                   'param_name', 'id',
                                   'param_type', 'integer',
                                   'param_description', 'Código do registro a ser excluído'
                                   ]));
  end;
 end;

function TUtilGeraRestInfo.BodyFieldsDescription(qry: TZQuery; AQdeCampos: Integer; AExcluirPrimayKey: Boolean): TJSONArray;
// modelo do Body para o request e response
var
  j: TJSONObject;
  lCount: Integer;
  lCampo, lCampoAlias, lcampoTipo, lCampoEspecial, ldescricao: string;
  bCampoAceito, bChavePrimaria, bRequerido, bLimparMascara, bCurrencyField: Boolean;
  lMaxLen, lPrecisao, lScale: LongInt;
  sMaxLen, sRequired: string;
begin
  Result := TJSONArray.Create;

  lCount := 0;
  qry.First;
  while not qry.EOF do begin
    lCampo := qry.FieldByName('campo').AsString;
    lCampoAlias := qry.FieldByName('campo_alias').AsString;
    if Trim(lCampoAlias) = '' then lCampoAlias := lcampo;
    lcampoTipo := qry.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    bCurrencyField := qry.FieldByName('currency_field').AsInteger = 1;
    bChavePrimaria := (qry.FieldByName('chave_primaria').AsInteger = 1);
    lMaxLen := StrToIntDef('0' + qry.FieldByName('tamanho').AsString, 50); //MaxLength do campo
    lPrecisao := StrToIntDef('0' + qry.FieldByName('precisao').AsString, 0); //tamanho o número
    lScale := StrToIntDef('0' + qry.FieldByName('escala').AsString, 2);   //casas decimais
    bRequerido := (qry.FieldByName('requerido').AsInteger = 1); //campo obrigatório
    ldescricao := Trim(qry.FieldByName('cmp_descricao').AsString);

    if ldescricao = '' then ldescricao := 'Undefined';

    sMaxLen := lMaxLen.ToString;
    bCampoAceito := True;

    case lcampoTipo.ToLower of
      'boolean':   lcampoTipo := 'boolean';
      'string':    lcampoTipo := 'string';
      'integer':   lcampoTipo := 'integer';
      'currency':  lcampoTipo := 'float';
      'double':    lcampoTipo := 'float';
      'tdatetime': lcampoTipo := 'datetime';
      'timage':
        begin
          bCampoAceito := False;
          lcampoTipo := 'image';
        end;
      else begin
        lcampoTipo := 'string';
      end;
    end;

    if AExcluirPrimayKey and bChavePrimaria then bCampoAceito := False;

    if bCampoAceito then begin
      lCount := lCount + 1;
      if (AQdeCampos > 0) and (lCount > AQdeCampos) then Break;

      j := TJSONObject.Create;
      j.Add('field_name', lCampoAlias);
      j.Add('field_type', lcampoTipo);
      j.Add('field_length', sMaxLen);
      j.Add('field_required', bRequerido);
      j.Add('field_description', ldescricao);

      Result.Add(j);
    end; // if

    qry.Next;
  end; //while
end;

function TUtilGeraRestInfo.ResponseBody(AMethod: string; ASucesso: Boolean): TJSONObject;
// modelo do response
var
  lMessage: string;
begin
  Result := TJSONObject.Create;

  if AMethod = 'get' then begin
    if not ASucesso then begin
      Result.Add('success', ASucesso);
      Result.Add('message', 'ID not provided');
    end;
  end
  else if AMethod = 'get_list' then begin
    Exit;
  end
  else if AMethod = 'post' then begin
    Result.Add('success', ASucesso);
    if ASucesso then
      Result.Add('message', 'Record created successfully. ID = 1')
    else
      Result.Add('message', 'Description error...');
  end
  else if AMethod = 'put' then begin
    Result.Add('success', ASucesso);
    if ASucesso then
      Result.Add('message', 'Record updated successfully.')
    else
      Result.Add('message', 'Description error...');
  end
  else if AMethod = 'patch' then begin
    Result.Add('success', ASucesso);
    if ASucesso then
      Result.Add('message', 'Record updated successfully.')
    else
      Result.Add('message', 'Description error...');
  end
  else if AMethod = 'delete' then begin
    Result.Add('success', ASucesso);
    if ASucesso then
      Result.Add('message', 'Record deleted successfully. ID = 1')
    else
      Result.Add('message', 'Description error...');
  end;
end;

function TUtilGeraRestInfo.ResponseBodyList(qry: TZQuery; AQdeItens: Integer): TJSONObject;
// modelo do Body para o response get paginação
var
  jobj: TJSONObject;
  jarr: TJSONArray;
  i: Integer;
  lCampo, lCampoAlias, lcampoTipo: string;
  bCampoAceito, bIncluirNaLista, bChaveEstrangeira: Boolean;
begin
  Result := TJSONObject.Create;

  if AQdeItens < 1 then AQdeItens := 1;
  if AQdeItens > 5 then AQdeItens := 5;

  jarr := TJSONArray.Create;

  for i := 1 to AQdeItens do begin
    jobj := TJSONObject.Create;
    qry.First;
    while not qry.EOF do begin
      lCampo := qry.FieldByName('campo').AsString;
      lCampoAlias := qry.FieldByName('campo_alias').AsString;
      if Trim(lCampoAlias) = '' then lCampoAlias := lcampo;
      lcampoTipo := qry.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
      bIncluirNaLista := qry.FieldByName('incluir_na_grid').AsInteger = 1;
      bChaveEstrangeira := qry.FieldByName('chave_estrangeira').AsInteger = 1;

      bCampoAceito := True;

      case lcampoTipo.ToLower of
        'boolean': lcampoTipo := 'boolean';
        'string':  lcampoTipo := 'string';
        'integer': lcampoTipo := 'integer';
        'currency':lcampoTipo := 'float';
        'double':  lcampoTipo := 'float';
        'tdatetime': lcampoTipo := 'datetime';
        'timage':
          begin
            bCampoAceito := False;
            lcampoTipo := 'image';
          end;
        else begin
          lcampoTipo := 'string';
        end;
      end;

      if bCampoAceito and bIncluirNaLista then begin
        case lcampoTipo.ToLower of
          'boolean':  jobj.Add(lCampoAlias, True);
          'datetime': jobj.Add(lCampoAlias, Format('%s', [DateToISO8601(now + i)]));
          'float':    jobj.Add(lCampoAlias, 71.50 * i);
          'integer':  jobj.Add(lCampoAlias, i);
          'string':   jobj.Add(lCampoAlias, 'abc ' + IntToStr(i));
        end;

        if bChaveEstrangeira then
          jobj.Add(lCampoAlias + '_value', 'abcde ' + IntToStr(i));
      end;

      qry.Next;
    end; //while

    jarr.Add(jobj);
  end;

  Result.Add('page', 1);
  Result.Add('per_page', AQdeItens);
  Result.Add('total_pages', 10);
  Result.Add('total_records', Trunc(Power(10, AQdeItens)));
  Result.Add('data', jArr);
end;

function TUtilGeraRestInfo.BodyFieldsToSendOrReceive(qry: TZQuery; AQdeCampos: Integer; AExcluirPrimayKey: Boolean): TJSONObject;
// exemplo de dados a ser enviado no body ou no response response
var
  lCount: Integer;
  lCampo, lCampoAlias, lcampoTipo: string;
  bCampoAceito, bChavePrimaria, bChaveEstrangeira: Boolean;
begin
  Result := TJSONObject.Create;

  lCount := 0;
  qry.First;
  while not qry.EOF do begin
    lCampo := qry.FieldByName('campo').AsString;
    lCampoAlias := qry.FieldByName('campo_alias').AsString;
    if Trim(lCampoAlias) = '' then lCampoAlias := lcampo;
    lcampoTipo := qry.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    bChavePrimaria := (qry.FieldByName('chave_primaria').AsInteger = 1);
    bChaveEstrangeira := qry.FieldByName('chave_estrangeira').AsInteger = 1;

    bCampoAceito := True;
    if AExcluirPrimayKey and bChavePrimaria then bCampoAceito := False;

    case lcampoTipo.ToLower of
      'boolean':   lcampoTipo := 'boolean';
      'string':    lcampoTipo := 'string';
      'integer':   lcampoTipo := 'integer';
      'currency':  lcampoTipo := 'float';
      'double':    lcampoTipo := 'float';
      'tdatetime': lcampoTipo := 'datetime';
      'timage':
        begin
          bCampoAceito := False;
          lcampoTipo := 'image';
        end;
      else begin
        lcampoTipo := 'string';
      end;
    end;

    if bCampoAceito then begin
      lCount := lCount + 1;
      if (AQdeCampos > 0) and (lCount > AQdeCampos) then Break;

      case lcampoTipo.ToLower of
        'boolean':  Result.Add(lCampoAlias, True);
        'datetime': Result.Add(lCampoAlias, Format('%s', [DateToISO8601(now + lCount)]));
        'float':    Result.Add(lCampoAlias, 71.50 * lCount);
        'integer':  Result.Add(lCampoAlias, lCount);
        'string':   Result.Add(lCampoAlias, 'abc ' + IntToStr(lCount));
      end;

      if bChaveEstrangeira then
        Result.Add(lCampoAlias + '_value', 'abcde ' + IntToStr(lCount));
    end;

    qry.Next;
  end; //while
end;

function TUtilGeraRestInfo.RotaAuth: TJSONArray;
// rota padrão de autenticação
begin
  Result := TJSONArray.Create;

  Result.Add(TJSONObject.Create([
                             'field_name', 'username',
                             'field_type', 'string',
                             'field_length', '50',
                             'field_required', true,
                             'field_description', 'Login do usuário'
                             ]));

  Result.Add(TJSONObject.Create([
                             'field_name', 'password',
                             'field_type', 'string',
                             'field_length', '50',
                             'field_required', true,
                             'field_description', 'Senha do usuário'
                             ]));
end;

end.

