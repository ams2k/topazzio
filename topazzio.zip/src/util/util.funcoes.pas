unit Util.Funcoes;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, StdCtrls, Graphics, LCLType;

type

  { Funcoes }

  Funcoes = class
    public
      class procedure EditBackColor(var AObj: TObject; AFocused: Boolean);
      class function MenuCor: TColor;
      class function MenuCorHover: TColor;
      class function MenuCorSelecionado: TColor;
  end;

implementation

{ Funcoes }

class procedure Funcoes.EditBackColor(var AObj: TObject; AFocused: Boolean);
//muda a cor de fundo do TEdit/TMemo quando tem foco e quando perde o foco
begin
  if AFocused then
    begin
      if AObj Is TEdit then (AObj As Tedit).Color := TColor($00D5FFFF);
      if AObj Is TMemo then (AObj As TMemo).Color := TColor($00D5FFFF);
    end
  else
    begin
      if AObj Is TEdit then (AObj As TEdit).Color := clWhite;
      if AObj Is TMemo then (AObj As TMemo).Color := clWhite;
    end;
end;

class function Funcoes.MenuCor: TColor;
begin
  Result := $00C8B730; // $0044CD81
end;

class function Funcoes.MenuCorHover: TColor;
begin
  Result := $00E9D220; // RGBToColor(141, 219, 79)
end;

class function Funcoes.MenuCorSelecionado: TColor;
begin
  Result := $003E7BC0; // $00393953
end;

end.

