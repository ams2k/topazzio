unit Util.PostmanGen;

// Gera arquivo postman.json com as rotas da API

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, fpjson, jsonparser, fgl;

type

  { TPostmanQueryParam }

  TPostmanQueryParam = class
  public
    Key: String;
    Value: String;
    Description: String;
    Disabled: Boolean;
  end;

  TPostmanQueryParamList = specialize TFPGObjectList<TPostmanQueryParam>;

  { TPostmanHeader }

  TPostmanHeader = class
  public
    Key: String;
    Value: String;
    HeaderType: String;
    Disabled: Boolean;
  end;

  TPostmanHeaderList = specialize TFPGObjectList<TPostmanHeader>;

  { TPostmanRequest }

  TPostmanRequest = class
  private
    FHeaders: TPostmanHeaderList;
    FQueryParams: TPostmanQueryParamList;
  public
    Name: String;
    Method: String;
    Url: String;
    Description: String;
    Body: String;
    BearerToken: String;
    Host: string;
    Port: string;

    constructor Create;
    destructor Destroy; override;

    procedure AddHeader(const AKey, AValue: String; const AType: String = 'text'; ADisabled: Boolean = False);
    procedure AddQueryParam(const AKey, AValue: String; const ADescription: String = ''; ADisabled: Boolean = False);
    function ToJSON: TJSONObject;
  end;

  TPostmanRequestList = specialize TFPGObjectList<TPostmanRequest>;

  { TPostmanCollection }

  TPostmanCollection = class
  private
    FRequests: TPostmanRequestList;
  public
    Name: String;

    constructor Create;
    destructor Destroy; override;

    procedure AddRequest(ARequest: TPostmanRequest);
    function GenerateJSON: String;
    procedure SaveToFile(const AFileName: String);
  end;

implementation

{ TPostmanRequest }

constructor TPostmanRequest.Create;
begin
  inherited Create;

  FHeaders := TPostmanHeaderList.Create(True);
  FQueryParams := TPostmanQueryParamList.Create(True);
end;

destructor TPostmanRequest.Destroy;
begin
  FHeaders.Free;
  FQueryParams.Free;

  inherited Destroy;
end;

procedure TPostmanRequest.AddHeader(const AKey, AValue: String; const AType: String; ADisabled: Boolean);
var
  H: TPostmanHeader;
begin
  H := TPostmanHeader.Create;

  H.Key := AKey;
  H.Value := AValue;
  H.HeaderType := AType;
  H.Disabled := ADisabled;

  FHeaders.Add(H);
end;

procedure TPostmanRequest.AddQueryParam(const AKey, AValue: String; const ADescription: String; ADisabled: Boolean);
var
  Q: TPostmanQueryParam;
begin
  Q := TPostmanQueryParam.Create;

  Q.Key := AKey;
  Q.Value := AValue;
  Q.Description := ADescription;
  Q.Disabled := ADisabled;

  FQueryParams.Add(Q);
end;

function TPostmanRequest.ToJSON: TJSONObject;
var
  Obj: TJSONObject;
  RequestObj: TJSONObject;
  HeadersArr: TJSONArray;
  HeaderObj: TJSONObject;
  QueryArr: TJSONArray;
  QueryObj: TJSONObject;
  UrlObj: TJSONObject;
  PathArr: TJSONArray;
  BodyObj: TJSONObject;
  AuthObj: TJSONObject;
  BearerArr: TJSONArray;
  I: Integer;
  UrlWithoutProtocol: String;
  UrlParts: TStringArray;
begin
  Obj := TJSONObject.Create;

  Obj.Add('name', Name);

  RequestObj := TJSONObject.Create;

  { METHOD }

  RequestObj.Add('method', UpperCase(Method));

  { HEADERS }

  HeadersArr := TJSONArray.Create;

  for I := 0 to FHeaders.Count - 1 do
  begin
    HeaderObj := TJSONObject.Create;
    HeaderObj.Add('key', FHeaders[I].Key);
    HeaderObj.Add('value', FHeaders[I].Value);
    HeaderObj.Add('type', FHeaders[I].HeaderType);
    HeaderObj.Add('disabled', FHeaders[I].Disabled);
    HeadersArr.Add(HeaderObj);
  end;

  RequestObj.Add('header', HeadersArr);

  { AUTH }

  if BearerToken <> '' then
  begin
    BearerArr := TJSONArray.Create;

    BearerArr.Add(TJSONObject.Create([
        'key', 'token',
        'value', BearerToken,
        'type', 'string'
      ])
    );

    AuthObj := TJSONObject.Create([
      'type', 'bearer',
      'bearer', BearerArr
    ]);

    RequestObj.Add('auth', AuthObj);
  end;

  { BODY }

  if Trim(Body) <> '' then
  begin
    BodyObj := TJSONObject.Create;

    BodyObj.Add('mode', 'raw');
    BodyObj.Add('raw', Body);

    BodyObj.Add(
      'options',
      TJSONObject.Create([
        'raw',
        TJSONObject.Create([
          'language',
          'json'
        ])
      ])
    );

    RequestObj.Add('body', BodyObj);
  end;

  { URL }

  if Pos('?', Url)>1 then Url := LeftStr(Url, Pos('?', Url) -1);

  UrlObj := TJSONObject.Create;

  UrlObj.Add('raw', Url);
  UrlObj.Add('host', TJSONArray.Create([Host]));
  UrlObj.Add('port', Port);

  UrlWithoutProtocol := Url;

  UrlWithoutProtocol :=
    StringReplace(
      UrlWithoutProtocol,
      'https://',
      '',
      [rfReplaceAll, rfIgnoreCase]
    );

  UrlWithoutProtocol :=
    StringReplace(
      UrlWithoutProtocol,
      'http://',
      '',
      [rfReplaceAll, rfIgnoreCase]
    );

  UrlParts := UrlWithoutProtocol.Split(['/']);

  PathArr := TJSONArray.Create;

  for I := 1 to High(UrlParts) do
  begin
    if Trim(UrlParts[I]) <> '' then
      PathArr.Add(UrlParts[I]);
  end;

  UrlObj.Add('path', PathArr);

  { QUERY }

  QueryArr := TJSONArray.Create;

  for I := 0 to FQueryParams.Count - 1 do
  begin
    QueryObj := TJSONObject.Create;

    QueryObj.Add('key', FQueryParams[I].Key);
    QueryObj.Add('value', FQueryParams[I].Value);
    QueryObj.Add('description', FQueryParams[I].Description);
    QueryObj.Add('disabled', FQueryParams[I].Disabled);

    QueryArr.Add(QueryObj);
  end;

  UrlObj.Add('query', QueryArr);
  RequestObj.Add('url', UrlObj);

  { DESCRIPTION }

  if Trim(Description) <> '' then
    RequestObj.Add('description', Description);

  Obj.Add('request', RequestObj);

  Result := Obj;
end;

{ TPostmanCollection }

constructor TPostmanCollection.Create;
begin
  inherited Create;

  FRequests := TPostmanRequestList.Create(True);
end;

destructor TPostmanCollection.Destroy;
begin
  FRequests.Free;

  inherited Destroy;
end;

procedure TPostmanCollection.AddRequest(ARequest: TPostmanRequest);
begin
  FRequests.Add(ARequest);
end;

function TPostmanCollection.GenerateJSON: String;
var
  Root: TJSONObject;
  InfoObj: TJSONObject;
  ItemsArr: TJSONArray;
  G: TGUID;
  I: Integer;
begin
  Root := TJSONObject.Create;

  try

    { INFO }

    InfoObj := TJSONObject.Create;

    InfoObj.Add('name', Name);

    CreateGUID(G);

    InfoObj.Add('_postman_id', GUIDToString(G));

    InfoObj.Add(
      'schema',
      'https://schema.getpostman.com/json/collection/v2.1.0/collection.json'
    );

    Root.Add('info', InfoObj);

    { ITEMS }

    ItemsArr := TJSONArray.Create;

    for I := 0 to FRequests.Count - 1 do
      ItemsArr.Add(FRequests[I].ToJSON);

    Root.Add('item', ItemsArr);

    Result := Root.FormatJSON;
  finally
    Root.Free;
  end;
end;

procedure TPostmanCollection.SaveToFile(const AFileName: String);
var
  SL: TStringList;
begin
  SL := TStringList.Create;
  try
    SL.Text :=  GenerateJSON;
    SL.SaveToFile(AFileName);
  finally
    SL.Free;
  end;
end;

end.

