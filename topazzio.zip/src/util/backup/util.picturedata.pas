unit Util.PictureData;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils;

implementation

end.

