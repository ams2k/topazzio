unit Util.GeraCrud;

// Gera o projeto completo com base nas tabelas obtidas dos scripts ou do servidor de banco de dados

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, StrUtils, Dialogs,  DateUtils, Strings,
  Service.Projeto, Service.Tabela, Service.Campo;

type
  TTipoBanco = (POSTGRE, MYSQL, FIREBIRD, SQLITE, SQLSERVER, ORACLE, MARIADB, NONE);

  { TProjetoLazarus }

  TProjetoLazarus = class
    private
      FErro: String;
      FIdProjeto: Integer;
      FTipoBanco: TTipoBanco;
      FModernUI: Boolean;
      Projeto: TServiceProjeto;

      FPastaRaiz: String;
      FPastaDataModule: String;
      FPastaModels: String;
      FPastaViews: String;
      FPastaServices: String;
      FPastaUtil: String;
      FPastaImagens: String;

      function LerArquivo(APathFilne: String): String;

      procedure Configurar(AValue: TTipoBanco);
      procedure CriarPasta(APasta: String);
      procedure SalvarArquivo(APathFilename, AContent: String);

      procedure GerarMainProject;
      procedure GerarMainForm;
      procedure GerarDatamodule;
      procedure GerarClasse;
      procedure GerarForm;
      procedure GerarFormPesquisa;
      procedure GerarFormSplash;
    public
      property GetErro: String read FErro;
      function GerarProjeto(AIdProjeto: Integer; AModernUI: Boolean): Boolean;
  end;

implementation

{ TProjetoLazarus }

function TProjetoLazarus.GerarProjeto(AIdProjeto: Integer; AModernUI: Boolean): Boolean;
//Gera o projeto
begin
  FErro     := '';
  Result    := False;
  FModernUI := AModernUI;
  Projeto   := TServiceProjeto.Create;

  if Projeto.Ler( AIdProjeto ) then begin
    FIdProjeto := AIdProjeto;
    FTipoBanco := TTipoBanco( Projeto.IdTipoBanco );

    Configurar( FTipoBanco );

    GerarMainProject;
    GerarMainForm;
    GerarFormSplash;
    GerarDatamodule;
    GerarClasse;
    GerarForm;
    GerarFormPesquisa;

    Result := True;
  end else
    FErro := Projeto.GetErro;

  Projeto.Free;
end;

procedure TProjetoLazarus.Configurar(AValue: TTipoBanco);
// tipo_banco/nome_projeto/src/{datamodule, models, services, views, utils}
begin
  FTipoBanco := AValue;

  FPastaRaiz := ExtractFileDir( ParamStr(0) ) + PathDelim;

  case FTipoBanco of
    POSTGRE:
      FPastaRaiz := FPastaRaiz + 'postgre' + PathDelim;
    MYSQL:
      FPastaRaiz := FPastaRaiz + 'mysql' + PathDelim;
    MARIADB:
      FPastaRaiz := FPastaRaiz + 'mariadb' + PathDelim;
    FIREBIRD:
      FPastaRaiz := FPastaRaiz + 'firebird' + PathDelim;
    SQLITE:
      FPastaRaiz := FPastaRaiz + 'sqlite' + PathDelim;
    SQLSERVER:
      FPastaRaiz := FPastaRaiz + 'sqlserver' + PathDelim;
    ORACLE:
      FPastaRaiz := FPastaRaiz + 'oracle' + PathDelim;
  end;

  //cria a pasta raiz. Ex: postgre/
  CriarPasta(FPastaRaiz);

  //pasta de fontes. Ex: postgre/src/
  FPastaRaiz := FPastaRaiz + PathDelim + 'src' + PathDelim;
  CriarPasta(FPastaRaiz);

  //demais pastas
  FPastaDataModule := FPastaRaiz + 'datamodule' + PathDelim;
  FPastaModels     := FPastaRaiz + 'models' + PathDelim;
  FPastaServices   := FPastaRaiz + 'services' + PathDelim;
  FPastaUtil       := FPastaRaiz + 'util' + PathDelim;
  FPastaViews      := FPastaRaiz + 'views' + PathDelim;
  FPastaImagens    := FPastaRaiz + 'images' + PathDelim;

  CriarPasta( FPastaDataModule );
  CriarPasta( FPastaModels );
  CriarPasta( FPastaServices );
  CriarPasta( FPastaViews );
  CriarPasta( FPastaUtil );
  CriarPasta( FPastaImagens );
end;

procedure TProjetoLazarus.CriarPasta(APasta: String);
// cria pastas
var
  s: String;
begin
  try
    if not DirectoryExists(APasta) then
      CreateDir(APasta);
  except
    on E: Exception do
      s := E.Message;
  end;
end;

procedure TProjetoLazarus.SalvarArquivo(APathFilename, AContent: String);
//salva o arquivo informado
var
  docFile: TextFile;
  s: String;
begin
  // deleta o arquivo, se existir
  if FileExists(APathFilename) then
    DeleteFile(APathFilename);

  // Define o arquivo a ser criado
  AssignFile(docFile, APathFilename);

  // Use isso para permitir capturar exceções. Não precisa usar se não quiser.
  {$I+}

  try
    // Cria ou sobrescreve o arquivo
    Rewrite(docFile);

    // grava o conteúdo do arquivo
    WriteLn(docFile, AContent);

    // fecha o arquivo
    CloseFile(docFile);
  except
    on E: EInOutError do
     s := 'Erro no arquivo.' + sLineBreak + APathFilename + sLineBreak + E.ClassName + sLineBreak + E.Message;
  end;
end;

function TProjetoLazarus.LerArquivo(APathFilne: String): String;
//ler dados do arquivo indicado
var
  lArquivo: TextFile;
  sTexto: String;
  i: Integer;
begin
  Result := '';
  i := 0;

  if FileExists(APathFilne) then begin

    AssignFile(lArquivo, APathFilne);
    Reset(lArquivo);

    try
       while not EOF(lArquivo) do begin
         sTexto := '';
         ReadLn (lArquivo, sTexto);

         if i > 0 then
           Result := Result + sLineBreak;

         Result := Result + sTexto;
         inc(i);
       end
    finally
       CloseFile(lArquivo)
    end
  end;
end;

procedure TProjetoLazarus.GerarMainProject;
begin
  //
end;

procedure TProjetoLazarus.GerarForm;
begin
  //
end;

procedure TProjetoLazarus.GerarFormPesquisa;
begin
 //
end;

procedure TProjetoLazarus.GerarFormSplash;
begin
  //
end;

procedure TProjetoLazarus.GerarMainForm;
begin
  //
end;

procedure TProjetoLazarus.GerarDatamodule;
begin
  //
end;

procedure TProjetoLazarus.GerarClasse;
begin
  //
end;

end.

