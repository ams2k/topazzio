unit Util.Criptografia;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, base64, BlowFish;

type

  { TCriptografa }

  TCriptografa = class
    private
      FKey: string;
    public
      constructor Create(ASecretKey: string = 'key@secret9');
      function Encrypt(AValueToEncrypt: string): string;
      function Decrypt(AValue: string): string;
  end;

implementation

{ TCriptografa }

constructor TCriptografa.Create(ASecretKey: string);
begin
  if Trim(ASecretKey) <> '' then
    FKey := ASecretKey;
end;

function TCriptografa.Encrypt(AValueToEncrypt: string): string;
//criptografa a string em AValue
var
  en: TBlowFishEncryptStream;
  s1: TStringStream;
  temp: String;
begin
  s1 := TStringStream.Create('');
  en := TBlowFishEncryptStream.Create(FKey, s1);
  en.WriteAnsiString( AValueToEncrypt );
  en.Free;
  Result := s1.DataString;
  s1.Free;
end;

function TCriptografa.Decrypt(AValue: string): string;
//descriptografa a string em AValue
begin

end;

end.

