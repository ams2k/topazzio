unit Util.ProjetoLazarusAPI;

// Gera o projeto completo do Servidor da API com base nas tabelas
// obtidas dos scripts ou do servidor de banco de dados

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ExtCtrls, StrUtils, Dialogs, HTTPDefs, DateUtils, ZDataset, DB,
  Util.ProjetoCommon,
  Service.Projeto, Service.RestApi, Service.Tabela, Service.Campo;

type

   { TProjetoLazarusAPI }

   TProjetoLazarusAPI = class

     private
       FPastaPublicImages: string;
       Projeto: TServiceRestApi;

       FErro: String;
       FIdProjeto: Integer;
       FTipoBanco: TTipoBanco;
       FProtocolo: string;
       FListaTabelasID: string; //apenas os IDs das tabelas

       FPastaRaiz: String;
       FPastaDataModule: String;
       FPastaModels: String;
       FPastaServices: String;
       FPastaUtil: String;
       FPastaRelease: string;
       FPastaReleasePublic: string;
       FPastaImagens: String;
       FPastaReports: string;
       FPastaCore, FPastaRoutes: string;
       FVersaoAbreviada: string;
       FVersaoAbreviadaRota: string;
       FPastaDocumentacaoDOC: string;
       FPastaDocumentacaoSwagger: string;
       FCriarServiceClasses: Boolean;
       FCriarModuloBoleto: Boolean;

       function AjustaNomeRota(ANomeTabela, ANomeRota: string): string;
       procedure Boleto_ApiFuncoes;
       procedure Boleto_BancoBradesco;
       procedure Boleto_BancoBrasil;
       procedure Boleto_BancoItau;
       procedure Boleto_BancoSantander;
       procedure Boleto_BancoSicoob;
       procedure Boleto_CaixaFederal;
       procedure Boleto_RouteFinanceiro;
       procedure GeraCore_HtmlToPdf;
       procedure Boleto_Layout;
       procedure Boleto_LinhaDigitavel;
       procedure Boleto_Models;
       procedure Boleto_Pix;
       function BooleanToString(AValue: Boolean): string;
       procedure Configurar(AValue: TTipoBanco);
       function GerarMailtoURI(AEmail, ASubject, ABody: string): string;
       procedure GerarMainProject;
       procedure GerarClasse(qryCampos: TZQuery);
       procedure GerarJSONTableStructure(qryCampos: TZQuery);
       procedure GerarModulosBoleto;
       procedure GerarObjetos;
       procedure GerarArquivoINI;
       procedure GeraCore_Server;
       procedure GeraCore_Cors;
       procedure GeraCore_DataControl;
       procedure GearCore_HttpContext;
       procedure GeraCore_JsonFloat;
       procedure GeraCore_JWT;
       procedure GeraCore_JWTMiddleware;
       procedure GeraCore_Logger;
       procedure GeraCore_Middleware;
       procedure GeraCore_RegisterRoutes;
       procedure GeraCore_Router;
       procedure GeraCore_StatusCode;
       procedure GeraCore_Util;
       procedure GeraModel_User;
       procedure GeraRoute_Auth;
       procedure GeraRoute_Doc;
       procedure GeraRotas(AObjetoTabela, ARota: string; campos: TZQuery);
       procedure GerarUtilCriptografia;
       procedure GerarUtilImagem;
       procedure GeraService_Auth;
       procedure GerarCore_HTMLResponse;
       procedure GerarReDoc;
       procedure CriarScriptTabelaAuditagem(AProtocolo: string);
     public
       constructor Create;
       destructor Destroy; override;
       property GetErro: String read FErro;
       property GetPastaRaiz: String read FPastaRaiz;
       property GetPastaRelease: string read FPastaRelease;
       property GetPastaPublic: string read FPastaReleasePublic;
       property GetPastaPublicImages: string read FPastaPublicImages;
       function GerarProjeto(AIdProjeto: Integer; AListaTabelasID: string): Boolean;
   end;

implementation

uses
  Util.Idioma, Util.GeraDoc, Util.GeraRestInfo, Util.GeraSwagger;

{ TProjetoLazarusAPI }

constructor TProjetoLazarusAPI.Create;
begin
  //
end;

destructor TProjetoLazarusAPI.Destroy;
begin
  inherited Destroy;
end;

function TProjetoLazarusAPI.GerarProjeto(AIdProjeto: Integer; AListaTabelasID: string): Boolean;
var
  lversao: array of String;
begin
  FErro           := '';
  Result          := False;
  FListaTabelasID := AListaTabelasID;
  FProtocolo      := '';
  FCriarServiceClasses := False;
  FCriarModuloBoleto := False;

  Projeto := TServiceRestApi.Create( AIdProjeto );

  if Projeto.Ler then begin
    if Projeto.ApiTotalTabelas < 1 then begin
      Result := False;
      FErro := ViewMain.ApiNenhumaTabelaIndicada;
      Projeto.Free;
      Exit;
    end;

    FCriarServiceClasses := Projeto.ApiClasseService;
    FCriarModuloBoleto := Projeto.ApiBoleto;
    FIdProjeto := AIdProjeto;
    FTipoBanco := TTipoBanco( Projeto.Proj_IdTipoBanco );
    FProtocolo := TUtilCommon.GetProtocoloSGDB( FTipoBanco) ;

    if Projeto.ApiVersao = ''  then Projeto.ApiVersao  := '/api/v1';
    if Projeto.ApiAdminNome  = '' then Projeto.ApiAdminNome  := 'Topazzio Rest Api Server';
    if Projeto.ApiAdminEmail = '' then Projeto.ApiAdminEmail := 'contato@example.com';
    if Projeto.ApiHeader1 = '' then Projeto.ApiHeader1 := 'Header 1';
    if Projeto.ApiHeader2 = '' then Projeto.ApiHeader2 := 'Header 2';
    if Projeto.ApiHeader3 = '' then Projeto.ApiHeader3 := 'Header 3';
    if Projeto.ApiFooter1 = '' then Projeto.ApiFooter1 := 'Footer 1';
    if Projeto.ApiFooter2 = '' then Projeto.ApiFooter2 := 'Footer 2';

    FVersaoAbreviada := '';
    lversao := Projeto.ApiVersao.Split(['/'], TStringSplitOptions.ExcludeEmpty);

    if High(lversao)>0 then begin
      FVersaoAbreviada := lversao[High(lversao)];
      if LeftStr(FVersaoAbreviada, 1) <> 'v' then
        FVersaoAbreviada := 'v' + FVersaoAbreviada;
    end;

    if Trim(FVersaoAbreviada) = '' then FVersaoAbreviada := 'v1';
    FVersaoAbreviadaRota := '_' + FVersaoAbreviada;

    SetLength(lversao, 0);

    //cria as pastas
    Configurar( FTipoBanco );

    Projeto.SetApiDefaults( FPastaRaiz );

    // cria programa principal: .lpr e .lpi
    GerarMainProject;

    // cria arquivo de configuração do host e database
    GerarArquivoINI;

    // cria o datamodule
    if FTipoBanco = SQLSERVER then
      TUtilCommon.GerarDatamoduleMSSQL( FPastaDataModule, 'server.ini', Projeto.ApiAudit )
    else
      TUtilCommon.GerarDatamodule( FIdProjeto, FProtocolo, FListaTabelasID, FPastaDataModule, 'server.ini', Projeto.ApiAudit );

    // cria o Core do servidor
    GeraCore_Server;
    GeraCore_Cors;
    GeraCore_DataControl;
    GerarCore_HTMLResponse;
    GearCore_HttpContext;
    GeraCore_JsonFloat;
    GeraCore_JWT;
    GeraCore_JWTMiddleware;
    GeraCore_Logger;
    GeraCore_Middleware;
    GeraCore_RegisterRoutes;
    GeraCore_Router;
    GeraCore_StatusCode;
    GeraCore_Util;
    GeraCore_HtmlToPdf;
    GeraModel_User;
    GeraRoute_Auth;
    //GeraRoute_Doc;

    // cria rotas para as tabelas, service classes, modelo de dados das tabelas
    GerarObjetos;
    GerarUtilCriptografia;
    //GerarUtilImagem;

    GeraService_Auth;
    CriarScriptTabelaAuditagem(FProtocolo);

    if Projeto.ApiAudit then
      TUtilCommon.GerarServiceApiAudit(FPastaServices, FTipoBanco);

    // módulos de boleto e pix
    if Projeto.ApiBoleto then
      GerarModulosBoleto;

    // documentação da API
    with TUtilGeraDoc.Create do begin
      GeraDocumento(Projeto, FListaTabelasID, FPastaDocumentacaoDOC);
      Free;
    end;

    // Json para importação no programa Topazzio Rest API
    with TUtilGeraRestInfo.Create do begin
      GeraDocumento(Projeto, FListaTabelasID, FPastaRelease);
      Free;
    end;

    // documentação da API com Swagger
    with TUtilGeraSwagger.Create do begin
      GeraDocumento(Projeto, FListaTabelasID, FVersaoAbreviada, FPastaDocumentacaoSwagger, FPastaRelease);
      GerarReDoc;
      Free;
    end;

    Result := True;
  end else
    FErro := Projeto.GetErro;

  Projeto.Free;
end;

procedure TProjetoLazarusAPI.Configurar(AValue: TTipoBanco);
// tipo_banco/nome_projeto/src/{datamodule, imagens, models, services, views, utils}
begin
  FTipoBanco := AValue;

  FPastaRaiz := ExtractFileDir( ParamStr(0) ) + PathDelim;


  // pasta projetos
  FPastaRaiz := FPastaRaiz + UtilProjetoLazarus.PastaProjetos + PathDelim;
  TUtilCommon.CriarPasta(FPastaRaiz);

  // pasta com nome do projeto: Ex: /projetos/nome_projeto/
  FPastaRaiz := FPastaRaiz + Projeto.Proj_Nome + PathDelim;
  TUtilCommon.CriarPasta(FPastaRaiz);

  case FTipoBanco of
    POSTGRE:
      FPastaRaiz := FPastaRaiz + 'postgre' + PathDelim;
    MYSQL:
      FPastaRaiz := FPastaRaiz + 'mysql' + PathDelim;
    MARIADB:
      FPastaRaiz := FPastaRaiz + 'mariadb' + PathDelim;
    FIREBIRD:
      FPastaRaiz := FPastaRaiz + 'firebird' + PathDelim;
    SQLITE:
      FPastaRaiz := FPastaRaiz + 'sqlite' + PathDelim;
    SQLSERVER:
      FPastaRaiz := FPastaRaiz + 'sqlserver' + PathDelim;
    ORACLE:
      FPastaRaiz := FPastaRaiz + 'oracle' + PathDelim;
  end;

  // cria a pasta ref. ao banco. Ex: /projetos/nome_projeto/postgre/
  TUtilCommon.CriarPasta(FPastaRaiz);

  // api
  FPastaRaiz := FPastaRaiz + 'api_server' + PathDelim;
  TUtilCommon.CriarPasta(FPastaRaiz);

  // pasta release
  FPastaRelease := FPastaRaiz + 'release' + PathDelim;
  TUtilCommon.CriarPasta(FPastaRelease);

  // pasta release/public
  FPastaReleasePublic := FPastaRelease + 'public';
  TUtilCommon.CriarPasta(FPastaReleasePublic);
  TUtilCommon.CriarPasta(FPastaReleasePublic + PathDelim + FVersaoAbreviada);
  TUtilCommon.CriarPasta(FPastaReleasePublic + PathDelim + FVersaoAbreviada + PathDelim + 'doc');
  TUtilCommon.CriarPasta(FPastaReleasePublic + PathDelim + FVersaoAbreviada + PathDelim + 'swagger' );
  TUtilCommon.CriarPasta(FPastaReleasePublic + PathDelim + 'js');
  TUtilCommon.CriarPasta(FPastaReleasePublic + PathDelim + 'css');
  TUtilCommon.CriarPasta(FPastaReleasePublic + PathDelim + 'images');

  FPastaDocumentacaoDOC     := FPastaReleasePublic + PathDelim + FVersaoAbreviada + PathDelim + 'doc';
  FPastaDocumentacaoSwagger := FPastaReleasePublic + PathDelim + FVersaoAbreviada + PathDelim + 'swagger';

  FPastaReleasePublic := FPastaReleasePublic + PathDelim;
  FPastaPublicImages := FPastaReleasePublic + 'images' + PathDelim;

  //pasta de fontes e projeto. Ex: postgre/src/
  FPastaRaiz := FPastaRaiz + 'src' + PathDelim;
  TUtilCommon.CriarPasta(FPastaRaiz);

  //demais pastas
  FPastaCore       := FPastaRaiz + 'core' + PathDelim;
  FPastaDataModule := FPastaRaiz + 'datamodule' + PathDelim;
  FPastaImagens    := FPastaRaiz + 'images' + PathDelim;
  FPastaModels     := FPastaRaiz + 'models' + PathDelim;
  FPastaReports    := FPastaRaiz + 'reports' + PathDelim;
  FPastaRoutes     := FPastaRaiz + 'routes' + PathDelim;
  FPastaServices   := FPastaRaiz + 'services' + PathDelim;
  FPastaUtil       := FPastaRaiz + 'util' + PathDelim;

  TUtilCommon.CriarPasta( FPastaCore );
  TUtilCommon.CriarPasta( FPastaDataModule );
  TUtilCommon.CriarPasta( FPastaImagens );
  TUtilCommon.CriarPasta( FPastaModels );
  TUtilCommon.CriarPasta( FPastaReports );
  TUtilCommon.CriarPasta( FPastaRoutes );
  TUtilCommon.CriarPasta( FPastaServices );
  TUtilCommon.CriarPasta( FPastaUtil );
end;

procedure TProjetoLazarusAPI.GerarMainProject;
//cria os arquivos do projeto: *.lpi, *.lpr
var
  st: TServiceTabela;
  tabelas: TZQuery;
  s, lTabela: string;
begin
  st := TServiceTabela.Create( FIdProjeto );
  tabelas := st.QueryTabelas( FListaTabelasID.Trim, True ); //tabelas

  //------------------------------[Arquivo .lpr]---------------------------------------------------

  s :=
  'program ' + Projeto.ApiNome.ToLower + '; ' + sLineBreak +
  ' ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '' + sLineBreak +
  '{$mode objfpc}{$H+}' + sLineBreak +
  '{$Codepage UTF8}' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  {$IFDEF UNIX}' + sLineBreak +
  '  cthreads,' + sLineBreak +
  '  {$ENDIF}' + sLineBreak +
  '  Classes, SysUtils,' + sLineBreak +
  '  Core.Server,' + sLineBreak +
  '  Core.JWT,' + sLineBreak +
  '  Core.JsonFloat;' + sLineBreak +
  '' + sLineBreak +
  'begin' + sLineBreak +
  '  AppServer := TAppServer.Create(nil);' + sLineBreak +
  '' + sLineBreak +
  '  JsonFloatNumber; // desativa notação científica em valores Float no Json' + sLineBreak +
  '  JWT_EncodedToken := True; // Token com payload codificado' + sLineBreak +
  '  JWT_HoursToExpire := 8; // total de horas para expirar o Token' + sLineBreak +
  '' + sLineBreak +
  '  with DefaultFormatSettings do begin' + sLineBreak +
  '    CurrencyString    := ''R$'';' + sLineBreak +
  '    CurrencyFormat    := 2;' + sLineBreak +
  '    DecimalSeparator  := '','';' + sLineBreak +
  '    ThousandSeparator := ''.'';' + sLineBreak +
  '    DateSeparator     := ''/'';' + sLineBreak +
  '    ShortDateFormat   := ''dd/mm/yyyy'';' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    AppServer.Static(''/'', ''./public'');' + sLineBreak +
  '    AppServer.Static(''/images'', ''./public/images'');' + sLineBreak +
  '    AppServer.Static(''/js'', ''./public/js'');' + sLineBreak +
  '    AppServer.Static(''/css'', ''./public/css''); ' + sLineBreak +
  '' + sLineBreak +
  '    AppServer.Run;' + sLineBreak +
  '  finally' + sLineBreak +
  '    AppServer.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end.' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaRaiz + Projeto.ApiNome.ToLower + '.lpr', s);
  s := '';

  //------------------------------[Arquivo .lpi]---------------------------------------------------

  s :=
  '<?xml version="1.0" encoding="UTF-8"?>' + sLineBreak +
  '<CONFIG>' + sLineBreak +
  '  <ProjectOptions>' + sLineBreak +
  '    <Version Value="12"/>' + sLineBreak +
  '    <General>' + sLineBreak +
  '      <Flags>' + sLineBreak +
  '        <MainUnitHasCreateFormStatements Value="False"/>' + sLineBreak +
  '        <MainUnitHasTitleStatement Value="False"/>' + sLineBreak +
  '        <MainUnitHasScaledStatement Value="False"/>' + sLineBreak +
  '      </Flags>' + sLineBreak +
  '      <SessionStorage Value="InProjectDir"/>' + sLineBreak +
  '      <Title Value="' + Projeto.ApiTitulo + '"/>' + sLineBreak +
  '      <UseAppBundle Value="False"/>' + sLineBreak +
  '      <ResourceType Value="res"/>' + sLineBreak +
  '    </General>' + sLineBreak +
  '    <BuildModes>' + sLineBreak +
  '      <Item Name="linux" Default="True"/>' + sLineBreak +
  '      <Item Name="windows">' + sLineBreak +
  '        <CompilerOptions>' + sLineBreak +
  '          <Version Value="11"/>' + sLineBreak +
  '          <Target>' + sLineBreak +
  '            <Filename Value="../release/' + Projeto.ApiNome.ToLower + '_windows.exe"/>' + sLineBreak +
  '          </Target>' + sLineBreak +
  '          <SearchPaths>' + sLineBreak +
  '            <IncludeFiles Value="$(ProjOutDir)"/>' + sLineBreak +
  '            <OtherUnitFiles Value="core;datamodule;models;reports;routes;services;util"/>' + sLineBreak +
  '            <UnitOutputDirectory Value="../temp/$(TargetCPU)-$(TargetOS)"/>' + sLineBreak +
  '          </SearchPaths>' + sLineBreak +
  '          <CodeGeneration>' + sLineBreak +
  '            <TargetCPU Value="x86_64"/>' + sLineBreak +
  '            <TargetOS Value="win64"/>' + sLineBreak +
  '          </CodeGeneration>' + sLineBreak +
  '        </CompilerOptions>' + sLineBreak +
  '      </Item>' + sLineBreak +
  '      <Item Name="aarch64">' + sLineBreak +
  '        <CompilerOptions>' + sLineBreak +
  '          <Version Value="11"/>' + sLineBreak +
  '          <Target>' + sLineBreak +
  '            <Filename Value="../release/' + Projeto.ApiNome.ToLower + '_aarch64"/>' + sLineBreak +
  '          </Target>' + sLineBreak +
  '          <SearchPaths>' + sLineBreak +
  '            <IncludeFiles Value="$(ProjOutDir)"/>' + sLineBreak +
  '            <OtherUnitFiles Value="core;datamodule;models;reports;routes;services;util"/>' + sLineBreak +
  '            <UnitOutputDirectory Value="../temp/$(TargetCPU)-$(TargetOS)"/>' + sLineBreak +
  '          </SearchPaths>' + sLineBreak +
  '          <CodeGeneration>' + sLineBreak +
  '            <TargetCPU Value="aarch64"/>' + sLineBreak +
  '            <TargetOS Value="linux"/>' + sLineBreak +
  '          </CodeGeneration>' + sLineBreak +
  '        </CompilerOptions>' + sLineBreak +
  '      </Item>' + sLineBreak +
  '    </BuildModes>' + sLineBreak +
  '    <PublishOptions>' + sLineBreak +
  '      <Version Value="2"/>' + sLineBreak +
  '      <UseFileFilters Value="True"/>' + sLineBreak +
  '    </PublishOptions>' + sLineBreak +
  '    <RunParams>' + sLineBreak +
  '      <FormatVersion Value="2"/>' + sLineBreak +
  '    </RunParams>' + sLineBreak +
  '    <RequiredPackages>' + sLineBreak +
  '      <Item>' + sLineBreak +
  '        <PackageName Value="LCL"/>' + sLineBreak +
  '      </Item>' + sLineBreak +
  '      <Item>' + sLineBreak +
  '        <PackageName Value="SQLDBLaz"/>' + sLineBreak +
  '      </Item>' + sLineBreak +
  '      <Item>' + sLineBreak +
  '        <PackageName Value="zcomponentdesign"/>' + sLineBreak +
  '      </Item>' + sLineBreak +
  '      <Item>' + sLineBreak +
  '        <PackageName Value="zcomponent"/>' + sLineBreak +
  '      </Item>' + sLineBreak +
  '    </RequiredPackages>' + sLineBreak +
  '    <Units>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="' + Projeto.ApiNome.ToLower + '.lpr"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.server.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.Server"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.router.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.Router"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.httpcontext.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.HttpContext"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.registerroutes.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.RegisterRoutes"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.middleware.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.Middleware"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.jwt.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.JWT"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.cors.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.Cors"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.logger.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.Logger"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.jsonfloat.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.statuscode.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.StatusCode"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.util.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.Util"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.datacontrol.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.htmlresponse.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.HTMLResponse"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="core/core.htmltopdf.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Core.HtmlToPdf"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="datamodule/dm.server.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <ComponentName Value="DMServer"/>' + sLineBreak +
  '        <HasResources Value="True"/>' + sLineBreak +
  '        <ResourceBaseClass Value="DataModule"/>' + sLineBreak +
  '        <UnitName Value="DM.Server"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +

  { AUTENTICAÇÃO BASE }

  '      <Unit>' + sLineBreak +
  '        <Filename Value="routes/route.auth.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Route.Auth"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="services/service.auth.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Service.Auth"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="models/model.userinfo.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Model.UserInfo"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +

  { UTIL }

  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/util.criptografia.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Util.Criptografia"/>' + sLineBreak +
  '      </Unit>' + sLineBreak;

  { AUDITAR ROTAS }

  if Projeto.ApiAudit then
  s := s +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="services/service.apiaudit.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Service.ApiAudit"/>' + sLineBreak +
  '      </Unit>' + sLineBreak;

  { ROTAS E SERVICES }

  tabelas.First;
  while not tabelas.EOF do begin
    lTabela := tabelas.FieldByName('nome_objeto').AsString;
    lTabela := lTabela + FVersaoAbreviadaRota;

    if (tabelas.FieldByName('chave_primaria').AsInteger = 1) then
    s := s +
    '      <Unit>' + sLineBreak +
    '        <Filename Value="routes/route.' + lTabela.ToLower + '.pas"/>' + sLineBreak +
    '        <IsPartOfProject Value="True"/>' + sLineBreak +
    '        <UnitName Value="Route.' + lTabela + '"/>' + sLineBreak +
    '      </Unit>' + sLineBreak;

    if FCriarServiceClasses then
    s := s +
    '      <Unit>' + sLineBreak +
    '        <Filename Value="services/service.' + lTabela.ToLower + '.pas"/>' + sLineBreak +
    '        <IsPartOfProject Value="True"/>' + sLineBreak +
    '        <UnitName Value="Service.' + lTabela + '"/>' + sLineBreak +
    '      </Unit>' + sLineBreak;

    tabelas.Next;
  end;

  { MÓDULO BOLETO - PIX }

  if FCriarModuloBoleto then
  s := s +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/api.funcoes.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Api.Funcoes"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.bancobradesco.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.BancoBradesco"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.bancobrasil.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.BancoBrasil"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.bancocef.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.BancoCEF"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.bancoitau.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.BancoItau"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.bancosantander.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.BancoSantander"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.bancosicoob.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.BancoSicoob"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.layout.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.Layout"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.linhadigitavel.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.LinhaDigitavel"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.models.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.Models"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="util/boleto.pix.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Boleto.Pix"/>' + sLineBreak +
  '      </Unit>' + sLineBreak +
  '      <Unit>' + sLineBreak +
  '        <Filename Value="routes/route.financeiro.pas"/>' + sLineBreak +
  '        <IsPartOfProject Value="True"/>' + sLineBreak +
  '        <UnitName Value="Route.Financeiro"/>' + sLineBreak +
  '      </Unit>' + sLineBreak;

  s := s +
  '    </Units>' + sLineBreak +
  '  </ProjectOptions>' + sLineBreak +
  '  <CompilerOptions>' + sLineBreak +
  '    <Version Value="11"/>' + sLineBreak +
  '    <Target>' + sLineBreak +
  '      <Filename Value="../release/' + Projeto.ApiNome.ToLower + '_linux"/>' + sLineBreak +
  '    </Target>' + sLineBreak +
  '    <SearchPaths>' + sLineBreak +
  '      <IncludeFiles Value="$(ProjOutDir)"/>' + sLineBreak +
  '      <OtherUnitFiles Value="core;datamodule;models;reports;routes;services;util"/>' + sLineBreak +
  '      <UnitOutputDirectory Value="../temp/$(TargetCPU)-$(TargetOS)"/>' + sLineBreak +
  '    </SearchPaths>' + sLineBreak +
  '    <CodeGeneration>' + sLineBreak +
  '      <TargetCPU Value="x86_64"/>' + sLineBreak +
  '      <TargetOS Value="linux"/>' + sLineBreak +
  '    </CodeGeneration>' + sLineBreak +
  '  </CompilerOptions>' + sLineBreak +
  '  <Debugging>' + sLineBreak +
  '    <Exceptions>' + sLineBreak +
  '      <Item>' + sLineBreak +
  '        <Name Value="EAbort"/>' + sLineBreak +
  '      </Item>' + sLineBreak +
  '      <Item>' + sLineBreak +
  '        <Name Value="ECodetoolError"/>' + sLineBreak +
  '      </Item>' + sLineBreak +
  '      <Item>' + sLineBreak +
  '        <Name Value="EFOpenError"/>' + sLineBreak +
  '      </Item>' + sLineBreak +
  '    </Exceptions>' + sLineBreak +
  '  </Debugging>' + sLineBreak +
  '</CONFIG>' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaRaiz + Projeto.ApiNome.ToLower + '.lpi', s);
  s := '';

  tabelas.Close;
  tabelas.Free;
  st.Free;
end;

procedure TProjetoLazarusAPI.GerarObjetos;
// gera os objetos
var
  st: TServiceTabela;
  sc: TServiceCampo;
  tabelas, campos: TZQuery;
begin
  st := TServiceTabela.Create( FIdProjeto );
  tabelas := st.QueryTabelas( FListaTabelasID.Trim, True ); //tabelas

  if tabelas.RecordCount > 0 then begin

    while not tabelas.EOF do begin
      sc := TServiceCampo.Create( tabelas.FieldByName('idtabela').AsInteger );
      campos := sc.QueryCampos; // campos da tabela

      if (campos.RecordCount > 0) and
         (campos.FieldByName('criar_api').AsInteger = 1) and
         (campos.FieldByName('chave_primaria').AsInteger = 1) then
      begin
        // Cria modelos json da tabela e seus campos
        GerarJSONTableStructure(campos);

        // Cria a rota para cada tabela
        GeraRotas(tabelas.FieldByName('nome_objeto').AsString,
                  tabelas.FieldByName('api_rota').AsString,
                  campos);

        // cria as classes services
        if FCriarServiceClasses then
          GerarClasse(campos);
      end;

      campos.Close;
      campos.Free;
      sc.Free;

      // próxima tabela
      tabelas.Next;
    end;

  end;

  tabelas.Close;
  tabelas.Free;
  st.Free;
end;

procedure TProjetoLazarusAPI.GerarArquivoINI;
//arquivo de configuração do banco de dados
var
  s: string;
begin
  s :=
    '[srvconfig]' + sLineBreak +
    'name=' + Projeto.ApiTitulo + sLineBreak +
    'port=' + Projeto.ApiPorta + sLineBreak +
    'admin=' + Projeto.ApiAdminNome + sLineBreak +
    'email=' + Projeto.ApiAdminEmail + sLineBreak +
    '' + sLineBreak +
    '[dbinfo]' + sLineBreak +
    'server=' + Projeto.Proj_HostServidor + sLineBreak +
    'port=' + Projeto.Proj_Porta + sLineBreak +
    'db=' + Projeto.Proj_BancoDados + sLineBreak +
    'protocol=' + FProtocolo + sLineBreak +
    'user=' + Projeto.Proj_Username + sLineBreak +
    'password=' + Projeto.Proj_Senha + sLineBreak +
    'odbc=' + sLineBreak +
    'encrypt=false' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaRelease + 'server.ini', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_Server;
// cria o arquivo core.server
var
  s: string;
begin
  s :=
  'unit Core.Server;' + sLineBreak +
  ' ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode objfpc}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, StrUtils, CustApp, crt, Contnrs, IniFiles,' + sLineBreak +
  '  fphttpserver, fphttpclient, HTTPDefs,' + sLineBreak +
  '  DM.Server, Core.Router, Core.Cors, Core.JWT, Core.JwtMiddleware,' + sLineBreak +
  '  Core.Logger, Core.RegisterRoutes;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TObserverThread }' + sLineBreak +
  '' + sLineBreak +
  '  TObserverThread = class(TThread)' + sLineBreak +
  '  protected' + sLineBreak +
  '    procedure Execute; override;' + sLineBreak +
  '  public' + sLineBreak +
  '    constructor Create(CreateSuspended: boolean);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  { TAppServer }' + sLineBreak +
  '' + sLineBreak +
  '  TAppServer = class(TCustomApplication)' + sLineBreak +
  '  private' + sLineBreak +
  '    FServer: TFPHTTPServer;' + sLineBreak +
  '    FRouter : TRouter;' + sLineBreak +
  '    FObserver: TObserverThread;' + sLineBreak +
  '    FStaticRoutes : TObjectList;' + sLineBreak +
  '    FAdminEmail: string;' + sLineBreak +
  '    FAdminName: string;' + sLineBreak +
  '    FServerName: string;' + sLineBreak +
  '    FServerPort: Word;' + sLineBreak +
  '    function GetMimeType(const AFileName: String): String;' + sLineBreak +
  '    procedure HandleRequest(Sender: TObject; var req: TFPHTTPConnectionRequest; var res: TFPHTTPConnectionResponse);' + sLineBreak +
  '    Procedure HandleError(Sender: TObject; AError: Exception);' + sLineBreak +
  '    function IsBrowserRequest(Req: TRequest): Boolean;' + sLineBreak +
  '    procedure LerConfig;' + sLineBreak +
  '    function SafeStaticFile(const ABaseFolder, AFileName: String): String;' + sLineBreak +
  '    function ServeStaticFile(Req: TRequest; Res: TResponse): Boolean;' + sLineBreak +
  '    procedure Stop;' + sLineBreak +
  '    procedure Log(const AMsg: string);' + sLineBreak +
  '    procedure SendMessage;' + sLineBreak +
  '    function ValidFileExtension(AFileName: String): Boolean;' + sLineBreak +
  '  protected' + sLineBreak +
  '    procedure DoRun; override;' + sLineBreak +
  '  public' + sLineBreak +
  '    constructor Create(TheOwner: TComponent); override;' + sLineBreak +
  '    destructor Destroy; override;' + sLineBreak +
  '    property Router:TRouter read FRouter;' + sLineBreak +
  '    procedure Init;' + sLineBreak +
  '    procedure Static(const AURLPrefix, ALocalFolder: String);' + sLineBreak +
  '    property ServerPort: Word read FServerPort write FServerPort default 8083;' + sLineBreak +
  '    property ServerName: string read FServerName write FServerName;' + sLineBreak +
  '    property AdminName: string read FAdminName write FAdminName;' + sLineBreak +
  '    property AdminEmail: string read FAdminEmail write FAdminEmail;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'var' + sLineBreak +
  '  AppServer: TAppServer;' + sLineBreak +
  '' + sLineBreak +
  'procedure Log(const AMsg: string);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.HTMLResponse;' + sLineBreak +
  '' + sLineBreak +
  '{ TObserverThread }' + sLineBreak +
  '' + sLineBreak +
  'constructor TObserverThread.Create(CreateSuspended: boolean);' + sLineBreak +
  'begin' + sLineBreak +
  '  FreeOnTerminate := True;' + sLineBreak +
  '  inherited Create(CreateSuspended);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TObserverThread.Execute;' + sLineBreak +
  'begin' + sLineBreak +
  '  while not Terminated do begin' + sLineBreak +
  '    Sleep(10); // evita 100% CPU' + sLineBreak +
  '    if KeyPressed then' + sLineBreak +
  '      case ReadKey of' + sLineBreak +
  '        ''q'',''Q'': begin' + sLineBreak +
  '                   Break;' + sLineBreak +
  '                 end;' + sLineBreak +
  '      end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  AppServer.Stop;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ TAppServer }' + sLineBreak +
  '' + sLineBreak +
  'constructor TAppServer.Create(TheOwner: TComponent);' + sLineBreak +
  'begin' + sLineBreak +
  '  // configurações do servidor' + sLineBreak +
  '  LerConfig;' + sLineBreak +
  '' + sLineBreak +
  '  // instancia o banco de dados' + sLineBreak +
  '  DMServer := TDMServer.Create(nil);' + sLineBreak +
  '' + sLineBreak +
  '  FObserver := TObserverThread.Create(True);' + sLineBreak +
  '  FObserver.Start;' + sLineBreak +
  '' + sLineBreak +
  '  // controlador de rotas' + sLineBreak +
  '  FRouter := TRouter.Create;' + sLineBreak +
  '' + sLineBreak +
  '  // rota estática' + sLineBreak +
  '  FStaticRoutes := TObjectList.Create(True);' + sLineBreak +
  '' + sLineBreak +
  '  // instancia o servidor da api' + sLineBreak +
  '  FServer := TFPHTTPServer.Create(Self);' + sLineBreak +
  '  FServer.Port := FServerPort;' + sLineBreak +
  '  Fserver.AdminName := FAdminName;' + sLineBreak +
  '  FServer.AdminMail := FAdminEmail;' + sLineBreak +
  '  FServer.ServerBanner := FServerName;' + sLineBreak +
  '  FServer.Threaded := True;' + sLineBreak +
  '  FServer.OnRequest := @HandleRequest;' + sLineBreak +
  '  FServer.OnRequestError := @HandleError;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'destructor TAppServer.Destroy;' + sLineBreak +
  'begin' + sLineBreak +
  '  if Assigned(DMServer) then DMServer.Free;' + sLineBreak +
  '  if Assigned(FRouter) then FRouter.Free;' + sLineBreak +
  '  if Assigned(FServer) then FreeAndNil(FServer);' + sLineBreak +
  '  if Assigned(FStaticRoutes) then FStaticRoutes.Free;' + sLineBreak +
  '  inherited Destroy;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TAppServer.Init;' + sLineBreak +
  '// inicia o servidor nas requisições' + sLineBreak +
  'begin' + sLineBreak +
  '  Log('''');' + sLineBreak +
  '  Log(''** TOPAZZIO REST API SERVER **'');' + sLineBreak +
  '  Log(' + QuotedStr(Projeto.ApiTitulo) + ');' + sLineBreak +
  '  Log( Format(' + QuotedStr(TApiMessages.ServidorOuvindo) + ', [FServer.Port]) );' + sLineBreak +
  '  Log( Format(' + QuotedStr(TApiMessages.ServidorFirewall) + ', [FServer.Port]) );' + sLineBreak +
  '  Log(DMServer.GetVersaoServidor);' + sLineBreak +
  '  Log(Format(''http://localhost:%d/'',[FServer.Port]));' + sLineBreak +
  '  Log(' + QuotedStr(TApiMessages.ServidorSair) + ');' + sLineBreak +
  '' + sLineBreak +
  '  FServer.Active := True;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TAppServer.Static(const AURLPrefix, ALocalFolder: String);' + sLineBreak +
  '// pasta estática para abrigar arquivos: html, imagens e etc' + sLineBreak +
  'var' + sLineBreak +
  '  S : TStaticRoute;' + sLineBreak +
  'begin' + sLineBreak +
  '  S := TStaticRoute.Create;' + sLineBreak +
  '  S.URLPrefix := AURLPrefix;' + sLineBreak +
  '  S.Folder := ALocalFolder;' + sLineBreak +
  '' + sLineBreak +
  '  FStaticRoutes.Add(S);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TAppServer.Stop;' + sLineBreak +
  '// força a parada de toda a aplicação' + sLineBreak +
  'begin' + sLineBreak +
  '  FServer.Active := False;' + sLineBreak +
  '  SendMessage;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TAppServer.Log(const AMsg: string);' + sLineBreak +
  '// exibe log no console' + sLineBreak +
  'begin' + sLineBreak +
  '  if Trim(AMsg) <> '''' then' + sLineBreak +
  '    WriteLn(FormatDateTime(''yyyy-mm-dd hh:nn:ss'', Now) + '' [LOG] '' + AMsg)' + sLineBreak +
  '  else' + sLineBreak +
  '    WriteLn('' '');' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TAppServer.SendMessage;' + sLineBreak +
  '// para forçar a parada do servidor' + sLineBreak +
  'var' + sLineBreak +
  ' Client: TFPHTTPClient;' + sLineBreak +
  'begin' + sLineBreak +
  '  Client := TFPHTTPClient.Create(nil);' + sLineBreak +
  '  Client.Post(Format(''http://localhost:%d/'',[FServer.Port]));' + sLineBreak +
  '  Client.Free;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TAppServer.HandleRequest(Sender: TObject; var req: TFPHTTPConnectionRequest; var res: TFPHTTPConnectionResponse);' + sLineBreak +
  '// controle das requisições aos endpoints' + sLineBreak +
  'begin' + sLineBreak +
  '  if not FRouter.Execute(req, res) then begin' + sLineBreak +
  '    // não encontrou a rota, tenta arquivos estáticos' + sLineBreak +
  '    if not ServeStaticFile(req, res) then begin' + sLineBreak +
  '      // não encontrou arquivos, retorna erro' + sLineBreak +
  '      res.Code := 404;' + sLineBreak +
  '      res.Content := ''Not Found'';' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TAppServer.GetMimeType(const AFileName:String):String;' + sLineBreak +
  'var' + sLineBreak +
  '  Ext : String;' + sLineBreak +
  'begin' + sLineBreak +
  '  Ext := LowerCase(ExtractFileExt(AFileName));' + sLineBreak +
  '' + sLineBreak +
  '  if Ext = ''.html'' then Result := ''text/html''' + sLineBreak +
  '  else if Ext = ''.css'' then Result := ''text/css''' + sLineBreak +
  '  else if Ext = ''.js'' then Result := ''application/javascript''' + sLineBreak +
  '  else if Ext = ''.png'' then Result := ''image/png''' + sLineBreak +
  '  else if Ext = ''.jpg'' then Result := ''image/jpeg''' + sLineBreak +
  '  else if Ext = ''.ico'' then Result := ''image/x-icon''' + sLineBreak +
  '  else Result := ''application/octet-stream'';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TAppServer.IsBrowserRequest(Req: TRequest): Boolean;' + sLineBreak +
  '// Detectar se o cliente é um navegador' + sLineBreak +
  'var' + sLineBreak +
  '  UA, Accept: String;' + sLineBreak +
  'begin' + sLineBreak +
  '  UA := LowerCase(Req.UserAgent);' + sLineBreak +
  '  Accept := LowerCase(Req.CustomHeaders.Values[''Accept'']);' + sLineBreak +
  '' + sLineBreak +
  '  Result :=' + sLineBreak +
  '    (Pos(''text/html'', Accept) > 0) or' + sLineBreak +
  '    (Pos(''mozilla'', UA) > 0) or' + sLineBreak +
  '    (Pos(''chrome'', UA) > 0) or' + sLineBreak +
  '    (Pos(''firefox'', UA) > 0) or' + sLineBreak +
  '    (Pos(''safari'', UA) > 0) or' + sLineBreak +
  '    (Pos(''edge'', UA) > 0);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TAppServer.ServeStaticFile(Req:TRequest; Res:TResponse): Boolean;' + sLineBreak +
  '// serve arquivos estáticos' + sLineBreak +
  'var' + sLineBreak +
  '  i: Integer;' + sLineBreak +
  '  S: TStaticRoute;' + sLineBreak +
  '  RelPath: String;' + sLineBreak +
  '  FileName: String;' + sLineBreak +
  '  FS: TFileStream;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '' + sLineBreak +
  '  // Página inicial' + sLineBreak +
  '  if Req.URI = ''/'' then' + sLineBreak +
  '  begin' + sLineBreak +
  '    Res.ContentType := ''text/html; charset=utf-8'';' + sLineBreak +
  '    Res.SetCustomHeader(''Cache-Control'', ''public, max-age=3600'');' + sLineBreak +
  '    Res.Content := THtmlResponse.Index(FServerName);' + sLineBreak +
  '    Exit(True);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // Procura pelas rotas estáticas' + sLineBreak +
  '  for i := FStaticRoutes.Count - 1 downto 0 do' + sLineBreak +
  '  begin' + sLineBreak +
  '    S := TStaticRoute(FStaticRoutes[i]);' + sLineBreak +
  '' + sLineBreak +
  '    // Prefixo deve coincidir exatamente' + sLineBreak +
  '    if (Req.URI = S.URLPrefix) or' + sLineBreak +
  '       (Pos(IncludeTrailingPathDelimiter(S.URLPrefix), Req.URI) = 1) then' + sLineBreak +
  '    begin' + sLineBreak +
  '      // Caminho relativo após o prefixo' + sLineBreak +
  '      RelPath := Copy(Req.URI, Length(S.URLPrefix) + 1, MaxInt);' + sLineBreak +
  '' + sLineBreak +
  '      // Remove barra inicial' + sLineBreak +
  '      if (RelPath <> '''') and (RelPath[1] in [''/'', ''\'']) then' + sLineBreak +
  '        Delete(RelPath, 1, 1);' + sLineBreak +
  '' + sLineBreak +
  '      // Monta nome completo do arquivo' + sLineBreak +
  '      FileName := IncludeTrailingPathDelimiter(S.Folder) + RelPath;' + sLineBreak +
  '' + sLineBreak +
  '      // Se for diretório, usa index.html' + sLineBreak +
  '      if DirectoryExists(FileName) then' + sLineBreak +
  '        FileName := IncludeTrailingPathDelimiter(FileName) + ''index.html'';' + sLineBreak +
  '' + sLineBreak +
  '      // Segurança: impede ../../../' + sLineBreak +
  '      FileName := SafeStaticFile(S.Folder, FileName);' + sLineBreak +
  '' + sLineBreak +
  '      // Extensão permitida' + sLineBreak +
  '      if not ValidFileExtension(FileName) then' + sLineBreak +
  '        FileName := '''';' + sLineBreak +
  '' + sLineBreak +
  '      // Arquivo encontrado ou redirecionado' + sLineBreak +
  '      if FileExists(FileName) then' + sLineBreak +
  '      begin' + sLineBreak +
  '        FS := TFileStream.Create(FileName, fmOpenRead or fmShareDenyNone);' + sLineBreak +
  '' + sLineBreak +
  '        Res.ContentStream := FS;' + sLineBreak +
  '        Res.FreeContentStream := True;' + sLineBreak +
  '        Res.ContentType := GetMimeType(FileName);' + sLineBreak +
  '        Res.SetCustomHeader(''Cache-Control'', ''public, max-age=3600'');' + sLineBreak +
  '' + sLineBreak +
  '        Exit(True);' + sLineBreak +
  '      end' + sLineBreak +
  '' + sLineBreak +
  '      // não encontrou o recurso' + sLineBreak +
  '' + sLineBreak +
  '      else if IsBrowserRequest(Req) then // requisição via browser ?' + sLineBreak +
  '      begin' + sLineBreak +
  '        Res.ContentType := ''text/html; charset=utf-8'';' + sLineBreak +
  '        //Res.Content := THtmlResponse.Build404HTML(Req.URI);' + sLineBreak +
  '        Res.Content := THtmlResponse.RecursoNaoEncontrado(Req.URI, FAdminEmail, FServerName, ''Recurso não encontrado: '' + Req.URI);' + sLineBreak +
  '        Exit(True);' + sLineBreak +
  '      end' + sLineBreak +
  '      else' + sLineBreak +
  '      begin' + sLineBreak +
  '        // Se a URI parecia apontar para um arquivo, retorna 404' + sLineBreak +
  '        if ExtractFileExt(FileName) <> '''' then' + sLineBreak +
  '        begin' + sLineBreak +
  '          Res.Code := 404;' + sLineBreak +
  '          Res.ContentType := ''text/plain'';' + sLineBreak +
  '          Res.Content := ''Not Found'';' + sLineBreak +
  '          Exit(True);' + sLineBreak +
  '        end;' + sLineBreak +
  '      end;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TAppServer.SafeStaticFile(const ABaseFolder, AFileName:String):String;' + sLineBreak +
  '// impede de sair da pasta raiz usando ../' + sLineBreak +
  'var' + sLineBreak +
  '  lBasePath : String;' + sLineBreak +
  '  lFullPath : String;' + sLineBreak +
  'begin' + sLineBreak +
  '  lBasePath := ExpandFileName(ABaseFolder);' + sLineBreak +
  '  lFullPath := ExpandFileName(AFileName);' + sLineBreak +
  '' + sLineBreak +
  '  if Pos(lBasePath, lFullPath) <> 1 then' + sLineBreak +
  '    Exit('''');' + sLineBreak +
  '' + sLineBreak +
  '  Result := lFullPath;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TAppServer.ValidFileExtension(AFileName: String):Boolean;' + sLineBreak +
  'begin' + sLineBreak +
  '  // estas extensões são rejeitadas' + sLineBreak +
  '  if IndexStr(LowerCase(ExtractFileExt(AFileName)), [''.exe'',''.dll'',''.ini'',''.so'',''.a'',''.sh'',''.bat'',''.gif'']) = -1 then' + sLineBreak +
  '    Result := True' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := False;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TAppServer.HandleError(Sender: TObject; AError: Exception);' + sLineBreak +
  '// controle de erros do servidor' + sLineBreak +
  'begin' + sLineBreak +
  '  Log(AError.Message);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TAppServer.LerConfig;' + sLineBreak +
  '//ler configurações do servidor' + sLineBreak +
  'var' + sLineBreak +
  '  ArqINI: TIniFile;' + sLineBreak +
  '  FArquivoINI: String;' + sLineBreak +
  'begin' + sLineBreak +
  '  FArquivoINI := ExtractFileDir( ParamStr(0) ) + PathDelim + ''server.ini'';' + sLineBreak +
  '  ArqINI := TIniFile.Create(FArquivoINI);' + sLineBreak +
  '' + sLineBreak +
  '  FServerName := ' + QuotedStr(Projeto.ApiTitulo) + ';' + sLineBreak +
  '  FServerPort := ' + Projeto.ApiPorta +';' + sLineBreak +
  '  FAdminName  := ' + QuotedStr(Projeto.ApiAdminNome) + ';' + sLineBreak +
  '  FAdminEmail := ' + QuotedStr(Projeto.ApiAdminEmail) + ';' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    if not FileExists(FArquivoINI) then begin' + sLineBreak +
  '      // server rest' + sLineBreak +
  '      ArqINI.WriteString(''srvconfig'',''name'', FServerName);' + sLineBreak +
  '      ArqINI.WriteInteger(''srvconfig'',''port'', FServerPort);' + sLineBreak +
  '      ArqINI.WriteString(''srvconfig'',''admin'', FAdminName);' + sLineBreak +
  '      ArqINI.WriteString(''srvconfig'',''email'', FAdminEmail);' + sLineBreak +
  '      // database' + sLineBreak +
  '      ArqINI.WriteString(''dbinfo'',''server'', ''127.0.0.1'');' + sLineBreak +
  '      ArqINI.WriteInteger(''dbinfo'',''port'', 5432);' + sLineBreak +
  '      ArqINI.WriteString(''dbinfo'',''protocol'', ''postgresql'');' + sLineBreak +
  '      ArqINI.WriteString(''dbinfo'',''db'', ''testdb'');' + sLineBreak +
  '      ArqINI.WriteString(''dbinfo'',''user'', ''userdb'');' + sLineBreak +
  '      ArqINI.WriteString(''dbinfo'',''password'', ''pass123'');' + sLineBreak +
  '      ArqINI.WriteString(''dbinfo'',''odbc'', '''');' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    FServerName := ArqINI.ReadString(''srvconfig'',''name'', FServerName);' + sLineBreak +
  '    FServerPort := ArqINI.ReadInteger(''srvconfig'',''port'', FServerPort);' + sLineBreak +
  '    FAdminName  := ArqINI.ReadString(''srvconfig'',''admin'', FAdminName);' + sLineBreak +
  '    FAdminEmail := ArqINI.ReadString(''srvconfig'',''email'', FAdminEmail);' + sLineBreak +
  '  finally' + sLineBreak +
  '    ArqINI.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TAppServer.DoRun;' + sLineBreak +
  'begin' + sLineBreak +
  '  Router.Use(@CorsMiddleware); {registra middleware CORS}' + sLineBreak +
  '  //Router.Use(@LoggerMiddleware);' + sLineBreak +
  '  //Router.Use(@JWTMiddleware); {assim, proteje todas as rotas}' + sLineBreak +
  '  RegisterRoutes(Router); {registro das rotas}' + sLineBreak +
  '' + sLineBreak +
  '  Init; { ficará parado aqui até o servidor ser finalizado }' + sLineBreak +
  '  Log('''');' + sLineBreak +
  '  Terminate;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure Log(const AMsg: string);' + sLineBreak +
  '// exibe log no console' + sLineBreak +
  'begin' + sLineBreak +
  '  if Trim(AMsg) <> '''' then' + sLineBreak +
  '    WriteLn(FormatDateTime(''yyyy-mm-dd hh:nn:ss'', Now) + '' [LOG] '' + AMsg)' + sLineBreak +
  '  else' + sLineBreak +
  '    WriteLn('' '');' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.server.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_Cors;
var
  s: string;
begin
  s :=
  'unit Core.Cors;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.HttpContext;' + sLineBreak +
  '' + sLineBreak +
  'procedure CorsMiddleware(Ctx:THttpContext; var Next:boolean);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'procedure CorsMiddleware(Ctx:THttpContext; var Next:boolean);' + sLineBreak +
  'begin' + sLineBreak +
  '  Ctx.Response.SetCustomHeader(''SERVER-API'',' + QuotedStr(Projeto.ApiTitulo) + ');' + sLineBreak +
  '  Ctx.Response.SetCustomHeader(''Access-Control-Allow-Origin'',''*'');' + sLineBreak +
  '  Ctx.Response.SetCustomHeader(''Access-Control-Allow-Methods'',''DELETE,GET,PATCH,POST,PUT'');' + sLineBreak +
  '  Ctx.Response.SetCustomHeader(''Access-Control-Allow-Headers'',''Content-Type,Authorization'');' + sLineBreak +
  '' + sLineBreak +
  '  if Ctx.Request.Method = ''OPTIONS'' then begin' + sLineBreak +
  '    Ctx.Response.Code := 200;' + sLineBreak +
  '    Next := False;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.cors.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_DataControl;
// ORM
var
  s, lTipoQuery: string;
begin
  if FTipoBanco = SQLSERVER then
    lTipoQuery := 'TSQLQuery'
  else
    lTipoQuery := 'TZQuery';

  s :=
  'unit Core.DataControl;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// ORM' + sLineBreak +
  '// Processa os dados recebidos via Post/Put/Patch no body do Request' + sLineBreak +
  '// em formato json string, incluindo o método Get' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, fpjson, jsonparser, DB, SQLDB, ZDataset;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '  EValidationError = class(Exception);' + sLineBreak +
  '  EDatabaseError = class(Exception);' + sLineBreak +
  '' + sLineBreak +
  '  { TFieldMeta }' + sLineBreak +
  '' + sLineBreak +
  '  TFieldMeta = record' + sLineBreak +
  '    Name: string;          // field name' + sLineBreak +
  '    NameAlias: string;     // alias do Name para o usuário montar seu json' + sLineBreak +
  '    DataType: string;      // field type: integer, varchar, float, date, etc' + sLineBreak +
  '    IsNullable: Boolean;   // aceita null' + sLineBreak +
  '    IsPrimaryKey: Boolean; // é chave primária ?' + sLineBreak +
  '    IsForeignKey: Boolean; // é chave estrangeira ?' + sLineBreak +
  '    MaxLength: Integer;    // total de carateceres possível no campo' + sLineBreak +
  '    Precision: Integer;    // numeric total digits' + sLineBreak +
  '    Scale: Integer;        // casas decimais' + sLineBreak +
  '    Required: Boolean;     // requerido no Insert' + sLineBreak +
  '    SpecialField: string;  // ''cpf, cnpj'', ''telefone, celular'', ''cep'' ou ''''' + sLineBreak +
  '    RemoveMask: Boolean;   // remover a máscara de formatação do conteúdo recebido ?' + sLineBreak +
  '    ToList: Boolean;       // para trazer em listagem, paginação' + sLineBreak +
  '    FPDataType: string;    // tipo de dados no Lazarus: string, integer, boolean, etc' + sLineBreak +
  '    FKTableName: string;   // tabela da chave estrangeira' + sLineBreak +
  '    FKCodeField: string;   // código (FK) da tabela estrangeira' + sLineBreak +
  '    FKTextField: string;   // campo texto da tabela estrangeira' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  TFieldMetaArray = array of TFieldMeta;' + sLineBreak +
  '' + sLineBreak +
  '  { TDataControl }' + sLineBreak +
  '' + sLineBreak +
  '  TDataControl = class' + sLineBreak +
  '  private' + sLineBreak +
  '    FMeta: TFieldMetaArray;' + sLineBreak +
  '    FHasData: Boolean;' + sLineBreak +
  '    FID: Integer;' + sLineBreak +
  '    FMessage: string;' + sLineBreak +
  '    FTableName: string;' + sLineBreak +
  '    FObjectName: string;' + sLineBreak +
  '    FApiRoute: string;' + sLineBreak +
  '    FPrimaryKey: string;' + sLineBreak +
  '    FIs_Postgresql: Boolean;' + sLineBreak +
  '    FIs_MySql: Boolean;' + sLineBreak +
  '    FIs_Mssql: Boolean;' + sLineBreak +
  '' + sLineBreak +
  '    procedure AddFieldToJSON(AJSON: TJSONObject; const AliasName, ASpecialField: string; AField: TField);' + sLineBreak +
  '    function FiltraErroSQL(AMessage: string): string;' + sLineBreak +
  '    function ForeignInfo(const AData: string; out ATableName: string; out' + sLineBreak +
  '      ACodeField: string; out ATextField: string): Boolean;' + sLineBreak +
  '    function Formata_Saida(const AValue, ASpecialField: string): string;' + sLineBreak +
  '    function GetFieldAlias(const AFieldName: string): string;' + sLineBreak +
  '    function LoadMetadata(const AStrJson: string): TFieldMetaArray;' + sLineBreak +
  '    function JSONHas(AJSON: TJSONObject; const AField: string): Boolean;' + sLineBreak +
  '    function FindField(const AFieldName: string): Integer;' + sLineBreak +
  '    function ParseISODate(const S: string; out ADate: TDateTime): Boolean;' + sLineBreak +
  '    function UTF8SafeTruncate(const S: string; AMaxBytes: Integer): string;' + sLineBreak +
  '    procedure ValidateField(const AFieldInfo: TFieldMeta; J: TJSONData);' + sLineBreak +
  '    procedure BindParam(Qry: ' + lTipoQuery + '; const AFieldInfo: TFieldMeta; AJSON: TJSONObject);' + sLineBreak +
  '    function ValidateJSONFields(AJSON: TJSONObject): string;' + sLineBreak +
  '    function IsValid_CPF_CNPJ(const AValue: string; ARequired: Boolean; out AMessage: string): Boolean;' + sLineBreak +
  '  public' + sLineBreak +
  '    constructor Create(AModelFields: string);' + sLineBreak +
  '    property ID: Integer read FID;' + sLineBreak +
  '    property Message: string read FMessage;' + sLineBreak +
  '    function Insert(const ABodyJson: string): Boolean;' + sLineBreak +
  '    function Update(AId: Integer; const ABodyJson: string): Boolean;' + sLineBreak +
  '    function GetByID(AId: Integer): string;' + sLineBreak +
  '    function DeleteByID(AId: Integer): Boolean;' + sLineBreak +
  '    function GetList(APageNumber, APageSize: Integer;' + sLineBreak +
  '                     ASearchField, ASearchOperator, ASearch, AOrderFields, AOrderDirection: string): string;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  DateUtils, StrUtils, RegExpr, base64,' + sLineBreak +
  '  DM.Server, Core.Util;' + sLineBreak +
  '' + sLineBreak +
  '{ TDataControl }' + sLineBreak +
  '' + sLineBreak +
  'constructor TDataControl.Create(AModelFields: string);' + sLineBreak +
  'begin' + sLineBreak +
  '  FHasData    := False;' + sLineBreak +
  '  FTableName  := '''';' + sLineBreak +
  '  FObjectName := '''';' + sLineBreak +
  '  FApiRoute   := '''';' + sLineBreak +
  '  FPrimaryKey := '''';' + sLineBreak +
  '  FMessage    := '''';' + sLineBreak +
  '  FID         := 0;' + sLineBreak +
  '' + sLineBreak +
  '  FIs_Postgresql := LowerCase(DMServer.Protocol) = ''postgresql'';' + sLineBreak +
  '  FIs_Mssql := LowerCase(DMServer.Protocol) = ''mssql'';' + sLineBreak +
  '  FIs_MySql := LowerCase(DMServer.Protocol).Contains(''mysql'') or' + sLineBreak +
  '               LowerCase(DMServer.Protocol).Contains(''mariadb'');' + sLineBreak +
  '' + sLineBreak +
  '  if not DMServer.IsConnected then' + sLineBreak +
  '    raise Exception.Create(''Database not connected.'');' + sLineBreak +
  '' + sLineBreak +
  '  FMeta := LoadMetadata( AModelFields ); // carrega informações da tabela' + sLineBreak +
  '' + sLineBreak +
  '  if (FHasData = False) or (FTableName = '''') then' + sLineBreak +
  '    raise Exception.Create(''The information in the table and fields is invalid.'');' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.ParseISODate(const S: string; out ADate: TDateTime): Boolean;' + sLineBreak +
  'begin' + sLineBreak +
  '  try' + sLineBreak +
  '    ADate := ISO8601ToDate(S, True); // True = considerar timezone' + sLineBreak +
  '    Result := True;' + sLineBreak +
  '  except' + sLineBreak +
  '    Result := False;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.ForeignInfo(const AData: string; out ATableName: string; out ACodeField: string; out ATextField: string): Boolean;' + sLineBreak +
  '// tenta encontrar dados da tabela estrangeira' + sLineBreak +
  'var' + sLineBreak +
  '  f: array of String;' + sLineBreak +
  'begin' + sLineBreak +
  '  ATableName := '''';' + sLineBreak +
  '  ACodeField := '''';' + sLineBreak +
  '  ATextField := '''';' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '' + sLineBreak +
  '  if Trim(AData) = '''' then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  f := AData.Split(['',''], TStringSplitOptions.ExcludeEmpty);' + sLineBreak +
  '' + sLineBreak +
  '  if High(f) = 2 then begin' + sLineBreak +
  '    ATableName := f[0];' + sLineBreak +
  '    ACodeField := f[1];' + sLineBreak +
  '    ATextField := f[2];' + sLineBreak +
  '    Result := True;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  SetLength(f, 0);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.LoadMetadata(const AStrJson: string): TFieldMetaArray;' + sLineBreak +
  '// carrega informações dos campos da tabela' + sLineBreak +
  'var' + sLineBreak +
  '  lJson, lObj: TJSONObject;' + sLineBreak +
  '  lFields: TJSONArray;' + sLineBreak +
  '  lList: array of TFieldMeta;' + sLineBreak +
  '  i: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  SetLength(lList, 0);' + sLineBreak +
  '  FHasData := False;' + sLineBreak +
  '  FTableName := '''';' + sLineBreak +
  '  FObjectName := '''';' + sLineBreak +
  '  FPrimaryKey := '''';' + sLineBreak +
  '  if Trim(AStrJson) = '''' then Exit(lList);' + sLineBreak +
  '' + sLineBreak +
  '  lJson := TJSONObject ( GetJSON( AStrJson ) );' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    if lJson <> nil then begin' + sLineBreak +
  '       FTableName  := lJson.Get(''table_name'', '''');' + sLineBreak +
  '       FObjectName := lJson.Get(''fp_objetc'', FTableName);' + sLineBreak +
  '       FApiRoute   := lJson.Get(''api_route'', LowerCase(FObjectName));' + sLineBreak +
  '' + sLineBreak +
  '       if FTableName <> '''' then begin' + sLineBreak +
  '         lFields := lJson.Arrays[''fields''];' + sLineBreak +
  '' + sLineBreak +
  '         if lFields.Count > 0 then begin' + sLineBreak +
  '           SetLength(lList, lFields.Count);' + sLineBreak +
  '' + sLineBreak +
  '           for i := 0 to lFields.Count -1 do begin' + sLineBreak +
  '             lObj := TJSONObject( lFields.Objects[i] );' + sLineBreak +
  '' + sLineBreak +
  '             lList[i].Name         := lObj.Get(''name'', '''');' + sLineBreak +
  '             lList[i].NameAlias    := lObj.Get(''name_alias'', lList[i].Name);' + sLineBreak +
  '             lList[i].DataType     := LowerCase(lObj.Get(''data_type'', ''''));' + sLineBreak +
  '             lList[i].IsPrimaryKey := lObj.Get(''is_primary_key'', false);' + sLineBreak +
  '             lList[i].IsForeignKey := lObj.Get(''is_foreign_key'', false);' + sLineBreak +
  '             lList[i].IsNullable   := lObj.Get(''is_nullable'', false);' + sLineBreak +
  '             lList[i].MaxLength    := lObj.Get(''max_length'', 0);' + sLineBreak +
  '             lList[i].Precision    := lObj.Get(''precision'', 0);' + sLineBreak +
  '             lList[i].Scale        := lObj.Get(''scale'', 0);' + sLineBreak +
  '             lList[i].Required     := lObj.Get(''required'', false);' + sLineBreak +
  '             lList[i].SpecialField := LowerCase( lObj.Get(''special_field'', '''') );' + sLineBreak +
  '             lList[i].RemoveMask   := lObj.Get(''remove_mask'', false);' + sLineBreak +
  '             lList[i].ToList       := lObj.Get(''to_list'', false);' + sLineBreak +
  '             // boolean, datetime, image, integer, currency, double, string' + sLineBreak +
  '             lList[i].FPDataType   := LowerCase(lObj.Get(''fp_data_type'', ''''));' + sLineBreak +
  '' + sLineBreak +
  '             //lList[i].FKTableName := '''';' + sLineBreak +
  '             //lList[i].FKCodeField := '''';' + sLineBreak +
  '             //lList[i].FKTextField := '''';' + sLineBreak +
  '' + sLineBreak +
  '             if lList[i].IsForeignKey then' + sLineBreak +
  '               ForeignInfo(lList[i].SpecialField,' + sLineBreak +
  '                           lList[i].FKTableName,' + sLineBreak +
  '                           lList[i].FKCodeField,' + sLineBreak +
  '                           lList[i].FKTextField);' + sLineBreak +
  '' + sLineBreak +
  '             if (FPrimaryKey = '''') and (lList[i].IsPrimaryKey) then' + sLineBreak +
  '               FPrimaryKey := lList[i].Name;' + sLineBreak +
  '           end; // for' + sLineBreak +
  '' + sLineBreak +
  '           Result := lList;' + sLineBreak +
  '           FHasData := True;' + sLineBreak +
  '         end // if' + sLineBreak +
  '         else begin' + sLineBreak +
  '           FTableName  := '''';' + sLineBreak +
  '           FObjectName := '''';' + sLineBreak +
  '         end;' + sLineBreak +
  '       end; // if' + sLineBreak +
  '    end; // if' + sLineBreak +
  '  finally' + sLineBreak +
  '    lJson.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.JSONHas(AJSON: TJSONObject; const AField: string): Boolean;' + sLineBreak +
  '// checa se o json enviado pelo usuário possui o campo no TFieldMetaArray' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := Assigned(AJSON.Find(AField));' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.ValidateJSONFields(AJSON: TJSONObject): string;' + sLineBreak +
  '// verifica se o usuário enviou campos desconhecidos no body json' + sLineBreak +
  'var' + sLineBreak +
  '  I, J: Integer;' + sLineBreak +
  '  lFieldName: string;' + sLineBreak +
  '  lAchou: Boolean;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '' + sLineBreak +
  '  for I := 0 to AJSON.Count - 1 do begin' + sLineBreak +
  '    lFieldName := AJSON.Names[I];' + sLineBreak +
  '    lAchou := False;' + sLineBreak +
  '' + sLineBreak +
  '    for J := 0 to High(FMeta) do begin' + sLineBreak +
  '      if SameText(FMeta[J].NameAlias, lFieldName) then begin' + sLineBreak +
  '        lAchou := True;' + sLineBreak +
  '        Break;' + sLineBreak +
  '      end;' + sLineBreak +
  '    end; // for' + sLineBreak +
  '' + sLineBreak +
  '    if not lAchou then begin' + sLineBreak +
  '      if Result <> '''' then Result := Result + '', '';' + sLineBreak +
  '      Result := Result + lFieldName;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '  end; // for' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.IsValid_CPF_CNPJ(const AValue: string; ARequired: Boolean; out AMessage: string): Boolean;' + sLineBreak +
  '// validação do cpf ou cnpj' + sLineBreak +
  'var' + sLineBreak +
  '  s: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '  AMessage := ''Invalid CPF/CNPJ'';' + sLineBreak +
  '  s := Trim( TUtil.RemoveMaskFormat( AValue ) );' + sLineBreak +
  '' + sLineBreak +
  '  if Length(s) = 11 then begin' + sLineBreak +
  '    Result := TUtil.IsValidCPF( s );' + sLineBreak +
  '    if not Result then AMessage := ''Invalid CPF'';' + sLineBreak +
  '  end' + sLineBreak +
  '  else if Length(s) = 14 then begin' + sLineBreak +
  '    Result := TUtil.IsValidCNPJ( s );' + sLineBreak +
  '    if not Result then AMessage := ''Invalid CNPJ'';' + sLineBreak +
  '  end' + sLineBreak +
  '  else if ARequired then begin' + sLineBreak +
  '    Result := True;' + sLineBreak +
  '    AMessage := '''';' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.Formata_Saida(const AValue, ASpecialField: string): string;' + sLineBreak +
  '// formata dados: cep, cpf, cnpj, telefone' + sLineBreak +
  'var' + sLineBreak +
  '  s: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  s := Trim( TUtil.RemoveMaskFormat( AValue ) );' + sLineBreak +
  '' + sLineBreak +
  '  if (ASpecialField.ToLower.Contains(''cpf'')) or' + sLineBreak +
  '     (ASpecialField.ToLower.Contains(''cnpj'')) then' + sLineBreak +
  '  begin' + sLineBreak +
  '    if (Length(s) = 11) then' + sLineBreak +
  '      Result := TUtil.FormataCPF( s )' + sLineBreak +
  '    else if (Length(s) = 14) then' + sLineBreak +
  '      Result := TUtil.FormataCNPJ( s )' + sLineBreak +
  '    else' + sLineBreak +
  '      Result := AValue;' + sLineBreak +
  '  end' + sLineBreak +
  '  else if (ASpecialField.ToLower = ''telefone'') or (ASpecialField.ToLower = ''celular'') then' + sLineBreak +
  '    Result := TUtil.FormataTelefone( s )' + sLineBreak +
  '  else if (ASpecialField.ToLower = ''cep'') then' + sLineBreak +
  '    Result := TUtil.FormataCEP( s )' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := AValue;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.FindField(const AFieldName: string): Integer;' + sLineBreak +
  '// retorna o índice de TFieldMeta no array TFieldMetaArray' + sLineBreak +
  'var' + sLineBreak +
  '  I: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  for I := 0 to High(FMeta) do begin' + sLineBreak +
  '    if SameText(FMeta[I].Name, AFieldName) then' + sLineBreak +
  '      Exit(I);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := -1; // não encontrado' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.GetFieldAlias(const AFieldName: string): string;' + sLineBreak +
  '// retorna o NameAlias conforme o nome correto na tabela' + sLineBreak +
  'var' + sLineBreak +
  '  I: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  for I := 0 to High(FMeta) do begin' + sLineBreak +
  '    if SameText(FMeta[I].Name, AFieldName) then' + sLineBreak +
  '      Exit(FMeta[I].NameAlias);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := ''''; // não encontrado' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TDataControl.ValidateField(const AFieldInfo: TFieldMeta; J: TJSONData);' + sLineBreak +
  '// verifica se o campo é válido' + sLineBreak +
  'var' + sLineBreak +
  '  S, lmessage: string;' + sLineBreak +
  '  FloatVal: Double;' + sLineBreak +
  '  Parts: TStringArray;' + sLineBreak +
  '  dt: TDateTime;' + sLineBreak +
  'begin' + sLineBreak +
  '  if (J = nil) or (J.JSONType = jtNull) then begin' + sLineBreak +
  '    if not AFieldInfo.IsNullable then' + sLineBreak +
  '      raise EValidationError.Create(''Required field cannot be NULL: '' + AFieldInfo.NameAlias);' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  case J.JSONType of' + sLineBreak +
  '    jtString:' + sLineBreak +
  '      begin' + sLineBreak +
  '        S := Trim(J.AsString);' + sLineBreak +
  '' + sLineBreak +
  '        if (AFieldInfo.FPDataType = ''datetime'') and (not AFieldInfo.IsNullable) then begin' + sLineBreak +
  '          if (S = '''') or not ParseISODate(S, dt) then' + sLineBreak +
  '            raise EValidationError.CreateFmt(' + sLineBreak +
  '              ''Invalid Date for field [%s]: %s'',' + sLineBreak +
  '              [AFieldInfo.NameAlias, S]' + sLineBreak +
  '            );' + sLineBreak +
  '        end' + sLineBreak +
  '        else if (AFieldInfo.SpecialField <> '''') then begin' + sLineBreak +
  '          if (AFieldInfo.SpecialField = ''cpf'') or' + sLineBreak +
  '             (AFieldInfo.SpecialField = ''cnpj'') or' + sLineBreak +
  '             (AFieldInfo.SpecialField = ''cpf_cnpj'') then begin' + sLineBreak +
  '              if not IsValid_CPF_CNPJ( S, AFieldInfo.Required, lmessage ) then' + sLineBreak +
  '                raise EValidationError.CreateFmt(''Field [%s]: %s'',[ AFieldInfo.NameAlias, lmessage]);' + sLineBreak +
  '          end;' + sLineBreak +
  '        end' + sLineBreak +
  '        else begin' + sLineBreak +
  '          // VARCHAR / TEXT' + sLineBreak +
  '          if (AFieldInfo.MaxLength > 0) and (Length(S) > AFieldInfo.MaxLength) then' + sLineBreak +
  '            raise EValidationError.CreateFmt(' + sLineBreak +
  '              ''Field [%s] exceeds maximum size of (%d)'',' + sLineBreak +
  '              [AFieldInfo.NameAlias, AFieldInfo.MaxLength]' + sLineBreak +
  '            );' + sLineBreak +
  '' + sLineBreak +
  '          if (AFieldInfo.Required) and (Length(S) < 1) then' + sLineBreak +
  '            raise EValidationError.CreateFmt(' + sLineBreak +
  '              ''Field [%s] cannot be empty'',' + sLineBreak +
  '              [AFieldInfo.NameAlias]' + sLineBreak +
  '            );   ' + sLineBreak +
  '        end;' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '    jtNumber:' + sLineBreak +
  '      begin' + sLineBreak +
  '        FloatVal := J.AsFloat;' + sLineBreak +
  '' + sLineBreak +
  '        // INTEGER' + sLineBreak +
  '        if (AFieldInfo.FPDataType = ''integer'') then begin' + sLineBreak +
  '          if Frac(FloatVal) <> 0 then' + sLineBreak +
  '            raise EValidationError.Create(''Invalid Integer field: '' + AFieldInfo.NameAlias);' + sLineBreak +
  '        end;' + sLineBreak +
  '' + sLineBreak +
  '        // DOUBLE / CURRENCY' + sLineBreak +
  '' + sLineBreak +
  '        if (AFieldInfo.FPDataType = ''double'') or (AFieldInfo.FPDataType = ''currency'') then begin' + sLineBreak +
  '          S := J.AsString;' + sLineBreak +
  '          if Pos(''E'', S) > 0 then Exit;' + sLineBreak +
  '          Parts := S.Split(''.'');' + sLineBreak +
  '' + sLineBreak +
  '          // parte inteiro não pode ser maior que a precisão definida na tabela' + sLineBreak +
  '          if (AFieldInfo.Precision > 0) and (Length(Parts[0]) > AFieldInfo.Precision) then' + sLineBreak +
  '            raise EValidationError.CreateFmt(' + sLineBreak +
  '              ''Field [%s] exceeds precision of (%d)'',' + sLineBreak +
  '              [LowerCase(AFieldInfo.NameAlias), AFieldInfo.Precision]' + sLineBreak +
  '            );' + sLineBreak +
  '        end; //if Double / Currency' + sLineBreak +
  '      end;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TDataControl.BindParam(Qry: ' + lTipoQuery + '; const AFieldInfo: TFieldMeta; AJSON: TJSONObject);' + sLineBreak +
  '// adiciona o campo como parâmetro do ' + lTipoQuery + sLineBreak +
  'var' + sLineBreak +
  '  J: TJSONData;' + sLineBreak +
  '  s: string;' + sLineBreak +
  '  dt: TDateTime;' + sLineBreak +
  'begin' + sLineBreak +
  '  if AFieldInfo.IsPrimaryKey then Exit; // não adiciona PK nos parâmetros' + sLineBreak +
  '' + sLineBreak +
  '  J := AJSON.Find(AFieldInfo.NameAlias); // localiza pelo Alias do nome do campo na tabela' + sLineBreak +
  '' + sLineBreak +
  '  ValidateField(AFieldInfo, J); // validação do campo' + sLineBreak +
  '' + sLineBreak +
  '  if (J = nil) or (J.JSONType = jtNull) then begin' + sLineBreak +
  '    Qry.ParamByName(AFieldInfo.Name).Clear; // Qry.ParamByName(Field.Name).IsNull := True;' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  case J.JSONType of' + sLineBreak +
  '    jtNumber:' + sLineBreak +
  '      begin' + sLineBreak +
  '        if (AFieldInfo.FPDataType = ''integer'') then' + sLineBreak +
  '          Qry.ParamByName(AFieldInfo.Name).AsInteger := J.AsInteger' + sLineBreak +
  '        else' + sLineBreak +
  '          Qry.ParamByName(AFieldInfo.Name).AsFloat := J.AsFloat;' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '    jtBoolean:' + sLineBreak +
  '      begin' + sLineBreak +
  '        if (Pos(''bool'', AFieldInfo.DataType.ToLower) > 0) then' + sLineBreak +
  '          Qry.ParamByName(AFieldInfo.Name).AsBoolean := J.AsBoolean' + sLineBreak +
  '        else if (AFieldInfo.FPDataType = ''integer'') or (AFieldInfo.DataType.Contains(''int'')) then' + sLineBreak +
  '          Qry.ParamByName(AFieldInfo.Name).AsInteger := Ord(J.AsBoolean)' + sLineBreak +
  '        else' + sLineBreak +
  '          Qry.ParamByName(AFieldInfo.Name).AsBoolean := J.AsBoolean;' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '    jtString:' + sLineBreak +
  '      begin' + sLineBreak +
  '        s := Trim(J.AsString);' + sLineBreak +
  '' + sLineBreak +
  '        if (AFieldInfo.FPDataType = ''datetime'') then begin' + sLineBreak +
  '          if (s <> '''') and ParseISODate(s, dt) then' + sLineBreak +
  '            Qry.ParamByName(AFieldInfo.Name).AsDateTime := dt  //StrToDateTime(J.AsString)' + sLineBreak +
  '          else' + sLineBreak +
  '            Qry.ParamByName(AFieldInfo.Name).Clear;' + sLineBreak +
  '        end' + sLineBreak +
  '        else begin' + sLineBreak +
  '          // remove a máscara de formatação, se houver' + sLineBreak +
  '          if (AFieldInfo.RemoveMask) then' + sLineBreak +
  '            s := TUtil.RemoveMaskFormat( s );' + sLineBreak +
  '' + sLineBreak +
  '          // Truncamento UTF-8 seguro' + sLineBreak +
  '          if (AFieldInfo.MaxLength > 0) then' + sLineBreak +
  '            s := UTF8SafeTruncate(s, AFieldInfo.MaxLength);' + sLineBreak +
  '' + sLineBreak +
  '          Qry.ParamByName(AFieldInfo.Name).AsString := Trim(s);' + sLineBreak +
  '        end;' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '    jtNull:' + sLineBreak +
  '      if (AFieldInfo.FPDataType = ''integer'') or' + sLineBreak +
  '         (AFieldInfo.FPDataType = ''currency'') or' + sLineBreak +
  '         (AFieldInfo.FPDataType = ''double'') then' + sLineBreak +
  '        Qry.ParamByName(AFieldInfo.Name).AsInteger := 0' + sLineBreak +
  '      else if (AFieldInfo.FPDataType = ''string'') then' + sLineBreak +
  '        Qry.ParamByName(AFieldInfo.Name).AsString := ''''' + sLineBreak +
  '      else' + sLineBreak +
  '        Qry.ParamByName(AFieldInfo.Name).Clear;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.UTF8SafeTruncate(const S: string; AMaxBytes: Integer): string;' + sLineBreak +
  '// Verifica o comprimento da string, para não ultrapassar o tamanho' + sLineBreak +
  '// definido para o campo no banco de dados' + sLineBreak +
  'var' + sLineBreak +
  '  i, lLen, lCharLen: Integer;' + sLineBreak +
  '  P: PByte;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '  lLen := Length(S);' + sLineBreak +
  '' + sLineBreak +
  '  if lLen <= AMaxBytes then' + sLineBreak +
  '    Exit(S);' + sLineBreak +
  '' + sLineBreak +
  '  i := 1;' + sLineBreak +
  '  while i <= lLen do' + sLineBreak +
  '  begin' + sLineBreak +
  '    P := @S[i];' + sLineBreak +
  '' + sLineBreak +
  '    // Detecta tamanho do caractere UTF-8' + sLineBreak +
  '    if (P^ and $80) = 0 then' + sLineBreak +
  '      lCharLen := 1' + sLineBreak +
  '    else if (P^ and $E0) = $C0 then' + sLineBreak +
  '      lCharLen := 2' + sLineBreak +
  '    else if (P^ and $F0) = $E0 then' + sLineBreak +
  '      lCharLen := 3' + sLineBreak +
  '    else if (P^ and $F8) = $F0 then' + sLineBreak +
  '      lCharLen := 4' + sLineBreak +
  '    else' + sLineBreak +
  '      Break; // byte inválido' + sLineBreak +
  '' + sLineBreak +
  '    if Length(Result) + lCharLen > AMaxBytes then' + sLineBreak +
  '      Break;' + sLineBreak +
  '' + sLineBreak +
  '    Result := Result + Copy(S, i, lCharLen);' + sLineBreak +
  '    Inc(i, lCharLen);' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.FiltraErroSQL(AMessage: string): string;' + sLineBreak +
  '// extrai mensagem de erro do sql' + sLineBreak +
  'var' + sLineBreak +
  '  i: integer;' + sLineBreak +
  '  s, lFieldAlias: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := ''SQL Error'';' + sLineBreak +
  '' + sLineBreak +
  '  if (Pos('' 23505'', AMessage) > 0) then begin //unique constraint' + sLineBreak +
  '    // postgresql - Code 23505' + sLineBreak +
  '    Result := ''Unique constraint: field with duplicated value on table.'';' + sLineBreak +
  '' + sLineBreak +
  '    try' + sLineBreak +
  '      i := Pos(''Key ('', AMessage);' + sLineBreak +
  '      if i > 0 then begin' + sLineBreak +
  '        s := MidStr(AMessage, i+4, Length(AMessage));' + sLineBreak +
  '        i := Pos('')=('', s.ToLower); // PosEx' + sLineBreak +
  '        if i > 0 then begin' + sLineBreak +
  '          lFieldAlias := Trim(LeftStr(s, i));' + sLineBreak +
  '          lFieldAlias := StringReplace(lFieldAlias, ''('', '''', [rfReplaceAll]);' + sLineBreak +
  '          lFieldAlias := StringReplace(lFieldAlias, '')'', '''', [rfReplaceAll]);' + sLineBreak +
  '          lFieldAlias := GetFieldAlias(lFieldAlias);' + sLineBreak +
  '          s := MidStr(s, i+3, Length(s));' + sLineBreak +
  '          i := Pos('')'', s);' + sLineBreak +
  '          if i > 0 then' + sLineBreak +
  '            s := Trim(LeftStr(s, i-1)); // conteúdo so campo' + sLineBreak +
  '' + sLineBreak +
  '          if lFieldAlias <> '''' then' + sLineBreak +
  '            Result := ''Unique constraint: field ('' + lFieldAlias + '') with duplicate value on table.'';' + sLineBreak +
  '        end; // if' + sLineBreak +
  '      end; // if' + sLineBreak +
  '    except' + sLineBreak +
  '    end;' + sLineBreak +
  '  end else if (Pos('' 1062'', AMessage) > 0) then begin // Duplicate entry' + sLineBreak +
  '    // mariadb - Code 1062' + sLineBreak +
  '    Result := ''Unique constraint: field with duplicated value on table.'';' + sLineBreak +
  '' + sLineBreak +
  '    try' + sLineBreak +
  '      i := Pos(''duplicate entry'', AMessage.ToLower);' + sLineBreak +
  '      if i > 0 then begin' + sLineBreak +
  '        s := MidStr(AMessage, i+16, Length(AMessage));' + sLineBreak +
  '        i := Pos(''Code: 1062'', s);' + sLineBreak +
  '        if i > 0 then begin' + sLineBreak +
  '          s := Trim(LeftStr(s, i -1));' + sLineBreak +
  '          i := Pos(''for key'', s);' + sLineBreak +
  '          if i > 0 then begin' + sLineBreak +
  '            lFieldAlias := Trim(MidStr(s, i + 8, Length(s)));' + sLineBreak +
  '            lFieldAlias := StringReplace(lFieldAlias, '''''''', '''', [rfReplaceAll]);' + sLineBreak +
  '            lFieldAlias := GetFieldAlias(lFieldAlias);' + sLineBreak +
  '            s := Trim(LeftStr(s, i -1)); // // conteúdo so campo' + sLineBreak +
  '            s := StringReplace(s, '''''''', '''', [rfReplaceAll]);' + sLineBreak +
  '            if lFieldAlias <> '''' then' + sLineBreak +
  '              Result := ''Unique constraint: field ('' + lFieldAlias + '') with duplicate value on table.'';' + sLineBreak +
  '          end;' + sLineBreak +
  '        end; // if' + sLineBreak +
  '      end; // if' + sLineBreak +
  '    except' + sLineBreak +
  '    end;' + sLineBreak +
  '  end' + sLineBreak +
  '  else if (Pos('' 42703'', AMessage) > 0) or (Pos('' 1054'', AMessage) > 0) then begin' + sLineBreak +
  '    // postgresql: 42703,  mariadb: 1054' + sLineBreak +
  '    Result := ''One column does not exist in the table.'';' + sLineBreak +
  '  end' + sLineBreak +
  '  else if (Pos('' 42804'', AMessage) > 0) or (Pos('' 1366'', AMessage) > 0) then begin' + sLineBreak +
  '    // postgresql: 42804, mariadb: 1366' + sLineBreak +
  '    Result := ''Improper data type for the table column.'';' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TDataControl.AddFieldToJSON(AJSON: TJSONObject; const AliasName, ASpecialField: string; AField: TField);' + sLineBreak +
  '// adiciona ao Json o campo conforme seu tipo no DB' + sLineBreak +
  'var' + sLineBreak +
  '  S: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  if AField.IsNull then' + sLineBreak +
  '  begin' + sLineBreak +
  '    AJSON.Add(AliasName, TJSONNull.Create);' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  case AField.DataType of' + sLineBreak +
  '    // Inteiros' + sLineBreak +
  '    ftSmallint, ftInteger, ftWord, ftAutoInc, ftLargeint:' + sLineBreak +
  '      AJSON.Add(AliasName, AField.AsLargeInt);' + sLineBreak +
  '' + sLineBreak +
  '    // Boolean' + sLineBreak +
  '    ftBoolean:' + sLineBreak +
  '      AJSON.Add(AliasName, AField.AsBoolean);' + sLineBreak +
  '' + sLineBreak +
  '    // Float / Decimal' + sLineBreak +
  '    ftFloat, ftCurrency, ftBCD, ftFMTBcd:' + sLineBreak +
  '      AJSON.Add(AliasName, AField.AsFloat);' + sLineBreak +
  '' + sLineBreak +
  '    // Data' + sLineBreak +
  '    ftDate:' + sLineBreak +
  '      AJSON.Add(AliasName, FormatDateTime(''yyyy-mm-dd'', AField.AsDateTime));' + sLineBreak +
  '' + sLineBreak +
  '    // Hora' + sLineBreak +
  '    ftTime:' + sLineBreak +
  '      AJSON.Add(AliasName, FormatDateTime(''hh:nn:ss'', AField.AsDateTime));' + sLineBreak +
  '' + sLineBreak +
  '    // Data + Hora' + sLineBreak +
  '    ftDateTime, ftTimeStamp:' + sLineBreak +
  '      AJSON.Add(AliasName, FormatDateTime(''yyyy-mm-dd"T"hh:nn:ss'', AField.AsDateTime));' + sLineBreak +
  '' + sLineBreak +
  '    // String curta' + sLineBreak +
  '    ftString, ftFixedChar:' + sLineBreak +
  '      AJSON.Add(AliasName, Formata_Saida(AField.AsString, ASpecialField));' + sLineBreak +
  '' + sLineBreak +
  '    // String longa' + sLineBreak +
  '    ftWideString, ftFixedWideChar, ftMemo, ftWideMemo:' + sLineBreak +
  '      AJSON.Add(AliasName, Formata_Saida(AField.AsString, ASpecialField));' + sLineBreak +
  '' + sLineBreak +
  '    // GUID' + sLineBreak +
  '    ftGuid:' + sLineBreak +
  '      AJSON.Add(AliasName, AField.AsString);' + sLineBreak +
  '' + sLineBreak +
  '    // Blob / binário' + sLineBreak +
  '    ftBlob, ftGraphic, ftBytes, ftVarBytes:' + sLineBreak +
  '      begin' + sLineBreak +
  '        //S := ''[BLOB]'';' + sLineBreak +
  '        S := EncodeStringBase64(AField.AsString);' + sLineBreak +
  '        AJSON.Add(AliasName, S);' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '    // Dataset aninhado' + sLineBreak +
  '    ftDataSet:' + sLineBreak +
  '      begin' + sLineBreak +
  '        // normalmente ignorado ou tratado separadamente' + sLineBreak +
  '        AJSON.Add(AliasName, ''[DATASET]'');' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '    // Outros / fallback' + sLineBreak +
  '  else' + sLineBreak +
  '    AJSON.Add(AliasName, Formata_Saida(AField.AsString, ASpecialField));' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.Insert(const ABodyJson: string): Boolean;' + sLineBreak +
  '// metodo para inserir dados no database' + sLineBreak +
  'var' + sLineBreak +
  '  lJSON: TJSONObject;' + sLineBreak +
  '  Qry: ' + lTipoQuery + ';' + sLineBreak +
  '  lFields, lParams: TStringList;' + sLineBreak +
  '  lMissingFields: TStringList;' + sLineBreak +
  '  I: Integer;' + sLineBreak +
  '  lInvalidFields: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '' + sLineBreak +
  '  if (Trim(ABodyJson) = '''') then' + sLineBreak +
  '    raise Exception.Create(''There is no JSON data in the body.'');' + sLineBreak +
  '' + sLineBreak +
  '  // dados enviados pelo cliente no body do request' + sLineBreak +
  '  lJSON := GetJSON( ABodyJson ) as TJSONObject;' + sLineBreak +
  '' + sLineBreak +
  '  // Verifica se o usuário enviou campos que não existe' + sLineBreak +
  '  lInvalidFields := ValidateJSONFields(lJSON);' + sLineBreak +
  '' + sLineBreak +
  '  if lInvalidFields <> '''' then begin' + sLineBreak +
  '    lJSON.Free;' + sLineBreak +
  '    raise Exception.Create(''Unknown or invalid fields: '' + lInvalidFields);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  lFields := TStringList.Create;' + sLineBreak +
  '  lParams := TStringList.Create;' + sLineBreak +
  '  lMissingFields := TStringList.Create;' + sLineBreak +
  '' + sLineBreak +
  '  Qry := DMServer.NewQuery();' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    // no insert, campos obrigatórios precisam ser enviados usuário' + sLineBreak +
  '    for I := 0 to High(FMeta) do begin' + sLineBreak +
  '      if JSONHas(lJSON, FMeta[I].NameAlias) then' + sLineBreak +
  '      begin' + sLineBreak +
  '        if FMeta[I].IsPrimaryKey then Continue; // não adiciona a PK' + sLineBreak +
  '        lFields.Add(FMeta[I].Name);' + sLineBreak +
  '        lParams.Add('':'' + FMeta[I].Name);' + sLineBreak +
  '      end' + sLineBreak +
  '      else if (not FMeta[I].IsNullable) and (not FMeta[I].IsPrimaryKey) then' + sLineBreak +
  '      begin' + sLineBreak +
  '        lMissingFields.Add(FMeta[I].NameAlias);' + sLineBreak +
  '      end;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    // Se houver campos obrigatórios faltando' + sLineBreak +
  '    if lMissingFields.Count > 0 then' + sLineBreak +
  '      raise Exception.Create(''Required fields are missing: '' + lMissingFields.CommaText);' + sLineBreak +
  '' + sLineBreak +
  '    if lFields.Count = 0 then' + sLineBreak +
  '      raise Exception.Create(''No fields specified for INSERT.'');' + sLineBreak +
  '' + sLineBreak +
  '    // monta a query e a executa' + sLineBreak +
  '' + sLineBreak +
  '    Qry.SQL.Text :=' + sLineBreak +
  '      ''INSERT INTO '' + FTableName +' + sLineBreak +
  '      '' ('' + StringReplace(lFields.CommaText, ''"'', '''', [rfReplaceAll]) + '')'' +' + sLineBreak +
  '      '' VALUES ('' + StringReplace(lParams.CommaText, ''"'', '''', [rfReplaceAll]) + '') '';' + sLineBreak +
  '' + sLineBreak +
  '    if FIs_Postgresql or FIs_MySql then' + sLineBreak +
  '      Qry.SQL.Text := Qry.SQL.Text + Format('' RETURNING %s AS id; '', [FPrimaryKey]);' + sLineBreak +
  '    ' + sLineBreak +
  '    if FIs_Mssql then' + sLineBreak +
  '      Qry.SQL.Text := Qry.SQL.Text + ''; SELECT SCOPE_IDENTITY() AS id; '';' + sLineBreak +
  '' + sLineBreak +
  '    // Bind + validação por tipo/tamanho' + sLineBreak +
  '    for I := 0 to lFields.Count - 1 do' + sLineBreak +
  '      BindParam(Qry, FMeta[FindField(lFields[I])], lJSON);' + sLineBreak +
  '' + sLineBreak +
  '    try' + sLineBreak +
  '      if not FIs_Mssql then' + sLineBreak +
  '        DMServer.TransactionPrepare;' + sLineBreak +
  '' + sLineBreak +
  '      if FIs_Postgresql or FIs_Mssql or FIs_MySql then begin' + sLineBreak +
  '        Qry.Open;' + sLineBreak +
  '        FID := Qry.FieldByName(''id'').AsInteger;' + sLineBreak +
  '      end else begin' + sLineBreak +
  '        Qry.ExecSQL;        ' + sLineBreak +
  '        FID := DMServer.LastInsertedID(FPrimaryKey, FTableName);' + sLineBreak +
  '      end;' + sLineBreak +
  '      ' + sLineBreak +
  '      DMServer.TransactionCommit;' + sLineBreak +
  '      Result := True;' + sLineBreak +
  '' + sLineBreak +
  '      if FIs_Postgresql or FIs_Mssql or FIs_MySql then' + sLineBreak +
  '        Qry.Close;' + sLineBreak +
  '      ' + sLineBreak +
  '      Qry.Free;' + sLineBreak +
  '    except' + sLineBreak +
  '      on E: Exception do begin' + sLineBreak +
  '        FID := 0;' + sLineBreak +
  '        FMessage := FiltraErroSQL(E.Message);' + sLineBreak +
  '        DMServer.TransactionRollback;' + sLineBreak +
  '        Qry.Free;' + sLineBreak +
  '      end;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '  finally' + sLineBreak +
  '    lJSON.Free;' + sLineBreak +
  '    lFields.Free;' + sLineBreak +
  '    lParams.Free;' + sLineBreak +
  '    lMissingFields.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.Update(AId: Integer; const ABodyJson: string): Boolean;' + sLineBreak +
  '// metodo para atualizar dados no database' + sLineBreak +
  'var' + sLineBreak +
  '  lJSON: TJSONObject;' + sLineBreak +
  '  Qry: ' + lTipoQuery + ';' + sLineBreak +
  '  lFields: TStringList;' + sLineBreak +
  '  I: Integer;' + sLineBreak +
  '  lInvalidFields: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '' + sLineBreak +
  '  if (Trim(ABodyJson) = '''') then' + sLineBreak +
  '    raise Exception.Create(''There is no JSON data in the body.'');' + sLineBreak +
  '' + sLineBreak +
  '  if FPrimaryKey = '''' then' + sLineBreak +
  '    raise Exception.Create(''Table without primary key'');' + sLineBreak +
  '' + sLineBreak +
  '  if AId < 1 then' + sLineBreak +
  '    raise Exception.Create(''ID for Primary key not provided.'');' + sLineBreak +
  '' + sLineBreak +
  '  // dados enviados pelo cliente no body do request' + sLineBreak +
  '  lJSON := GetJSON(ABodyJson) as TJSONObject;' + sLineBreak +
  '' + sLineBreak +
  '  // Verifica se o usuário enviou campos que não existe' + sLineBreak +
  '  lInvalidFields := ValidateJSONFields(lJSON);' + sLineBreak +
  '' + sLineBreak +
  '  if lInvalidFields <> '''' then begin' + sLineBreak +
  '    lJSON.Free;' + sLineBreak +
  '    raise Exception.Create(''Unknown or invalid fields: '' + lInvalidFields);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // tudo ok' + sLineBreak +
  '' + sLineBreak +
  '  lFields := TStringList.Create;' + sLineBreak +
  '  lFields.Delimiter := '','';' + sLineBreak +
  '  lFields.StrictDelimiter := True;' + sLineBreak +
  '' + sLineBreak +
  '  Qry := DMServer.NewQuery();' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    // campos para o SET' + sLineBreak +
  '    for I := 0 to High(FMeta) do begin' + sLineBreak +
  '      if FMeta[I].IsPrimaryKey then Continue; // não adiciona a PK' + sLineBreak +
  '' + sLineBreak +
  '      if JSONHas(lJSON, FMeta[I].NameAlias) then' + sLineBreak +
  '        lFields.Add(FMeta[I].Name + ''=:'' + FMeta[I].Name);' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    if lFields.Count = 0 then' + sLineBreak +
  '      raise Exception.Create(''No data provided to update.'');' + sLineBreak +
  '' + sLineBreak +
  '    // monta a query e a executa' + sLineBreak +
  '' + sLineBreak +
  '    Qry.SQL.Text :=' + sLineBreak +
  '      ''UPDATE '' + FTableName +' + sLineBreak +
  '      '' SET '' + lFields.DelimitedText +' + sLineBreak +
  '      '' WHERE '' + FPrimaryKey + ''='' + IntToStr(AId);' + sLineBreak +
  '' + sLineBreak +
  '    // Bind + validação por tipo/tamanho' + sLineBreak +
  '    for I := 0 to High(FMeta) do' + sLineBreak +
  '      if JSONHas(lJSON, FMeta[I].NameAlias) then' + sLineBreak +
  '        BindParam(Qry, FMeta[I], lJSON);' + sLineBreak +
  '' + sLineBreak +
  '    // envia para o DB' + sLineBreak +
  '    try' + sLineBreak +
  '      if not FIs_Mssql then' + sLineBreak +
  '        DMServer.TransactionPrepare;' + sLineBreak +
  '    ' + sLineBreak +
  '      Qry.ExecSQL;' + sLineBreak +
  '    ' + sLineBreak +
  '      DMServer.TransactionCommit;' + sLineBreak +
  '      ' + sLineBreak +
  '      Result := Qry.RowsAffected > 0;' + sLineBreak +
  '' + sLineBreak +
  '      if Qry.RowsAffected <> 1 then' + sLineBreak +
  '        FMessage := ''No records updated. ID = '' + IntToStr(AId);' + sLineBreak +
  '' + sLineBreak +
  '      Qry.Free;' + sLineBreak +
  '    except' + sLineBreak +
  '      on E: Exception do begin //EZSQLException' + sLineBreak +
  '        FMessage := FiltraErroSQL(E.Message);' + sLineBreak +
  '        DMServer.TransactionRollback;' + sLineBreak +
  '        Qry.Free;' + sLineBreak +
  '      end;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '  finally' + sLineBreak +
  '    lJSON.Free;' + sLineBreak +
  '    lFields.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.GetByID(AId: Integer): string;' + sLineBreak +
  '// obtém dados conforme ID informado' + sLineBreak +
  'var' + sLineBreak +
  '  lJSON: TJSONObject;' + sLineBreak +
  '  lFields: TStringList;' + sLineBreak +
  '  Qry: ' + lTipoQuery + ';' + sLineBreak +
  '  I, lCount: Integer;' + sLineBreak +
  '  lFieldName, lAliasName, lSpecialField, lForeignTable: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '  lForeignTable := '''';' + sLineBreak +
  '' + sLineBreak +
  '  if FPrimaryKey = '''' then' + sLineBreak +
  '    raise Exception.Create(''Table without primary key'');' + sLineBreak +
  '' + sLineBreak +
  '  if AId < 1 then' + sLineBreak +
  '    raise Exception.Create(''ID for Primary key not provided.'');' + sLineBreak +
  '' + sLineBreak +
  '  // Tudo OK' + sLineBreak +
  '  Qry := DMServer.NewQuery();' + sLineBreak +
  '  lJSON := TJSONObject.Create;' + sLineBreak +
  '  lFields := TStringList.Create;' + sLineBreak +
  '  lFields.Delimiter := '','';' + sLineBreak +
  '  lFields.StrictDelimiter := True;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    try' + sLineBreak +
  '      // campos para o SET' + sLineBreak +
  '      for I := 0 to High(FMeta) do begin' + sLineBreak +
  '        //if FMeta[I].IsPrimaryKey then Continue; // não adiciona a PK' + sLineBreak +
  '' + sLineBreak +
  '        if FMeta[I].ToList then begin' + sLineBreak +
  '          lFieldName := ''t.'' + FMeta[I].Name;' + sLineBreak +
  '' + sLineBreak +
  '          if FIs_Mssql and' + sLineBreak +
  '             (FMeta[I].DataType = ''numeric'') and' + sLineBreak +
  '             ((FMeta[I].FPDataType = ''currency'') or (FMeta[I].FPDataType = ''double'')) then' + sLineBreak +
  '            lFieldName := ''CAST('' + lFieldName + '' AS FLOAT) AS '' + FMeta[I].Name;' + sLineBreak +
  '' + sLineBreak +
  '          if FMeta[I].FKTableName <> '''' then begin' + sLineBreak +
  '            // chave estrangeira' + sLineBreak +
  '            lFields.Add(lFieldName);' + sLineBreak +
  '' + sLineBreak +
  '            // campo que traz o texto relacionado à chave estrangeira' + sLineBreak +
  '            lFieldName := ''f'' + I.ToString + ''.'' + FMeta[I].FKTextField + '' AS '' + FMeta[I].NameAlias + ''_value'';' + sLineBreak +
  '            lForeignTable := lForeignTable +' + sLineBreak +
  '              ''LEFT JOIN '' + FMeta[I].FKTableName + '' f'' + I.ToString + '' ON '' +' + sLineBreak +
  '              ''f'' + I.ToString + ''.'' + FMeta[I].FKCodeField + '' = '' + ''t.'' + FMeta[I].Name + '' '';' + sLineBreak +
  '          end;' + sLineBreak +
  '' + sLineBreak +
  '          lFields.Add(lFieldName);' + sLineBreak +
  '        end; // if' + sLineBreak +
  '      end;// for' + sLineBreak +
  '' + sLineBreak +
  '      if lFields.Count = 0 then' + sLineBreak +
  '        raise Exception.Create(''No data provided to update.'');' + sLineBreak +
  '' + sLineBreak +
  '      // Monta SELECT' + sLineBreak +
  '      Qry.SQL.Text := ''SELECT '' + lFields.DelimitedText +' + sLineBreak +
  '                      '' FROM '' + FTableName + '' t '' + lForeignTable +' + sLineBreak +
  '                      '' WHERE '' + FPrimaryKey + '' = :id'';' + sLineBreak +
  '' + sLineBreak +
  '      Qry.ParamByName(''id'').AsInteger := AId;' + sLineBreak +
  '' + sLineBreak +
  '      Qry.Open;' + sLineBreak +
  '' + sLineBreak +
  '      lCount := Qry.RecordCount;' + sLineBreak +
  '' + sLineBreak +
  '      if lCount > 0 then begin' + sLineBreak +
  '        // Monta JSON com alias' + sLineBreak +
  '        for I := 0 to High(FMeta) do begin' + sLineBreak +
  '          if FMeta[I].ToList then begin' + sLineBreak +
  '            lFieldName := FMeta[I].Name;' + sLineBreak +
  '            lSpecialField := '''';' + sLineBreak +
  '' + sLineBreak +
  '            if FMeta[I].RemoveMask then' + sLineBreak +
  '              lSpecialField := Trim(FMeta[I].SpecialField);' + sLineBreak +
  '' + sLineBreak +
  '            if FMeta[I].NameAlias <> '''' then' + sLineBreak +
  '              lAliasName := FMeta[I].NameAlias' + sLineBreak +
  '            else' + sLineBreak +
  '              lAliasName := lFieldName;' + sLineBreak +
  '' + sLineBreak +
  '            // adiciona ao Json conforme o tipo de dados' + sLineBreak +
  '            AddFieldToJSON(lJSON, lAliasName, lSpecialField, Qry.FieldByName(lFieldName));' + sLineBreak +
  '' + sLineBreak +
  '            if FMeta[I].IsForeignKey and (FMeta[I].FKTableName <> '''') then begin' + sLineBreak +
  '              // campo da tabela estrangeira' + sLineBreak +
  '              lFieldName := lAliasName + ''_value'';' + sLineBreak +
  '              AddFieldToJSON(lJSON, lFieldName, '''', Qry.FieldByName(lFieldName));' + sLineBreak +
  '            end;' + sLineBreak +
  '' + sLineBreak +
  '          end; // if' + sLineBreak +
  '        end; // for' + sLineBreak +
  '' + sLineBreak +
  '        Result := lJSON.AsJSON;' + sLineBreak +
  '      end; // if' + sLineBreak +
  '' + sLineBreak +
  '      if lCount < 1 then' + sLineBreak +
  '        FMessage := ''Record not found. ID = '' + IntToStr(AId);' + sLineBreak +
  '' + sLineBreak +
  '      Qry.Close;' + sLineBreak +
  '      Qry.Free;' + sLineBreak +
  '    except' + sLineBreak +
  '      on E: Exception do begin' + sLineBreak +
  '        FMessage := E.Message;' + sLineBreak +
  '        Qry.Free;' + sLineBreak +
  '      end;' + sLineBreak +
  '    end; // try' + sLineBreak +
  '  finally' + sLineBreak +
  '    lJSON.Free;' + sLineBreak +
  '    lFields.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.DeleteByID(AId: Integer): Boolean;' + sLineBreak +
  '// deleta o registro' + sLineBreak +
  'var' + sLineBreak +
  '  Qry: ' + lTipoQuery + ';' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '' + sLineBreak +
  '  if FPrimaryKey = '''' then' + sLineBreak +
  '    raise Exception.Create(''Table without primary key'');' + sLineBreak +
  '' + sLineBreak +
  '  if AId < 1 then' + sLineBreak +
  '    raise Exception.Create(''ID for Primary key not provided.'');' + sLineBreak +
  '' + sLineBreak +
  '  // Tudo OK' + sLineBreak +
  '  Qry := DMServer.NewQuery();' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    // Monta SELECT' + sLineBreak +
  '    Qry.SQL.Text := ''DELETE FROM '' + FTableName +' + sLineBreak +
  '                    '' WHERE '' + FPrimaryKey + '' = :id'';' + sLineBreak +
  '' + sLineBreak +
  '    Qry.ParamByName(''id'').AsInteger := AId;' + sLineBreak +
  '' + sLineBreak +
  '    if not FIs_Mssql then' + sLineBreak +
  '      DMServer.TransactionPrepare;' + sLineBreak +
  '' + sLineBreak +
  '    Qry.ExecSQL;' + sLineBreak +
  '' + sLineBreak +
  '    DMServer.TransactionCommit;' + sLineBreak +
  '' + sLineBreak +
  '    Result := Qry.RowsAffected > 0;' + sLineBreak +
  '' + sLineBreak +
  '    if not Result then' + sLineBreak +
  '      FMessage := ''No records deleted. ID = '' + IntToStr(AId);' + sLineBreak +
  '' + sLineBreak +
  '    Qry.Free;' + sLineBreak +
  '  except' + sLineBreak +
  '    on E: Exception do begin' + sLineBreak +
  '      FMessage := FiltraErroSQL(E.Message);' + sLineBreak +
  '      DMServer.TransactionRollback;' + sLineBreak +
  '      Qry.Free;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end; // try' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TDataControl.GetList(APageNumber, APageSize: Integer;' + sLineBreak +
  '                              ASearchField, ASearchOperator, ASearch, AOrderFields, AOrderDirection: string): string;' + sLineBreak +
  '// Listagem com paginação, pesquisa e ordenação' + sLineBreak +
  '// Campos opcionais: ASearchField, ASearchOperator, ASearch, AOrderFields, AOrderDirection' + sLineBreak +
  '// ASearchField: Nome do campo onde será efetuado a pesquisa' + sLineBreak +
  '// ASearchOperator: Operador da pesquisa' + sLineBreak +
  '// ASearch: Conteúdo a ser pesquisado.' + sLineBreak +
  '// -----------------------------------------------' + sLineBreak +
  '// Alias    | Operador SQL   | Tipo de campo' + sLineBreak +
  '// ---------+----------------+--------------------' + sLineBreak +
  '// eq       | =	             | texto, número, data' + sLineBreak +
  '// neq      | <>             | texto, número, data' + sLineBreak +
  '// gt       | >              | número, data' + sLineBreak +
  '// gte      | >=             | número, data' + sLineBreak +
  '// lt       | <              | número, data' + sLineBreak +
  '// lte      | <=             | número, data' + sLineBreak +
  '// between  | BETWEEN        | número, data' + sLineBreak +
  '// contains | LIKE ''%valor%'' | texto' + sLineBreak +
  '// starts   | LIKE ''valor%''  | texto' + sLineBreak +
  '// ends     | LIKE ''%valor''  | texto' + sLineBreak +
  '// ---------+----------------+--------------------' + sLineBreak +
  '// Igualdade' + sLineBreak +
  '//  /GetList?page=1&limit=10&search_field=id&search_operator=eq&search=10' + sLineBreak +
  '// Maior ou igual' + sLineBreak +
  '//  /GetList?page=1&limit=10&search_field=price&search_operator=gte&search=100' + sLineBreak +
  '// Menor ou igual' + sLineBreak +
  '//  /GetList?page=1&limit=10&search_field=price&search_operator=lte&search=500' + sLineBreak +
  '// Intervalo' + sLineBreak +
  '//  /GetList?page=1&limit=10&search_field=price&search_operator=between&search=100;500' + sLineBreak +
  '// Contém' + sLineBreak +
  '//  /GetList?page=1&limit=10&search_field=name&search_operator=contains&search=bicicleta' + sLineBreak +
  '// Data' + sLineBreak +
  '//  /GetList?page=1&limit=10&search_field=date_created&search_operator=gte&search=2026-01-01' + sLineBreak +
  'var' + sLineBreak +
  '  Qry: ' + lTipoQuery + ';' + sLineBreak +
  '  lJson: TJSONObject;' + sLineBreak +
  '  lArr: TJSONArray;' + sLineBreak +
  '  JSONItem: TJSONObject;' + sLineBreak +
  '  SelectFields: TStringList;' + sLineBreak +
  '  SearchFields: TStringList;' + sLineBreak +
  '  OrderFields: TStringList;' + sLineBreak +
  '  InvalidFields: TStringList;' + sLineBreak +
  '  I, Idx: Integer;' + sLineBreak +
  '  Offset: Integer;' + sLineBreak +
  '  lFieldName, lAliasName, lRange, lSpecialField, lForeignTable: string;' + sLineBreak +
  '  lTotalPages, lTotalRecords: Integer;' + sLineBreak +
  '  lWhere, lOrderBy, lDir: string;' + sLineBreak +
  '' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  // Retorna o nome real do campo a partir do NameAlias ou Name' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  function ResolveFieldName(const AFieldOrAlias: string): string;' + sLineBreak +
  '  var' + sLineBreak +
  '    J: Integer;' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result := '''';' + sLineBreak +
  '' + sLineBreak +
  '    for J := 0 to High(FMeta) do' + sLineBreak +
  '    begin' + sLineBreak +
  '      // procura por alias do nome real do campo' + sLineBreak +
  '      if (FMeta[J].NameAlias <> '''') and' + sLineBreak +
  '         SameText(FMeta[J].NameAlias, AFieldOrAlias) then' + sLineBreak +
  '        Exit(FMeta[J].Name);' + sLineBreak +
  '' + sLineBreak +
  '      // procura pelo nome real' + sLineBreak +
  '      if SameText(FMeta[J].Name, AFieldOrAlias) then' + sLineBreak +
  '        Exit(FMeta[J].Name);' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  // Verifica se o campo pode participar da listagem/pesquisa/ordenação' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  function IsAllowedField(const AFieldName: string): Boolean;' + sLineBreak +
  '  var' + sLineBreak +
  '    J: Integer;' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result := False;' + sLineBreak +
  '' + sLineBreak +
  '    for J := 0 to High(FMeta) do' + sLineBreak +
  '      if SameText(FMeta[J].Name, AFieldName) and FMeta[J].ToList then' + sLineBreak +
  '        Exit(True);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  // Verifica se é campo texto' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  function IsTextField(const M: TFieldMeta): Boolean;' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result := SameText(M.FPDataType, ''string'');' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  // Verifica se é campo numérico' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  function IsNumericField(const M: TFieldMeta): Boolean;' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result :=' + sLineBreak +
  '      SameText(M.FPDataType, ''currency'') or' + sLineBreak +
  '      SameText(M.FPDataType, ''float'') or' + sLineBreak +
  '      SameText(M.FPDataType, ''double'') or' + sLineBreak +
  '      SameText(M.FPDataType, ''integer'');' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  // Verifica se é campo date/datetime' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  function IsDateField(const M: TFieldMeta): Boolean;' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result :=' + sLineBreak +
  '      SameText(M.FPDataType, ''date'') or' + sLineBreak +
  '      SameText(M.FPDataType, ''datetime'');' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  // valida os operadores da pesquisa' + sLineBreak +
  '  // ---------------------------------------------------------------------------' + sLineBreak +
  '  function NormalizeOperator(const AOperator: string): string;' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result := LowerCase(Trim(AOperator));' + sLineBreak +
  '' + sLineBreak +
  '    if Result = '''' then' + sLineBreak +
  '      Result := ''contains''' + sLineBreak +
  '    else if Result = ''eq'' then' + sLineBreak +
  '      Result := ''=''' + sLineBreak +
  '    else if Result = ''neq'' then' + sLineBreak +
  '      Result := ''<>''' + sLineBreak +
  '    else if Result = ''gt'' then' + sLineBreak +
  '      Result := ''>''' + sLineBreak +
  '    else if Result = ''gte'' then' + sLineBreak +
  '      Result := ''>=''' + sLineBreak +
  '    else if Result = ''lt'' then' + sLineBreak +
  '      Result := ''<''' + sLineBreak +
  '    else if Result = ''lte'' then' + sLineBreak +
  '      Result := ''<=''' + sLineBreak +
  '    else if Result = ''contains'' then' + sLineBreak +
  '      Result := ''contains''' + sLineBreak +
  '    else if Result = ''starts'' then' + sLineBreak +
  '      Result := ''starts''' + sLineBreak +
  '    else if Result = ''ends'' then' + sLineBreak +
  '      Result := ''ends''' + sLineBreak +
  '    else if Result = ''between'' then' + sLineBreak +
  '      Result := ''between''' + sLineBreak +
  '    else' + sLineBreak +
  '      raise Exception.Create(''Invalid search operator: '' + AOperator);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  function FloatValue(const AValue: string): Double;' + sLineBreak +
  '  var' + sLineBreak +
  '    s: string;' + sLineBreak +
  '  begin' + sLineBreak +
  '    s := ''0'' + Trim(AValue);' + sLineBreak +
  '    s := s.Replace(''.'', DefaultFormatSettings.DecimalSeparator);' + sLineBreak +
  '    Result := StrToFloatDef(s, 0);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '  Qry := DMServer.NewQuery();' + sLineBreak +
  '  SelectFields := TStringList.Create;' + sLineBreak +
  '  SearchFields := TStringList.Create;' + sLineBreak +
  '  OrderFields := TStringList.Create;' + sLineBreak +
  '  InvalidFields := TStringList.Create;' + sLineBreak +
  '  lArr := TJSONArray.Create;' + sLineBreak +
  '  lJson := TJSONObject.Create;' + sLineBreak +
  '' + sLineBreak +
  '  lTotalPages := 0;' + sLineBreak +
  '  lTotalRecords := 0;' + sLineBreak +
  '  lForeignTable := '''';' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    // Campos do SELECT' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    for I := 0 to High(FMeta) do begin' + sLineBreak +
  '      if FMeta[I].ToList then begin' + sLineBreak +
  '        lFieldName := ''t.'' + FMeta[I].Name;' + sLineBreak +
  '' + sLineBreak +
  '        if FIs_Mssql and' + sLineBreak +
  '           (FMeta[I].DataType = ''numeric'') and' + sLineBreak +
  '           ((FMeta[I].FPDataType = ''currency'') or (FMeta[I].FPDataType = ''double'')) then' + sLineBreak +
  '          lFieldName := ''CAST('' + lFieldName + '' AS FLOAT) AS '' + FMeta[I].Name;' + sLineBreak +
  '' + sLineBreak +
  '        if FMeta[I].FKTableName <> '''' then begin' + sLineBreak +
  '          // chave estrangeira' + sLineBreak +
  '          SelectFields.Add(lFieldName);' + sLineBreak +
  '' + sLineBreak +
  '          // campo que traz o texto relacionado à chave estrangeira' + sLineBreak +
  '          lFieldName := ''f'' + I.ToString + ''.'' + FMeta[I].FKTextField + '' AS '' + FMeta[I].NameAlias + ''_value'';' + sLineBreak +
  '          lForeignTable := lForeignTable +' + sLineBreak +
  '            ''LEFT JOIN '' + FMeta[I].FKTableName + '' f'' + I.ToString + '' ON '' +' + sLineBreak +
  '            ''f'' + I.ToString + ''.'' + FMeta[I].FKCodeField + '' = '' + ''t.'' + FMeta[I].Name + '' '';' + sLineBreak +
  '        end;' + sLineBreak +
  '' + sLineBreak +
  '        SelectFields.Add(lFieldName);' + sLineBreak +
  '      end;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    if SelectFields.Count = 0 then' + sLineBreak +
  '      raise Exception.Create(''No fields defined for listing.'');' + sLineBreak +
  '' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    // Paginação' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    if APageNumber < 1 then APageNumber := 1;' + sLineBreak +
  '    if APageSize < 5 then APageSize := 5;' + sLineBreak +
  '    if APageSize > 100 then APageSize := 100;' + sLineBreak +
  '' + sLineBreak +
  '    Offset := (APageNumber - 1) * APageSize;' + sLineBreak +
  '' + sLineBreak +
  '    lRange := ''LIMIT :limit OFFSET :offset '';' + sLineBreak +
  '' + sLineBreak +
  '    case UpperCase(DMServer.Protocol) of' + sLineBreak +
  '      ''SQLITE'':' + sLineBreak +
  '        lRange := ''LIMIT :limit OFFSET :offset '';' + sLineBreak +
  '      ''POSTGRE'':' + sLineBreak +
  '        lRange := ''LIMIT :limit OFFSET :offset '';' + sLineBreak +
  '      ''MARIADB'', ''MYSQL'':' + sLineBreak +
  '        lRange := ''LIMIT :offset, :limit '';' + sLineBreak +
  '      ''FIREBIRD'':' + sLineBreak +
  '        begin' + sLineBreak +
  '          if Offset < 1 then' + sLineBreak +
  '            Offset := 1;' + sLineBreak +
  '          lRange := ''ROWS :offset TO :limit '';' + sLineBreak +
  '        end;' + sLineBreak +
  '      ''MSSQL'', ''ORACLE'':' + sLineBreak +
  '        lRange := ''OFFSET :offset ROWS FETCH NEXT :limit ROWS ONLY '';' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    // WHERE (pesquisa)' + sLineBreak +
  '    //' + sLineBreak +
  '    // ASearch  -> valor a pesquisar' + sLineBreak +
  '    // AOrderFields pode receber:' + sLineBreak +
  '    //   ''nome''' + sLineBreak +
  '    //   ''nome,preco''' + sLineBreak +
  '    // utilizando NameAlias ou Name' + sLineBreak +
  '    //' + sLineBreak +
  '    // Pesquisa é feita em todos os campos ToList do tipo texto.' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    lWhere := '''';' + sLineBreak +
  '' + sLineBreak +
  '    if (Trim(ASearch) <> '''') and (Trim(ASearchField) <> '''') then' + sLineBreak +
  '    begin' + sLineBreak +
  '      lFieldName := ResolveFieldName(Trim(ASearchField));' + sLineBreak +
  '' + sLineBreak +
  '      if lFieldName = '''' then' + sLineBreak +
  '        raise Exception.Create(''Invalid search field: '' + ASearchField);' + sLineBreak +
  '' + sLineBreak +
  '      if not IsAllowedField(lFieldName) then' + sLineBreak +
  '        raise Exception.Create(''Field not allowed for search: '' + ASearchField);' + sLineBreak +
  '' + sLineBreak +
  '      Idx := FindField(lFieldName);' + sLineBreak +
  '      if Idx = -1 then' + sLineBreak +
  '        raise Exception.Create(''Metadata not found for field: '' + lFieldName);' + sLineBreak +
  '' + sLineBreak +
  '      lDir := NormalizeOperator(ASearchOperator);' + sLineBreak +
  '      if lDir = '''' then lDir := ''contains'';' + sLineBreak +
  '' + sLineBreak +
  '      // ---------------------------------------------------------------------------' + sLineBreak +
  '      // CAMPOS TEXTO' + sLineBreak +
  '      // ---------------------------------------------------------------------------' + sLineBreak +
  '      if IsTextField(FMeta[Idx]) then' + sLineBreak +
  '      begin' + sLineBreak +
  '        case lDir of' + sLineBreak +
  '          ''contains'', ''starts'', ''ends'':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' LIKE :search1 '';' + sLineBreak +
  '          ''='':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' = :search1 '';' + sLineBreak +
  '          ''<>'':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' <> :search1 '';' + sLineBreak +
  '        else' + sLineBreak +
  '          raise Exception.Create(''Invalid operator for text field: '' + ASearchOperator);' + sLineBreak +
  '        end;' + sLineBreak +
  '      end' + sLineBreak +
  '      // ---------------------------------------------------------------------------' + sLineBreak +
  '      // CAMPOS NUMÉRICOS' + sLineBreak +
  '      // ---------------------------------------------------------------------------' + sLineBreak +
  '      else if IsNumericField(FMeta[Idx]) then' + sLineBreak +
  '      begin' + sLineBreak +
  '        case lDir of' + sLineBreak +
  '          ''='':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' = :search1 '';' + sLineBreak +
  '          ''>'':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' > :search1 '';' + sLineBreak +
  '          ''>='':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' >= :search1 '';' + sLineBreak +
  '          ''<'':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' < :search1 '';' + sLineBreak +
  '          ''<='':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' <= :search1 '';' + sLineBreak +
  '          ''between'':' + sLineBreak +
  '            begin' + sLineBreak +
  '              if Pos('';'', ASearch) = 0 then' + sLineBreak +
  '                raise Exception.Create(''Between requires two values separated by ";"'');' + sLineBreak +
  '' + sLineBreak +
  '              lWhere := '' WHERE '' + lFieldName +' + sLineBreak +
  '                        '' BETWEEN :search1 AND :search2 '';' + sLineBreak +
  '            end;' + sLineBreak +
  '        else' + sLineBreak +
  '          raise Exception.Create(''Invalid numeric operator: '' + ASearchOperator);' + sLineBreak +
  '        end;' + sLineBreak +
  '      end' + sLineBreak +
  '' + sLineBreak +
  '      // ---------------------------------------------------------------------------' + sLineBreak +
  '      // CAMPOS DATA / DATETIME' + sLineBreak +
  '      // ---------------------------------------------------------------------------' + sLineBreak +
  '      else if IsDateField(FMeta[Idx]) then' + sLineBreak +
  '      begin' + sLineBreak +
  '        case lDir of' + sLineBreak +
  '          ''='':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' = :search1 '';' + sLineBreak +
  '          ''>'':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' > :search1 '';' + sLineBreak +
  '          ''>='':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' >= :search1 '';' + sLineBreak +
  '          ''<'':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' < :search1 '';' + sLineBreak +
  '          ''<='':' + sLineBreak +
  '            lWhere := '' WHERE '' + lFieldName + '' <= :search1 '';' + sLineBreak +
  '          ''between'':' + sLineBreak +
  '            begin' + sLineBreak +
  '              if Pos('';'', ASearch) = 0 then' + sLineBreak +
  '                raise Exception.Create(''Between requires two dates separated by ";"'');' + sLineBreak +
  '' + sLineBreak +
  '              lWhere := '' WHERE '' + lFieldName +' + sLineBreak +
  '                        '' BETWEEN :search1 AND :search2 '';' + sLineBreak +
  '            end;' + sLineBreak +
  '        else' + sLineBreak +
  '          raise Exception.Create(''Invalid date operator: '' + ASearchOperator);' + sLineBreak +
  '        end;' + sLineBreak +
  '      end' + sLineBreak +
  '' + sLineBreak +
  '      else' + sLineBreak +
  '        raise Exception.Create(''Unsupported field type for search: '' + ASearchField);' + sLineBreak +
  '    end' + sLineBreak +
  '    else if Trim(ASearch) <> '''' then' + sLineBreak +
  '    begin' + sLineBreak +
  '      // Pesquisa global em todos os campos textuais ToList' + sLineBreak +
  '      for I := 0 to High(FMeta) do' + sLineBreak +
  '      begin' + sLineBreak +
  '        if not FMeta[I].ToList then' + sLineBreak +
  '          Continue;' + sLineBreak +
  '' + sLineBreak +
  '        if not IsTextField(FMeta[I]) then' + sLineBreak +
  '          Continue;' + sLineBreak +
  '' + sLineBreak +
  '        if lWhere <> '''' then' + sLineBreak +
  '          lWhere := lWhere + '' OR '';' + sLineBreak +
  '' + sLineBreak +
  '        lWhere := lWhere + FMeta[I].Name + '' LIKE :search1'';' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '      if lWhere <> '''' then' + sLineBreak +
  '        lWhere := '' WHERE ('' + lWhere + '') '';' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    // ORDER BY' + sLineBreak +
  '    //' + sLineBreak +
  '    // AOrderFields:' + sLineBreak +
  '    //   ''nome''' + sLineBreak +
  '    //   ''nome,preco''' + sLineBreak +
  '    //' + sLineBreak +
  '    // AOrderDirection:' + sLineBreak +
  '    //   ''ASC'' ou ''DESC''' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    lOrderBy := '''';' + sLineBreak +
  '' + sLineBreak +
  '    if Trim(AOrderFields) <> '''' then' + sLineBreak +
  '    begin' + sLineBreak +
  '      OrderFields.StrictDelimiter := True;' + sLineBreak +
  '      OrderFields.Delimiter := '','';' + sLineBreak +
  '      OrderFields.DelimitedText := AOrderFields;' + sLineBreak +
  '' + sLineBreak +
  '      for I := 0 to OrderFields.Count - 1 do' + sLineBreak +
  '      begin' + sLineBreak +
  '        lFieldName := ResolveFieldName(Trim(OrderFields[I]));' + sLineBreak +
  '' + sLineBreak +
  '        if lFieldName = '''' then' + sLineBreak +
  '        begin' + sLineBreak +
  '          InvalidFields.Add(OrderFields[I]);' + sLineBreak +
  '          Continue;' + sLineBreak +
  '        end;' + sLineBreak +
  '' + sLineBreak +
  '        if not IsAllowedField(lFieldName) then' + sLineBreak +
  '        begin' + sLineBreak +
  '          InvalidFields.Add(OrderFields[I]);' + sLineBreak +
  '          Continue;' + sLineBreak +
  '        end;' + sLineBreak +
  '' + sLineBreak +
  '        if lOrderBy <> '''' then' + sLineBreak +
  '          lOrderBy := lOrderBy + '', '';' + sLineBreak +
  '' + sLineBreak +
  '        lDir := UpperCase(Trim(AOrderDirection));' + sLineBreak +
  '        if (lDir <> ''DESC'') then lDir := ''ASC'';' + sLineBreak +
  '' + sLineBreak +
  '        lOrderBy := lOrderBy + ''t.'' + lFieldName + '' '' + lDir;' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '      if InvalidFields.Count > 0 then' + sLineBreak +
  '        raise Exception.Create(''Invalid order field(s): '' + InvalidFields.CommaText);' + sLineBreak +
  '' + sLineBreak +
  '      if lOrderBy <> '''' then' + sLineBreak +
  '        lOrderBy := '' ORDER BY '' + lOrderBy + '' '';' + sLineBreak +
  '    end' + sLineBreak +
  '    else' + sLineBreak +
  '    begin' + sLineBreak +
  '      // ordenação padrão pela chave primária' + sLineBreak +
  '      if Trim(FPrimaryKey) <> '''' then' + sLineBreak +
  '        lOrderBy := '' ORDER BY '' + ''t.'' + FPrimaryKey + '' ASC '';' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    // SQL final' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    Qry.SQL.Text := Format(' + sLineBreak +
  '      ''SELECT '' + StringReplace(SelectFields.CommaText, ''"'', '''', [rfReplaceAll]) +' + sLineBreak +
  '      '', COUNT(*) OVER() total_rec '' +' + sLineBreak;

  if FTipoBanco = SQLSERVER then
    s := s +
    '      '', CEILING(COUNT(*) OVER() / (%d/1.0)) total_page '' +' + sLineBreak
  else
    s := s +
    '      '', CEIL(COUNT(*) OVER() / (%d/1.0)) total_page '' +' + sLineBreak;

  s := s +
  '      ''FROM '' + FTableName + '' t '' +' + sLineBreak +
  '      lForeignTable +' + sLineBreak +
  '      lWhere +' + sLineBreak +
  '      lOrderBy +' + sLineBreak +
  '      lRange,' + sLineBreak +
  '      [APageSize]' + sLineBreak +
  '    );' + sLineBreak +
  '' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    // Binding dos parâmetros' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    if Trim(ASearch) <> '''' then' + sLineBreak +
  '    begin' + sLineBreak +
  '      lDir := LowerCase(Trim(ASearchOperator));' + sLineBreak +
  '      if lDir = '''' then lDir := ''contains'';' + sLineBreak +
  '' + sLineBreak +
  '      // Identifica o tipo do campo, se informado' + sLineBreak +
  '      Idx := -1;' + sLineBreak +
  '      if Trim(ASearchField) <> '''' then' + sLineBreak +
  '      begin' + sLineBreak +
  '        lFieldName := ResolveFieldName(Trim(ASearchField));' + sLineBreak +
  '        if lFieldName <> '''' then' + sLineBreak +
  '          Idx := FindField(lFieldName);' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '      // BETWEEN' + sLineBreak +
  '      if lDir = ''between'' then' + sLineBreak +
  '      begin' + sLineBreak +
  '        if Idx >= 0 then' + sLineBreak +
  '        begin' + sLineBreak +
  '          // NUMÉRICO' + sLineBreak +
  '          if IsNumericField(FMeta[Idx]) then' + sLineBreak +
  '          begin' + sLineBreak +
  '            Qry.ParamByName(''search1'').AsFloat :=' + sLineBreak +
  '              FloatValue(Trim(Copy(ASearch, 1, Pos('';'', ASearch) - 1)));' + sLineBreak +
  '' + sLineBreak +
  '            Qry.ParamByName(''search2'').AsFloat :=' + sLineBreak +
  '              FloatValue(Trim(Copy(ASearch, Pos('';'', ASearch) + 1, MaxInt)));' + sLineBreak +
  '          end' + sLineBreak +
  '          // DATA' + sLineBreak +
  '          else if IsDateField(FMeta[Idx]) then' + sLineBreak +
  '          begin' + sLineBreak +
  '            Qry.ParamByName(''search1'').AsDateTime :=' + sLineBreak +
  '              ISO8601ToDate(Trim(Copy(ASearch, 1, Pos('';'', ASearch) - 1)));' + sLineBreak +
  '' + sLineBreak +
  '            Qry.ParamByName(''search2'').AsDateTime :=' + sLineBreak +
  '              ISO8601ToDate(Trim(Copy(ASearch, Pos('';'', ASearch) + 1, MaxInt)));' + sLineBreak +
  '          end;' + sLineBreak +
  '        end;' + sLineBreak +
  '      end' + sLineBreak +
  '      else' + sLineBreak +
  '      begin' + sLineBreak +
  '        // TEXTO' + sLineBreak +
  '        if (Idx >= 0) and IsTextField(FMeta[Idx]) then' + sLineBreak +
  '        begin' + sLineBreak +
  '          if lDir = ''contains'' then' + sLineBreak +
  '            Qry.ParamByName(''search1'').AsString := ''%'' + Trim(ASearch) + ''%''' + sLineBreak +
  '          else if lDir = ''starts'' then' + sLineBreak +
  '            Qry.ParamByName(''search1'').AsString := Trim(ASearch) + ''%''' + sLineBreak +
  '          else if lDir = ''ends'' then' + sLineBreak +
  '            Qry.ParamByName(''search1'').AsString := ''%'' + Trim(ASearch)' + sLineBreak +
  '          else' + sLineBreak +
  '            Qry.ParamByName(''search1'').AsString := Trim(ASearch);' + sLineBreak +
  '        end' + sLineBreak +
  '        // NUMÉRICO' + sLineBreak +
  '        else if (Idx >= 0) and IsNumericField(FMeta[Idx]) then' + sLineBreak +
  '          Qry.ParamByName(''search1'').AsFloat := FloatValue(Trim(''0'' + ASearch))' + sLineBreak +
  '        // DATA' + sLineBreak +
  '        else if (Idx >= 0) and IsDateField(FMeta[Idx]) then' + sLineBreak +
  '          Qry.ParamByName(''search1'').AsDateTime := ISO8601ToDate(Trim(ASearch))' + sLineBreak +
  '        // Pesquisa global textual' + sLineBreak +
  '        else' + sLineBreak +
  '          Qry.ParamByName(''search1'').AsString := ''%'' + Trim(ASearch) + ''%'';' + sLineBreak +
  '      end;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    // Limit e Offset' + sLineBreak +
  '    Qry.ParamByName(''limit'').AsInteger  := APageSize;' + sLineBreak +
  '    Qry.ParamByName(''offset'').AsInteger := Offset;' + sLineBreak +
  '' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    // Execução' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    Qry.Open;' + sLineBreak +
  '' + sLineBreak +
  '    while not Qry.EOF do' + sLineBreak +
  '    begin' + sLineBreak +
  '      lTotalPages := Qry.FieldByName(''total_page'').AsInteger;' + sLineBreak +
  '      lTotalRecords := Qry.FieldByName(''total_rec'').AsInteger;' + sLineBreak +
  '' + sLineBreak +
  '      JSONItem := TJSONObject.Create;' + sLineBreak +
  '' + sLineBreak +
  '      for I := 0 to High(FMeta) do' + sLineBreak +
  '      begin' + sLineBreak +
  '        if not FMeta[I].ToList then' + sLineBreak +
  '          Continue;' + sLineBreak +
  '' + sLineBreak +
  '        lFieldName := FMeta[I].Name;' + sLineBreak +
  '        lSpecialField := '''';' + sLineBreak +
  '' + sLineBreak +
  '        if FMeta[I].RemoveMask then' + sLineBreak +
  '          lSpecialField := Trim(FMeta[I].SpecialField);' + sLineBreak +
  '' + sLineBreak +
  '        if FMeta[I].NameAlias <> '''' then' + sLineBreak +
  '          lAliasName := FMeta[I].NameAlias' + sLineBreak +
  '        else' + sLineBreak +
  '          lAliasName := lFieldName;' + sLineBreak +
  '' + sLineBreak +
  '        // campo da tabela principal' + sLineBreak +
  '        AddFieldToJSON(' + sLineBreak +
  '          JSONItem,' + sLineBreak +
  '          lAliasName,' + sLineBreak +
  '          lSpecialField,' + sLineBreak +
  '          Qry.FieldByName(lFieldName)' + sLineBreak +
  '        );' + sLineBreak +
  '' + sLineBreak +
  '        if FMeta[I].IsForeignKey and (FMeta[I].FKTableName <> '''') then begin' + sLineBreak +
  '          // campo da tabela estrangeira' + sLineBreak +
  '          lFieldName := lAliasName + ''_value'';' + sLineBreak +
  '          AddFieldToJSON(' + sLineBreak +
  '            JSONItem,' + sLineBreak +
  '            lFieldName,' + sLineBreak +
  '            '''',' + sLineBreak +
  '            Qry.FieldByName(lFieldName)' + sLineBreak +
  '          );' + sLineBreak +
  '        end;' + sLineBreak +
  '' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '      lArr.Add(JSONItem);' + sLineBreak +
  '      Qry.Next;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    // JSON final' + sLineBreak +
  '    // -------------------------------------------------------------------------' + sLineBreak +
  '    lJson.Add(''page'', APageNumber);' + sLineBreak +
  '    lJson.Add(''per_page'', APageSize);' + sLineBreak +
  '    lJson.Add(''total_pages'', lTotalPages);' + sLineBreak +
  '    lJson.Add(''total_records'', lTotalRecords);' + sLineBreak +
  '    lJson.Add(''data'', lArr);' + sLineBreak +
  '' + sLineBreak +
  '    Result := lJson.AsJSON;' + sLineBreak +
  '' + sLineBreak +
  '    Qry.Close;' + sLineBreak +
  '  finally' + sLineBreak +
  '    Qry.Free;' + sLineBreak +
  '    SelectFields.Free;' + sLineBreak +
  '    SearchFields.Free;' + sLineBreak +
  '    OrderFields.Free;' + sLineBreak +
  '    InvalidFields.Free;' + sLineBreak +
  '    lJson.Free; // lArr é destruído automaticamente pelo lJson' + sLineBreak +
  '  end;' + sLineBreak +
  'end; ' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.datacontrol.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GearCore_HttpContext;
// Controlador de Request e Response
var
  s: string;
begin
  s :=
  'unit Core.HttpContext;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Controlador de Request e Response' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, httpdefs, base64, fpjson, jsonparser,' + sLineBreak +
  '  Core.StatusCode, Core.JWT, Model.UserInfo;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { THttpContext }' + sLineBreak +
  '' + sLineBreak +
  '  THttpContext = class' + sLineBreak +
  '  private' + sLineBreak +
  '    FJson: TJSONObject;' + sLineBreak +
  '    FBasicPassword: string;' + sLineBreak +
  '    FBasicUsername: string;' + sLineBreak +
  '    FIsValidJson: Boolean;' + sLineBreak +
  '    FJsonError: string;' + sLineBreak +
  '    FReq: TRequest;' + sLineBreak +
  '    FRes: TResponse;' + sLineBreak +
  '    FResponseCode: Integer;' + sLineBreak +
  '    FLoginToken: string;' + sLineBreak +
  '' + sLineBreak +
  '    function ResponseCode(): Integer;' + sLineBreak +
  '    procedure GetBasicAuthentication;' + sLineBreak +
  '  public' + sLineBreak +
  '    constructor Create(AReq:TRequest; ARes:TResponse);' + sLineBreak +
  '    destructor Destroy; override;' + sLineBreak +
  '' + sLineBreak +
  '    property Request:TRequest read FReq;' + sLineBreak +
  '    property Response:TResponse read FRes;' + sLineBreak +
  '' + sLineBreak +
  '    { Conteúdo do Body enviado pelo cliente }' + sLineBreak +
  '    function Body:string;' + sLineBreak +
  '    { Transforma o conteúdo do Body em JSON Object }' + sLineBreak +
  '    function JSON:TJSONObject;' + sLineBreak +
  '    { Conteúdo do do header conforme nome da variável }' + sLineBreak +
  '    function Header(const AName:String):String;' + sLineBreak +
  '    { Valor string do parâmetro (path ou querystring) da variável informada }' + sLineBreak +
  '    function Query(AName:string):string;' + sLineBreak +
  '    { Valor integer do parâmetro da variável informada }' + sLineBreak +
  '    function QueryInt(const AName:String; ADefault:Integer=0):Integer;' + sLineBreak +
  '    { Valor boolean do parâmetro da variável informada }' + sLineBreak +
  '    function QueryBool(const AName:String; ADefault:Boolean=False):Boolean;' + sLineBreak +
  '    { Valor float do parâmetro da variável informada }' + sLineBreak +
  '    function QueryFloat(const AName:String; ADefault:Double=0.0):Double;' + sLineBreak +
  '    { Valor datetime do parâmetro da variável informada }' + sLineBreak +
  '    function QueryDate(const AName:String):TDateTime;' + sLineBreak +
  '    { Valor string do parâmetro da variável informada }' + sLineBreak +
  '    function QueryRequired(const AName:String):String;' + sLineBreak +
  '    { Código de retorno do statusCode }' + sLineBreak +
  '    function Code(ACode: Integer):THttpContext;' + sLineBreak +
  '    { Retorna conteúdo texto }' + sLineBreak +
  '    function SendTEXT(AText:string): THttpContext;' + sLineBreak +
  '    { Retorna conteúdo html }' + sLineBreak +
  '    function SendHTML(AHtml:string): THttpContext;' + sLineBreak +
  '    { Retorna conteúdo json }' + sLineBreak +
  '    function SendJSON(AStrJSON:string): THttpContext;' + sLineBreak +
  '    { Retorna conteúdo json através da função AddPair }' + sLineBreak +
  '    function Send: THttpContext;' + sLineBreak +
  '    { envia um arquivo stream }' + sLineBreak +
  '    function SendStream(AStream:TStream): THttpContext;' + sLineBreak +
  '    { envia um arquivo PDF } ' + sLineBreak +
  '    function SendPDF(AStream: TStream; APDFName: string): THttpContext;' + sLineBreak +
  '    { Endereço IP do cliente }' + sLineBreak +
  '    function IPClient: string;' + sLineBreak +
  '    { obtém o token recebido no header authorization }' + sLineBreak +
  '    function ReadToken: string;' + sLineBreak +
  '    { Obtém dados do usuário contidos no token }' + sLineBreak +
  '    function UserInformation: TModelUserInfo;' + sLineBreak +
  '    { Adiciona dados json, depois use SendJSON }' + sLineBreak +
  '    function AddSuccess(const AValue: Boolean): THttpContext;' + sLineBreak +
  '    function AddMessage(AMessage: String): THttpContext;' + sLineBreak +
  '    function AddStatus(ASuccess: Boolean; AMessage: string): THttpContext; ' + sLineBreak +
  '    function AddPair(const AKey, AValue: String): THttpContext; overload;' + sLineBreak +
  '    function AddPair(const AKey: String; AValue: Boolean): THttpContext; overload;' + sLineBreak +
  '    function AddPair(const AKey: String; AValue: Integer): THttpContext; overload;' + sLineBreak +
  '    function AddPair(const AKey: String; AValue: Double): THttpContext; overload;' + sLineBreak +
  '    function AddPairDate(const AKey: String; AValue: TDateTime): THttpContext;' + sLineBreak +
  '    function AddPairDateTime(const AKey: String; AValue: TDateTime): THttpContext;' + sLineBreak +
  '    function AddPairTime(const AKey: String; AValue: TDateTime): THttpContext;' + sLineBreak +
  '    function AddPairCurrency(const AKey: String; AValue: Double; const ACurrencySymbol: String): THttpContext;' + sLineBreak +
  '    function AddPairFloatFormatted(const AKey: String; AValue: Double; const ADecimals: Integer = 2): THttpContext;' + sLineBreak +
  '    function AddPairNull(const AKey: String): THttpContext;' + sLineBreak +
  '    function AddPairArray(const AKey: String; AJsonArray: TJSONArray): THttpContext;' + sLineBreak +
  '    procedure SetAuthentication(AToken, ALogin: string);' + sLineBreak +
  '    property BasicUsername: string read FBasicUsername;' + sLineBreak +
  '    property BasicPassword: string read FBasicPassword;' + sLineBreak +
  '    property IsValidJson: Boolean read FIsValidJson;' + sLineBreak +
  '    property JsonError: string read FJsonError;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'var' + sLineBreak +
  '  StatusCode :TResponseCode;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'constructor THttpContext.Create(AReq:TRequest; ARes:TResponse);' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson:= TJSONObject.Create;' + sLineBreak +
  '  FReq := AReq;' + sLineBreak +
  '  FRes := ARes;' + sLineBreak +
  '  FIsValidJson := False;' + sLineBreak +
  '  FJsonError := '''';' + sLineBreak +
  '  FLoginToken := '''';' + sLineBreak +
  '  GetBasicAuthentication;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'destructor THttpContext.Destroy;' + sLineBreak +
  'begin' + sLineBreak +
  '  if Assigned(FJson) then FJson.Free;' + sLineBreak +
  '  inherited Destroy;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.ResponseCode(): Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  if FResponseCode < 100 then' + sLineBreak +
  '     Result := 200' + sLineBreak +
  '  else' + sLineBreak +
  '     Result := FResponseCode;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure THttpContext.GetBasicAuthentication;' + sLineBreak +
  '// extrai username e password enviados via Basic authentication' + sLineBreak +
  'var' + sLineBreak +
  '  S : String;' + sLineBreak +
  '  P : Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  FBasicUsername := '''';' + sLineBreak +
  '  FBasicPassword := '''';' + sLineBreak +
  '' + sLineBreak +
  '  if Pos(''Basic '', FReq.Authorization) <> 1 then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  S := Copy(FReq.Authorization, 7, Length(FReq.Authorization));' + sLineBreak +
  '' + sLineBreak +
  '  S := DecodeStringBase64(S);' + sLineBreak +
  '' + sLineBreak +
  '  P := Pos('':'', S);' + sLineBreak +
  '' + sLineBreak +
  '  if P > 0 then begin' + sLineBreak +
  '    FBasicUsername := Copy(S, 1, P-1);' + sLineBreak +
  '    FBasicPassword := Copy(S, P+1, Length(S));' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.Body:string;' + sLineBreak +
  '// conteúdo enviado no body' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := Trim(FReq.Content);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.JSON: TJSONObject;' + sLineBreak +
  '// transforma o conteúdo do body em json' + sLineBreak +
  'var' + sLineBreak +
  '  lData: TJSONData;' + sLineBreak +
  '  s: String;' + sLineBreak +
  'begin' + sLineBreak +
  '  //Result := GetJSON(FReq.Content) as TJSONObject;' + sLineBreak +
  '  FIsValidJson := False;' + sLineBreak +
  '  FJsonError := '''';' + sLineBreak +
  '  Result := nil;' + sLineBreak +
  '  s := Trim(FReq.Content);' + sLineBreak +
  '' + sLineBreak +
  '  if s = '''' then begin' + sLineBreak +
  '    FJsonError := ''{"error":"JSON: Empty body"}'';' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    lData := GetJSON(s);' + sLineBreak +
  '' + sLineBreak +
  '    if not (lData is TJSONObject) then begin' + sLineBreak +
  '      FJsonError := ''{"error":"JSON is not an object"}'';' + sLineBreak +
  '      Exit;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    Result := TJSONObject(lData);' + sLineBreak +
  '    FIsValidJson := (Result.Count > 0);' + sLineBreak +
  '' + sLineBreak +
  '    if not FIsValidJson then' + sLineBreak +
  '      FJsonError := ''{"error":"JSON with no data"}'';' + sLineBreak +
  '  except' + sLineBreak +
  '    on E: Exception do begin' + sLineBreak +
  '      FReq.Content := '''';' + sLineBreak +
  '      FJsonError := Format(''{"error":"JSON: %s"}'', [StringReplace(E.Message, ''"'', ''\"'', [rfReplaceAll])]);' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.Header(const AName: String): String;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := FReq.CustomHeaders.Values[AName];' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.Query(AName:string):string;' + sLineBreak +
  '// parâmetro enviado na rota: http://localhost:8080/product/:id' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := Trim(FReq.QueryFields.Values[AName]);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.QueryInt(const AName: String; ADefault: Integer): Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := StrToIntDef(FReq.QueryFields.Values[AName], ADefault);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.QueryBool(const AName: String; ADefault: Boolean): Boolean;' + sLineBreak +
  'var' + sLineBreak +
  '  V : String;' + sLineBreak +
  'begin' + sLineBreak +
  '  V := LowerCase(FReq.QueryFields.Values[AName]);' + sLineBreak +
  '' + sLineBreak +
  '  if V=''true'' then Exit(True);' + sLineBreak +
  '  if V=''1'' then Exit(True);' + sLineBreak +
  '  if V=''yes'' then Exit(True);' + sLineBreak +
  '' + sLineBreak +
  '  if V=''false'' then Exit(False);' + sLineBreak +
  '  if V=''0'' then Exit(False);' + sLineBreak +
  '  if V=''no'' then Exit(False);' + sLineBreak +
  '' + sLineBreak +
  '  Result := ADefault;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.QueryFloat(const AName: String; ADefault: Double): Double;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := StrToFloatDef(FReq.QueryFields.Values[AName], ADefault);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.QueryDate(const AName: String): TDateTime;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := StrToDateDef(FReq.QueryFields.Values[AName],0);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.QueryRequired(const AName: String): String;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := Trim(FReq.QueryFields.Values[AName]);' + sLineBreak +
  '' + sLineBreak +
  '  if Result='''' then' + sLineBreak +
  '    raise Exception.Create(''missing query param: '' + AName);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.Code(ACode: Integer): THttpContext;' + sLineBreak +
  '// código de resposta' + sLineBreak +
  'begin' + sLineBreak +
  '  if ACode < 100 then ACode := 200;' + sLineBreak +
  '  FResponseCode := Acode;' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.SendTEXT(AText: string): THttpContext;' + sLineBreak +
  '// response conteúdo texto' + sLineBreak +
  'begin' + sLineBreak +
  '  FRes.ContentType := ''text/plain'';' + sLineBreak +
  '  FRes.Code := ResponseCode;' + sLineBreak +
  '  FRes.Content := AText;' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.SendHTML(AHtml: string): THttpContext;' + sLineBreak +
  '// response conteúdo html' + sLineBreak +
  'begin' + sLineBreak +
  '  FRes.ContentType := ''text/html; charset=utf-8'';' + sLineBreak +
  '  FRes.Code := ResponseCode;' + sLineBreak +
  '  FRes.Content := AHtml;' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.SendJSON(AStrJSON: string): THttpContext;' + sLineBreak +
  '// response conteúdo json' + sLineBreak +
  'begin' + sLineBreak +
  '  FRes.ContentType := ''application/json'';' + sLineBreak +
  '  FRes.Code := ResponseCode;' + sLineBreak +
  '  FRes.Content := AStrJSON;' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.Send: THttpContext;' + sLineBreak +
  '// response conteúdo json' + sLineBreak +
  'begin' + sLineBreak +
  '  FRes.ContentType := ''application/json'';' + sLineBreak +
  '  FRes.Code := ResponseCode;' + sLineBreak +
  '' + sLineBreak +
  '  if Assigned(FJson) and (FJson.Count > 0) then' + sLineBreak +
  '    FRes.Content := FJson.AsJSON' + sLineBreak +
  '  else begin' + sLineBreak +
  '    FRes.Code := 400;' + sLineBreak +
  '    FRes.Content := ''{"error":"No content"}'';' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.SendStream(AStream: TStream): THttpContext;' + sLineBreak +
  '// envia um arquivo em formato stream' + sLineBreak +
  'begin' + sLineBreak +
  '  FRes.ContentLength := AStream.Size;' + sLineBreak +
  '  FRes.ContentStream := AStream;' + sLineBreak +
  '  FRes.SendContent;' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.SendPDF(AStream: TStream; APDFName: string): THttpContext;' + sLineBreak +
  '// envia um arquivo PDF' + sLineBreak +
  'begin' + sLineBreak +
  '  AStream.Position := 0;' + sLineBreak +
  '' + sLineBreak +
  '  FRes.FreeContentStream := True;' + sLineBreak +
  '  FRes.ContentType := ''application/pdf'';' + sLineBreak +
  '  FRes.ContentLength := AStream.Size;' + sLineBreak +
  '  FRes.ContentStream := AStream;' + sLineBreak +
  '' + sLineBreak +
  '  FRes.SetCustomHeader(' + sLineBreak +
  '    ''Content-Disposition'',' + sLineBreak +
  '    Format(''inline; filename="%s"'', [APDFName])' + sLineBreak +
  '  );' + sLineBreak +
  '' + sLineBreak +
  '  FRes.SendContent;' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;           ' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.IPClient: string;' + sLineBreak +
  '// retorna o IP do cliente' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := FReq.RemoteAddress;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.ReadToken: string;' + sLineBreak +
  '// retorna o token enviado no header authorization' + sLineBreak +
  '// FReq.CustomHeaders.Values[''Authorization''];' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := FReq.Authorization;' + sLineBreak +
  '' + sLineBreak +
  '  if Pos(''Bearer '', Result) = 1 then' + sLineBreak +
  '    Result := Trim( Copy(Result, 8, Length(Result)) )' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := FLoginToken;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.UserInformation: TModelUserInfo;' + sLineBreak +
  '// retorna dados do usuário contidos no token, se não expirou' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TCoreJWT.ValidateToken( ReadToken );' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddSuccess(const AValue: Boolean): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(''success'', TJSONBoolean.Create(AValue));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddMessage(AMessage: String): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(''message'', TJSONString.Create(AMessage));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddStatus(ASuccess: Boolean; AMessage: string): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(''status'', TJSONBoolean.Create(ASuccess));' + sLineBreak +
  '  FJson.Add(''message'', TJSONString.Create(AMessage));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;  ' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPair(const AKey, AValue: String): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, TJSONString.Create(AValue));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPair(const AKey: String; AValue: Boolean): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, TJSONBoolean.Create(AValue));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPair(const AKey: String; AValue: Integer): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, TJSONIntegerNumber.Create(AValue));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPair(const AKey: String; AValue: Double): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, TJSONFloatNumber.Create(AValue));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPairDate(const AKey: String; AValue: TDateTime): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, TJSONString.Create(FormatDateTime(''yyyy-mm-dd'', AValue)));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPairDateTime(const AKey: String; AValue: TDateTime): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, TJSONString.Create(FormatDateTime(''yyyy-mm-dd"T"hh:nn:ss'', AValue)));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPairTime(const AKey: String; AValue: TDateTime): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, TJSONString.Create(FormatDateTime(''hh:nn:ss'', AValue)));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPairCurrency(const AKey: String; AValue: Double; const ACurrencySymbol: String): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, TJSONString.Create(ACurrencySymbol + '' '' + FormatFloat(''#,##0.00'', AValue)));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPairFloatFormatted(const AKey: String; AValue: Double; const ADecimals: Integer): THttpContext;' + sLineBreak +
  '//formata double as string com casas decimais indicadas' + sLineBreak +
  'var' + sLineBreak +
  '  lDecimals: Integer;' + sLineBreak +
  '  sValor: String;' + sLineBreak +
  'begin' + sLineBreak +
  '  // sValor := FormatFloat(''#0.####'', AValue).Replace('','', ''.'');' + sLineBreak +
  '  lDecimals := ADecimals;' + sLineBreak +
  '  if lDecimals < 0 then lDecimals := 0;' + sLineBreak +
  '  sValor := Format(''%0.'' + IntToStr(lDecimals) +''f'', [AValue]).Replace('','', ''.'');' + sLineBreak +
  '  FJson.Add(AKey, TJSONString.Create(sValor));' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPairNull(const AKey: String): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, TJSONNull.Create);' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THttpContext.AddPairArray(const AKey: String; AJsonArray: TJSONArray): THttpContext;' + sLineBreak +
  'begin' + sLineBreak +
  '  FJson.Add(AKey, AJsonArray);' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure THttpContext.SetAuthentication(AToken, ALogin: string);' + sLineBreak +
  'begin' + sLineBreak +
  '  FLoginToken := AToken;' + sLineBreak +
  '  FBasicUsername := ALogin;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.httpcontext.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_JsonFloat;
var
  s: string;
begin
  s :=
  'unit Core.JsonFloat;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Evita exibir valores float com notação científica' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, fpjson, jsonparser;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  ' { TJSONFloatToNumber }' + sLineBreak +
  '' + sLineBreak +
  ' TJSONFloatToNumber = class(TJSONFloatNumber)' + sLineBreak +
  ' protected' + sLineBreak +
  '   function GetAsString: TJSONStringType; override;' + sLineBreak +
  ' end;' + sLineBreak +
  '' + sLineBreak +
  ' procedure JsonFloatNumber;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'procedure JsonFloatNumber;' + sLineBreak +
  'begin' + sLineBreak +
  '  SetJSONInstanceType(jitNumberFloat, TJSONFloatToNumber);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ TJSONFloatToNumber }' + sLineBreak +
  '' + sLineBreak +
  'function TJSONFloatToNumber.GetAsString: TJSONStringType;' + sLineBreak +
  '// como usar:  SetJSONInstanceType(jitNumberFloat, TJSONFloat4Number);' + sLineBreak +
  'var' + sLineBreak +
  '  F: TJSONFloat;' + sLineBreak +
  '  fs: TFormatSettings;' + sLineBreak +
  'begin' + sLineBreak +
  '  //Result := inherited GetAsString;' + sLineBreak +
  '  F := GetAsFloat;' + sLineBreak +
  '  fs := DefaultFormatSettings;' + sLineBreak +
  '  fs.DecimalSeparator := ''.'';' + sLineBreak +
  '' + sLineBreak +
  '  //Result := FormatFloat(''0.00###############'', F, fs); // format with your preferences' + sLineBreak +
  '  Result := FormatFloat(''0.00##########'', F, fs); // format with your preferences' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.jsonfloat.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_JWT;
// Validação do Token JWT
var
  s: string;
begin
  s :=
  'unit Core.JWT;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Controle de geração e validação de Token JWT' + sLineBreak +
  '' + sLineBreak +
  '{$mode objfpc}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, DateUtils, fpjson, jsonparser, base64, sha1,' + sLineBreak +
  '  HTTPDefs, httproute, {fpjwt,}' + sLineBreak +
  '  Model.UserInfo;' + sLineBreak +
  '' + sLineBreak +
  'const' + sLineBreak +
  '  SECRET = ''BhZGJmYzhiYWM4OWYzZg'';' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '  TCoreJWTResponse = (jrsValid, jrsInvalid, jrsExpired);' + sLineBreak +
  '' + sLineBreak +
  '  { TCoreJWT }' + sLineBreak +
  '' + sLineBreak +
  '  TCoreJWT = class' + sLineBreak +
  '  private' + sLineBreak +
  '    class function DecryptString(const s: string): string;' + sLineBreak +
  '    class function EncodeBase64URL(S:String):String;' + sLineBreak +
  '    class function EncryptString(const s: string): string;' + sLineBreak +
  '    class function GetPayload(AToken: String): String;' + sLineBreak +
  '    class function Sign(AData: String): String;' + sLineBreak +
  '  public' + sLineBreak +
  '    { Gera o Token JWT }' + sLineBreak +
  '    class function GetToken(AUserInfo: TModelUserInfo): String;' + sLineBreak +
  '    { Verifica se o Token JWT recebido é válido }' + sLineBreak +
  '    class function ValidateToken(AToken: String): TModelUserInfo;' + sLineBreak +
  '    { Obtém dados do usuário contidos no Token JWT }' + sLineBreak +
  '    class function GetUserInfo(AToken: string): TModelUserInfo;' + sLineBreak +
  '    { Obtém o Token JWT enviado no header authorization }' + sLineBreak +
  '    class function ExtractToken(req: TRequest): string;' + sLineBreak +
  '    { Verifica se o Token JWT é válido, inválido ou expirou }' + sLineBreak +
  '    class function VerifyToken(req: TRequest): TCoreJWTResponse;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'var' + sLineBreak +
  '  JWT_EncodedToken: Boolean = True;' + sLineBreak +
  '  JWT_HoursToExpire: Int64 = 8;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  '{ TCoreJWT }' + sLineBreak +
  '' + sLineBreak +
  'class function TCoreJWT.EncodeBase64URL(S: String): String;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := EncodeStringBase64(S);' + sLineBreak +
  '  Result := StringReplace(Result,''+'',''-'',[rfReplaceAll]);' + sLineBreak +
  '  Result := StringReplace(Result,''/'',''_'',[rfReplaceAll]);' + sLineBreak +
  '  Result := StringReplace(Result,''='','''',[rfReplaceAll]);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TCoreJWT.Sign(AData: String): String;' + sLineBreak +
  'var' + sLineBreak +
  '  Digest: TSHA1Digest;' + sLineBreak +
  'begin' + sLineBreak +
  '  if not JWT_EncodedToken then AData := AData + SECRET;' + sLineBreak +
  '  Digest := SHA1String(AData);' + sLineBreak +
  '  Result := SHA1Print(Digest);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TCoreJWT.GetPayload(AToken: String): String;' + sLineBreak +
  '// Obtém a Payload contido no Token' + sLineBreak +
  'var' + sLineBreak +
  '  Parts: TStringArray;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '  Parts := AToken.Split(''.'');' + sLineBreak +
  '' + sLineBreak +
  '  if Length(Parts) <> 3 then exit;' + sLineBreak +
  '' + sLineBreak +
  '  if not JWT_EncodedToken then begin' + sLineBreak +
  '    // JWT padrão' + sLineBreak +
  '    if EncodeBase64URL(Sign(Parts[0] + ''.'' + Parts[1])) <> Parts[2] then exit;' + sLineBreak +
  '    Result := DecodeStringBase64( Parts[1] );' + sLineBreak +
  '  end else begin' + sLineBreak +
  '    // JWT com payload codificado, não pode ser decifrado pelo site jwt.io' + sLineBreak +
  '    if Sign(SECRET) <> Parts[2] then exit;' + sLineBreak +
  '    Result := DecryptString( DecodeStringBase64( Parts[1] ) );' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TCoreJWT.GetToken(AUserInfo: TModelUserInfo): String;' + sLineBreak +
  '// gera o token JWT' + sLineBreak +
  'var' + sLineBreak +
  '  Header, Payload, Signature: String;' + sLineBreak +
  'begin' + sLineBreak +
  '  Header := EncodeBase64URL(Format(''{"alg":"HS256","typ":"JWT","exp":%d}'', [DateTimeToUnix( IncHour(Now, JWT_HoursToExpire) )]));' + sLineBreak +
  '' + sLineBreak +
  '  Payload := TJSONObject.Create([' + sLineBreak +
  '       ''id'', AUserInfo.Id,' + sLineBreak +
  '       ''name'', AUserInfo.Name,' + sLineBreak +
  '       ''login'', AUserInfo.Login,' + sLineBreak +
  '       ''iss'', ''Meu Inss'',' + sLineBreak +
  '       ''iat'', DateTimeToUnix(Now),' + sLineBreak +
  '       ''exp'', DateTimeToUnix(IncHour(Now, JWT_HoursToExpire))' + sLineBreak +
  '     ]).AsJSON;' + sLineBreak +
  '' + sLineBreak +
  '  if not JWT_EncodedToken then begin' + sLineBreak +
  '    // este token pode ser verificado no site jwt.io' + sLineBreak +
  '    Signature := EncodeBase64URL(Sign(Header + ''.'' + EncodeBase64URL(Payload)));' + sLineBreak +
  '    Result := Header + ''.'' + EncodeBase64URL(Payload) + ''.'' + Signature;' + sLineBreak +
  '  end else begin' + sLineBreak +
  '    // este token só funciona neste servidor e não pode ser verificado no site jwt.io' + sLineBreak +
  '    Result := Header + ''.'' + EncodeBase64URL(EncryptString(Payload)) + ''.'' + Sign(SECRET);' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TCoreJWT.ValidateToken(AToken: String): TModelUserInfo;' + sLineBreak +
  '// valida o token informado pelo usuário' + sLineBreak +
  'var' + sLineBreak +
  '  Payload: String;' + sLineBreak +
  '  jObj: TJSONObject;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TModelUserInfo.Create();' + sLineBreak +
  '  if Trim(AToken) = '''' then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  Payload := GetPayload(AToken);' + sLineBreak +
  '  if Payload = '''' then exit;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    jObj := TJSONObject( GetJSON(Payload) );' + sLineBreak +
  '' + sLineBreak +
  '    if (jObj <> nil) and (jObj.FindPath(''exp'').AsInt64 - DateTimeToUnix(Now) > 0) then begin' + sLineBreak +
  '      // dentro do prazo de validade' + sLineBreak +
  '      Result.Id := jObj.FindPath(''id'').AsInteger;' + sLineBreak +
  '      Result.Name := jObj.FindPath(''name'').AsString;' + sLineBreak +
  '      Result.Login := jObj.FindPath(''login'').AsString;' + sLineBreak +
  '      Result.exp := jObj.FindPath(''exp'').AsInt64;' + sLineBreak +
  '    end;' + sLineBreak +
  '  finally' + sLineBreak +
  '    jObj.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TCoreJWT.GetUserInfo(AToken: string): TModelUserInfo;' + sLineBreak +
  '// retorna os dados do usuário contidos no Token' + sLineBreak +
  'var' + sLineBreak +
  '  Payload: String;' + sLineBreak +
  '  jObj: TJSONObject;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TModelUserInfo.Create();' + sLineBreak +
  '  Payload := GetPayload(AToken);' + sLineBreak +
  '  if Payload = '''' then exit;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    jObj := TJSONObject( GetJSON(Payload) );' + sLineBreak +
  '' + sLineBreak +
  '    if (jObj <> nil) then begin' + sLineBreak +
  '      // dentro do prazo de validade' + sLineBreak +
  '      Result.Id := jObj.FindPath(''id'').AsInteger;' + sLineBreak +
  '      Result.Name := jObj.FindPath(''name'').AsString;' + sLineBreak +
  '      Result.Login := jObj.FindPath(''login'').AsString;' + sLineBreak +
  '      Result.exp := jObj.FindPath(''exp'').AsInt64;' + sLineBreak +
  '    end;' + sLineBreak +
  '  finally' + sLineBreak +
  '    jObj.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TCoreJWT.ExtractToken(req: TRequest): string;' + sLineBreak +
  '// obtém o token enviado pelo request' + sLineBreak +
  'var' + sLineBreak +
  '  Token: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Token := req.Authorization;' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '' + sLineBreak +
  '  if Pos(''Bearer '', Token) = 1 then' + sLineBreak +
  '    Result := Trim( Copy(Token, 8, Length(Token)) );' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TCoreJWT.VerifyToken(req: TRequest): TCoreJWTResponse;' + sLineBreak +
  '// retorna se o token é válido, inválido ou se expirou' + sLineBreak +
  'var' + sLineBreak +
  '  Payload: String;' + sLineBreak +
  '  jObj: TJSONObject;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := jrsInvalid;' + sLineBreak +
  '  Payload := GetPayload( ExtractToken(req) );' + sLineBreak +
  '  if Payload = '''' then exit;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    jObj := TJSONObject( GetJSON(Payload) );' + sLineBreak +
  '' + sLineBreak +
  '    if (jObj <> nil) then begin' + sLineBreak +
  '      if (jObj.FindPath(''exp'').AsInt64 - DateTimeToUnix(Now) > 0) then' + sLineBreak +
  '        Result := jrsValid' + sLineBreak +
  '      else' + sLineBreak +
  '        Result := jrsExpired;' + sLineBreak +
  '    end;' + sLineBreak +
  '  finally' + sLineBreak +
  '    jObj.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '// simple xor encrypt' + sLineBreak +
  'class function TCoreJWT.EncryptString(const s:string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  i: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  result := '''';' + sLineBreak +
  '  for i:=1 to Length(s) do' + sLineBreak +
  '    result := result + chr(ord(s[i]) xor 21);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TCoreJWT.DecryptString(const s:string): string;' + sLineBreak +
  'begin' + sLineBreak +
  '  result := EncryptString(s);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.jwt.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_JWTMiddleware;
var
  s: string;
begin
  s :=
  'unit Core.JwtMiddleware;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Middleware do JWT' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.HttpContext;' + sLineBreak +
  '' + sLineBreak +
  'procedure JWTMiddleware(Ctx:THttpContext; var Next:boolean);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  SysUtils, Core.JWT;' + sLineBreak +
  '' + sLineBreak +
  'procedure JWTMiddleware(Ctx:THttpContext; var Next:boolean);' + sLineBreak +
  'var' + sLineBreak +
  '  ret: TCoreJWTResponse;' + sLineBreak +
  'begin' + sLineBreak +
  '  ret := TCoreJWT.VerifyToken(ctx.Request);' + sLineBreak +
  '' + sLineBreak +
  '  if ret = TCoreJWTResponse.jrsInvalid then begin' + sLineBreak +
  '    Ctx.Response.Code := 401;' + sLineBreak +
  '    Ctx.Response.Content := ''Token requerido'';' + sLineBreak +
  '    Next := False;' + sLineBreak +
  '    exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  if ret = TCoreJWTResponse.jrsExpired then begin' + sLineBreak +
  '    Ctx.Response.Code := 401;' + sLineBreak +
  '    Ctx.Response.Content := ''Token expired'';' + sLineBreak +
  '    Next := False;' + sLineBreak +
  '    exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Next := True;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.jwtmiddleware.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_Logger;
var
  s: string;
begin
  s :=
  'unit Core.Logger;' + sLineBreak +
  '' + sLineBreak +
  '// Gerador Logger' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  SysUtils, Core.HttpContext;' + sLineBreak +
  '' + sLineBreak +
  'procedure LoggerMiddleware(Ctx:THttpContext; var Next:boolean);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'procedure LoggerMiddleware(Ctx:THttpContext; var Next:boolean);' + sLineBreak +
  'begin' + sLineBreak +
  '  WriteLn(' + sLineBreak +
  '    Format(''[%s] %s %s'',' + sLineBreak +
  '      [FormatDateTime(''yyyy-mm-dd hh:nn:ss'',Now),' + sLineBreak +
  '       Ctx.Request.Method,' + sLineBreak +
  '       Ctx.Request.URI])' + sLineBreak +
  '  );' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.logger.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_Middleware;
// gerenciador de Middlewares
var
  s: string;
begin
  s :=
  'unit Core.Middleware;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Gerenciador de Middlewares' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.HttpContext;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '  TMiddleware = procedure(Ctx:THttpContext; var Next:boolean);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.middleware.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_RegisterRoutes;
// registra as rotas do usuário
var
  st: TServiceTabela;
  tabelas: TZQuery;
  s, lTabela: string;
begin
  st := TServiceTabela.Create( FIdProjeto );
  tabelas := st.QueryTabelas( FListaTabelasID.Trim, True ); //tabelas

  s :=
  'unit Core.RegisterRoutes;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Informe aqui as suas rotas' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.Router;' + sLineBreak +
  '' + sLineBreak +
  'procedure RegisterRoutes(Router:TRouter);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Route.Auth';

  if FCriarModuloBoleto then
    s := s + ',' + sLineBreak + '  Route.Financeiro';

  tabelas.First;
  while not tabelas.EOF do begin
    if tabelas.FieldByName('for_auth').AsInteger = 0 then begin
      lTabela := tabelas.FieldByName('nome_objeto').AsString;

      s := s +
      ', ' + sLineBreak +
      '  Route.' + lTabela + FVersaoAbreviadaRota;
    end;

    tabelas.Next;
  end;

  s := s +
  ';' + sLineBreak +
  ' ' + sLineBreak +
  'procedure RegisterRoutes(Router:TRouter);' + sLineBreak +
  'begin' + sLineBreak +
  '  RegisterRoutesAuth(Router);' + sLineBreak;

  tabelas.First;
  while not tabelas.EOF do begin
    if tabelas.FieldByName('for_auth').AsInteger = 0 then begin
      lTabela := tabelas.FieldByName('nome_objeto').AsString;

      s := s +
      '  RegisterRoutes' + lTabela + FVersaoAbreviadaRota + '(Router);' + sLineBreak;
    end;

    tabelas.Next;
  end;

  if FCriarModuloBoleto then
    s := s + sLineBreak + '  RegisterRoutesFinanceiro_v1(Router);' + sLineBreak;

  s := s +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.registerroutes.pas', s);
  s := '';

  tabelas.Close;
  tabelas.Free;
  st.Free
end;

procedure TProjetoLazarusAPI.GeraCore_Router;
// controlador de rotas
var
  s: string;
begin
  s :=
  'unit Core.Router;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Controlador das rotas' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, httpdefs, Core.HttpContext, Core.Middleware;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '  TRouteHandler = procedure(Ctx:THttpContext);' + sLineBreak +
  '' + sLineBreak +
  '  TRoute = record' + sLineBreak +
  '    Method : string;' + sLineBreak +
  '    Path   : string;' + sLineBreak +
  '    Handler: TRouteHandler;' + sLineBreak +
  '    AuthRequired : boolean;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  { TStaticRoute }' + sLineBreak +
  '' + sLineBreak +
  '  TStaticRoute = class' + sLineBreak +
  '  private' + sLineBreak +
  '    FFolder: String;' + sLineBreak +
  '    FURLPrefix: String;' + sLineBreak +
  '  public' + sLineBreak +
  '    property URLPrefix: String read FURLPrefix write FURLPrefix;' + sLineBreak +
  '    property Folder: String read FFolder write FFolder;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  TRouteGroup = class;' + sLineBreak +
  '' + sLineBreak +
  '  { TRouter }' + sLineBreak +
  '' + sLineBreak +
  '  TRouter = class  { rotas individuais }' + sLineBreak +
  '  private' + sLineBreak +
  '    FRoutes : array of TRoute;' + sLineBreak +
  '    FMiddlewares : array of TMiddleware;' + sLineBreak +
  '    function CleanURI(const URI:String):String;' + sLineBreak +
  '    function MatchRoute(RoutePath, URI: string; Params: TStrings): boolean;' + sLineBreak +
  '    function SplitParam(const S: string): TStringArray;' + sLineBreak +
  '  public' + sLineBreak +
  '    constructor Create;' + sLineBreak +
  '    destructor Destroy; override;' + sLineBreak +
  '    procedure Use(M:TMiddleware);' + sLineBreak +
  '    procedure Get(Path:string; Handler:TRouteHandler; Auth: boolean = false);' + sLineBreak +
  '    procedure Post(Path:string; Handler:TRouteHandler; Auth: boolean = false);' + sLineBreak +
  '    procedure Put(Path:string; Handler:TRouteHandler; Auth: boolean = false);' + sLineBreak +
  '    procedure Delete(Path:string; Handler:TRouteHandler; Auth: boolean = false);' + sLineBreak +
  '    procedure Patch(Path:string; Handler:TRouteHandler; Auth: boolean = false);' + sLineBreak +
  '    function Group(Prefix:string; Auth:boolean=false):TRouteGroup;' + sLineBreak +
  '    function Execute(Req:TRequest; Res:TResponse):boolean;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  { TRouteGroup }' + sLineBreak +
  '' + sLineBreak +
  '  TRouteGroup = class { rotas agrupadas }' + sLineBreak +
  '  private' + sLineBreak +
  '    FRouter : TRouter;' + sLineBreak +
  '    FPrefix : string;' + sLineBreak +
  '    FAuth   : boolean;' + sLineBreak +
  '  public' + sLineBreak +
  '    constructor Create(ARouter:TRouter; APrefix:string; AAuth:boolean);' + sLineBreak +
  '    function Get(Path:string; Handler:TRouteHandler):TRouteGroup;' + sLineBreak +
  '    function Post(Path:string; Handler:TRouteHandler):TRouteGroup;' + sLineBreak +
  '    function Put(Path:string; Handler:TRouteHandler):TRouteGroup;' + sLineBreak +
  '    function Delete(Path:string; Handler:TRouteHandler):TRouteGroup;' + sLineBreak +
  '    function Patch(Path:string; Handler:TRouteHandler):TRouteGroup;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.JWT, Core.Util;' + sLineBreak +
  '' + sLineBreak +
  '{ TRouter }' + sLineBreak +
  '' + sLineBreak +
  'constructor TRouter.Create;' + sLineBreak +
  'begin' + sLineBreak +
  '  SetLength(FRoutes,0);' + sLineBreak +
  '  SetLength(FMiddlewares,0);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'destructor TRouter.Destroy;' + sLineBreak +
  'begin' + sLineBreak +
  '  SetLength(FRoutes,0);' + sLineBreak +
  '  SetLength(FMiddlewares,0);' + sLineBreak +
  '  inherited Destroy;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TRouter.Use(M:TMiddleware);' + sLineBreak +
  'var' + sLineBreak +
  '  i:integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  i := Length(FMiddlewares);' + sLineBreak +
  '  SetLength(FMiddlewares,i+1);' + sLineBreak +
  '  FMiddlewares[i] := M;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TRouter.Get(Path: string; Handler: TRouteHandler; Auth: boolean);' + sLineBreak +
  'var' + sLineBreak +
  '  i:integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  i := Length(FRoutes);' + sLineBreak +
  '  SetLength(FRoutes,i+1);' + sLineBreak +
  '' + sLineBreak +
  '  FRoutes[i].Method := ''GET'';' + sLineBreak +
  '  FRoutes[i].Path := Path;' + sLineBreak +
  '  FRoutes[i].Handler := Handler;' + sLineBreak +
  '  FRoutes[i].AuthRequired := Auth;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TRouter.Post(Path: string; Handler: TRouteHandler; Auth: boolean);' + sLineBreak +
  'var' + sLineBreak +
  '  i:integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  i := Length(FRoutes);' + sLineBreak +
  '  SetLength(FRoutes,i+1);' + sLineBreak +
  '' + sLineBreak +
  '  FRoutes[i].Method := ''POST'';' + sLineBreak +
  '  FRoutes[i].Path := Path;' + sLineBreak +
  '  FRoutes[i].Handler := Handler;' + sLineBreak +
  '  FRoutes[i].AuthRequired := Auth;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TRouter.Put(Path: string; Handler: TRouteHandler; Auth: boolean);' + sLineBreak +
  'var' + sLineBreak +
  '  i:integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  i := Length(FRoutes);' + sLineBreak +
  '  SetLength(FRoutes,i+1);' + sLineBreak +
  '' + sLineBreak +
  '  FRoutes[i].Method := ''PUT'';' + sLineBreak +
  '  FRoutes[i].Path := Path;' + sLineBreak +
  '  FRoutes[i].Handler := Handler;' + sLineBreak +
  '  FRoutes[i].AuthRequired := Auth;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TRouter.Delete(Path: string; Handler: TRouteHandler; Auth: boolean);' + sLineBreak +
  'var' + sLineBreak +
  '  i:integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  i := Length(FRoutes);' + sLineBreak +
  '  SetLength(FRoutes,i+1);' + sLineBreak +
  '' + sLineBreak +
  '  FRoutes[i].Method := ''DELETE'';' + sLineBreak +
  '  FRoutes[i].Path := Path;' + sLineBreak +
  '  FRoutes[i].Handler := Handler;' + sLineBreak +
  '  FRoutes[i].AuthRequired := Auth;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure TRouter.Patch(Path: string; Handler: TRouteHandler; Auth: boolean);' + sLineBreak +
  'var' + sLineBreak +
  '  i:integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  i := Length(FRoutes);' + sLineBreak +
  '  SetLength(FRoutes,i+1);' + sLineBreak +
  '' + sLineBreak +
  '  FRoutes[i].Method := ''PATCH'';' + sLineBreak +
  '  FRoutes[i].Path := Path;' + sLineBreak +
  '  FRoutes[i].Handler := Handler;' + sLineBreak +
  '  FRoutes[i].AuthRequired := Auth;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouter.Group(Prefix: string; Auth: boolean): TRouteGroup;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TRouteGroup.Create(Self, Prefix, Auth);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouter.SplitParam(const S:string):TStringArray;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := S.Split(''/'', TStringSplitOptions.ExcludeEmpty);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouter.CleanURI(const URI: String): String;' + sLineBreak +
  '// separa dados vindos de QueryString (/products?page=1&limit=10)' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TUtil.CleanURI(URI);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouter.MatchRoute(RoutePath, URI: string; Params: TStrings): boolean;' + sLineBreak +
  '// checa se os prâmetros da rota interna batem com os parâmetros enviados pelo cliente' + sLineBreak +
  '// /product/:id  ou  /product/{id}  ou  /api/v1/user/1/vendas/50?page=1' + sLineBreak +
  'var' + sLineBreak +
  '  r, u: TStringArray;' + sLineBreak +
  '  i: integer;' + sLineBreak +
  '  param: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  r := SplitParam(RoutePath);' + sLineBreak +
  '  u := SplitParam(URI);' + sLineBreak +
  '' + sLineBreak +
  '  if Length(r) <> Length(u) then exit(False);' + sLineBreak +
  '' + sLineBreak +
  '  for i := 0 to High(r) do begin' + sLineBreak +
  '    if (Length(r[i]) < 2 ) then Continue;' + sLineBreak +
  '' + sLineBreak +
  '    // :param' + sLineBreak +
  '    if (r[i][1] = '':'') then begin' + sLineBreak +
  '      param := Trim( Copy(r[i], 2, Length(r[i])) );' + sLineBreak +
  '      if param <> '''' then begin' + sLineBreak +
  '        Params.Values[param] := u[i];' + sLineBreak +
  '        Continue;' + sLineBreak +
  '      end;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    // {param}' + sLineBreak +
  '    if (r[i][1] = ''{'') and (r[i][Length(r[i])] = ''}'') then begin' + sLineBreak +
  '      param := Trim( Copy(r[i], 2, Length(r[i]) - 2) );' + sLineBreak +
  '      if param <> '''' then begin' + sLineBreak +
  '        Params.Values[param] := u[i];' + sLineBreak +
  '        Continue;' + sLineBreak +
  '      end;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    // rota fixa' + sLineBreak +
  '    if r[i] <> u[i] then exit(False);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := True;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouter.Execute(Req:TRequest; Res:TResponse):boolean;' + sLineBreak +
  'var' + sLineBreak +
  '  ctx     : THttpContext;' + sLineBreak +
  '  params  : TStringList;' + sLineBreak +
  '  resp    : TCoreJWTResponse;' + sLineBreak +
  '  i       : integer;' + sLineBreak +
  '  Next    : boolean;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '' + sLineBreak +
  '  ctx := THttpContext.Create(Req, Res);' + sLineBreak +
  '' + sLineBreak +
  '  { executa middlewares }' + sLineBreak +
  '' + sLineBreak +
  '  for i := 0 to High(FMiddlewares) do begin' + sLineBreak +
  '    Next := True;' + sLineBreak +
  '    FMiddlewares[i](ctx, Next);' + sLineBreak +
  '' + sLineBreak +
  '    if not Next then begin' + sLineBreak +
  '      ctx.Free;' + sLineBreak +
  '      exit;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  params := TStringList.Create;' + sLineBreak +
  '' + sLineBreak +
  '  { procura rota }' + sLineBreak +
  '' + sLineBreak +
  '  for i := 0 to High(FRoutes) do begin' + sLineBreak +
  '    params.Clear;' + sLineBreak +
  '' + sLineBreak +
  '    if (UpperCase(FRoutes[i].Method) = UpperCase(Req.Method)) and' + sLineBreak +
  '       MatchRoute(FRoutes[i].Path, CleanURI(Req.URI), params) then' + sLineBreak +
  '    begin' + sLineBreak +
  '      if params.Count > 0 then' + sLineBreak +
  '        ctx.Request.QueryFields.AddStrings(params);' + sLineBreak +
  '' + sLineBreak +
  '      { verifica autenticação }' + sLineBreak +
  '      if FRoutes[i].AuthRequired then begin' + sLineBreak +
  '        resp := TCoreJWT.VerifyToken(Req);' + sLineBreak +
  '' + sLineBreak +
  '        if (resp <> jrsValid) then begin' + sLineBreak +
  '          Res.Code := 401;' + sLineBreak +
  '' + sLineBreak +
  '          if resp = jrsExpired then' + sLineBreak +
  '            Res.Content := ''Unauthorized / token expired''' + sLineBreak +
  '          else' + sLineBreak +
  '            Res.Content := ''Unauthorized / invalid token'';' + sLineBreak +
  '' + sLineBreak +
  '          params.Free;' + sLineBreak +
  '          ctx.Free;' + sLineBreak +
  '          exit(True);' + sLineBreak +
  '        end;' + sLineBreak +
  '      end;' + sLineBreak +
  '' + sLineBreak +
  '      FRoutes[i].Handler(ctx);' + sLineBreak +
  '      Result := True;' + sLineBreak +
  '      params.Free;' + sLineBreak +
  '      ctx.Free;' + sLineBreak +
  '      exit;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end; // for' + sLineBreak +
  '' + sLineBreak +
  '  params.Free;' + sLineBreak +
  '  ctx.Free;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ TRouteGroup }' + sLineBreak +
  '' + sLineBreak +
  'constructor TRouteGroup.Create(ARouter: TRouter; APrefix: string; AAuth: boolean);' + sLineBreak +
  'begin' + sLineBreak +
  '  FRouter := ARouter;' + sLineBreak +
  '  FPrefix := APrefix;' + sLineBreak +
  '  FAuth   := AAuth;' + sLineBreak +
  '  if FPrefix = ''/'' then FPrefix := '''';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouteGroup.Get(Path: string; Handler: TRouteHandler): TRouteGroup;' + sLineBreak +
  'begin' + sLineBreak +
  '  FRouter.Get(FPrefix + Path, Handler, FAuth);' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouteGroup.Post(Path: string; Handler: TRouteHandler): TRouteGroup;' + sLineBreak +
  'begin' + sLineBreak +
  '  FRouter.Post(FPrefix + Path, Handler, FAuth);' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouteGroup.Put(Path: string; Handler: TRouteHandler): TRouteGroup;' + sLineBreak +
  'begin' + sLineBreak +
  '  FRouter.Put(FPrefix + Path, Handler, FAuth);' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouteGroup.Delete(Path: string; Handler: TRouteHandler): TRouteGroup;' + sLineBreak +
  'begin' + sLineBreak +
  '  FRouter.Delete(FPrefix + Path, Handler, FAuth);' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TRouteGroup.Patch(Path: string; Handler: TRouteHandler): TRouteGroup;' + sLineBreak +
  'begin' + sLineBreak +
  '  FRouter.Patch(FPrefix + Path, Handler, FAuth);' + sLineBreak +
  '  Result := Self;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.router.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_StatusCode;
var
  s: string;
begin
  s :=
  'unit Core.StatusCode;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  TResponseCode = class' + sLineBreak +
  '    const Continue             = 100;' + sLineBreak +
  '' + sLineBreak +
  '    const OK                   = 200;' + sLineBreak +
  '    const Created              = 201;' + sLineBreak +
  '    const Accepted             = 202;' + sLineBreak +
  '    const NoContent            = 204;' + sLineBreak +
  '' + sLineBreak +
  '    const BadRequest           = 400;' + sLineBreak +
  '    const Unauthorized         = 401;' + sLineBreak +
  '    const Forbidden            = 403;' + sLineBreak +
  '    const NotFound             = 404;' + sLineBreak +
  '    const MethodNotAllowed     = 405;' + sLineBreak +
  '' + sLineBreak +
  '    const InternalServerError  = 500;' + sLineBreak +
  '    const NotImplemented       = 501;' + sLineBreak +
  '    const BadGateway           = 502;' + sLineBreak +
  '    const ServiceUnavailable   = 503;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak ;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.statuscode.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraCore_Util;
var
  s: string;
begin
  s :=
  'unit Core.Util;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Funções auxiliares' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, StrUtils, HTTPDefs, sha1, md5, RegExpr;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TUtil }' + sLineBreak +
  '' + sLineBreak +
  '  TUtil = class' + sLineBreak +
  '    private' + sLineBreak +
  '      class function CalculaDigito_CNPJ(const cnpj: string): Integer;' + sLineBreak +
  '      class function CalculaDV_CNPJ(baseCnpj: string): string;' + sLineBreak +
  '      class function IsCnpjFormacaoValidaComDV(const ACNPJComDV: string): boolean;' + sLineBreak +
  '      class function IsCnpjFormacaoValidaSemDV(const ACNPJSemDV: string): boolean;' + sLineBreak +
  '    public' + sLineBreak +
  '      class function CleanURI(const AURI: String): String;' + sLineBreak +
  '      class function FileToString(const AFileName:String):String;' + sLineBreak +
  '      class function FindField(const AField: String; const AFieldsList: array of string): Boolean;' + sLineBreak +
  '      class function Hash_Password(const APassword, AUsername: String; AIterations: Integer = 50): String;' + sLineBreak +
  '      class function RangeInteger(const AValue, AMinValue, AMaxValue: Integer): Integer; overload;' + sLineBreak +
  '      class function RangeDouble(const AValue, AMinValue, AMaxValue: Double): Double; overload;' + sLineBreak +
  '      class function SelectOption(const AValue: String; const AOptions: array of string; const ADefaultValue: String): String;' + sLineBreak +
  '      { remove a máscara de formação, como em CEP, CPF, CNPJ, Telefone }' + sLineBreak +
  '      class function RemoveMaskFormat(const AValue: string): string;' + sLineBreak +
  '      class function OnlyNumbers(const AValue: String): String;' + sLineBreak +
  '      class function IsValidCPF(const ACPF: string): Boolean;' + sLineBreak +
  '      class function IsValidCNPJ(const ACNPJ: string): Boolean;' + sLineBreak +
  '      class function FormataCPF(AValue: string): string;' + sLineBreak +
  '      class function FormataCNPJ(AValue: string): string;' + sLineBreak +
  '      class function FormataCEP(AValue: string): string;' + sLineBreak +
  '      class function FormataTelefone(AValue: string): string;' + sLineBreak +
  '      class function EncodeURI(AValue: string): string;' + sLineBreak +
  '      class function Encrypt_MD5(const AValue: string): string;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  '{ TUtil }' + sLineBreak +
  '' + sLineBreak +
  'const' + sLineBreak +
  '  TAMANHO_CNPJ_SEM_DV = 12;' + sLineBreak +
  '  VALOR_BASE = Ord(''0''); // 48' + sLineBreak +
  '  PESOS_DV: array[0..12] of Integer = (6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2);' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.CleanURI(const AURI: String): String;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := Copy(AURI, 1, Pos(''?'', AURI + ''?'')-1);' + sLineBreak +
  '' + sLineBreak +
  '  if (Length(Result) > 1) and (Result[Length(Result)] = ''/'') then' + sLineBreak +
  '    Delete(Result, Length(Result), 1);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ response := TUsil.SelectOption(''sobrenome'',[''nome'',''idade'',''endereco''],''nome''); }' + sLineBreak +
  'class function TUtil.SelectOption(const AValue: String; const AOptions: array of string;' + sLineBreak +
  '                                  const ADefaultValue: String): String;' + sLineBreak +
  'begin' + sLineBreak +
  '  if IndexStr(AValue, AOptions) = -1 then' + sLineBreak +
  '    Result := ADefaultValue' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := AValue;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ remove a máscara de formação, como em CEP, CPF, CNPJ, Telefone }' + sLineBreak +
  'class function TUtil.RemoveMaskFormat(const AValue: string): string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := Trim(AValue);' + sLineBreak +
  '  Result := ReplaceRegExpr(''[./\-\(\)]'', Result, '''', False); // ''[./-]''' + sLineBreak +
  '  Result := StringReplace(Result, '' '', '''', [rfReplaceAll]);  // remove espaços' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ Retorna apenas números contidos na string }' + sLineBreak +
  'class function TUtil.OnlyNumbers(const AValue: String): String;' + sLineBreak +
  'var' + sLineBreak +
  '  c: Char;' + sLineBreak +
  '  v: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '  v := Trim(AValue);' + sLineBreak +
  '' + sLineBreak +
  '  for c in v do' + sLineBreak +
  '    if (c in [''0''..''9'']) then Result := Result + c;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ verifica se o CPF é vaĺido }' + sLineBreak +
  'class function TUtil.IsValidCPF(const ACPF: string): Boolean;' + sLineBreak +
  'var' + sLineBreak +
  '  s: string;' + sLineBreak +
  '  i, soma, dig1, dig2: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  s := ACPF.Trim;' + sLineBreak +
  '  s := RemoveMaskFormat(s);' + sLineBreak +
  '  s := RightStr(''00000000000'' + s, 11);' + sLineBreak +
  '' + sLineBreak +
  '  // Rejeita CPFs com todos os dígitos iguais' + sLineBreak +
  '  if (s = ''00000000000'') or (s = ''11111111111'') or (s = ''22222222222'') or' + sLineBreak +
  '     (s = ''33333333333'') or (s = ''44444444444'') or (s = ''55555555555'') or' + sLineBreak +
  '     (s = ''66666666666'') or (s = ''77777777777'') or (s = ''88888888888'') or' + sLineBreak +
  '     (s = ''99999999999'') then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  // Calcula primeiro dígito verificador' + sLineBreak +
  '  soma := 0;' + sLineBreak +
  '  for i := 1 to 9 do' + sLineBreak +
  '    soma := soma + (Ord(s[i]) - Ord(''0'')) * (10 - i + 1);' + sLineBreak +
  '' + sLineBreak +
  '  dig1 := 11 - (soma mod 11);' + sLineBreak +
  '  if dig1 >= 10 then dig1 := 0;' + sLineBreak +
  '' + sLineBreak +
  '  // Calcula segundo dígito verificador' + sLineBreak +
  '  soma := 0;' + sLineBreak +
  '  for i := 1 to 9 do' + sLineBreak +
  '    soma := soma + (Ord(s[i]) - Ord(''0'')) * (11 - i + 1);' + sLineBreak +
  '  soma := soma + dig1 * 2;' + sLineBreak +
  '' + sLineBreak +
  '  dig2 := 11 - (soma mod 11);' + sLineBreak +
  '  if dig2 >= 10 then dig2 := 0;' + sLineBreak +
  '' + sLineBreak +
  '  // Compara com os dígitos informados' + sLineBreak +
  '  Result := (dig1 = Ord(s[10]) - Ord(''0'')) and (dig2 = Ord(s[11]) - Ord(''0''));' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ verifica se o CNPJ é válido }' + sLineBreak +
  'class function TUtil.IsValidCNPJ(const ACNPJ: string): Boolean;' + sLineBreak +
  'var' + sLineBreak +
  '  cnpjLimpo, dvInformado, dvCalculado: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '  cnpjLimpo := ACNPJ;' + sLineBreak +
  '  if Trim(cnpjLimpo) = '''' then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  cnpjLimpo := RemoveMaskFormat(cnpjLimpo);' + sLineBreak +
  '  cnpjLimpo := RightStr(''00000000000000'' + cnpjLimpo, 14);' + sLineBreak +
  '' + sLineBreak +
  '  if IsCnpjFormacaoValidaComDV(cnpjLimpo) then begin' + sLineBreak +
  '    try' + sLineBreak +
  '      dvInformado := Copy(cnpjLimpo, TAMANHO_CNPJ_SEM_DV + 1, 2);' + sLineBreak +
  '      dvCalculado := CalculaDV_CNPJ(Copy(cnpjLimpo, 1, TAMANHO_CNPJ_SEM_DV));' + sLineBreak +
  '      Result := dvCalculado = dvInformado;' + sLineBreak +
  '    except' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.FormataCPF(AValue: string): string;' + sLineBreak +
  '//formata o Cpf' + sLineBreak +
  'var' + sLineBreak +
  '  Raw: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  try' + sLineBreak +
  '    Raw := RemoveMaskFormat(AValue);' + sLineBreak +
  '    if Length(Raw) > 11 then Delete(Raw, 12, MaxInt);' + sLineBreak +
  '    if Length(Raw) >= 10 then' + sLineBreak +
  '      Raw := Format(''%s.%s.%s-%s'', [Copy(Raw,1,3), Copy(Raw,4,3), Copy(Raw,7,3), Copy(Raw,10,2)])' + sLineBreak +
  '    else if Length(Raw) >= 7 then' + sLineBreak +
  '      Raw := Format(''%s.%s.%s'', [Copy(Raw,1,3), Copy(Raw,4,3), Copy(Raw,7)])' + sLineBreak +
  '    else if Length(Raw) >= 4 then' + sLineBreak +
  '      Raw := Format(''%s.%s'', [Copy(Raw,1,3), Copy(Raw,4)]);' + sLineBreak +
  '' + sLineBreak +
  '    Result := Raw;' + sLineBreak +
  '  except' + sLineBreak +
  '    Result := AValue;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.FormataCNPJ(AValue: string): string;' + sLineBreak +
  '//formata o Cnpj' + sLineBreak +
  'var' + sLineBreak +
  '  Raw: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  try' + sLineBreak +
  '    Raw := RemoveMaskFormat(AValue);' + sLineBreak +
  '    if Length(Raw) > 14 then Delete(Raw, 15, MaxInt);' + sLineBreak +
  '    if Length(Raw) >= 13 then' + sLineBreak +
  '      Raw := Format(''%s.%s.%s/%s-%s'', [Copy(Raw,1,2), Copy(Raw,3,3), Copy(Raw,6,3), Copy(Raw,9,4), Copy(Raw,13,2)])' + sLineBreak +
  '    else if Length(Raw) >= 9 then' + sLineBreak +
  '      Raw := Format(''%s.%s.%s/%s'', [Copy(Raw,1,2), Copy(Raw,3,3), Copy(Raw,6,3), Copy(Raw,9)])' + sLineBreak +
  '    else if Length(Raw) >= 6 then' + sLineBreak +
  '      Raw := Format(''%s.%s.%s'', [Copy(Raw,1,2), Copy(Raw,3,3), Copy(Raw,6)])' + sLineBreak +
  '    else if Length(Raw) >= 3 then' + sLineBreak +
  '      Raw := Format(''%s.%s'', [Copy(Raw,1,2), Copy(Raw,3)]);' + sLineBreak +
  '' + sLineBreak +
  '    Result := Raw;' + sLineBreak +
  '  except' + sLineBreak +
  '    Result := AValue;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.FormataCEP(AValue: string): string;' + sLineBreak +
  '//formata o Cep' + sLineBreak +
  'var' + sLineBreak +
  '  Raw: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  try' + sLineBreak +
  '    Raw := OnlyNumbers(AValue);' + sLineBreak +
  '    if Length(Raw) > 8 then Delete(Raw, 9, MaxInt);' + sLineBreak +
  '    if Length(Raw) >= 6 then' + sLineBreak +
  '      Raw := Format(''%s-%s'', [Copy(Raw,1,5), Copy(Raw,6,3)]);' + sLineBreak +
  '' + sLineBreak +
  '    Result := Raw;' + sLineBreak +
  '  except' + sLineBreak +
  '    Result := AValue;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.FormataTelefone(AValue: string): string;' + sLineBreak +
  '//formata o telefone' + sLineBreak +
  'var' + sLineBreak +
  '  Raw: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Raw := OnlyNumbers(AValue);' + sLineBreak +
  '  if Length(Raw) > 11 then Delete(Raw, 12, MaxInt);' + sLineBreak +
  '  if Length(Raw) = 11 then' + sLineBreak +
  '    Raw := Format(''(%s) %s-%s'', [Copy(Raw,1,2), Copy(Raw,3,5), Copy(Raw,8,4)])' + sLineBreak +
  '  else if Length(Raw) = 10 then' + sLineBreak +
  '    Raw := Format(''(%s) %s-%s'', [Copy(Raw,1,2), Copy(Raw,3,4), Copy(Raw,7,4)])' + sLineBreak +
  '  else if Length(Raw) = 9 then' + sLineBreak +
  '    Raw := Format(''%s-%s'', [Copy(Raw,1,5), Copy(Raw,6,4)])' + sLineBreak +
  '  else if Length(Raw) = 8 then' + sLineBreak +
  '    Raw := Format(''%s-%s'', [Copy(Raw,1,4), Copy(Raw,5,4)]);' + sLineBreak +
  '' + sLineBreak +
  '  Result := Raw;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.IsCnpjFormacaoValidaComDV(const ACNPJComDV: string): boolean;' + sLineBreak +
  'var' + sLineBreak +
  '  i: Integer;' + sLineBreak +
  '  cnpj: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '  cnpj := RightStr(''00000000000000'' + ACNPJComDV, 14);' + sLineBreak +
  '' + sLineBreak +
  '  // Verifica se os 12 primeiros são alfanuméricos e os 2 últimos são dígitos' + sLineBreak +
  '  for i := 1 to 12 do' + sLineBreak +
  '    if not (cnpj[i] in [''0''..''9'', ''A''..''Z'']) then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  for i := 13 to 14 do' + sLineBreak +
  '    if not (cnpj[i] in [''0''..''9'']) then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  // Verifica se não é todo zero' + sLineBreak +
  '  Result := cnpj <> ''00000000000000'';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.IsCnpjFormacaoValidaSemDV(const ACNPJSemDV: string): boolean;' + sLineBreak +
  'var' + sLineBreak +
  '  i: Integer;' + sLineBreak +
  '  cnpj: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '  cnpj := RightStr(''00000000000000'' + ACNPJSemDV, 14);' + sLineBreak +
  '' + sLineBreak +
  '  // Verifica se todos os caracteres são dígito ou letra maiúscula' + sLineBreak +
  '  for i := 1 to 12 do' + sLineBreak +
  '    if not (cnpj[i] in [''0''..''9'', ''A''..''Z'']) then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  // Verifica se não é todo zero' + sLineBreak +
  '  Result := cnpj <> ''000000000000'';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.CalculaDigito_CNPJ(const cnpj: string): Integer;' + sLineBreak +
  'var' + sLineBreak +
  '  i, soma, valorCaracter: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  soma := 0;' + sLineBreak +
  '  for i := Length(cnpj) downto 1 do' + sLineBreak +
  '  begin' + sLineBreak +
  '    valorCaracter := Ord(cnpj[i]) - VALOR_BASE;' + sLineBreak +
  '    soma := soma + valorCaracter * PESOS_DV[High(PESOS_DV) - Length(cnpj) + i];' + sLineBreak +
  '  end;' + sLineBreak +
  '  if (soma mod 11) < 2 then' + sLineBreak +
  '    Result := 0' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := 11 - (soma mod 11);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.CalculaDV_CNPJ(baseCnpj: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  baseLimpa, dv1, dv2: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  if baseCnpj = '''' then' + sLineBreak +
  '    raise Exception.Create(''CNPJ não pode ser vazio para cálculo do DV'');' + sLineBreak +
  '' + sLineBreak +
  '  baseLimpa := RemoveMaskFormat(baseCnpj);' + sLineBreak +
  '' + sLineBreak +
  '  if not IsCnpjFormacaoValidaSemDV(baseLimpa) then' + sLineBreak +
  '    raise Exception.CreateFmt(''Cnpj %s não é válido para o cálculo do DV'', [baseCnpj]);' + sLineBreak +
  '' + sLineBreak +
  '  dv1 := IntToStr(CalculaDigito_CNPJ(baseLimpa));' + sLineBreak +
  '  dv2 := IntToStr(CalculaDigito_CNPJ(baseLimpa + dv1));' + sLineBreak +
  '' + sLineBreak +
  '  Result := dv1 + dv2;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ Verifica se o campo está na lista: FindField(''nome'', [''nome'',''endereco'',''cpf'']) }' + sLineBreak +
  'class function TUtil.FindField(const AField: String;  const AFieldsList: array of string): Boolean;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := (IndexStr(AField, AFieldsList) >= 0);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.RangeInteger(const AValue, AMinValue, AMaxValue: Integer): Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := AValue;' + sLineBreak +
  '  if AValue < AMinValue then Result := AMinValue;' + sLineBreak +
  '  if AValue > AMaxValue then Result := AMaxValue;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.RangeDouble(const AValue, AMinValue, AMaxValue: Double): Double;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := AValue;' + sLineBreak +
  '  if AValue < AMinValue then Result := AMinValue;' + sLineBreak +
  '  if AValue > AMaxValue then Result := AMaxValue;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.FileToString(const AFileName: String): String;' + sLineBreak +
  '// AFileName = ''./public/v1/doc.html''' + sLineBreak +
  'var' + sLineBreak +
  '  S : TStringList;' + sLineBreak +
  'begin' + sLineBreak +
  '  S := TStringList.Create;' + sLineBreak +
  '  try' + sLineBreak +
  '    S.LoadFromFile(AFileName);' + sLineBreak +
  '    Result := S.Text;' + sLineBreak +
  '  finally' + sLineBreak +
  '    S.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.Hash_Password(const APassword, AUsername: String; AIterations: Integer):String;' + sLineBreak +
  '// codifica a senha' + sLineBreak +
  'var' + sLineBreak +
  '  I : Integer;' + sLineBreak +
  '  S : String;' + sLineBreak +
  'begin' + sLineBreak +
  '  S := APassword + LowerCase(AUsername);' + sLineBreak +
  '' + sLineBreak +
  '  for I := 1 to AIterations do' + sLineBreak +
  '    S := SHA1Print(SHA1String(S));' + sLineBreak +
  '' + sLineBreak +
  '  Result := S;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TUtil.EncodeURI(AValue: string): string;' + sLineBreak +
  '// O HTTPEncode converte espaços em ''+'' ou ''%20'' e protege caracteres especiais' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := HTTPEncode(AValue);' + sLineBreak +
  'end;' + sLineBreak +
  ' ' + sLineBreak +
  'class function TUtil.Encrypt_MD5(const AValue: string): string;' + sLineBreak +
  '// criptografa a senha usando MD5' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := MD5Print(MD5String(AValue));' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.util.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraModel_User;
// modelo padrão para dados do usuário após autenticação
var
  s: string;
begin
  s :=
  'unit Model.UserInfo;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Modelo de informações do usuário' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TModelUserInfo }' + sLineBreak +
  '' + sLineBreak +
  '  TModelUserInfo = class' + sLineBreak +
  '  private' + sLineBreak +
  '    FExp: Int64;' + sLineBreak +
  '    FId: Integer;' + sLineBreak +
  '    FLogin: string;' + sLineBreak +
  '    FName: string;' + sLineBreak +
  '  public' + sLineBreak +
  '    constructor Create(AId: Integer = 0; AName: string = ''''; ALogin: string = '''');' + sLineBreak +
  '    property Id: Integer read FId write FId;' + sLineBreak +
  '    property Name: string read FName write FName;' + sLineBreak +
  '    property Login: string read FLogin write FLogin;' + sLineBreak +
  '    property exp: Int64 read FExp write Fexp;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  '{ TModelUserInfo }' + sLineBreak +
  '' + sLineBreak +
  'constructor TModelUserInfo.Create(AId: Integer; AName: string; ALogin: string);' + sLineBreak +
  'begin' + sLineBreak +
  '  FId := AId;' + sLineBreak +
  '  FName := AName;' + sLineBreak +
  '  FLogin := ALogin;' + sLineBreak +
  '  FExp := 0;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaModels + 'model.userinfo.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraRoute_Auth;
// rota de autenticação do usuário
var
  s: string;
begin
  s :=
  'unit Route.Auth;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Rota de autenticação do usuário' + sLineBreak +
  '// Body do seu POST: {"username":"admin","password":"123"}' + sLineBreak +
  '// Adeque a classe Service.Auth para sua realidade' + sLineBreak +
  '' + sLineBreak +
  '{$mode objfpc}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.Router;' + sLineBreak +
  '' + sLineBreak +
  'procedure RegisterRoutesAuth(Router: TRouter);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  sysutils, DateUtils, fpjson, jsonparser,' + sLineBreak +
  '  Core.HttpContext, Core.JWT, Model.UserInfo, ' + sLineBreak +
  '  Service.Auth';

  if Projeto.ApiAudit then
    s := s +
    ', Service.ApiAudit';

  s := s +
  ';' + sLineBreak +
  '' + sLineBreak +
  'procedure RouteLogin(ctx: THttpContext);' + sLineBreak +
  '// valida o usuário e retorna o token (SHA1)' + sLineBreak +
  'var' + sLineBreak +
  '  lUser: TModelUserInfo;' + sLineBreak +
  '  lJson: TJSONObject;' + sLineBreak +
  '  lToken, lLogin: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  lJson := ctx.JSON; {json enviado no body da requisição}' + sLineBreak +
  '' + sLineBreak +
  'if ctx.IsValidJson then begin' + sLineBreak +
  '    // busca dados do usuário no banco de dados' + sLineBreak +
  '    lLogin := lJson.Get(''username'','''');' + sLineBreak +
  '    lUser := TServiceAuth.New.ValidateLogin(lLogin, lJson.Get(''password'', ''''));' + sLineBreak +
  '' + sLineBreak +
  '    if lUser.Id > 0 then begin' + sLineBreak +
  '      lToken := TCoreJWT.GetToken( lUser );' + sLineBreak +
  '      ctx.SetAuthentication(lToken, lUser.Login);' + sLineBreak;

  if Projeto.ApiAudit then
    s := s +
    '      TServiceApiAudit.Log(ctx, ''POST'', ''/login'', ''Auth'', ''authentication ok'', 1, lUser.Id);' + sLineBreak;

  s := s +
  '      ctx.Code(StatusCode.OK)' + sLineBreak +
  '         .AddPair(''id'', lUser.Id)' + sLineBreak +
  '         .AddPair(''name'', lUser.Name)' + sLineBreak +
  '         .AddPair(''exp'', DateTimeToUnix( IncHour(Now, JWT_HoursToExpire) ))' + sLineBreak +
  '         .AddPair(''token'', lToken)' + sLineBreak +
  '         .Send;' + sLineBreak +
  '    end' + sLineBreak +
  '    else begin' + sLineBreak +
  '      ctx.SetAuthentication(lToken, lLogin);' + sLineBreak;

  if Projeto.ApiAudit then
    s := s +
    '      TServiceApiAudit.Log(ctx, ''POST'', ''/login'', ''Auth'', ''authentication failed'', 0, 0);' + sLineBreak;

  s := s +
  '      ctx.Code(StatusCode.Unauthorized)' + sLineBreak +
  '         .SendTEXT(''authentication failed'');' + sLineBreak +
  '' + sLineBreak +
  '      lUser.Free;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end' + sLineBreak +
  '  else begin' + sLineBreak;

  if Projeto.ApiAudit then
    s := s +
    '      TServiceApiAudit.Log(ctx, ''POST'', ''/login'', ''Auth'', ''authentication failed, missing data'', 0, 0);' + sLineBreak;

  s := s +
  '      ctx.Code(StatusCode.Unauthorized)' + sLineBreak +
  '         .SendTEXT(''authentication failed, missing data'');' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  lJson.Free;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure RouteValidaLogin(ctx: THttpContext);' + sLineBreak +
  '// valida o usuário com base no token' + sLineBreak +
  'var' + sLineBreak +
  '  lUser: TModelUserInfo;' + sLineBreak +
  'begin' + sLineBreak +
  '  //req.CustomHeaders.Values[''Authorization''];' + sLineBreak +
  '  //lUser := TCoreJWT.ValidateToken(ctx.ReadToken);' + sLineBreak +
  '  lUser := ctx.UserInformation;' + sLineBreak +
  '' + sLineBreak +
  '  //ctx.Code(200).Success(True).Message(''Legal'').Send;' + sLineBreak +
  '  if (lUser.Id > 0) then begin' + sLineBreak +
  '    ctx.Code(200)' + sLineBreak +
  '       .SendJSON( TJSONObject.Create([' + sLineBreak +
  '                      ''auth'',''autenticação ok'',' + sLineBreak +
  '                      ''id'', lUser.Id,' + sLineBreak +
  '                      ''nome'', lUser.Name,' + sLineBreak +
  '                      ''login'', lUser.Login,' + sLineBreak +
  '                      ''ip'', ctx.IPClient,' + sLineBreak +
  '                      ''exp'', FormatDateTime(''yyyy-mm-dd hh:nn:ss'', UnixToDateTime(lUser.exp))' + sLineBreak +
  '                 ]).AsJSON);' + sLineBreak +
  '  end else begin' + sLineBreak +
  '    ctx.Code(StatusCode.Unauthorized)' + sLineBreak +
  '       .SendTEXT(''authentication failed'');' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure RegisterRoutesAuth(Router: TRouter);' + sLineBreak +
  '// registro das rotas' + sLineBreak +
  'begin' + sLineBreak +
  '  Router.Post(''/login'', @RouteLogin, False);' + sLineBreak +
  '  Router.Post(''/validar'', @RouteValidaLogin, False);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaRoutes + 'route.auth.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraRoute_Doc;
var
  s: string;
begin
  s :=
  'unit Route.Doc;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// rotas de documentação da API' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.Router;' + sLineBreak +
  '' + sLineBreak +
  'procedure RegisterDocRoutes(Router: TRouter);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.HttpContext, Core.Util;' + sLineBreak +
  '' + sLineBreak +
  'procedure RouteDocV1(ctx:THttpContext);' + sLineBreak +
  '// Documentação Versão 1' + sLineBreak +
  'begin' + sLineBreak +
  '  ctx.SendHTML(TUtil.FileToString(''./api/v1/doc.html''));' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure RouteDocV2(ctx:THttpContext);' + sLineBreak +
  '// Documentação Versão 2' + sLineBreak +
  'begin' + sLineBreak +
  '  ctx.SendHTML(TUtil.FileToString(''./api/v2/doc.html''));' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure RegisterDocRoutes(Router: TRouter);' + sLineBreak +
  '// registra as rotas de documentação' + sLineBreak +
  'begin' + sLineBreak +
  '  Router.Get(''/api/v1'', @RouteDocV1, False);' + sLineBreak +
  '  Router.Get(''/api/v2'', @RouteDocV2, False);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaRoutes + 'route.doc.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraRotas(AObjetoTabela, ARota: string; campos: TZQuery);
// gera a rota conforme a tabela
var
  s, lObjeto, lRota, lNome_tabela: string;
begin
  campos.First;
  if campos.FieldByName('for_auth').AsInteger = 1 then Exit;
  lNome_tabela := campos.FieldByName('tabela').AsString;
  lObjeto := Trim(AObjetoTabela) + FVersaoAbreviadaRota;
  lRota := Trim(ARota);
  lRota := LowerCase( AjustaNomeRota(lObjeto, lRota) );

  s :=
  'unit Route.' + lObjeto + ';' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '' + sLineBreak +
  '// rotas de [ ' + lRota + ' ]' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.Router;' + sLineBreak +
  '' + sLineBreak +
  'procedure RegisterRoutes' + lObjeto + '(Router: TRouter);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  sysutils, StrUtils, DateUtils, fpjson, jsonparser,' + sLineBreak +
  '  Core.HttpContext, Core.JWT, Model.UserInfo,' + sLineBreak +
  '  Core.Util, Core.DataControl, TableModel.' + lObjeto;

  if Projeto.ApiAudit then
    s := s +
    ', Service.ApiAudit';

  if FCriarServiceClasses then
    s := s +
    ' {, Service.' + lObjeto + '}';

  s := s +
  ';' + sLineBreak +
  '' + sLineBreak +
  'procedure Route' + lObjeto + '_GetById(ctx:THttpContext);' + sLineBreak +
  '// obtém o registro pelo seu id' + sLineBreak +
  'var' + sLineBreak +
  '  dc: TDataControl;' + sLineBreak +
  '  ID: Integer;' + sLineBreak +
  '  lErro, lDados: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  lErro := '''';' + sLineBreak +
  '  ID := ctx.QueryInt(''id'', 0);' + sLineBreak +
  '' + sLineBreak +
  '  if ID < 1 then begin' + sLineBreak +
  '    ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '       .AddSuccess(False)' + sLineBreak +
  '       .AddMessage(''ID not provided'')' + sLineBreak +
  '       .Send;' + sLineBreak +
  '' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    dc := TDataControl.Create ( TTableModel' + lObjeto + '.new.GetModel );' + sLineBreak +
  ' ' + sLineBreak +
  '    lDados := dc.GetByID( ID );' + sLineBreak +
  '' + sLineBreak +
  '    if Trim(lDados) <> '''' then' + sLineBreak +
  '      ctx.SendJSON( lDados ) // envia os dados' + sLineBreak +
  '    else' + sLineBreak +
  '      lErro := dc.Message;' + sLineBreak +
  '  except' + sLineBreak +
  '    on E: EValidationError do begin' + sLineBreak +
  '      lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '    on E: Exception do begin' + sLineBreak +
  '      if E.ClassName = ''EJSONParser'' then' + sLineBreak +
  '        lErro := ''Invalid JSON: '' + E.Message' + sLineBreak +
  '      else' + sLineBreak +
  '        lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  dc.Free;' + sLineBreak +
  '  lDados := '''';' + sLineBreak +
  '' + sLineBreak +
  '  if lErro <> '''' then' + sLineBreak +
  '    ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '       .AddSuccess(False)' + sLineBreak +
  '       .AddMessage(StringReplace(lErro, ''"'', ''\"'', [rfReplaceAll]))' + sLineBreak +
  '       .Send;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak;

  if campos.FieldByName('api_get').AsInteger = 1 then begin
  s := s +
  'procedure Route' + lObjeto + '_GetList(ctx:THttpContext);' + sLineBreak +
  '// Lista de registros com paginação' + sLineBreak +
  '// /cliente' + sLineBreak +
  '// /cliente?page=1&limit=6&search_field=name&search_operator=eq&search=jose%20silva&order_field=nome,idade&direction=asc' + sLineBreak +
  'var' + sLineBreak +
  '  dc: TDataControl;' + sLineBreak +
  '  lPage, lLimit: Integer;' + sLineBreak +
  '  lSearchField, lSearchOperator, lSearch, lOrderFields, lOrderDirection: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  lPage := ctx.QueryInt(''page'', 1);' + sLineBreak +
  '  lLimit := ctx.QueryInt(''limit'', 10);' + sLineBreak +
  '  lSearchField := ctx.Query(''search_field'');' + sLineBreak +
  '  lSearchOperator := ctx.Query(''search_operator'');' + sLineBreak +
  '  lSearch := ctx.Query(''search'');' + sLineBreak +
  '  lOrderFields := ctx.Query(''order_field'').ToLower;' + sLineBreak +
  '  lOrderDirection := ctx.Query(''direction'').ToLower;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    dc := TDataControl.Create ( TTableModel' + lObjeto + '.new.GetModel );' + sLineBreak +
  '' + sLineBreak +
  '    ctx.SendJSON( dc.GetList(lPage, lLimit, lSearchField, lSearchOperator, lSearch, lOrderFields, lOrderDirection) );' + sLineBreak +
  '  except' + sLineBreak +
  '    on E: Exception do begin' + sLineBreak +
  '      ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '         .AddSuccess(False)' + sLineBreak +
  '         .AddMessage(StringReplace(E.Message, ''"'', ''\"'', [rfReplaceAll]))' + sLineBreak +
  '         .Send;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  dc.Free;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak;
  end;

  if campos.FieldByName('api_post').AsInteger = 1 then begin
  s := s +
  'procedure Route' + lObjeto + '_Post(ctx:THttpContext);' + sLineBreak +
  '// adiciona novo registro' + sLineBreak +
  'var' + sLineBreak +
  '  dc: TDataControl;' + sLineBreak +
  '  lErro: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  lErro := '''';' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    dc := TDataControl.Create( TTableModel' + lObjeto + '.new.GetModel );' + sLineBreak +
  '' + sLineBreak +
  '    if dc.Insert( ctx.Body ) then begin' + sLineBreak;

  if Projeto.ApiAudit then
    s := s +
    '      TServiceApiAudit.Log(ctx, ''POST'', ''' + Projeto.ApiVersao + '/' + lRota + ''', ' + QuotedStr(lNome_tabela) + ', ''Record created successfully. ID = '' + dc.ID.ToString, 1, dc.ID);' + sLineBreak;

  s := s +
  '      ctx.Code(201)' + sLineBreak +
  '         .AddSuccess(True)' + sLineBreak +
  '         .AddMessage(''Record created successfully. ID = '' + dc.ID.ToString)' + sLineBreak +
  '         .Send;' + sLineBreak +
  '    end' + sLineBreak +
  '    else' + sLineBreak +
  '      lErro := dc.Message;' + sLineBreak +
  '  except' + sLineBreak +
  '    on E: EValidationError do begin' + sLineBreak +
  '      lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '    on E: Exception do begin' + sLineBreak +
  '      if E.ClassName = ''EJSONParser'' then' + sLineBreak +
  '        lErro := ''Invalid JSON: '' + E.Message' + sLineBreak +
  '      else' + sLineBreak +
  '        lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  dc.Free;' + sLineBreak +
  '' + sLineBreak +
  '  if lErro <> '''' then' + sLineBreak +
  '    ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '       .AddSuccess(False)' + sLineBreak +
  '       .AddMessage(StringReplace(lErro, ''"'', ''\"'', [rfReplaceAll]))' + sLineBreak +
  '       .Send;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak;
  end;

  if campos.FieldByName('api_put').AsInteger = 1 then begin
  s := s +
  'procedure Route' + lObjeto + '_Put(ctx:THttpContext);' + sLineBreak +
  '// altera o registro' + sLineBreak +
  'var' + sLineBreak +
  '  dc: TDataControl;' + sLineBreak +
  '  lErro: string;' + sLineBreak +
  '  ID: INteger;' + sLineBreak +
  'begin' + sLineBreak +
  '  lErro := '''';' + sLineBreak +
  '  ID := ctx.QueryInt(''id'', 0);' + sLineBreak +
  '' + sLineBreak +
  '  if ID < 1 then begin' + sLineBreak +
  '    ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '       .AddSuccess(False)' + sLineBreak +
  '       .AddMessage(''ID not provided to update'')' + sLineBreak +
  '       .Send;' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    dc := TDataControl.Create ( TTableModel' + lObjeto + '.new.GetModel );' + sLineBreak +
  '' + sLineBreak +
  '    if dc.Update(ID, ctx.Body) then begin' + sLineBreak;

  if Projeto.ApiAudit then
    s := s +
    '      TServiceApiAudit.Log(ctx, ''PUT'', ''' + Projeto.ApiVersao + '/' + lRota + '/:id'', ' + QuotedStr(lNome_tabela) + ', ''Record updated successfully.'', 1, ID);' + sLineBreak;

  s := s +
  '      ctx.Code(202)' + sLineBreak +
  '         .AddSuccess(True)' + sLineBreak +
  '         .AddMessage(''Record updated successfully.'')' + sLineBreak +
  '         .Send;' + sLineBreak +
  '    end' + sLineBreak +
  '    else' + sLineBreak +
  '      lErro := dc.Message;' + sLineBreak +
  '  except' + sLineBreak +
  '    on E: EValidationError do begin' + sLineBreak +
  '      lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '    on E: Exception do begin' + sLineBreak +
  '      if E.ClassName = ''EJSONParser'' then' + sLineBreak +
  '        lErro := ''Invalid JSON: '' + E.Message' + sLineBreak +
  '      else' + sLineBreak +
  '        lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  dc.Free;' + sLineBreak +
  '' + sLineBreak +
  '  if lErro <> '''' then' + sLineBreak +
  '    ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '       .AddSuccess(False)' + sLineBreak +
  '       .AddMessage(StringReplace(lErro, ''"'', ''\"'', [rfReplaceAll]))' + sLineBreak +
  '       .Send;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak;
  end;

  if campos.FieldByName('api_patch').AsInteger = 1 then begin
  s := s +
  'procedure Route' + lObjeto + '_Patch(ctx:THttpContext);' + sLineBreak +
  '// altera o registro' + sLineBreak +
  'var' + sLineBreak +
  '  dc: TDataControl;' + sLineBreak +
  '  lErro: string;' + sLineBreak +
  '  ID: INteger;' + sLineBreak +
  'begin' + sLineBreak +
  '  lErro := '''';' + sLineBreak +
  '  ID := ctx.QueryInt(''id'', 0);' + sLineBreak +
  '' + sLineBreak +
  '  if ID < 1 then begin' + sLineBreak +
  '    ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '       .AddSuccess(False)' + sLineBreak +
  '       .AddMessage(''ID not provided to update'')' + sLineBreak +
  '       .Send;' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    dc := TDataControl.Create ( TTableModel' + lObjeto + '.new.GetModel );' + sLineBreak +
  '' + sLineBreak +
  '    if dc.Update(ID, ctx.Body) then begin' + sLineBreak;

  if Projeto.ApiAudit then
    s := s +
    '      TServiceApiAudit.Log(ctx, ''PATCH'', ''' + Projeto.ApiVersao + '/' + lRota + '/:id'', ' + QuotedStr(lNome_tabela) + ', ''Record updated successfully.'', 1, ID);' + sLineBreak;

  s := s +
  '      ctx.Code(202)' + sLineBreak +
  '         .AddSuccess(True)' + sLineBreak +
  '         .AddMessage(''Record updated successfully.'')' + sLineBreak +
  '         .Send;' + sLineBreak +
  '    end' + sLineBreak +
  '    else' + sLineBreak +
  '      lErro := dc.Message;' + sLineBreak +
  '  except' + sLineBreak +
  '    on E: EValidationError do begin' + sLineBreak +
  '      lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '    on E: Exception do begin' + sLineBreak +
  '      if E.ClassName = ''EJSONParser'' then' + sLineBreak +
  '        lErro := ''Invalid JSON: '' + E.Message' + sLineBreak +
  '      else' + sLineBreak +
  '        lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  dc.Free;' + sLineBreak +
  '' + sLineBreak +
  '  if lErro <> '''' then' + sLineBreak +
  '    ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '       .AddSuccess(False)' + sLineBreak +
  '       .AddMessage(StringReplace(lErro, ''"'', ''\"'', [rfReplaceAll]))' + sLineBreak +
  '       .Send;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak;
  end;

  if campos.FieldByName('api_delete').AsInteger = 1 then begin
  s := s +
  'procedure Route' + lObjeto + '_Delete(ctx:THttpContext);' + sLineBreak +
  '// deleta o registro. Acho que deveria marcar o registro como deletado!' + sLineBreak +
  'var' + sLineBreak +
  '  dc: TDataControl;' + sLineBreak +
  '  lErro: string;' + sLineBreak +
  '  ID: INteger;' + sLineBreak +
  'begin' + sLineBreak +
  '  lErro := '''';' + sLineBreak +
  '  ID := ctx.QueryInt(''id'', 0);' + sLineBreak +
  '' + sLineBreak +
  '  if ID < 1 then begin' + sLineBreak +
  '    ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '       .AddSuccess(False)' + sLineBreak +
  '       .AddMessage(''ID not provided to delete'')' + sLineBreak +
  '       .Send;' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    dc := TDataControl.Create ( TTableModel' + lObjeto + '.new.GetModel );' + sLineBreak +
  '' + sLineBreak +
  '    if dc.DeleteByID(ID) then begin' + sLineBreak;


  if Projeto.ApiAudit then
    s := s +
    '      TServiceApiAudit.Log(ctx, ''DELETE'', ''' + Projeto.ApiVersao + '/' + lRota + '/:id'', ' + QuotedStr(lNome_tabela) + ', ''Record deleted successfully. ID = '' + ID.ToString, 1, ID);' + sLineBreak;

  s := s +
  '      ctx.Code(200)' + sLineBreak +
  '         .AddSuccess(True)' + sLineBreak +
  '         .AddMessage(''Record deleted successfully. ID = '' + ID.ToString)' + sLineBreak +
  '         .Send;' + sLineBreak +
  '    end' + sLineBreak +
  '    else' + sLineBreak +
  '      lErro := dc.Message;' + sLineBreak +
  '  except' + sLineBreak +
  '    on E: EValidationError do begin' + sLineBreak +
  '      lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '    on E: Exception do begin' + sLineBreak +
  '      if E.ClassName = ''EJSONParser'' then' + sLineBreak +
  '        lErro := ''Invalid JSON: '' + E.Message' + sLineBreak +
  '      else' + sLineBreak +
  '        lErro := E.Message;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  dc.Free;' + sLineBreak +
  '' + sLineBreak +
  '  if lErro <> '''' then' + sLineBreak +
  '    ctx.Code(StatusCode.BadRequest)' + sLineBreak +
  '       .AddSuccess(False)' + sLineBreak +
  '       .AddMessage(StringReplace(lErro, ''"'', ''\"'', [rfReplaceAll]))' + sLineBreak +
  '       .Send;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak;
  end;

  s := s +
  'procedure RegisterRoutes' + lObjeto + '(Router: TRouter);' + sLineBreak +
  '// registra as rotas de [ ' + lRota + ' ]' + sLineBreak +
  '// Router.Get(''/api/v1/produtos/:id'', @RouteProdutos_GetById, True); { True = rota autenticada }' + sLineBreak +
  'begin' + sLineBreak +
  '  Router.Group(' + QuotedStr(Projeto.ApiVersao) + ', True)' + sLineBreak +
  '        .Get(''/' + lRota + '/:id'', @Route' + lObjeto + '_GetById)';

  if campos.FieldByName('api_get').AsInteger = 1 then
  s := s + sLineBreak +
  '        .Get(''/' + lRota + ''', @Route' + lObjeto + '_GetList)';

  if campos.FieldByName('api_post').AsInteger = 1 then
  s := s + sLineBreak +
  '        .Post(''/' + lRota + ''', @Route' + lObjeto + '_Post)';

  if campos.FieldByName('api_put').AsInteger = 1 then
  s := s + sLineBreak +
  '        .Put(''/' + lRota + '/:id'', @Route' + lObjeto + '_Put)';

  if campos.FieldByName('api_patch').AsInteger = 1 then
  s := s + sLineBreak +
  '        .Patch(''/' + lRota + '/:id'', @Route' + lObjeto + '_Patch)';

  if campos.FieldByName('api_delete').AsInteger = 1 then
  s := s + sLineBreak +
  '        .Delete(''/' + lRota + '/:id'', @Route' + lObjeto + '_Delete)';

  s := s +
  ';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaRoutes + 'route.' + lObjeto.ToLower + '.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GeraService_Auth;
// classe de autenticação do usuário
var
  st: TServiceTabela;
  sc: TServiceCampo;
  tabelas, campos: TZQuery;
  s, lTableName, lPk, lUser, lUsername, lPassword: string;
  lUsarMd5: Boolean;
  lCampoEspecial, lCampo, lQuery: string;
begin
  st := TServiceTabela.Create( FIdProjeto );
  tabelas := st.QueryTabelas( FListaTabelasID.Trim, True ); //tabelas

  lUsarMd5 := False;
  lTableName := '';
  lPk := '';
  lUser := '';
  lUsername := '';
  lPassword := '';

  if FTipoBanco = SQLSERVER then
    lQuery := 'TSQLQuery'
  else
    lQuery := 'TZQuery';

  if tabelas.RecordCount > 0 then begin

    while not tabelas.EOF do begin

      if tabelas.FieldByName('for_auth').AsInteger = 1 then begin
        sc := TServiceCampo.Create( tabelas.FieldByName('idtabela').AsInteger );
        campos := sc.QueryCampos; // campos da tabela

        lTableName := tabelas.FieldByName('tabela').AsString; // nome da tabela

        while not campos.EOF do begin
          lCampoEspecial := UpperCase( Trim(campos.FieldByName('campo_especial').AsString) );
          lCampo := campos.FieldByName('campo').AsString;

          if campos.FieldByName('chave_primaria').AsInteger = 1 then lPk := lCampo;

          case lCampoEspecial of
            'AUTH_NAME': lUser := lCampo;
            'AUTH_USERNAME': lUsername := lCampo;
            'AUTH_PASSWORD_CLEAR':
              begin
                lPassword := lCampo;
                lUsarMd5 := False;
              end;
            'AUTH_PASSWORD_MD5':
              begin
                lPassword := lCampo;
                lUsarMd5 := True;
              end;
          end;

          campos.Next;
        end; // while campos

        campos.Close;
        campos.Free;
        sc.Free;

        Break; // já achou
      end; // if for auth

      // próxima tabela
      tabelas.Next;
    end; // while tabelas

  end; // if recordcount

  // precisa encontra todos estes campos
  if (lPk = '') or (lUser = '') or (lUsername = '') or (lPassword = '') then lTableName := '';

  s :=
  'unit Service.Auth;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// controle do usuário no banco de dados' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, fpjson, DB, SQLDB, ZDataset, Model.UserInfo;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TServiceAuth }' + sLineBreak +
  '' + sLineBreak +
  '  TServiceAuth = class' + sLineBreak +
  '    private' + sLineBreak +
  '      FIsConectado: Boolean;' + sLineBreak +
  '      FMensagem: string;' + sLineBreak +
  '      FSucesso: Boolean;' + sLineBreak +
  '    public' + sLineBreak +
  '      constructor Create;' + sLineBreak +
  '      destructor Destroy; override;' + sLineBreak +
  '      class function New: TServiceAuth;' + sLineBreak +
  '      property GetMensagem: string read FMensagem;' + sLineBreak +
  '      property Sucesso: Boolean read FSucesso;' + sLineBreak +
  '      function ValidateLogin(ALogin, APassword: string): TModelUserInfo;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  DM.Server, Util.Criptografia;' + sLineBreak +
  '' + sLineBreak +
  '{ TServiceAuth }' + sLineBreak +
  '' + sLineBreak +
  'constructor TServiceAuth.Create;' + sLineBreak +
  'begin' + sLineBreak +
  '  FMensagem := '''';' + sLineBreak +
  '  FSucesso  := True;' + sLineBreak +
  '  FIsConectado := True;' + sLineBreak +
  '' + sLineBreak +
  '  if not DMServer.IsConnected then' + sLineBreak +
  '  begin' + sLineBreak +
  '    FMensagem := ' + QuotedStr(UtilProjetoLazarus.CRUD_DesconectadoMsg1) + ';' + sLineBreak +
  '    FSucesso  := False;' + sLineBreak +
  '    FIsConectado := False;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'destructor TServiceAuth.Destroy;' + sLineBreak +
  'begin' + sLineBreak +
  '  inherited Destroy;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TServiceAuth.New: TServiceAuth;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TServiceAuth.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TServiceAuth.ValidateLogin(ALogin, APassword: string): TModelUserInfo;' + sLineBreak +
  '// valida o usuário' + sLineBreak;
  if lPk <> '' then
    s := s +
    'var ' + sLineBreak +
    '  q: ' + lQuery + sLineBreak;
  s := s +
  'begin' + sLineBreak +
  '  Result := TModelUserInfo.Create();' + sLineBreak +
  '' + sLineBreak;

  if lPk <> '' then begin
    s := s +
    '  try ' + sLineBreak +
    '    q := DMServer.NewQuery(); ' + sLineBreak +
    ' ' + sLineBreak +
    '    q.SQL.Add(''SELECT ''); ' + sLineBreak +
    '    q.SQL.Add(''' + lPk + ', ' + lUser + ' ''); ' + sLineBreak +
    '    q.SQL.Add(''FROM ' + lTableName + ' ''); ' + sLineBreak +
    '    q.SQL.Add(''WHERE ' + lUsername + ' = :username ''); ' + sLineBreak +
    '    q.SQL.Add(''AND ' + lPassword + ' = :password ''); ' + sLineBreak +

    '' + sLineBreak +
    '    q.ParamByName(''username'').AsString := ALogin; ' + sLineBreak;

    if lUsarMd5 then
      s := s +
      '    q.ParamByName(''password'').AsString := TCriptografa.new.Encrypt_MD5(APassword);' + sLineBreak
    else
      s := s +
      '    q.ParamByName(''password'').AsString := APassword;' + sLineBreak;

    s := s +
    '    ' + sLineBreak +
    '    q.Open; ' + sLineBreak +
    ' ' + sLineBreak +
    '    if not q.EOF then begin ' + sLineBreak +
    '      Result.Id := q.FieldByName(' + QuotedStr(lPk) + ').AsInteger; ' + sLineBreak +
    '      Result.Name := q.FieldByName(' + QuotedStr(lUser) + ').AsString; ' + sLineBreak +
    '      Result.Login := ALogin; ' + sLineBreak +
    '    end; ' + sLineBreak +
    ' ' + sLineBreak +
    '    q.Close; ' + sLineBreak +
    '    q.Free; ' + sLineBreak +
    '  except ' + sLineBreak +
    '    on E: Exception do ' + sLineBreak +
    '      q.Free; ' + sLineBreak +
    '  end; ' + sLineBreak;
  end else
  s := s +
  '  if (ALogin = ''admin'') and (APassword = ''123'') then begin' + sLineBreak +
  '    Result.Id := 1;' + sLineBreak +
  '    Result.Name := ''Administrador'';' + sLineBreak +
  '    Result.Login := ALogin;' + sLineBreak +
  '  end;' + sLineBreak;

  s := s +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaServices + 'service.auth.pas', s);
  s := '';
  tabelas.Close;
  tabelas.Free;
  st.Free;
end;

procedure TProjetoLazarusAPI.GerarCore_HTMLResponse;
var
  s: string;
begin
  s :=
  'unit Core.HTMLResponse;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, HTTPDefs;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { THtmlResponse }' + sLineBreak +
  '' + sLineBreak +
  '  THtmlResponse = class' + sLineBreak +
  '    public' + sLineBreak +
  '      class function Index(const AApiName: string): string;' + sLineBreak +
  '      class function Build404HTML(const AURI: String): String;' + sLineBreak +
  '      class function RecursoNaoEncontrado(const AURI, AEmail, AAssunto, ABody: string): string;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  '{ THtmlResponse }' + sLineBreak +
  '' + sLineBreak +
  'class function THtmlResponse.Index(const AApiName: string): string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result :=' + sLineBreak +
  '  ''<!DOCTYPE html>'' + sLineBreak +' + sLineBreak +
  '  ''<html lang="pt-br">'' + sLineBreak +' + sLineBreak +
  '  ''<head>'' + sLineBreak +' + sLineBreak +
  '  ''<meta charset="UTF-8">'' + sLineBreak +' + sLineBreak +
  '  ''<meta name="viewport" content="width=device-width, initial-scale=1.0">'' + sLineBreak +' + sLineBreak +
  '  ''<title>'' + AApiName + ''</title>'' + sLineBreak +' + sLineBreak +
  '  ''<link rel="icon" type="image/x-icon" href="/favicon.ico">'' + sLineBreak +' + sLineBreak +
  '  ''<style>'' + sLineBreak +' + sLineBreak +
  '  ''body {'' + sLineBreak +' + sLineBreak +
  '  ''margin: 0;'' + sLineBreak +' + sLineBreak +
  '  ''padding: 0;'' + sLineBreak +' + sLineBreak +
  '  ''font-family: ''''Segoe UI'''', Tahoma, Geneva, Verdana, sans-serif;'' + sLineBreak +' + sLineBreak +
  '  ''background-color: #f4f7f6;'' + sLineBreak +' + sLineBreak +
  '  ''display: flex;'' + sLineBreak +' + sLineBreak +
  '  ''justify-content: center;'' + sLineBreak +' + sLineBreak +
  '  ''align-items: center;'' + sLineBreak +' + sLineBreak +
  '  ''min-height: 100vh;'' + sLineBreak +' + sLineBreak +
  '  ''color: #333;'' + sLineBreak +' + sLineBreak +
  '  ''}'' + sLineBreak +' + sLineBreak +
  '  ''.container {'' + sLineBreak +' + sLineBreak +
  '  ''text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''background: #ffffff;'' + sLineBreak +' + sLineBreak +
  '  ''padding: 20px 20px;'' + sLineBreak +' + sLineBreak +
  '  ''border-radius: 12px;'' + sLineBreak +' + sLineBreak +
  '  ''box-shadow: 0 4px 15px rgba(0,0,0,0.1);'' + sLineBreak +' + sLineBreak +
  '  ''max-width: 400px;'' + sLineBreak +' + sLineBreak +
  '  ''width: 90%;'' + sLineBreak +' + sLineBreak +
  '  ''}'' + sLineBreak +' + sLineBreak +
  '  ''.logo {'' + sLineBreak +' + sLineBreak +
  '  ''max-width: 150px;'' + sLineBreak +' + sLineBreak +
  '  ''margin-bottom: 20px;'' + sLineBreak +' + sLineBreak +
  '  ''}'' + sLineBreak +' + sLineBreak +
  '  ''h1 {'' + sLineBreak +' + sLineBreak +
  '  ''font-size: 1.5rem;'' + sLineBreak +' + sLineBreak +
  '  ''color: #d9534f; /* Tom de alerta */'' + sLineBreak +' + sLineBreak +
  '  ''margin-bottom: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''}'' + sLineBreak +' + sLineBreak +
  '  ''p {'' + sLineBreak +' + sLineBreak +
  '  ''font-size: 1rem;'' + sLineBreak +' + sLineBreak +
  '  ''line-height: 1.5;'' + sLineBreak +' + sLineBreak +
  '  ''color: #666;'' + sLineBreak +' + sLineBreak +
  '  ''margin-bottom: 25px;'' + sLineBreak +' + sLineBreak +
  '  ''}'' + sLineBreak +' + sLineBreak +
  '  ''.company-info {'' + sLineBreak +' + sLineBreak +
  '  ''font-size: 0.85rem;'' + sLineBreak +' + sLineBreak +
  '  ''border-top: 1px solid #eee;'' + sLineBreak +' + sLineBreak +
  '  ''padding-top: 20px;'' + sLineBreak +' + sLineBreak +
  '  ''margin-bottom: 20px;'' + sLineBreak +' + sLineBreak +
  '  ''}'' + sLineBreak +' + sLineBreak +
  '  ''.qr-code {'' + sLineBreak +' + sLineBreak +
  '  ''width: 120px;'' + sLineBreak +' + sLineBreak +
  '  ''height: 120px;'' + sLineBreak +' + sLineBreak +
  '  ''margin: 0 auto 10px;'' + sLineBreak +' + sLineBreak +
  '  ''background-color: #eee; /* Placeholder para o QR Code */'' + sLineBreak +' + sLineBreak +
  '  ''display: flex;'' + sLineBreak +' + sLineBreak +
  '  ''align-items: center;'' + sLineBreak +' + sLineBreak +
  '  ''justify-content: center;'' + sLineBreak +' + sLineBreak +
  '  ''}'' + sLineBreak +' + sLineBreak +
  '  ''.footer-text {'' + sLineBreak +' + sLineBreak +
  '  ''font-size: 0.8rem;'' + sLineBreak +' + sLineBreak +
  '  ''color: #999;'' + sLineBreak +' + sLineBreak +
  '  ''}'' + sLineBreak +' + sLineBreak +
  '  ''</style>'' + sLineBreak +' + sLineBreak +
  '  ''</head>'' + sLineBreak +' + sLineBreak +
  '  ''<body>'' + sLineBreak +' + sLineBreak +
  '  ''<div class="container">'' + sLineBreak +' + sLineBreak +
  '  ''<!-- Logotipo da Empresa -->'' + sLineBreak +' + sLineBreak +
  '  ''<img src="/images/logo.png" alt="Logotipo" class="logo">'' + sLineBreak +' + sLineBreak +
  '  '''' + sLineBreak +' + sLineBreak +
  '  ''<div class="company-info">'' + sLineBreak +' + sLineBreak +
  '  ''<h2>'' + AApiName + ''</h2>'' + sLineBreak +' + sLineBreak +
  '  ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''<br><br><br>'' + sLineBreak +' + sLineBreak +
  '  ''<div class="footer-text">'' + sLineBreak +' + sLineBreak +
  '  ''Criado por TOPAZZIO © 2026'' + sLineBreak +' + sLineBreak +
  '  ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''</body>'' + sLineBreak +' + sLineBreak +
  '  ''</html>'' + sLineBreak +' + sLineBreak +
  '  '''' + sLineBreak;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function THtmlResponse.Build404HTML(const AURI: String): String;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result :=' + sLineBreak +
  '    ''<!DOCTYPE html>'' +' + sLineBreak +
  '    ''<html lang="pt-BR">'' +' + sLineBreak +
  '    ''<head>'' +' + sLineBreak +
  '    ''  <meta charset="utf-8">'' +' + sLineBreak +
  '    ''  <meta name="viewport" content="width=device-width, initial-scale=1">'' +' + sLineBreak +
  '    ''  <title>404 - Recurso não encontrado</title>'' +' + sLineBreak +
  '    ''  <style>'' +' + sLineBreak +
  '    ''    body {'' +' + sLineBreak +
  '    ''      margin:0; padding:0;'' +' + sLineBreak +
  '    ''      font-family:Segoe UI, Arial, sans-serif;'' +' + sLineBreak +
  '    ''      background:linear-gradient(135deg,#0f172a,#1e293b);'' +' + sLineBreak +
  '    ''      color:#f8fafc;'' +' + sLineBreak +
  '    ''      display:flex;'' +' + sLineBreak +
  '    ''      align-items:center;'' +' + sLineBreak +
  '    ''      justify-content:center;'' +' + sLineBreak +
  '    ''      height:100vh;'' +' + sLineBreak +
  '    ''    }'' +' + sLineBreak +
  '    ''    .card {'' +' + sLineBreak +
  '    ''      max-width:700px;'' +' + sLineBreak +
  '    ''      background:#ffffff;'' +' + sLineBreak +
  '    ''      color:#0f172a;'' +' + sLineBreak +
  '    ''      border-radius:16px;'' +' + sLineBreak +
  '    ''      padding:40px;'' +' + sLineBreak +
  '    ''      box-shadow:0 20px 60px rgba(0,0,0,0.35);'' +' + sLineBreak +
  '    ''      text-align:center;'' +' + sLineBreak +
  '    ''    }'' +' + sLineBreak +
  '    ''    h1 {'' +' + sLineBreak +
  '    ''      margin:0;'' +' + sLineBreak +
  '    ''      font-size:72px;'' +' + sLineBreak +
  '    ''      color:#ef4444;'' +' + sLineBreak +
  '    ''    }'' +' + sLineBreak +
  '    ''    h2 {'' +' + sLineBreak +
  '    ''      margin:10px 0 20px 0;'' +' + sLineBreak +
  '    ''      font-size:28px;'' +' + sLineBreak +
  '    ''    }'' +' + sLineBreak +
  '    ''    .uri {'' +' + sLineBreak +
  '    ''      margin:20px 0;'' +' + sLineBreak +
  '    ''      padding:12px;'' +' + sLineBreak +
  '    ''      background:#f1f5f9;'' +' + sLineBreak +
  '    ''      border-radius:8px;'' +' + sLineBreak +
  '    ''      font-family:monospace;'' +' + sLineBreak +
  '    ''      word-break:break-all;'' +' + sLineBreak +
  '    ''    }'' +' + sLineBreak +
  '    ''    a {'' +' + sLineBreak +
  '    ''      display:inline-block;'' +' + sLineBreak +
  '    ''      margin-top:20px;'' +' + sLineBreak +
  '    ''      padding:12px 24px;'' +' + sLineBreak +
  '    ''      background:#2563eb;'' +' + sLineBreak +
  '    ''      color:#fff;'' +' + sLineBreak +
  '    ''      text-decoration:none;'' +' + sLineBreak +
  '    ''      border-radius:8px;'' +' + sLineBreak +
  '    ''      font-weight:bold;'' +' + sLineBreak +
  '    ''    }'' +' + sLineBreak +
  '    ''    a:hover {'' +' + sLineBreak +
  '    ''      background:#1d4ed8;'' +' + sLineBreak +
  '    ''    }'' +' + sLineBreak +
  '    ''  </style>'' +' + sLineBreak +
  '    ''</head>'' +' + sLineBreak +
  '    ''<body>'' +' + sLineBreak +
  '    ''  <div class="card">'' +' + sLineBreak +
  '    ''    <h1>404</h1>'' +' + sLineBreak +
  '    ''    <h2>Recurso não encontrado</h2>'' +' + sLineBreak +
  '    ''    <p>O recurso solicitado não foi localizado no servidor.</p>'' +' + sLineBreak +
  '    ''    <div class="uri">'' + AURI + ''</div>'' +' + sLineBreak +
  '    ''    <a href="/">Voltar para a página inicial</a>'' +' + sLineBreak +
  '    ''  </div>'' +' + sLineBreak +
  '    ''</body>'' +' + sLineBreak +
  '    ''</html>'';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function THtmlResponse.RecursoNaoEncontrado(const AURI, AEmail, AAssunto, ABody: string): string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result :=' + sLineBreak +
  '  ''<!DOCTYPE html>'' + sLineBreak +' + sLineBreak +
  '  ''<html lang="pt-br">'' + sLineBreak +' + sLineBreak +
  '  ''<head>'' + sLineBreak +' + sLineBreak +
  '  ''    <meta charset="UTF-8">'' + sLineBreak +' + sLineBreak +
  '  ''    <meta name="viewport" content="width=device-width, initial-scale=1.0">'' + sLineBreak +' + sLineBreak +
  '  ''    <title>Recurso não Encontrado</title>'' + sLineBreak +' + sLineBreak +
  '  ''    <link rel="icon" type="image/x-icon" href="/favicon.ico">'' + sLineBreak +' + sLineBreak +
  '  ''    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>'' + sLineBreak +' + sLineBreak +
  '  ''    <style>'' + sLineBreak +' + sLineBreak +
  '  ''        body {'' + sLineBreak +' + sLineBreak +
  '  ''            margin: 0;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 0;'' + sLineBreak +' + sLineBreak +
  '  ''            font-family: ''''Segoe UI'''', Tahoma, Geneva, Verdana, sans-serif;'' + sLineBreak +' + sLineBreak +
  '  ''            background-color: #f4f7f6;'' + sLineBreak +' + sLineBreak +
  '  ''            display: flex;'' + sLineBreak +' + sLineBreak +
  '  ''            justify-content: center;'' + sLineBreak +' + sLineBreak +
  '  ''            align-items: center;'' + sLineBreak +' + sLineBreak +
  '  ''            min-height: 100vh;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #333;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .container {'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''            background: #ffffff;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 20px 20px;'' + sLineBreak +' + sLineBreak +
  '  ''            border-radius: 12px;'' + sLineBreak +' + sLineBreak +
  '  ''            box-shadow: 0 4px 15px rgba(0,0,0,0.1);'' + sLineBreak +' + sLineBreak +
  '  ''            max-width: 400px;'' + sLineBreak +' + sLineBreak +
  '  ''            width: 90%;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .logo {'' + sLineBreak +' + sLineBreak +
  '  ''            max-width: 150px;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 20px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        h1 {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 1.5rem;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #d9534f; /* Tom de alerta */'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        p {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 1rem;'' + sLineBreak +' + sLineBreak +
  '  ''            line-height: 1.5;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #666;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 25px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .company-info {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 0.85rem;'' + sLineBreak +' + sLineBreak +
  '  ''            border-top: 1px solid #eee;'' + sLineBreak +' + sLineBreak +
  '  ''            padding-top: 20px;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 20px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .qr-code {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 120px;'' + sLineBreak +' + sLineBreak +
  '  ''            height: 120px;'' + sLineBreak +' + sLineBreak +
  '  ''            margin: 0 auto 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            background-color: #eee; /* Placeholder para o QR Code */'' + sLineBreak +' + sLineBreak +
  '  ''            display: flex;'' + sLineBreak +' + sLineBreak +
  '  ''            align-items: center;'' + sLineBreak +' + sLineBreak +
  '  ''            justify-content: center;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .footer-text {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 0.8rem;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #999;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .uri {'' +' + sLineBreak +
  '  ''          margin:20px 0;'' +' + sLineBreak +
  '  ''          padding:12px;'' +' + sLineBreak +
  '  ''          background:#f1f5f9;'' +' + sLineBreak +
  '  ''          border-radius:8px;'' +' + sLineBreak +
  '  ''          font-family:monospace;'' +' + sLineBreak +
  '  ''          word-break:break-all;'' +' + sLineBreak +
  '  ''        }'' +' + sLineBreak +
  '  ''    </style>'' + sLineBreak +' + sLineBreak +
  '  ''</head>'' + sLineBreak +' + sLineBreak +
  '  ''<body>'' + sLineBreak +' + sLineBreak +
  '  ''<div class="container">'' + sLineBreak +' + sLineBreak +
  '  ''    <!-- Logotipo da Empresa -->'' + sLineBreak +' + sLineBreak +
  '  ''    <img src="/images/logo.png" alt="Logotipo" class="logo">'' + sLineBreak +' + sLineBreak +
  '  ''    <div class="company-info">'' + sLineBreak +' + sLineBreak +
  '  ''      <h3>Api fluxo de caixa</h3>'' + sLineBreak +' + sLineBreak +
  '  ''    </div>'' + sLineBreak +' + sLineBreak +
  '  ''    '' + sLineBreak +' + sLineBreak +
  '  ''    <h1>Oops! Algo deu errado.</h1>'' + sLineBreak +' + sLineBreak +
  '  ''    '' + sLineBreak +' + sLineBreak +
  '  ''    <!-- Mensagem Dinâmica -->'' + sLineBreak +' + sLineBreak +
  '  ''    <p>O recurso solicitado não pôde ser encontrado ou está temporariamente indisponível.</p>'' + sLineBreak +' + sLineBreak +
  '  ''    <div class="uri">'' + AURI + ''</div>'' +' + sLineBreak +
  '  '''' + sLineBreak +' + sLineBreak +
  '  ''    <div class="company-info">'' + sLineBreak +' + sLineBreak +
  '  ''      Suporte Técnico Especializado'' + sLineBreak +' + sLineBreak +
  '  ''    </div>'' + sLineBreak +' + sLineBreak +
  '  '''' + sLineBreak +' + sLineBreak +
  '  ''    <!-- QR Code de Contato -->'' + sLineBreak +' + sLineBreak +
  '  ''    <center>'' + sLineBreak +' + sLineBreak +
  '  ''    <div id="qrcode-container" style="position: relative; width: 200px; height: 200px;">   '' + sLineBreak +' + sLineBreak +
  '  ''      <div id="qrcode"></div>   '' + sLineBreak +' + sLineBreak +
  '  ''      <img id="logo" src="/images/logo_qr.png" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); width: 50px; height: 50px; border: 4px solid white; background: white; border-radius: 8px;"> '' + sLineBreak +' + sLineBreak +
  '  ''    </div>'' + sLineBreak +' + sLineBreak +
  '  ''    </center>'' + sLineBreak +' + sLineBreak +
  '  ''    <br>'' + sLineBreak +' + sLineBreak +
  '  ''    <div class="footer-text">'' + sLineBreak +' + sLineBreak +
  '  ''        Aponte a câmera para entrar em contato via e-mail.        '' + sLineBreak +' + sLineBreak +
  '  ''    </div>'' + sLineBreak +' + sLineBreak +
  '  ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''<script> '' + sLineBreak +' + sLineBreak +
  '  ''  var qrcode = new QRCode(document.getElementById("qrcode"), { text: "mailto:'' + HTTPEncode(AEmail) + ''?subject='' + HTTPEncode(AAssunto) + ''&body='' + HTTPEncode(ABody) + ''", width: 200, height: 200, colorDark: "#000000", colorLight: "#ffffff", correctLevel: QRCode.CorrectLevel.H }); '' + sLineBreak +' + sLineBreak +
  '  ''</script>'' + sLineBreak +' + sLineBreak +
  '  ''</body>'' + sLineBreak +' + sLineBreak +
  '  ''</html>'' + sLineBreak +' + sLineBreak +
  '  '''' + sLineBreak;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.htmlresponse.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GerarClasse(qryCampos: TZQuery);
//gera a clase do crud
var
  f: array of string;
  i, j, cTop, cLeft, lMaxLen, lScale: Integer;
  s, lObjeto, lCampo, lCampoPK, lcampoChavePrimaria, lComponente, lTabela: string;
  lPesquisaCampo, lListaCampos, lFields, lTipoBanco: string;
  bAchou_campo_estrangeiro, bCampoAceito: Boolean;
  bChavePrimaria, bChaveEstrangeira, bGrid, bComboBox, bImagem, bCurrencyField, bCampoValido: Boolean;
  lProceduresComboBox, lEditPlus, lcampoObjeto, lcampoDBTipo, lcampoTipo: string;
  lFK_Tabela, lFK_Codigo, lFK_Texto, lcomboLista, lcampo_estrangeiro: string;
  lCount, lQdePorColuna, lQdeRegistros, lQdeRegistrosEstrangeiros, lQdeItensGrid: Integer;
begin
  qryCampos.First;
  if qryCampos.FieldByName('chave_primaria').AsInteger <> 1 then exit;
  lObjeto := qryCampos.FieldByName('nome_objeto').AsString; //tabela objeto
  lTabela := qryCampos.FieldByName('tabela').AsString; //nome da tabela original
  lTipoBanco := qryCampos.FieldByName('tipo_banco').AsString; //sqlite, mysql, mariadb, mssql, oracle, postgresql, firebird
  lQdeItensGrid := qryCampos.FieldByName('qdeitensgrid').AsInteger;
  lQdeRegistros := qryCampos.RecordCount;
  lQdeRegistrosEstrangeiros := 0;

  lObjeto := lObjeto + FVersaoAbreviadaRota;

  s :=
  'unit Service.' + lObjeto + '; ' + sLineBreak +
  ' ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+} ' + sLineBreak +
  ' ' + sLineBreak +
  'interface ' + sLineBreak +
  ' ' + sLineBreak +
  'uses ' + sLineBreak +
  '  Classes, SysUtils, DB, SQLDB';

  if FTipoBanco <> SQLSERVER then
    s := s + ', ZDataset';

  s := s +
  ';' + sLineBreak +
  ' ' + sLineBreak +
  'type ' + sLineBreak +
  ' ' + sLineBreak +
  '  { TService' + lObjeto + ' } ' + sLineBreak +
  ' ' + sLineBreak +
  '  TService' + lObjeto + ' = class ' + sLineBreak +
  '    private ' + sLineBreak +
  '      FIsConectado: Boolean; ' + sLineBreak +
  '      FMensagem: string; ' + sLineBreak +
  '      FSucesso: Boolean; ' + sLineBreak;

  { private - declaração dos campos }

  lCampoPK := ''; //ID nesta tabela
  bChavePrimaria := False;
  bChaveEstrangeira := False;
  bImagem := False;
  bComboBox := False;
  bGrid := False;
  lPesquisaCampo := '';
  lListaCampos := '';
  lcampoChavePrimaria := '';
  lcampo_estrangeiro := '';
  bAchou_campo_estrangeiro := False;

  qryCampos.First;
  while not qryCampos.EOF do begin
    lCampo  := qryCampos.FieldByName('campo').AsString;
    lcampoObjeto := qryCampos.FieldByName('objeto').AsString;
    lcampoDBTipo := LowerCase(qryCampos.FieldByName('tipo').AsString); //tipo de campo no DB
    lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    lComponente := qryCampos.FieldByName('componente').AsString; //TEdit, TMemo, TDateTime, TImage, TCheckbox, TCombobox
    bCurrencyField := qryCampos.FieldByName('currency_field').AsInteger = 1;
    bChavePrimaria := (qryCampos.FieldByName('chave_primaria').AsInteger = 1);
    lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
    lFK_Texto := Trim(qryCampos.FieldByName('fk_texto').AsString);
    lcomboLista := Trim(qryCampos.FieldByName('combo_lista').AsString);
    bChaveEstrangeira := ((qryCampos.FieldByName('chave_estrangeira').AsInteger = 1) and (Length(lFK_Tabela) > 0));
    lMaxLen := StrToIntDef('0' + qryCampos.FieldByName('tamanho').AsString, 50); //MaxLength do campo
    lScale  := StrToIntDef('0' + qryCampos.FieldByName('escala').AsString, 2);   //casas decimais

    bCampoAceito := (lcampoTipo.ToLower <> 'timage'); // recusa se for imagem

    if bCampoAceito then begin
      // há referência de chave estrangeira desta tabela em outra tabela ?
      lcampo_estrangeiro := Trim(qryCampos.FieldByName('campo_estrangeiro').AsString); //fk_texto
      bAchou_campo_estrangeiro := ( (Length(lcampo_estrangeiro) > 0) and (lCampo = lcampo_estrangeiro) );

      //tem combobox com carga via tabela ?
      if (lComponente.ToLower = 'tcombobox') and ( (lFK_Tabela <> '') or (lcomboLista <> '') ) then
        bComboBox := True;

      //Criar grid ?
      if (qryCampos.FieldByName('incluir_na_grid').AsInteger = 1) then
        bGrid := True;

      //campo de pesquisa (where) na Grid
      if bGrid and (lPesquisaCampo = '') and
         (LowerCase(qryCampos.FieldByName('tipo_fp').AsString) = 'string') then
         lPesquisaCampo := lCampo;

      //Campo chave primária
      if (lCampoPK = '') and bChavePrimaria then begin
        bChavePrimaria := True;
        lCampoPK := lCampo;
        lcampoChavePrimaria := lcampoObjeto;
      end;

      //campos para Insert/Update e Read
      if (lCampo <> lCampoPK) and not bChavePrimaria then begin
        if lListaCampos <> '' then lListaCampos := lListaCampos + ', ';
        lListaCampos := lListaCampos + lCampo;
      end;

      //quantidade de registros de tabelas estrangeira
      if bChaveEstrangeira or ((qryCampos.FieldByName('incluir_na_grid').AsInteger = 0) and bChavePrimaria) then
        lQdeRegistrosEstrangeiros := lQdeRegistrosEstrangeiros + 1;

      case lcampoTipo.ToLower of
        'string':
          begin
            s := s +
            '      F' + lcampoObjeto + ': string; ' + sLineBreak;
          end;
        'integer':
          begin
            if lComponente.ToLower = 'tcheckbox' then
              s := s +
              '      F' + lcampoObjeto + ': Boolean; ' + sLineBreak
            else
            begin
              s := s +
              '      F' + lcampoObjeto + ': Integer; ' + sLineBreak;

              if bChaveEstrangeira then
                s := s +
                '      FFK_' + TUtilCommon.CapitalizaTexto( lFK_Texto ) + ': string; ' + sLineBreak;
            end;
          end;
        'currency':
          begin
            s := s +
            '      F' + lcampoObjeto + ': Currency; ' + sLineBreak;
          end;
        'double':
          begin
            s := s +
            '      F' + lcampoObjeto + ': Double; ' + sLineBreak;
          end;
        'timage':
          begin
            s := s +
            '      F' + lcampoObjeto + ': TImage; ' + sLineBreak;

            bImagem := True;
          end;
        'tdatetime':
          begin
            s := s +
            '      F' + lcampoObjeto + ': TDateTime; ' + sLineBreak;
          end;
        else
          s := s +
          '      F' + lcampoObjeto + ': string; ' + sLineBreak;
      end;
    end;

    qryCampos.Next;
  end; //while

  { public - property, procedure, function }

  s := s +
  '    public ' + sLineBreak +
  '      constructor Create; ' + sLineBreak +
  '      destructor Destroy; override; ' + sLineBreak;

  qryCampos.First;
  while not qryCampos.EOF do begin
    lCampo  := qryCampos.FieldByName('campo').AsString;
    lcampoObjeto := qryCampos.FieldByName('objeto').AsString;
    lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    lComponente := qryCampos.FieldByName('componente').AsString; //TEdit, TMemo, TDateTime, TImage, TCheckbox, TCombobox
    bChavePrimaria := (qryCampos.FieldByName('chave_primaria').AsInteger = 1);
    lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
    lFK_Texto := Trim(qryCampos.FieldByName('fk_texto').AsString);
    bChaveEstrangeira := ((qryCampos.FieldByName('chave_estrangeira').AsInteger = 1) and (Length(lFK_Tabela) > 0));
    lcomboLista := Trim(qryCampos.FieldByName('combo_lista').AsString);
    bCurrencyField := qryCampos.FieldByName('currency_field').AsInteger = 1;
    lMaxLen := StrToIntDef('0' + qryCampos.FieldByName('tamanho').AsString, 50); //MaxLength do campo
    lScale  := StrToIntDef('0' + qryCampos.FieldByName('escala').AsString, 2);   //casas decimais

    bCampoAceito := (lcampoTipo.ToLower <> 'timage'); // recusa se for imagem

    if bCampoAceito then begin
      case lcampoTipo.ToLower of
        'string':
          begin
            s := s +
            '      property ' + lcampoObjeto + ': string read F' + lcampoObjeto + ' write F' + lcampoObjeto + '; ' + sLineBreak;
          end;
        'integer':
          begin
            if bChavePrimaria then
              s := s +
              '      property ' + lcampoObjeto + ': Integer read F' + lcampoObjeto + '; ' + sLineBreak
            else if lComponente.ToLower = 'tcheckbox' then
              s := s +
              '      property ' + lcampoObjeto + ': Boolean read F' + lcampoObjeto + ' write F' + lcampoObjeto + '; ' + sLineBreak
            else
            begin
              s := s +
              '      property ' + lcampoObjeto + ': Integer read F' + lcampoObjeto + ' write F' + lcampoObjeto + '; ' + sLineBreak;

              if bChaveEstrangeira then
                s := s +
                '      property FK_' + TUtilCommon.CapitalizaTexto( lFK_Texto ) + ': string read FFK_' + TUtilCommon.CapitalizaTexto( lFK_Texto ) + ' write FFK_' + TUtilCommon.CapitalizaTexto( lFK_Texto ) + '; ' + sLineBreak;
            end;
          end;
        'currency':
          begin
            s := s +
            '      property ' + lcampoObjeto + ': Currency read F' + lcampoObjeto + ' write F' + lcampoObjeto + '; ' + sLineBreak;
          end;
        'double':
          begin
            s := s +
            '      property ' + lcampoObjeto + ': Double read F' + lcampoObjeto + ' write F' + lcampoObjeto + '; ' + sLineBreak;
          end;
        'timage':
          begin
            s := s +
            '      property ' + lcampoObjeto + ': TImage read F' + lcampoObjeto + ' write F' + lcampoObjeto + '; ' + sLineBreak;
          end;
        'tdatetime':
          begin
            s := s +
            '      property ' + lcampoObjeto + ': TDateTime read F' + lcampoObjeto + ' write F' + lcampoObjeto + '; ' + sLineBreak;
          end;
        else
        begin
          s := s +
          '      property ' + lcampoObjeto + ': string read F' + lcampoObjeto + ' write F' + lcampoObjeto + '; ' + sLineBreak;
        end;
      end;
    end;


    qryCampos.Next;
  end; //while

  // Procedures

  s := s +
  '      property GetMensagem: string read FMensagem; ' + sLineBreak +
  '      property Sucesso: Boolean read FSucesso; ' + sLineBreak +
  '      procedure Salvar(AId: integer); ' + sLineBreak +
  '      procedure Excluir(AId: integer); ' + sLineBreak +
  '      procedure Ler(AId: integer); ' + sLineBreak;

  if bComboBox then begin
    qryCampos.First;
    while not qryCampos.EOF do begin
      lCampo  := qryCampos.FieldByName('campo').AsString;
      lcampoObjeto := qryCampos.FieldByName('objeto').AsString;
      lcampoDBTipo := qryCampos.FieldByName('tipo').AsString;
      lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
      lComponente := qryCampos.FieldByName('componente').AsString; //TEdit, TMemo, TDateTime, TImage, TCheckbox, TCombobox
      lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
      lFK_Texto := Trim(qryCampos.FieldByName('fk_texto').AsString);
      lcomboLista := Trim(qryCampos.FieldByName('combo_lista').AsString);

      case lComponente.ToLower of
        'tcombobox':
          if lFK_Tabela <> '' then // carrega a combo via banco de dados
            s := s +
            '      procedure CarregaComboBox' + TUtilCommon.RemoveFieldUnderscore( lFK_Tabela ) + '(var AComboBox: TComboBox; AIdSelect: Integer = -1); ' + sLineBreak
          else if lcomboLista <> '' then  //carrega a combo via lista manual
            s := s +
            '      procedure CarregaComboBox' + lcampoObjeto + '(var AComboBox: TComboBox; AIdSelect: Integer = -1); ' + sLineBreak;
       end;

      qryCampos.Next;
    end; //while
  end;

  if bGrid and (lQdeItensGrid > 0) then
    s := s +
    '      function DataSetGrid(ASearch: String; AFirstRow: Integer = 0; AMaxRows: Integer = 100): TDataSource; ' + sLineBreak;

  s := s +
  '  end; ' + sLineBreak +
  ' ' + sLineBreak +
  'implementation ' + sLineBreak +
  ' ' + sLineBreak +
  'uses ' + sLineBreak +
  '  DM.Server';

  if bImagem then
    s := s +
    ', Util.Imagem';

  if bComboBox then
    s := s +
    ', Util.ComboBoxItemData';

  s := s + ';' + sLineBreak +
  ' ' + sLineBreak +
  '{ TService' + lObjeto + ' } ' + sLineBreak +
  ' ' + sLineBreak +
  'constructor TService' + lObjeto + '.Create; ' + sLineBreak +  // Constructor
  'begin ' + sLineBreak +
  '  FMensagem := ''''; ' + sLineBreak +
  '  FSucesso  := True; ' + sLineBreak +
  '  FIsConectado := True; ' + sLineBreak;

  { Instancia objetos TImage }

  if bImagem then begin
    qryCampos.First;
    while not qryCampos.EOF do begin
      lcampoObjeto := qryCampos.FieldByName('objeto').AsString;
      lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage

      case lcampoTipo.ToLower of
        'timage':
          begin
            s := s +
            '  F' + lcampoObjeto + ' := TImage.Create(nil); ' + sLineBreak;
          end;
      end;

      qryCampos.Next;
    end; //while
  end;

  s := s +
  ' ' + sLineBreak +
  '  if not DMServer.IsConnected then ' + sLineBreak +
  '  begin ' + sLineBreak +
  '    FMensagem := ' + QuotedStr( UtilProjetoLazarus.CRUD_DesconectadoMsg1 ) + '; ' + sLineBreak +
  '    FSucesso  := False; ' + sLineBreak +
  '    FIsConectado := False; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'destructor TService' + lObjeto + '.Destroy; ' + sLineBreak +   // Destructor
  'begin ' + sLineBreak;

  if bImagem then begin
    qryCampos.First;
    while not qryCampos.EOF do begin
      lcampoObjeto := qryCampos.FieldByName('objeto').AsString;
      lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage

      case lcampoTipo.ToLower of
        'timage':
          s := s +
          '  if Assigned(F' + lcampoObjeto + ') then F' + lcampoObjeto + '.Free; ' + sLineBreak;
      end;

      qryCampos.Next;
    end;
  end;

  { INSERT e UPDATE do Registro }

  lQdePorColuna := 6;  //campos por linha

  s := s +
  '  inherited Destroy; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TService' + lObjeto + '.Salvar(AId: integer); ' + sLineBreak +
  '//salva o registro (saves data) ' + sLineBreak +
  'var ' + sLineBreak;

  if FTipoBanco = SQLSERVER then
    s := s + '  q: TSQLQuery; ' + sLineBreak
  else
    s := s + '  q: TZQuery; ' + sLineBreak;

  s := s +
  'begin ' + sLineBreak +
  '  if not FIsConectado then Exit; ' + sLineBreak +
  '  FMensagem := ''''; ' + sLineBreak +
  '  FSucesso  := False; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    q := DMServer.NewQuery(); ' + sLineBreak +
  ' ' + sLineBreak +
  '    if AId < 1 then ' + sLineBreak +
  '    begin ' + sLineBreak +
  '      q.SQL.Add(''INSERT INTO ' + lTabela + ' ''); ' + sLineBreak +
  '      q.SQL.Add(''( ''); ' + sLineBreak; //descricao, valor, data, plano, idcidade, foto) ''); ' + sLineBreak +

  // Insert - Lista de campos

  i := 0;
  lCount := 0;
  lFields := '';
  qryCampos.First;
  while not qryCampos.EOF do begin
    lCampo := qryCampos.FieldByName('campo').AsString;
    lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString;
    bCampoAceito := (lcampoTipo.ToLower <> 'timage'); // recusa se for imagem

    if bCampoAceito then begin
      i := i + 1;

      if lCampo <> lCampoPK then begin
        if lFields <> '' then lFields := lFields + ', ';
        lFields := lFields + lCampo;
        lCount := lCount + 1;

        if lCount >= lQdePorColuna then begin
          if i < lQdeRegistros then lFields := lFields + ', ';
          s := s +
          '      q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;

          lFields := '';
          lCount := 0;
        end;
      end;
    end;

    qryCampos.Next;
  end;

  if lFields <> '' then
    s := s +
    '      q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;

  s := s +
  '      q.SQL.Add('') ''); ' + sLineBreak; // fechamentos dos campos

  // Lista de parâmetros

  s := s +
  '      q.SQL.Add(''VALUES(''); ' + sLineBreak;

  i := 0;
  lCount := 0;
  lFields := '';
  qryCampos.First;
  while not qryCampos.EOF do begin
    lCampo := qryCampos.FieldByName('campo').AsString;
    lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString;
    bCampoAceito := (lcampoTipo.ToLower <> 'timage'); // recusa se for imagem

    if bCampoAceito then begin
      i := i + 1;

      if lCampo <> lCampoPK then begin
        if lFields <> '' then lFields := lFields + ', ';
        lFields := lFields + ':' + lCampo;
        lCount := lCount + 1;

        if lCount >= lQdePorColuna then begin
          if i < lQdeRegistros then lFields := lFields + ', ';
          s := s +
          '      q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;

          lFields := '';
          lCount := 0;
        end;
      end;
    end;

    qryCampos.Next;
  end;

  if lFields <> '' then
    s := s +
    '      q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;

  s := s +
  '      q.SQL.Add('') ''); ' + sLineBreak; //fechamento dos parâmetros

  { obtenção do novo id inserido }

  case FTipoBanco of
    POSTGRE, MARIADB, MYSQL:
      begin
        s := s +
        '      q.SQL.Add(''RETURNING ' + lCampoPK + ' as id; ''); ' + sLineBreak;
      end;
    SQLSERVER:
      begin
        s := s +
        '      q.SQL.Add(''; SELECT SCOPE_IDENTITY() as id; ''); ' + sLineBreak;
      end;
  end;

  s := s +
  '    end ' + sLineBreak +
  '    else ' + sLineBreak +
  '    begin ' + sLineBreak +
  '      q.SQL.Add(''UPDATE ' + lTabela + ' SET ''); ' + sLineBreak;

  // campos do update

  i := 0;
  lCount := 0;
  lFields := '';
  qryCampos.First;
  while not qryCampos.EOF do begin
    lCampo := qryCampos.FieldByName('campo').AsString;
    lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString;
    bCampoAceito := (lcampoTipo.ToLower <> 'timage'); // recusa se for imagem

    if bCampoAceito then begin
      i := i + 1;

      if lCampo <> lCampoPK then begin
        if lFields <> '' then lFields := lFields + ', ';
        lFields := lFields + lCampo + ' = :' + lCampo;
        lCount := lCount + 1;

        if lCount >= lQdePorColuna then begin
          if i < lQdeRegistros then lFields := lFields + ', ';
          s := s +
          '      q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;

          lFields := '';
          lCount := 0;
        end;
      end;
    end;

    qryCampos.Next;
  end;

  if lFields <> '' then
    s := s +
    '      q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;

  s := s +
  '      q.SQL.Add(''WHERE ' + lCampoPK + ' = '' + IntToStr(AId)); ' + sLineBreak +
  '    end; ' + sLineBreak +
  ' ' + sLineBreak;

  // Parâmetros

  qryCampos.First;
  while not qryCampos.EOF do begin
    lCampo  := qryCampos.FieldByName('campo').AsString;
    lcampoObjeto := qryCampos.FieldByName('objeto').AsString;
    lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    lComponente := qryCampos.FieldByName('componente').AsString; //TEdit, TMemo, TDateTime, TImage, TCheckbox, TCombobox
    bCampoAceito := (lcampoTipo.ToLower <> 'timage'); // recusa se for imagem

    if bCampoAceito then begin
      if lCampo <> lCampoPK then begin
        case lcampoTipo.ToLower of
          'string':
            begin
              s := s +
              '    q.ParamByName(''' + lCampo + ''').AsString := ' + lcampoObjeto + '; ' + sLineBreak;
            end;
          'integer':
            begin
              if lComponente.ToLower = 'tcheckbox' then
                s := s +
                '    q.ParamByName(''' + lCampo + ''').AsInteger := Ord(' + lcampoObjeto + '); ' + sLineBreak
              else
                s := s +
                '    q.ParamByName(''' + lCampo + ''').AsInteger := ' + lcampoObjeto + '; ' + sLineBreak;
            end;
          'currency':
            begin
              s := s +
              '    q.ParamByName(''' + lCampo + ''').AsFloat := ' + lcampoObjeto + '; ' + sLineBreak;
            end;
          'double':
            begin
              s := s +
              '    q.ParamByName(''' + lCampo + ''').AsFloat := ' + lcampoObjeto + '; ' + sLineBreak;
            end;
          'timage':
            begin
              if FTipoBanco = SQLSERVER then
                s := s +
                '    TUtilImagem.GetStreamSQLQuery(F' + lcampoObjeto + ', q, ''' + lCampo + '''); //carrega a imagem no sqlquery' + sLineBreak
              else
                s := s +
                '    TUtilImagem.GetStream(F' + lcampoObjeto + ', q, ''' + lCampo + '''); //carrega a imagem no zquery' + sLineBreak;
            end;
          'tdatetime':
            begin
              s := s +
              '    q.ParamByName(''' + lCampo + ''').AsDateTime := ' + lcampoObjeto + '; ' + sLineBreak;
            end;
        else
          begin
            s := s +
            '    q.ParamByName(''' + lCampo + ''').AsString := ' + lcampoObjeto + '; ' + sLineBreak;
          end;
        end;
      end;
    end;

    qryCampos.Next;
  end; //while

  if FTipoBanco <> SQLSERVER then
    s := s +
    ' ' + sLineBreak +
    '    DMServer.TransactionPrepare; ' + sLineBreak;

  { Open ou ExecSQL }

  s := s +
  ' ' + sLineBreak +
  '    if AId < 1 then ' + sLineBreak +
  '    begin ' + sLineBreak;

  { como pegar o ID inserido }

  case FTipoBanco of
    POSTGRE, SQLSERVER, MARIADB, MYSQL:
      begin
        s := s +
        '      q.Open; ' + sLineBreak +
        '      F' + lcampoChavePrimaria + ' := q.FieldByName(''id'').AsInteger; ' + sLineBreak;
      end;
    else
      begin
        s := s +
        '      q.ExecSQL; ' + sLineBreak +
        '      F' + lcampoChavePrimaria + ' := DMServer.LastInsertedID(' + QuotedStr(lCampoPK) + ', ' + QuotedStr(lTabela) + '); ' + sLineBreak;
      end;
  end;

  s := s +
  '      FMensagem := ' + QuotedStr( UtilProjetoLazarus.CRUD_SalvarMsg1 ) + '; ' + sLineBreak +
  '    end ' + sLineBreak +
  '    else ' + sLineBreak +
  '    begin ' + sLineBreak +
  '      q.ExecSQL; ' + sLineBreak +
  '      F' + lcampoChavePrimaria + ' := AId; ' + sLineBreak +
  '      FMensagem := ' + QuotedStr( UtilProjetoLazarus.CRUD_SalvarMsg2 ) + '; ' + sLineBreak +
  '    end; ' + sLineBreak +
  ' ' + sLineBreak +
  '    DMServer.TransactionCommit; ' + sLineBreak +
  ' ' + sLineBreak +
  '    FSucesso := True; ' + sLineBreak;

  { Precisa fechar o TZQuery ?}

  case FTipoBanco of
    POSTGRE, SQLSERVER:
      begin
        s := s +
        '    if AId < 1 then q.Close; ' + sLineBreak;
      end;
  end;

  s := s +
  '    q.Free; ' + sLineBreak +
  '  except ' + sLineBreak +
  '    on E: Exception do ' + sLineBreak +
  '    begin ' + sLineBreak +
  '      F' + lcampoChavePrimaria + ' := 0; ' + sLineBreak +
  '      FSucesso  := False; ' + sLineBreak +
  '      FMensagem := E.Message; ' + sLineBreak +
  '      DMServer.TransactionRollback; ' + sLineBreak +
  '      q.Free; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak;

  { EXCLUIR Registro }

  s := s +
  'procedure TService' + lObjeto + '.Excluir(AId: integer); ' + sLineBreak +
  '//exclui o registro informado (delete record)' + sLineBreak +
  'var ' + sLineBreak;

  if FTipoBanco = SQLSERVER then
    s := s + '  q: TSQLQuery; ' + sLineBreak
  else
    s := s + '  q: TZQuery; ' + sLineBreak;

  s := s +
  'begin ' + sLineBreak +
  '  if not FIsConectado then Exit; ' + sLineBreak +
  '  FMensagem := ''''; ' + sLineBreak +
  '  FSucesso  := False; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    q := DMServer.NewQuery(); ' + sLineBreak +
  ' ' + sLineBreak +
  '    q.SQL.Add(''DELETE FROM ' + lTabela + ' ''); ' + sLineBreak +
  '    q.SQL.Add(''WHERE ' + lCampoPK + ' = '' + IntToStr(AId)); ' + sLineBreak +
  ' ' + sLineBreak;

  if FTipoBanco <> SQLSERVER then
    s := s +
    '    DMServer.TransactionPrepare; ' + sLineBreak +
    ' ' + sLineBreak;

  s := s +
  '    q.ExecSQL; ' + sLineBreak +
  ' ' + sLineBreak +
  '    DMServer.TransactionCommit; ' + sLineBreak +
  ' ' + sLineBreak +
  '    FSucesso  := True; ' + sLineBreak +
  '    FMensagem := ' + QuotedStr( UtilProjetoLazarus.CRUD_ExcluirMsg1 ) + '; ' + sLineBreak +
  '    q.Free; ' + sLineBreak +
  '  except ' + sLineBreak +
  '    on E: Exception do ' + sLineBreak +
  '    begin ' + sLineBreak +
  '      FSucesso  := False; ' + sLineBreak +
  '      FMensagem := E.Message; ' + sLineBreak +
  '      DMServer.TransactionRollback; ' + sLineBreak +
  '      q.Free; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak;

  { LER Registro }

  s := s +
  'procedure TService' + lObjeto + '.Ler(AId: integer); ' + sLineBreak +
  '//ler dados do registro conforme id ' + sLineBreak +
  'var ' + sLineBreak;

  if FTipoBanco = SQLSERVER then
    s := s + '  q: TSQLQuery; ' + sLineBreak
  else
    s := s + '  q: TZQuery; ' + sLineBreak;

  s := s +
  'begin ' + sLineBreak +
  '  if not FIsConectado then Exit; ' + sLineBreak +
  '  FMensagem := ''''; ' + sLineBreak +
  '  FSucesso  := False; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    q := DMServer.NewQuery(); ' + sLineBreak +
  ' ' + sLineBreak +
  '    q.SQL.Add(''SELECT ''); ' + sLineBreak;

  i := 0;
  j := 0;
  lCount := 0;
  lFields := '';

  qryCampos.First;
  while not qryCampos.EOF do begin
    lCampo := 't.' + qryCampos.FieldByName('campo').AsString;
    lcampoDBTipo := LowerCase(qryCampos.FieldByName('tipo').AsString); //tipo de dados no DB
    lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString;
    bCampoAceito := (lcampoTipo.ToLower <> 'timage'); // recusa se for imagem

    if bCampoAceito then begin
      if (FTipoBanco = SQLSERVER) and
         (qryCampos.FieldByName('currency_field').AsInteger = 1) and
         (lcampoDBTipo = 'numeric') then
          lCampo := 'CAST(' + lCampo + ' AS FLOAT) AS ' + qryCampos.FieldByName('campo').AsString;

      i := i + 1;
      lCount := lCount + 1;

      if (lFields <> '') then lFields := lFields + ', ';
      lFields := lFields + lCampo;

      if (qryCampos.FieldByName('chave_estrangeira').AsInteger = 1) then begin
        { select de campos da tabela estrangeira }
        j := j + 1;
        lcount := lcount + 1;
        lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
        lFK_Texto  := Trim(qryCampos.FieldByName('fk_texto').AsString);
        lFields    := lFields + ', e' + IntToStr(j) + '.' + lFK_Texto + ' AS fk_' + lFK_Texto;
      end;

      if (lCount >= lQdePorColuna) then begin
        if (i < lQdeRegistros) then lFields := lFields + ',';
        s := s +
        '    q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;

        lFields := '';
        lCount := 0;
      end;
    end;

    qryCampos.Next;
  end;

  if (lFields <> '') then
    s := s +
    '    q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;

  { from da tabela primária }

  s := s +
  '    q.SQL.Add(''FROM ' + lTabela + ' t ''); ' + sLineBreak;

  { left join da tabela estrangeira }

  i := 0;
  qryCampos.First;
  while not qryCampos.EOF do begin
    if (qryCampos.FieldByName('chave_estrangeira').AsInteger = 1) then begin
      i := i + 1;
      lCampo     := qryCampos.FieldByName('campo').AsString;
      lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
      lFK_Codigo := Trim(qryCampos.FieldByName('fk_codigo').AsString);
      lFK_Texto  := Trim(qryCampos.FieldByName('fk_texto').AsString);
      lFields    := 'LEFT JOIN ' + lFK_Tabela + ' e' + IntToStr(i) +
                    ' ON ' + 'e' + IntToStr(i) + '.' + lFK_Codigo + ' = t.' + lCampo;
      s := s +
      '    q.SQL.Add('' ' + lFields + ' ''); ' + sLineBreak;
    end;

    qryCampos.Next;
  end;

  { where da tabela primária }

  s := s +
  '    q.SQL.Add(''WHERE t.' + lCampoPK + ' = '' + IntToStr(AId)); ' + sLineBreak +
  ' ' + sLineBreak +
  '    q.Open; ' + sLineBreak +
  ' ' + sLineBreak +
  '    if not q.EOF then ' + sLineBreak +
  '    begin ' + sLineBreak +
  '      F' + lcampoChavePrimaria + ' := AId; ' + sLineBreak;

  qryCampos.First;
  while not qryCampos.EOF do begin
    lCampo       := qryCampos.FieldByName('campo').AsString;
    lcampoObjeto := qryCampos.FieldByName('objeto').AsString;
    lcampoTipo   := qryCampos.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    lComponente  := qryCampos.FieldByName('componente').AsString; //TEdit, TMemo, TDateTime, TImage, TCheckbox, TCombobox
    lFK_Tabela   := Trim(qryCampos.FieldByName('fk_tabela').AsString);
    lFK_Texto    := Trim(qryCampos.FieldByName('fk_texto').AsString);
    bChaveEstrangeira := ((qryCampos.FieldByName('chave_estrangeira').AsInteger = 1) and (Length(lFK_Tabela) > 0));
    bCampoAceito := (lcampoTipo.ToLower <> 'timage'); // recusa se for imagem

    if bCampoAceito then begin
      case lcampoTipo.ToLower of
        'string':
          begin
            s := s +
            '      ' + lcampoObjeto + ' := q.FieldByName(''' + lCampo + ''').AsString; ' + sLineBreak;
          end;
        'integer':
          begin
            if lComponente.ToLower = 'tcheckbox' then
              s := s +
              '      ' + lcampoObjeto + ' := q.FieldByName(''' + lCampo + ''').AsInteger = 1; ' + sLineBreak
            else if (lCampo <> lCampoPK) then
            begin
              s := s +
              '      ' + lcampoObjeto + ' := q.FieldByName(''' + lCampo + ''').AsInteger; ' + sLineBreak;

              if bChaveEstrangeira then // campo texto da chave estrangeira
                s := s +
                '      FK_' + TUtilCommon.CapitalizaTexto( lFK_Texto ) + ' := q.FieldByName(''fk_' + lFK_Texto + ''').AsString; ' + sLineBreak;
            end;
          end;
        'currency':
          begin
            s := s +
            '      ' + lcampoObjeto + ' := q.FieldByName(''' + lCampo + ''').AsFloat; ' + sLineBreak;
          end;
        'double':
          begin
            s := s +
            '      ' + lcampoObjeto + ' := q.FieldByName(''' + lCampo + ''').AsFloat; ' + sLineBreak;
          end;
        'timage':
          begin
            if FTipoBanco = SQLSERVER then
               s := s +
              '      TUtilImagem.GetImageSQLQuery(F' + lcampoObjeto + ', q, ''' + lCampo + '''); ' + sLineBreak
            else
              s := s +
              '      TUtilImagem.GetImage(F' + lcampoObjeto + ', q, ''' + lCampo + '''); ' + sLineBreak;
          end;
        'tdatetime':
          begin
            s := s +
            '      ' + lcampoObjeto + ' := q.FieldByName(''' + lCampo + ''').AsDateTime; ' + sLineBreak;
          end;
      else
        s := s +
        '      ' + lcampoObjeto + ' := q.FieldByName(''' + lCampo + ''').AsString; ' + sLineBreak;
      end;
    end;

    qryCampos.Next;
  end; //while

  s := s +
  ' ' + sLineBreak +
  '      FSucesso  := True; ' + sLineBreak +
  '      FMensagem := ' + QuotedStr( UtilProjetoLazarus.CRUD_LerMsg1 ) + '; ' + sLineBreak +
  '    end ' + sLineBreak +
  '    else ' + sLineBreak +
  '    begin ' + sLineBreak +
  '      FMensagem := ' + QuotedStr( UtilProjetoLazarus.CRUD_LerMsg2 ) + '; ' + sLineBreak +
  '      FSucesso  := False; ' + sLineBreak +
  '    end; ' + sLineBreak +
  ' ' + sLineBreak +
  '    q.Close; ' + sLineBreak +
  '    q.Free; ' + sLineBreak +
  '  except ' + sLineBreak +
  '    on E: Exception do ' + sLineBreak +
  '    begin ' + sLineBreak +
  '      FSucesso  := False; ' + sLineBreak +
  '      FMensagem := E.Message; ' + sLineBreak +
  '      q.Free; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak;

  { COMBOBOX }

  if bComboBox then begin
    qryCampos.First;
    while not qryCampos.EOF do begin
      lCampo  := qryCampos.FieldByName('campo').AsString;
      lcampoObjeto := qryCampos.FieldByName('objeto').AsString;
      lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
      lComponente := qryCampos.FieldByName('componente').AsString; //TEdit, TMemo, TDateTime, TImage, TCheckbox, TCombobox
      lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
      lFK_Codigo := Trim(qryCampos.FieldByName('fk_codigo').AsString);
      lFK_Texto := Trim(qryCampos.FieldByName('fk_texto').AsString);
      lcomboLista := Trim(qryCampos.FieldByName('combo_lista').AsString);

      case lComponente.ToLower of
        'tcombobox':
          begin
            if lFK_Tabela <> '' then begin // carrega a combo via banco de dados
              s := s +
              'procedure TService' + lObjeto + '.CarregaComboBox' + TUtilCommon.RemoveFieldUnderscore( lFK_Tabela ) + '(var AComboBox: TComboBox; AIdSelect: Integer); ' + sLineBreak +
              '//carrega a combobox com os dados ' + sLineBreak +
              'var ' + sLineBreak +
              '  q: TZQuery; ' + sLineBreak +
              'begin ' + sLineBreak +
              '  AComboBox.Clear; ' + sLineBreak +
              '  AComboBox.AddItem('''', TComboBoxItemData.Create(0)); ' + sLineBreak +
              '  if not FIsConectado then Exit; ' + sLineBreak +
              '  FMensagem := ''''; ' + sLineBreak +
              '  FSucesso  := True; ' + sLineBreak +
              ' ' + sLineBreak +
              '  try ' + sLineBreak +
              '    q := DMServer.NewQuery(); ' + sLineBreak +
              ' ' + sLineBreak +
              '    q.SQL.Add(''SELECT ''); ' + sLineBreak +
              '    q.SQL.Add(''' + lFK_Codigo + ', ' + lFK_Texto + ' ''); ' + sLineBreak +
              '    q.SQL.Add(''FROM ' + lFK_Tabela + ' ''); ' + sLineBreak +
              '    q.SQL.Add(''ORDER BY ' + lFK_Texto + ' ASC ''); ' + sLineBreak +
              ' ' + sLineBreak +
              '    q.Open; ' + sLineBreak +
              ' ' + sLineBreak +
              '    while not q.EOF do ' + sLineBreak +
              '    begin ' + sLineBreak +
              '      AComboBox.AddItem(q.FieldByName(''' + lFK_Texto + ''').AsString, TComboBoxItemData.Create(q.FieldByName(''' + lFK_Codigo + ''').AsInteger)); ' + sLineBreak +
              '      q.Next; ' + sLineBreak +
              '    end; ' + sLineBreak +
              ' ' + sLineBreak +
              '    q.Close; ' + sLineBreak +
              '    q.Free; ' + sLineBreak +
              '  except ' + sLineBreak +
              '  end; ' + sLineBreak +
              ' ' + sLineBreak +
              '  if AComboBox.Items.Count > 0 then ' + sLineBreak +
              '    TComboBoxItemData.ComboBox_Select(AComboBox, AIdSelect); ' + sLineBreak +
              'end; ' + sLineBreak +
              ' ' + sLineBreak;
            end
            else if lcomboLista <> '' then begin //carrega a combo via lista manual
              s := s +
              'procedure TService' + lObjeto + '.CarregaComboBox' + lcampoObjeto + '(var AComboBox: TComboBox; AIdSelect: Integer); ' + sLineBreak +
              'begin ' + sLineBreak +
              '  AComboBox.Clear;' + sLineBreak +
              '  AComboBox.Items.Add(' + QuotedStr('') + '); ' + sLineBreak;

              SetLength(f, 0);
              f := lcomboLista.Split([sLineBreak], TStringSplitOptions.ExcludeEmpty);

              for i := 0 to High(f) do
                s := s +
                '  AComboBox.Items.Add(' + QuotedStr(f[i]) + '); ' + sLineBreak;

              s := s +
              ' ' + sLineBreak +
              '  if AComboBox.Items.Count > 0 then ' + sLineBreak +
              '    AComboBox.ItemIndex := AIdSelect; ' + sLineBreak +
              'end; ' + sLineBreak +
              ' ' + sLineBreak;

              SetLength(f, 0);
            end;
          end;
       end;

      qryCampos.Next;
    end; //while
  end;

  { DBGRID - Dataset }

  if bGrid and (lQdeItensGrid > 0) then begin
    s := s +
    'function TService' + lObjeto + '.DataSetGrid(ASearch: String; AFirstRow: Integer; AMaxRows: Integer): TDataSource; ' + sLineBreak +
    '//dataset de tabelas para dbgrid ' + sLineBreak +
    'var ' + sLineBreak;

    if (FTipoBanco = SQLSERVER) then
      s := s + '  q: TSQLQuery; ' + sLineBreak
    else
      s := s + '  q: TZQuery; ' + sLineBreak;

    s := s +
    'begin ' + sLineBreak +
    '  Result    := TDataSource.Create(nil); ' + sLineBreak +
    '  if not FIsConectado then Exit; ' + sLineBreak +
    '  FMensagem := ''''; ' + sLineBreak +
    '  FSucesso  := True; ' + sLineBreak +
    ' ' + sLineBreak +
    '  try ' + sLineBreak +
    '    q := DMServer.NewQuery(); ' + sLineBreak +
    ' ' + sLineBreak +
    '    q.SQL.Add(''SELECT ''); ' + sLineBreak;

    //checa se o campo estrangeiro já faz parte da lista
    //(campo desta tabela referenciado em outra tabela)
    qryCampos.First;
    while not qryCampos.EOF do begin
      if LowerCase(qryCampos.FieldByName('campo').AsString) = LowerCase(lcampo_estrangeiro) then begin
         lcampo_estrangeiro := '';
         Break;
      end;
      qryCampos.Next;
    end;

    {  campos da lista do select }

    i := 0;
    j := 0;
    lCount := 0;
    lFields := '';

    qryCampos.First;
    while not qryCampos.EOF do begin
      bCampoValido := ((qryCampos.FieldByName('incluir_na_grid').AsInteger = 1) or
                       (qryCampos.FieldByName('chave_primaria').AsInteger = 1));
      lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
      lFK_Texto := Trim(qryCampos.FieldByName('fk_texto').AsString);
      bChaveEstrangeira := (qryCampos.FieldByName('chave_estrangeira').AsInteger = 1) and (Length(lFK_Tabela) > 0);
      lCampo := '';

      if bCampoValido or bChaveEstrangeira or (Length(lcampo_estrangeiro) > 0) then begin

        { compo indicado para incluir da grid / chave estrangeira }

        if bCampoValido then begin
           lCampo := 't.' + qryCampos.FieldByName('campo').AsString;
           lcampoDBTipo := LowerCase(qryCampos.FieldByName('tipo').AsString); //tipo de dados no DB
           lCount := lCount + 1;

           if (FTipoBanco = SQLSERVER) and
              (qryCampos.FieldByName('currency_field').AsInteger = 1) and
              (lcampoDBTipo = 'numeric') then
               lCampo := 'CAST(' + lCampo + ' AS FLOAT) AS ' + qryCampos.FieldByName('campo').AsString;
        end;

        { select de campos da tabela estrangeira }

        if bChaveEstrangeira then begin
          j := j + 1;
          lcount := lcount + 1;
          lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
          lFK_Texto  := Trim(qryCampos.FieldByName('fk_texto').AsString);

          if bCampoValido then
            lCampo := lCampo + ', e' + IntToStr(j) + '.' + lFK_Texto + ' AS fk_' + lFK_Texto
          else
            lCampo := 'e' + IntToStr(j) + '.' + lFK_Texto + ' AS fk_' + lFK_Texto;
        end;

        { tem refência de campo estrangeiro desta tabela em outra tabela ? }

        if (i = 1) and (Length( lcampo_estrangeiro ) > 0) then begin
          lcount := lcount + 1;
          if (lCampo <> '') then
            lCampo := lCampo + ', t.' + lcampo_estrangeiro
          else
            lCampo := 't.' + lcampo_estrangeiro;
        end;
      end;

      { adiciona o campo à lista de select }

      if (Trim(lcampo) <> '') then begin
        if (lFields <> '') then lFields := lFields + ', ';
        lFields := lFields + lCampo;
      end;

      qryCampos.Next;
    end; //while

    if (lFields <> '') then
      s := s +
      '    q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;

    { from da tabela primária }

    s := s +
    '    q.SQL.Add(''FROM ' + lTabela + ' t ''); ' + sLineBreak;

    { left join da tabela estrangeira }

    i := 0;
    qryCampos.First;
    while not qryCampos.EOF do begin
      lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
      bChaveEstrangeira := (qryCampos.FieldByName('chave_estrangeira').AsInteger = 1) and (Length(lFK_Tabela) > 0);

      if bChaveEstrangeira then begin
        i := i + 1;
        lCampo     := qryCampos.FieldByName('campo').AsString;
        lFK_Codigo := Trim(qryCampos.FieldByName('fk_codigo').AsString);
        lFK_Texto  := Trim(qryCampos.FieldByName('fk_texto').AsString);
        lFields    := 'LEFT JOIN ' + lFK_Tabela + ' e' + IntToStr(i) + ' ON ' + 'e' + IntToStr(i) + '.' + lFK_Codigo + ' = t.' + lCampo;

        s := s +
        '    q.SQL.Add(''' + lFields + ' ''); ' + sLineBreak;
      end;

      qryCampos.Next;
    end;

    { where da tabela primária, pesquisa e order by }

    if lPesquisaCampo <> '' then
      s := s +
      ' ' + sLineBreak +
      '    if ASearch.Trim <> '''' then ' + sLineBreak +
      '    begin ' + sLineBreak +
      '      q.SQL.Add(''WHERE t.' + lPesquisaCampo + ' LIKE :pesquisa ''); ' + sLineBreak +
      '      q.ParamByName(''pesquisa'').AsString := ''%'' + ASearch.Trim + ''%''; ' + sLineBreak +
      '    end; ' + sLineBreak +
      ' ' + sLineBreak +
      '    q.SQL.Add(''ORDER BY t.' + lPesquisaCampo + ' ASC ''); ' + sLineBreak
    else if lCampoPK <> '' then
      s := s +
      ' ' + sLineBreak +
      '    //if ASearch.Trim <> '''' then ' + sLineBreak +
      '    //begin ' + sLineBreak +
      '    //  q.SQL.Add(''WHERE t.field_search LIKE :pesquisa ''); ' + sLineBreak +
      '    //  q.ParamByName(''pesquisa'').AsString := ''%'' + ASearch.Trim + ''%''; ' + sLineBreak +
      '    //end; ' + sLineBreak +
      '    //' + sLineBreak +
      '    //q.SQL.Add(''ORDER BY t.field_search ASC ''); ' + sLineBreak + sLineBreak +
      '    q.SQL.Add(''ORDER BY t.' + lCampoPK + ' ASC ''); ' + sLineBreak;

    //limita a quantidade de linhas (pade fazer paginação)

    case FTipoBanco of
      SQLITE:
        s := s +
        ' ' + sLineBreak +
        '    if AMaxRows > 0 then ' + sLineBreak +
        '      q.SQL.Add( Format(''LIMIT %d, %d '', [AFirstRow, AMaxRows]) ); //LIMIT first_row, total_rows (LIMIT 0, 100) ' + sLineBreak;
      POSTGRE:
        s := s +
        ' ' + sLineBreak +
        '    if AMaxRows > 0 then ' + sLineBreak +
        '      q.SQL.Add( Format(''LIMIT %d OFFSET %d '', [AMaxRows, AFirstRow]) ); //LIMIT total_rows OFFSET first_row (LIMIT 100, 0)' + sLineBreak;
      MARIADB, MYSQL:
        s := s +
        ' ' + sLineBreak +
        '    if AMaxRows > 0 then ' + sLineBreak +
        '      q.SQL.Add( Format(''LIMIT %d, %d '', [AFirstRow, AMaxRows]) ); //LIMIT first_row, total_rows (LIMIT 0, 100)' + sLineBreak;
      FIREBIRD:
        s := s +
        ' ' + sLineBreak +
        '    if AMaxRows > 0 then begin ' + sLineBreak +
        '      if AFirstRow < 1 then AFirstRow := 1; ' + sLineBreak +
        '      q.SQL.Add( Format(''ROWS %d TO %d '', [AFirstRow, AMaxRows]) ); //ROWS [first_row] TO [total_rows] (ROWS 1 TO 100)' + sLineBreak +
        '    end; ' + sLineBreak;
      SQLSERVER:
        s := s +
        ' ' + sLineBreak +
        '    if AMaxRows > 0 then ' + sLineBreak +
        '      q.SQL.Add( Format(''OFFSET %d ROWS FETCH NEXT %d ROWS ONLY '', [AFirstRow, AMaxRows]) ); //from ROW 0 to 100 ' + sLineBreak;
      ORACLE:
        s := s +
        ' ' + sLineBreak +
        '    if AMaxRows > 0 then ' + sLineBreak +
        '      q.SQL.Add( Format(''OFFSET %d ROWS FETCH NEXT %d ROWS ONLY '', [AFirstRow, AMaxRows]) ); //from ROW 0 to 100 ' + sLineBreak;
    end;

    s := s +
    ' ' + sLineBreak +
    '    q.Open; ' + sLineBreak +
    '    Result.DataSet := q; ' + sLineBreak +
    '    // fechar lá no destino/cliente (close on client side)' + sLineBreak +
    '  except ' + sLineBreak +
    '    on E: Exception do ' + sLineBreak +
    '    begin ' + sLineBreak +
    '      FMensagem := E.Message; ' + sLineBreak +
    '      FSucesso  := False; ' + sLineBreak +
    '      q.Free; ' + sLineBreak +
    '    end; ' + sLineBreak +
    '  end; ' + sLineBreak +
    'end; ' + sLineBreak +
    ' ' + sLineBreak;
  end;

  s := s +
  'end. ' + sLineBreak +
  ' ' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaServices + 'service.' + lObjeto.ToLower + '.pas', s);
  s := '';
  SetLength(f, 0);
end;

procedure TProjetoLazarusAPI.GerarUtilCriptografia;
//cria o utilitário de criptografia
begin
  TUtilCommon.GerarUtilCriptografia(FPastaUtil);
end;

procedure TProjetoLazarusAPI.GerarJSONTableStructure(qryCampos: TZQuery);
// gera uma classe com a estrutura da tabela em formato json
// para utilizar no Core.DataControl
var
  lObjeto, lTabela, lApiRoute: string;
  lCampo, lCampoAlias, lcampoDBTipo, lcampoTipo: string;
  lcomboLista: string;
  lFK_Tabela, lFK_Codigo, lFK_Texto: string;
  bCurrencyField, bChavePrimaria, bChaveEstrangeira, bRequerido: Boolean;
  bToList, bAceitaNull, bCampoAceito, bLimparMascara: Boolean;
  lCount, lMaxLen, lPrecisao, lScale: Integer;
  s, lCampoEspecial: string;
begin
  qryCampos.First;
  if qryCampos.FieldByName('for_auth').AsInteger = 1 then Exit;
  //if qryCampos.FieldByName('chave_primaria').AsInteger <> 1 then exit;
  lObjeto := qryCampos.FieldByName('nome_objeto').AsString; //tabela objeto
  lTabela := qryCampos.FieldByName('tabela').AsString; //nome da tabela original
  lApiRoute := qryCampos.FieldByName('api_rota').AsString; // rota da api: /produto, /cliente, etc

  lApiRoute := AjustaNomeRota(lObjeto, lApiRoute);

  lObjeto := lObjeto + FVersaoAbreviadaRota;

  s :=
    'unit TableModel.' + lObjeto + ';' + sLineBreak +
    '' + sLineBreak +
    TUtilCommon.InformacoesLegais +
    '// informações dos campos da tabela ' + lTabela + ' ' + sLineBreak +
    '' + sLineBreak +
    '{$mode ObjFPC}{$H+}' + sLineBreak +
    '' + sLineBreak +
    'interface' + sLineBreak +
    '' + sLineBreak +
    'uses' + sLineBreak +
    '  Classes, SysUtils;' + sLineBreak +
    '' + sLineBreak +
    'type' + sLineBreak +
    '' + sLineBreak +
    '  { TTableModel' + lObjeto + ' }' + sLineBreak +
    '' + sLineBreak +
    '  TTableModel' + lObjeto + ' = class' + sLineBreak +
    '  public' + sLineBreak +
    '    function GetModel(): string;' + sLineBreak +
    '    class function new: TTableModel' + lObjeto + '; ' + sLineBreak +
    '  end;' + sLineBreak +
    '' + sLineBreak +
    'implementation' + sLineBreak +
    '' + sLineBreak +
    '{ TTableModel' + lObjeto + ' }' + sLineBreak +
    '' + sLineBreak +
    'class function TTableModel' + lObjeto + '.new: TTableModel' + lObjeto + ';' + sLineBreak +
    'begin' + sLineBreak +
    '  Result := TTableModel' + lObjeto + '.Create;' + sLineBreak +
    'end;  ' + sLineBreak +
    '' + sLineBreak +
    'function TTableModel' + lObjeto + '.GetModel(): string;' + sLineBreak +
    'begin' + sLineBreak +
    '  Result :=' + sLineBreak +
    '  ''{'' +' + sLineBreak +
    '  '' "table_name": "' + lTabela + '",'' +' + sLineBreak +
    '  '' "fp_objetc": "' + qryCampos.FieldByName('nome_objeto').AsString + '",'' +' + sLineBreak +
    '  '' "api_route": "' + lApiRoute.ToLower + '",'' +' + sLineBreak +
    '  '' "fields": ['' +' + sLineBreak;

  lCount := 0;
  qryCampos.First;
  while not qryCampos.EOF do begin
    lCampo := qryCampos.FieldByName('campo').AsString;
    lCampoAlias := qryCampos.FieldByName('campo_alias').AsString;
    if Trim(lCampoAlias) = '' then lCampoAlias := lcampo;
    lcampoDBTipo := LowerCase(qryCampos.FieldByName('tipo').AsString); //tipo de campo no DB
    lcampoTipo := qryCampos.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    bCurrencyField := qryCampos.FieldByName('currency_field').AsInteger = 1;
    bChavePrimaria := (qryCampos.FieldByName('chave_primaria').AsInteger = 1);
    lFK_Tabela := Trim(qryCampos.FieldByName('fk_tabela').AsString);
    lFK_Codigo := Trim(qryCampos.FieldByName('fk_codigo').AsString);
    lFK_Texto := Trim(qryCampos.FieldByName('fk_texto').AsString);
    lcomboLista := Trim(qryCampos.FieldByName('combo_lista').AsString);
    bChaveEstrangeira := ((qryCampos.FieldByName('chave_estrangeira').AsInteger = 1) and (Length(lFK_Tabela) > 0));
    lMaxLen := StrToIntDef('0' + qryCampos.FieldByName('tamanho').AsString, 50); //MaxLength do campo
    lPrecisao := StrToIntDef('0' + qryCampos.FieldByName('precisao').AsString, 0); //tamanho o número
    lScale := StrToIntDef('0' + qryCampos.FieldByName('escala').AsString, 2);   //casas decimais
    bRequerido := (qryCampos.FieldByName('requerido').AsInteger = 1); //campo obrigatório
    bToList := (qryCampos.FieldByName('incluir_na_grid').AsInteger = 1); //exibir na paginação
    bAceitaNull := (qryCampos.FieldByName('aceita_null').AsInteger = 1); //campo aceita nulo ?
    lCampoEspecial := Trim(qryCampos.FieldByName('campo_especial').AsString); //cpf, cnpj, Cep, celular, etc
    bLimparMascara := (qryCampos.FieldByName('remove_mask').AsInteger = 1); // remover máscara do valor

    lCampoEspecial := LowerCase(lCampoEspecial.ToLower);

    if bChaveEstrangeira then
      lCampoEspecial := lFK_Tabela + ',' + lFK_Codigo + ',' + lFK_Texto;

    bCampoAceito := True;

    case lcampoTipo.ToLower of
      'boolean':
        begin
          lcampoTipo := 'boolean';
          if Pos('bool', lcampoDBTipo) < 1 then lcampoDBTipo := 'integer';
        end;
      'string':
        begin
          lcampoTipo := 'string';
        end;
      'integer':
        begin
          lcampoTipo := 'integer';
        end;
      'currency':
        begin
          lcampoTipo := 'currency';
        end;
      'double':
        begin
          lcampoTipo := 'double';
        end;
      'timage':
        begin
          bCampoAceito := False;
          lcampoTipo := 'image';
        end;
      'tdatetime':
        begin
          lcampoTipo := 'datetime';
        end;
      else
      begin
        lcampoTipo := 'string';
      end;
    end;

    if bCampoAceito then begin
      if lCount > 0 then
        s := s + '  ''    },'' +' + sLineBreak;

      lCount := lCount + 1;

      s := s +
      '  ''    {'' +' + sLineBreak +
      '  ''      "name": "' + lCampo.ToLower + '",'' +' + sLineBreak +
      '  ''      "name_alias": "' + lCampoAlias.ToLower + '",'' +' + sLineBreak +
      '  ''      "data_type": "' + lcampoDBTipo.ToLower + '",'' +' + sLineBreak +
      '  ''      "is_primary_key": ' + BooleanToString(bChavePrimaria) + ','' +' + sLineBreak +
      '  ''      "is_foreign_key": ' + BooleanToString(bChaveEstrangeira) + ','' +' + sLineBreak +
      '  ''      "is_nullable": ' + BooleanToString(bAceitaNull) + ','' +' + sLineBreak +
      '  ''      "max_length": ' + IntToStr(lMaxLen) + ','' +' + sLineBreak +
      '  ''      "precision": ' + IntToStr(lPrecisao) + ','' +' + sLineBreak +
      '  ''      "scale": ' + IntToStr(lScale) + ','' +' + sLineBreak +
      '  ''      "required": ' + BooleanToString(bRequerido) + ','' +' + sLineBreak +
      '  ''      "special_field": "' + lCampoEspecial + '",'' +' + sLineBreak +
      '  ''      "remove_mask": ' + BooleanToString(bLimparMascara) + ','' +' + sLineBreak +
      '  ''      "to_list": ' + BooleanToString(bToList) + ','' +' + sLineBreak +
      '  ''      "fp_data_type": "' + lcampoTipo.ToLower + '"'' +' + sLineBreak;
    end;

    qryCampos.Next;
  end; //while

  if lCount > 0 then
    s := s + '  ''    }'' +' + sLineBreak;

  s := s +
    '  '' ]'' +' + sLineBreak +
    '  ''}'';' + sLineBreak +
    'end;' + sLineBreak +
    '' + sLineBreak +
    'end.' + sLineBreak +
    '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaModels + 'tablemodel.' + lObjeto.ToLower + '.pas', s);
  s := '';
end;

function TProjetoLazarusAPI.BooleanToString(AValue: Boolean): string;
begin
  Result := 'false';
  if AValue then Result := 'true';
end;

function TProjetoLazarusAPI.AjustaNomeRota(ANomeTabela, ANomeRota: string): string;
begin
  if ANomeRota = '' then ANomeRota := LowerCase(ANomeTabela);
  ANomeRota := StringReplace(ANomeRota, '/', '', [rfReplaceAll]);
  ANomeRota := TUtilCommon.CapitalizaTexto(ANomeRota);
  Result := ANomeRota;
end;

function TProjetoLazarusAPI.GerarMailtoURI(AEmail, ASubject, ABody: string): string;
begin
  // O HTTPEncode converte espaços em '+' ou '%20' e protege caracteres especiais
  Result := 'mailto:' + AEmail;
  if ASubject <> '' then Result := Result + '?subject=' + HTTPEncode(ASubject);
  if ABody <> '' then Result := Result + '&body=' + HTTPEncode(ABody);
end;

procedure TProjetoLazarusAPI.GerarUtilImagem;
//cria o utilitário de manipulação de imagem para banco de dados
begin
  TUtilCommon.GerarUtilImagem(FPastaUtil);
end;

procedure TProjetoLazarusAPI.GerarModulosBoleto;
begin
  Boleto_ApiFuncoes;
  Boleto_BancoBradesco;
  Boleto_BancoBrasil;
  Boleto_CaixaFederal;
  Boleto_BancoItau;
  Boleto_BancoSantander;
  Boleto_BancoSicoob;
  Boleto_Layout;
  Boleto_LinhaDigitavel;
  Boleto_Models;
  Boleto_Pix;
  Boleto_RouteFinanceiro;
end;

procedure TProjetoLazarusAPI.GeraCore_HtmlToPdf;
var
  s: string;
begin
  s :=
  'unit Core.HtmlToPdf;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{' + sLineBreak +
  '  Utiliza google chrome para criar arquivo PDF' + sLineBreak +
  '   - Windows' + sLineBreak +
  '' + sLineBreak +
  '     Instalar: Google Chrome' + sLineBreak +
  '' + sLineBreak +
  '   - Linux' + sLineBreak +
  '' + sLineBreak +
  '     Ubuntu/Debian:' + sLineBreak +
  '' + sLineBreak +
  '     sudo apt install chromium-browser' + sLineBreak +
  '     ou' + sLineBreak +
  '     sudo apt install chromium' + sLineBreak +
  '' + sLineBreak +
  '     Arch Linux' + sLineBreak +
  '' + sLineBreak +
  '     sudo pacman -Sy' + sLineBreak +
  '     sudo pacman -S chromium' + sLineBreak +
  ' }' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { THtmlToPdf }' + sLineBreak +
  '' + sLineBreak +
  '  THtmlToPdf = class' + sLineBreak +
  '    private' + sLineBreak +
  '      function GetChromeExecutableWindows: string;' + sLineBreak +
  '      function GuidString: string;' + sLineBreak +
  '      function GetChromeExecutable: string;' + sLineBreak +
  '    public' + sLineBreak +
  '      { Converte um HTML em formato string para stream em memória }' + sLineBreak +
  '      function HtmlToPdfStream(const AHtml: string): TMemoryStream;' + sLineBreak +
  '      { Converte um arquivo HTML para stream em memória }' + sLineBreak +
  '      function HtmlFileToPdfStream(const AHtmlFile: string): TMemoryStream;' + sLineBreak +
  '      { Converte um arquivo HTML para arquivo PDF }' + sLineBreak +
  '      function HtmlFileToPdfFile(const AHtmlFile, APdfFile: string): Boolean;' + sLineBreak +
  '      class function new: THtmlToPdf;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Process, Registry;' + sLineBreak +
  '' + sLineBreak +
  'class function THtmlToPdf.new: THtmlToPdf;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := THtmlToPdf.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THtmlToPdf.GuidString: string;' + sLineBreak +
  'var' + sLineBreak +
  '  G: TGUID;' + sLineBreak +
  'begin' + sLineBreak +
  '  CreateGUID(G);' + sLineBreak +
  '  Result := GUIDToString(G);' + sLineBreak +
  '  Result := StringReplace(Result, ''{'', '''', [rfReplaceAll]);' + sLineBreak +
  '  Result := StringReplace(Result, ''}'', '''', [rfReplaceAll]);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THtmlToPdf.GetChromeExecutableWindows: string;' + sLineBreak +
  'var' + sLineBreak +
  '  Reg: TRegistry;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '' + sLineBreak +
  '  Reg := TRegistry.Create;' + sLineBreak +
  '  try' + sLineBreak +
  '    Reg.RootKey := HKEY_LOCAL_MACHINE;' + sLineBreak +
  '' + sLineBreak +
  '    if Reg.OpenKeyReadOnly(''\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe'') then' + sLineBreak +
  '    begin' + sLineBreak +
  '      Result := Reg.ReadString('''');' + sLineBreak +
  '' + sLineBreak +
  '      if FileExists(Result) then' + sLineBreak +
  '        Exit;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    Reg.RootKey := HKEY_CURRENT_USER;' + sLineBreak +
  '' + sLineBreak +
  '    if Reg.OpenKeyReadOnly(''\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe'') then' + sLineBreak +
  '    begin' + sLineBreak +
  '      Result := Reg.ReadString('''');' + sLineBreak +
  '' + sLineBreak +
  '      if FileExists(Result) then' + sLineBreak +
  '        Exit;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '  finally' + sLineBreak +
  '    Reg.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := ''chrome.exe'';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THtmlToPdf.GetChromeExecutable: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  {$IFDEF WINDOWS}' + sLineBreak +
  '    Result := GetChromeExecutableWindows;' + sLineBreak +
  '  {$ENDIF}' + sLineBreak +
  '' + sLineBreak +
  '  {$IFDEF LINUX}' + sLineBreak +
  '    if FileExists(''/usr/bin/google-chrome-stable'') then' + sLineBreak +
  '      Exit(''/usr/bin/google-chrome-stable'');' + sLineBreak +
  '' + sLineBreak +
  '    if FileExists(''/usr/bin/google-chrome'') then' + sLineBreak +
  '      Exit(''/usr/bin/google-chrome'');' + sLineBreak +
  '' + sLineBreak +
  '    if FileExists(''/usr/bin/chromium'') then' + sLineBreak +
  '      Exit(''/usr/bin/chromium'');' + sLineBreak +
  '' + sLineBreak +
  '    if FileExists(''/usr/bin/chromium-browser'') then' + sLineBreak +
  '      Exit(''/usr/bin/chromium-browser'');' + sLineBreak +
  '' + sLineBreak +
  '    Result := ''google-chrome'';' + sLineBreak +
  '  {$ENDIF}' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THtmlToPdf.HtmlToPdfStream(const AHtml: string): TMemoryStream;' + sLineBreak +
  '// Converte HTML em formato string para PDF em memory stream' + sLineBreak +
  'var' + sLineBreak +
  '  HtmlFile, PdfFile : string;' + sLineBreak +
  '  SL: TStringList;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TMemoryStream.Create;' + sLineBreak +
  '' + sLineBreak +
  '  //HtmlFile := GetTempDir + GuidString + ''.html'';' + sLineBreak +
  '  HtmlFile := ExtractFileDir( ParamStr(0) ) + PathDelim + ''public'' + PathDelim + GuidString + ''.html'';' + sLineBreak +
  '  PdfFile  := GetTempDir + GuidString + ''.pdf'';' + sLineBreak +
  '' + sLineBreak +
  '  SL := TStringList.Create;' + sLineBreak +
  '  try' + sLineBreak +
  '    SL.Text := AHtml;' + sLineBreak +
  '    SL.SaveToFile(HtmlFile);' + sLineBreak +
  '  finally' + sLineBreak +
  '    SL.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  if HtmlFileToPdfFile(HtmlFile, PdfFile) then' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result.LoadFromFile(PdfFile);' + sLineBreak +
  '    Result.Position := 0;' + sLineBreak +
  '    DeleteFile(HtmlFile);' + sLineBreak +
  '    DeleteFile(PdfFile);' + sLineBreak +
  '  end' + sLineBreak +
  '  else' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result.Free;' + sLineBreak +
  '    raise Exception.Create(''Error generating PDF.'');' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THtmlToPdf.HtmlFileToPdfStream(const AHtmlFile: string): TMemoryStream;' + sLineBreak +
  '// converte um arquivo html em PDF em memory stream' + sLineBreak +
  'var' + sLineBreak +
  '  PdfFile : string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TMemoryStream.Create;' + sLineBreak +
  '' + sLineBreak +
  '  if not FileExists(AHtmlFile) then' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result.Free;' + sLineBreak +
  '    raise Exception.Create(''File not found: '' + AHtmlFile);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  PdfFile  := GetTempDir + GuidString + ''.pdf'';' + sLineBreak +
  '' + sLineBreak +
  '  if HtmlFileToPdfFile(AHtmlFile, PdfFile) then' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result.LoadFromFile(PdfFile);' + sLineBreak +
  '    Result.Position := 0;' + sLineBreak +
  '    DeleteFile(PdfFile);' + sLineBreak +
  '  end' + sLineBreak +
  '  else' + sLineBreak +
  '  begin' + sLineBreak +
  '    Result.Free;' + sLineBreak +
  '    raise Exception.Create(''Error generating PDF.'');' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function THtmlToPdf.HtmlFileToPdfFile(const AHtmlFile, APdfFile: string): Boolean;' + sLineBreak +
  '// converte um arquivo html em arquivo pdf' + sLineBreak +
  '{' + sLineBreak +
  'if HtmlFileToPdfFile(''c:\temp\teste.html'', ''c:\temp\teste.pdf'') then' + sLineBreak +
  '  ShowMessage(''PDF gerado com sucesso'')' + sLineBreak +
  'else' + sLineBreak +
  '  ShowMessage(''Erro na geração do PDF'');' + sLineBreak +
  '}' + sLineBreak +
  'var' + sLineBreak +
  '  Proc: TProcess;' + sLineBreak +
  '  lExe: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := False;' + sLineBreak +
  '  lExe := GetChromeExecutable;' + sLineBreak +
  '' + sLineBreak +
  '  if Trim(lExe) = '''' then' + sLineBreak +
  '    raise Exception.Create(''Resource not found: google-chrome, google-chrome-stable or chromium'');' + sLineBreak +
  '  if not FileExists(AHtmlFile) then' + sLineBreak +
  '    raise Exception.Create(''File not found: '' + AHtmlFile);' + sLineBreak +
  '' + sLineBreak +
  '  if APdfFile = '''' then' + sLineBreak +
  '    raise Exception.Create(''Output file not specified'');' + sLineBreak +
  '' + sLineBreak +
  '  Proc := TProcess.Create(nil);' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    Proc.Executable := lExe;' + sLineBreak +
  '    Proc.ShowWindow := swoHIDE;' + sLineBreak +
  '    Proc.Options := [poWaitOnExit, poNoConsole];' + sLineBreak +
  '    Proc.Parameters.Add(''--headless'');' + sLineBreak +
  '    Proc.Parameters.Add(''--disable-gpu'');' + sLineBreak +
  '    Proc.Parameters.Add(''--silent'');' + sLineBreak +
  '' + sLineBreak +
  '    {$IFDEF LINUX}' + sLineBreak +
  '    Proc.Parameters.Add(''--no-sandbox'');' + sLineBreak +
  '    Proc.Parameters.Add(''--disable-dev-shm-usage'');' + sLineBreak +
  '    {$ENDIF}' + sLineBreak +
  '' + sLineBreak +
  '    Proc.Parameters.Add(''--print-to-pdf-no-header'');' + sLineBreak +
  '    Proc.Parameters.Add(''--print-background'');' + sLineBreak +
  '    Proc.Parameters.Add(''--allow-file-access-from-files'');' + sLineBreak +
  '    Proc.Parameters.Add(''--print-to-pdf='' + APdfFile);' + sLineBreak +
  '    Proc.Parameters.Add(AHtmlFile);' + sLineBreak +
  '    Proc.Execute;' + sLineBreak +
  '' + sLineBreak +
  '    Result := FileExists(APdfFile);' + sLineBreak +
  '  finally' + sLineBreak +
  '    Proc.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaCore + 'core.htmltopdf.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_ApiFuncoes;
var
  s: string;
begin
  s :=
  'unit Api.Funcoes;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// funções comuns' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils;' + sLineBreak +
  '' + sLineBreak +
  'const' + sLineBreak +
  '  SUrlImagem = ''/images/''; // ''http://localhost:8083/public/images/'';' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TApiFuncoes }' + sLineBreak +
  '' + sLineBreak +
  '  TApiFuncoes = class' + sLineBreak +
  '  private' + sLineBreak +
  '' + sLineBreak +
  '  public' + sLineBreak +
  '    class function FatorVencimento(AData: TDateTime): string;' + sLineBreak +
  '    class function FormataNumero(ANumero: string; ALoop: Integer; AChar: Char; ATipo: string = ''''): string;' + sLineBreak +
  '    class function FormatFloatNotRounded(const AFormato: string; AValor: Double; ACasasDecimais: Integer): string;' + sLineBreak +
  '    class function NumeroParaReal(valor: Real; const dec: Integer; const bFormatoREAL: Boolean): String;' + sLineBreak +
  '    class function OnlyAlfabetic(const ATexto: string): string;' + sLineBreak +
  '    class function RealParaNumero(s: string; const dec: Integer): Double;' + sLineBreak +
  '    class function RemoveFormatacaoCurrency(s: string): string;' + sLineBreak +
  '    class function RemoverAcentos(const S: string): string;' + sLineBreak +
  '    class function ReplaceStr(const S, Srch, Replace: string): string;' + sLineBreak +
  '    class function TruncFloatToStr(AValor: Double): string;' + sLineBreak +
  '    class function DesenhaCodigoBarrasHtml(ACodigoBarras: string): string;' + sLineBreak +
  '    class function DesenhaCodigoBarrasSVG(ACodigoBarras: string): string;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  StrUtils, DateUtils, Math, unicodedata, RegExpr;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.FatorVencimento(AData: TDateTime): string;' + sLineBreak +
  '// calcula o fator de vencimento: entre 1000 e 9999' + sLineBreak +
  'var' + sLineBreak +
  '  LDataBase: TDateTime;' + sLineBreak +
  '  LDias: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  // Data base conforme regras da Febraban' + sLineBreak +
  '  if AData < EncodeDate(2025, 2, 22) then' + sLineBreak +
  '    LDataBase := EncodeDate(1997, 10, 7)' + sLineBreak +
  '  else' + sLineBreak +
  '    LDataBase := EncodeDate(2025, 2, 22);' + sLineBreak +
  '' + sLineBreak +
  '  LDias := DaysBetween(AData, LDataBase);' + sLineBreak +
  '' + sLineBreak +
  '  // Ajuste do fator de vencimento para boletos antigos/novos' + sLineBreak +
  '  if AData < EncodeDate(2025, 2, 22) then' + sLineBreak +
  '    Result := IntToStr(LDias)' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := IntToStr(LDias + 1000); // Exemplo de transição de ciclo' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.FormataNumero(ANumero: string; ALoop: Integer; AChar: Char; ATipo: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  S: string;' + sLineBreak +
  '  i: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  ATipo := Trim(LowerCase(ATipo));' + sLineBreak +
  '  if ATipo = '''' then ATipo := ''geral'';' + sLineBreak +
  '  // Remove caracteres não numéricos' + sLineBreak +
  '  S := '''';' + sLineBreak +
  '  for i := 1 to Length(ANumero) do' + sLineBreak +
  '    if ANumero[i] in [''0''..''9''] then S := S + ANumero[i];' + sLineBreak +
  '' + sLineBreak +
  '  if (ATipo = ''geral'') or (ATipo = ''valor'') then' + sLineBreak +
  '    Result := AddChar(AChar, S, ALoop)  // adiciona AChar à esquerda' + sLineBreak +
  '  else if ATipo = ''convenio'' then' + sLineBreak +
  '    Result := AddCharR(AChar, S, ALoop) // adiciona AChar à direita' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := S;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.RemoverAcentos(const S: string): string;' + sLineBreak +
  '// remove acento das letras' + sLineBreak +
  '// S := StringReplace(S, ''ä'', ''a'', [rfReplaceAll]); // tb funciona' + sLineBreak +
  'var' + sLineBreak +
  '  i: Integer;' + sLineBreak +
  '  Temp: UnicodeString;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '' + sLineBreak +
  '  // Converte para UnicodeString para tratar corretamente os acentos' + sLineBreak +
  '  Temp := UnicodeString(S);' + sLineBreak +
  '' + sLineBreak +
  '  // Normaliza para NFD e remove os acentos (combining marks)' + sLineBreak +
  '  Temp := NormalizeNFD(Temp);' + sLineBreak +
  '' + sLineBreak +
  '  for i := 1 to Length(Temp) do begin' + sLineBreak +
  '    // Remove caracteres de marcação (categoria Mn - Nonspacing Mark)' + sLineBreak +
  '    if (Ord(Temp[i]) < 768) or (Ord(Temp[i]) > 879) then  // Range aproximado de combining diacritical marks' + sLineBreak +
  '      Result := Result + string(Temp[i]);' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.OnlyAlfabetic(const ATexto: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  I: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '  for I := 1 to Length(ATexto) do begin' + sLineBreak +
  '    if (ATexto[I] in ['' '', ''a''..''z'', ''A''..''Z'']) then' + sLineBreak +
  '      Result := Result + ATexto[I];' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.RemoveFormatacaoCurrency(s: string): string;' + sLineBreak +
  '// remove a formatação ficando penas [-.,0123456789]' + sLineBreak +
  'var' + sLineBreak +
  '  c: Char;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '  for c in s do' + sLineBreak +
  '    if c in [''0''..''9'', ''-'','','', ''.''] then // ''A''..''Z''' + sLineBreak +
  '      AppendStr(Result, c);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.ReplaceStr(const S, Srch, Replace: string): string;' + sLineBreak +
  '// Substitui um valor por outro dentro da string' + sLineBreak +
  'var' + sLineBreak +
  '  i: Integer;' + sLineBreak +
  '  Source: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Source := S;' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '' + sLineBreak +
  '  repeat' + sLineBreak +
  '    i := Pos(UpperCase(Srch), UpperCase(Source));' + sLineBreak +
  '    if i > 0 then begin' + sLineBreak +
  '      Result := Result + Copy(Source, 1, i - 1) + Replace;' + sLineBreak +
  '      Source := Copy(Source, i + Length(Srch), MaxInt);' + sLineBreak +
  '    end' + sLineBreak +
  '    else' + sLineBreak +
  '      Result := Result + Source;' + sLineBreak +
  '  until i <= 0;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.NumeroParaReal(valor: Real; const dec: Integer; const bFormatoREAL: Boolean): String;' + sLineBreak +
  '// converte o número para o formato Real(String).' + sLineBreak +
  '// Exemplo: 2406.93 --> 2.406,93' + sLineBreak +
  'var' + sLineBreak +
  '  vlr: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  vlr := FloatToStrF(valor, ffCurrency, 999, dec );' + sLineBreak +
  '  vlr := RemoveFormatacaoCurrency(vlr);' + sLineBreak +
  '' + sLineBreak +
  '  If (not bFormatoREAL) or (dec < 1) Then //''Não coloca "." separando as milhares' + sLineBreak +
  '     vlr := ReplaceStr(vlr, DefaultFormatSettings.ThousandSeparator, ''''); //TFormatSettings' + sLineBreak +
  '' + sLineBreak +
  '  Result := vlr;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.RealParaNumero(s: string; const dec: Integer): Double;' + sLineBreak +
  '// Converte uma string em formato R$ em valor de ponto flutuante' + sLineBreak +
  'var' + sLineBreak +
  '  num: String;' + sLineBreak +
  '  valor: Double;' + sLineBreak +
  '  erro: Integer = 0;' + sLineBreak +
  '  idiv : Float;' + sLineBreak +
  'begin' + sLineBreak +
  '  num := Trim(s);' + sLineBreak +
  '  valor := 0.0;' + sLineBreak +
  '  idiv := Power(10.0, dec);  // 10^x' + sLineBreak +
  '' + sLineBreak +
  '  If num = '''' Then num := ''0'';' + sLineBreak +
  '' + sLineBreak +
  '  // Exemplo: 1.235,99 --> 1235.99' + sLineBreak +
  '  num := RemoveFormatacaoCurrency(num);' + sLineBreak +
  '  num := ReplaceStr(num, DefaultFormatSettings.DecimalSeparator, ''p''); // '',''' + sLineBreak +
  '  num := ReplaceStr(num, DefaultFormatSettings.ThousandSeparator, ''''); // ''.''' + sLineBreak +
  '  num := ReplaceStr(num, ''p'', ''.''); //''.''' + sLineBreak +
  '' + sLineBreak +
  '  // transforma em ponto número de flutuante' + sLineBreak +
  '  Val(num, valor, erro);' + sLineBreak +
  '' + sLineBreak +
  '  //valor := Round(valor * idiv) / idiv;' + sLineBreak +
  '  valor := RoundTo(valor, -1 * dec);' + sLineBreak +
  '' + sLineBreak +
  '  Result := valor;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.FormatFloatNotRounded(const AFormato: string; AValor: Double; ACasasDecimais: Integer): string;' + sLineBreak +
  '// AFormato: ''0.00''' + sLineBreak +
  '// Sem arredondamento de casas descimais: 10.959 --> 10.95' + sLineBreak +
  '// Result := Format(''%.2f'', [AValor]); // 10.959 --> 10.96' + sLineBreak +
  'var' + sLineBreak +
  '  lFator: Double;' + sLineBreak +
  '  lValorTruncado: Double;' + sLineBreak +
  'begin' + sLineBreak +
  '  lFator := Power(10, ACasasDecimais);' + sLineBreak +
  '  lValorTruncado := Trunc(AValor * lFator) / lFator;' + sLineBreak +
  '' + sLineBreak +
  '  Result := FormatFloat(AFormato, lValorTruncado);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.TruncFloatToStr(AValor: Double): string;' + sLineBreak +
  '// TruncFloatToStr(10.999); // 10.99' + sLineBreak +
  'var' + sLineBreak +
  '  ValorTrunc: Double;' + sLineBreak +
  'begin' + sLineBreak +
  '  ValorTrunc := Trunc(AValor * 100) / 100;   // Trunca para 2 casas' + sLineBreak +
  '  Result := FormatFloat(''0.00'', ValorTrunc);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.DesenhaCodigoBarrasHtml(ACodigoBarras: string): string;' + sLineBreak +
  'const' + sLineBreak +
  '  Padroes: array[0..9] of string =' + sLineBreak +
  '    (''00110'', ''10001'', ''01001'', ''11000'', ''00101'',' + sLineBreak +
  '     ''10100'', ''01100'', ''00011'', ''10010'', ''01010'');' + sLineBreak +
  'var' + sLineBreak +
  '  i, j, f, f1, f2: Integer;' + sLineBreak +
  '  Texto, Binario: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  // Início do Código (Start)' + sLineBreak +
  '  Result := ''<img src="'' + SUrlImagem + ''p.png" width="1" height="50" border="0">'' +' + sLineBreak +
  '            ''<img src="'' + SUrlImagem + ''b.png" width="1" height="50" border="0">'' +' + sLineBreak +
  '            ''<img src="'' + SUrlImagem + ''p.png" width="1" height="50" border="0">'' +' + sLineBreak +
  '            ''<img src="'' + SUrlImagem + ''b.png" width="1" height="50" border="0">'';' + sLineBreak +
  '' + sLineBreak +
  '  // Lógica de Intercalado 2 de 5' + sLineBreak +
  '  i := 1;' + sLineBreak +
  '  while i < Length(ACodigoBarras) do' + sLineBreak +
  '  begin' + sLineBreak +
  '    f1 := StrToInt(ACodigoBarras[i]);' + sLineBreak +
  '    f2 := StrToInt(ACodigoBarras[i+1]);' + sLineBreak +
  '    Binario := '''';' + sLineBreak +
  '' + sLineBreak +
  '    for j := 1 to 5 do Binario := Binario + Padroes[f1][j] + Padroes[f2][j];' + sLineBreak +
  '' + sLineBreak +
  '    for j := 1 to Length(Binario) do begin' + sLineBreak +
  '      if j mod 2 <> 0 then // Barra Preta' + sLineBreak +
  '        Result := Result + ''<img src="'' + SUrlImagem + ''p.png" width="'' + IntToStr(StrToInt(Binario[j])*2 + 1) + ''" height="50" border="0">''' + sLineBreak +
  '      else // Barra Branca' + sLineBreak +
  '        Result := Result + ''<img src="'' + SUrlImagem + ''b.png" width="'' + IntToStr(StrToInt(Binario[j])*2 + 1) + ''" height="50" border="0">'';' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    Inc(i, 2);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // Fim do Código (Stop)' + sLineBreak +
  '  Result := Result + ''<img src="'' + SUrlImagem + ''p.png" width="3" height="50" border="0">'' +' + sLineBreak +
  '            ''<img src="'' + SUrlImagem + ''b.png" width="1" height="50" border="0">'' +' + sLineBreak +
  '            ''<img src="'' + SUrlImagem + ''p.png" width="1" height="50" border="0">'';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TApiFuncoes.DesenhaCodigoBarrasSVG(ACodigoBarras: string): string;' + sLineBreak +
  'const' + sLineBreak +
  '  // Padrões do Intercalado 2 de 5 (0 a 9)' + sLineBreak +
  '  Padroes: array[0..9] of string =' + sLineBreak +
  '    (''00110'', ''10001'', ''01001'', ''11000'', ''00101'',' + sLineBreak +
  '     ''10100'', ''01100'', ''00011'', ''10010'', ''01010'');' + sLineBreak +
  'var' + sLineBreak +
  '  i, j, f1, f2: Integer;' + sLineBreak +
  '  Binario: string;' + sLineBreak +
  '  PosX: Double;' + sLineBreak +
  '  LarguraBarra: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  PosX := 0;' + sLineBreak +
  '  // Iniciamos a string do SVG.' + sLineBreak +
  '  // O viewbox será ajustado dinamicamente conforme as barras são desenhadas.' + sLineBreak +
  '  Result := ''<svg xmlns="http://www.w3.org/2000/svg" height="50" style="background-color: white;">'';' + sLineBreak +
  '' + sLineBreak +
  '  // --- START (Início do código de barras) ---' + sLineBreak +
  '  // Sequência: Barra Fina, Espaço Fino, Barra Fina, Espaço Fino' + sLineBreak +
  '  Result := Result + ''<rect x="0" y="0" width="1" height="50" fill="black" />'';' + sLineBreak +
  '  Result := Result + ''<rect x="1" y="0" width="1" height="50" fill="white" />'';' + sLineBreak +
  '  Result := Result + ''<rect x="2" y="0" width="1" height="50" fill="black" />'';' + sLineBreak +
  '  Result := Result + ''<rect x="3" y="0" width="1" height="50" fill="white" />'';' + sLineBreak +
  '  PosX := 4;' + sLineBreak +
  '' + sLineBreak +
  '  // --- CORPO (Intercalado 2 de 5) ---' + sLineBreak +
  '  i := 1;' + sLineBreak +
  '  while i < Length(ACodigoBarras) do' + sLineBreak +
  '  begin' + sLineBreak +
  '    f1 := StrToInt(ACodigoBarras[i]);' + sLineBreak +
  '    f2 := StrToInt(ACodigoBarras[i+1]);' + sLineBreak +
  '' + sLineBreak +
  '    // Intercala os padrões de f1 (barras) e f2 (espaços)' + sLineBreak +
  '    Binario := '''';' + sLineBreak +
  '    for j := 1 to 5 do' + sLineBreak +
  '      Binario := Binario + Padroes[f1][j] + Padroes[f2][j];' + sLineBreak +
  '' + sLineBreak +
  '    for j := 1 to Length(Binario) do' + sLineBreak +
  '    begin' + sLineBreak +
  '      // Se ''0'' largura fina (1px), se ''1'' largura larga (3px)' + sLineBreak +
  '      if Binario[j] = ''0'' then LarguraBarra := 1 else LarguraBarra := 3;' + sLineBreak +
  '' + sLineBreak +
  '      // j ímpar = Barra (Preta), j par = Espaço (Branco/Transparente)' + sLineBreak +
  '      if j mod 2 <> 0 then' + sLineBreak +
  '        Result := Result + Format(''<rect x="%.0f" y="0" width="%d" height="50" fill="black" />'', [PosX, LarguraBarra]);' + sLineBreak +
  '' + sLineBreak +
  '      PosX := PosX + LarguraBarra;' + sLineBreak +
  '    end;' + sLineBreak +
  '    Inc(i, 2);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // --- STOP (Fim do código de barras) ---' + sLineBreak +
  '  // Sequência: Barra Larga, Espaço Fino, Barra Fina' + sLineBreak +
  '  Result := Result + Format(''<rect x="%.0f" y="0" width="3" height="50" fill="black" />'', [PosX]);' + sLineBreak +
  '  Result := Result + Format(''<rect x="%.0f" y="0" width="1" height="50" fill="white" />'', [PosX + 3]);' + sLineBreak +
  '  Result := Result + Format(''<rect x="%.0f" y="0" width="1" height="50" fill="black" />'', [PosX + 4]);' + sLineBreak +
  '' + sLineBreak +
  '  PosX := PosX + 5;' + sLineBreak +
  '' + sLineBreak +
  '  // Fecha o SVG definindo a largura final calculada' + sLineBreak +
  '  Result := StringReplace(Result, ''<svg '', Format(''<svg width="%.0f" '', [PosX]), [rfReplaceAll]);' + sLineBreak +
  '  Result := Result + ''</svg>'';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'api.funcoes.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_BancoBradesco;
var
  s: string;
begin
  s :=
  'unit Boleto.BancoBradesco;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// gera informações para o boleto: 237' + sLineBreak +
  '' + sLineBreak +
  '{$mode objfpc}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  SysUtils, Classes,' + sLineBreak +
  '  Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TBoletoBancoBradesco }' + sLineBreak +
  '' + sLineBreak +
  '  TBoletoBancoBradesco = class' + sLineBreak +
  '  private' + sLineBreak +
  '    function Modulo_10(const ADados: string): string;' + sLineBreak +
  '    function Modulo_11(const ADados: string; ALimiteSup, AFlag: Integer): Integer;' + sLineBreak +
  '    function DigitoVerificador_Barra(const ADados: string): string;' + sLineBreak +
  '    function DigitoVerificador_NossoNumero(const ADados: string): string;' + sLineBreak +
  '    function MontaLinhaDigitavel(const ACodigo: string): string;' + sLineBreak +
  '  public' + sLineBreak +
  '    function GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '    class function new: TBoletoBancoBradesco;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  StrUtils, DateUtils,' + sLineBreak +
  '  Api.Funcoes;' + sLineBreak +
  '' + sLineBreak +
  'class function TBoletoBancoBradesco.new: TBoletoBancoBradesco;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TBoletoBancoBradesco.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBradesco.GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '// retorna dados da linha digitável' + sLineBreak +
  'var' + sLineBreak +
  '  NumMoeda, Fator, ValorFormatado, nossoNumero, NNum: string;' + sLineBreak +
  '  dv_nosso_numero, DV_Barra, linha: string;' + sLineBreak +
  '  agencia, codigoBanco, conta_cedente: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  // tipo da moeda' + sLineBreak +
  '  NumMoeda := ABoleto.Titulo.MoedaTipo;' + sLineBreak +
  '  if NumMoeda = '''' then NumMoeda := ''9'';' + sLineBreak +
  '' + sLineBreak +
  '  Fator := TApiFuncoes.FatorVencimento(ABoleto.Titulo.DataVencimento);' + sLineBreak +
  '' + sLineBreak +
  '  // Valor sem vírgula e com 10 dígitos' + sLineBreak +
  '  //ValorFormatado := FormatFloat(''0000000000'', ABoleto.Titulo.Valor * 100);;' + sLineBreak +
  '  ValorFormatado := TApiFuncoes.FormataNumero(FormatFloat(''0.00'', ABoleto.Titulo.Valor), 10, ''0'', ''valor'');' + sLineBreak +
  '' + sLineBreak +
  '  agencia := TApiFuncoes.FormataNumero(ABoleto.Conta.Agencia, 4, ''0'', '''');' + sLineBreak +
  '  conta_cedente := TApiFuncoes.FormataNumero(ABoleto.Conta.ContaCorrente, 7, ''0'');' + sLineBreak +
  '  codigoBanco := ABoleto.Conta.BancoCodigo;' + sLineBreak +
  '' + sLineBreak +
  '  // Nosso número sem o DV (11 dígitos)' + sLineBreak +
  '  nossoNumero := ABoleto.Titulo.NossoNumero;' + sLineBreak +
  '  nossoNumero := LeftStr(nossoNumero, Length(nossoNumero) - 1);' + sLineBreak +
  '  NNum := TApiFuncoes.FormataNumero(ABoleto.Conta.Carteira, 2, ''0'') + TApiFuncoes.FormataNumero(nossonumero, 11, ''0'');' + sLineBreak +
  '  dv_nosso_numero := DigitoVerificador_NossoNumero(NNum);' + sLineBreak +
  '' + sLineBreak +
  '  // Cálculo do DV do Código de Barras (43 posições para o cálculo)' + sLineBreak +
  '  DV_Barra := DigitoVerificador_Barra(codigoBanco + NumMoeda + Fator + ValorFormatado + agencia + NNum + conta_cedente + ''0'');' + sLineBreak +
  '' + sLineBreak +
  '  // Montagem final do Código de Barras (44 dígitos)' + sLineBreak +
  '  linha :=' + sLineBreak +
  '    codigoBanco +' + sLineBreak +
  '    NumMoeda +' + sLineBreak +
  '    DV_Barra +' + sLineBreak +
  '    Fator +' + sLineBreak +
  '    ValorFormatado +' + sLineBreak +
  '    agencia +' + sLineBreak +
  '    NNum +' + sLineBreak +
  '    conta_cedente +' + sLineBreak +
  '    ''0'';' + sLineBreak +
  '' + sLineBreak +
  '  Result.CodigoBarras   := linha;' + sLineBreak +
  '  Result.LinhaDigitavel := MontaLinhaDigitavel(linha);' + sLineBreak +
  '  //Result.LinhaDigitavel := StringReplace( MontaLinhaDigitavel(linha), ''.'', '' '', [rfReplaceAll]);' + sLineBreak +
  '  Result.NossoNumero    := Copy(NNum, 1, 2) + ''/'' + Copy(NNum, 3, Length(NNum)) + ''-'' + dv_nosso_numero;' + sLineBreak +
  '  //Result.DesenhoCodigoBarras := TApiFuncoes.DesenhaCodigoBarrasSVG(linha);' + sLineBreak +
  '' + sLineBreak +
  '  ABoleto.Titulo.CodigoBarras   := Result.CodigoBarras;' + sLineBreak +
  '  ABoleto.Titulo.LinhaDigitavel := Result.LinhaDigitavel;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBradesco.DigitoVerificador_NossoNumero(const ADados: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  Resto, Digito: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Resto := Modulo_11(ADados, 7, 1);' + sLineBreak +
  '  Digito := 11 - Resto;' + sLineBreak +
  '  if Digito = 10 then Result := ''P''' + sLineBreak +
  '  else if Digito = 11 then Result := ''0''' + sLineBreak +
  '  else Result := IntToStr(Digito);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBradesco.DigitoVerificador_Barra(const ADados: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  Resto, DV: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Resto := Modulo_11(ADados, 9, 1);' + sLineBreak +
  '  if (Resto = 0) or (Resto = 1) or (Resto = 10) then' + sLineBreak +
  '    DV := 1' + sLineBreak +
  '  else' + sLineBreak +
  '    DV := 11 - Resto;' + sLineBreak +
  '  Result := IntToStr(DV);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBradesco.Modulo_10(const ADados: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  Mult, Total, Res, I: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Mult := (Length(ADados) mod 2) + 1;' + sLineBreak +
  '  Total := 0;' + sLineBreak +
  '' + sLineBreak +
  '  for I := 1 to Length(ADados) do begin' + sLineBreak +
  '    Res := StrToInt(ADados[I]) * Mult;' + sLineBreak +
  '    if Res > 9 then Res := (Res div 10) + (Res mod 10);' + sLineBreak +
  '    Total := Total + Res;' + sLineBreak +
  '    if Mult = 2 then Mult := 1 else Mult := 2;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := IntToStr(((10 - (Total mod 10)) mod 10));' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBradesco.Modulo_11(const ADados: string; ALimiteSup, AFlag: Integer): Integer;' + sLineBreak +
  'var' + sLineBreak +
  '  Mult, Total, I, NResto: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Mult := 1 + (Length(ADados) mod (ALimiteSup - 1));' + sLineBreak +
  '  if Mult = 1 then Mult := ALimiteSup;' + sLineBreak +
  '  Total := 0;' + sLineBreak +
  '' + sLineBreak +
  '  for I := 1 to Length(ADados) do begin' + sLineBreak +
  '    Total := Total + (StrToInt(ADados[I]) * Mult);' + sLineBreak +
  '    Dec(Mult);' + sLineBreak +
  '    if Mult = 1 then Mult := ALimiteSup;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  NResto := Total mod 11;' + sLineBreak +
  '' + sLineBreak +
  '  if AFlag = 1 then' + sLineBreak +
  '    Result := NResto' + sLineBreak +
  '  else' + sLineBreak +
  '  begin' + sLineBreak +
  '    if (NResto = 0) or (NResto = 1) or (NResto = 10) then Result := 1' + sLineBreak +
  '    else Result := 11 - NResto;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBradesco.MontaLinhaDigitavel(const ACodigo: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  P1, P2, P3, P4, Campo1, Campo2, Campo3, Campo4, Campo5: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  // Campo 1' + sLineBreak +
  '  P1 := Copy(ACodigo, 1, 4);' + sLineBreak +
  '  P2 := Copy(ACodigo, 20, 5);' + sLineBreak +
  '  P3 := Modulo_10(P1 + P2);' + sLineBreak +
  '  P4 := P1 + P2 + P3;' + sLineBreak +
  '  Campo1 := Copy(P4, 1, 5) + ''.'' + Copy(P4, 6, 5);' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 2' + sLineBreak +
  '  P1 := Copy(ACodigo, 25, 10);' + sLineBreak +
  '  P2 := Modulo_10(P1);' + sLineBreak +
  '  P3 := P1 + P2;' + sLineBreak +
  '  Campo2 := Copy(P3, 1, 5) + ''.'' + Copy(P3, 6, 6);' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 3' + sLineBreak +
  '  P1 := Copy(ACodigo, 35, 10);' + sLineBreak +
  '  P2 := Modulo_10(P1);' + sLineBreak +
  '  P3 := P1 + P2;' + sLineBreak +
  '  Campo3 := Copy(P3, 1, 5) + ''.'' + Copy(P3, 6, 6);' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 4' + sLineBreak +
  '  Campo4 := Copy(ACodigo, 5, 1);' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 5' + sLineBreak +
  '  Campo5 := Copy(ACodigo, 6, 4) + Copy(ACodigo, 10, 10);' + sLineBreak +
  '' + sLineBreak +
  '  Result := Campo1 + '' '' + Campo2 + '' '' + Campo3 + '' '' + Campo4 + '' '' + Campo5;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.bancobradesco.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_BancoBrasil;
var
  s: string;
begin
  s :=
  'unit Boleto.BancoBrasil;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// gera informações para o boleto: 001' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils,' + sLineBreak +
  '  Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TBoletoBancoBrasil }' + sLineBreak +
  '' + sLineBreak +
  '  TBoletoBancoBrasil = class' + sLineBreak +
  '  private' + sLineBreak +
  '    function Modulo_10(const ADados: string): Integer;' + sLineBreak +
  '    function Modulo_11(const ADados: string; Base: Integer; R: Integer): string;' + sLineBreak +
  '    function MontaLinhaDigitavel(const ACodigo: string): string;' + sLineBreak +
  '  public' + sLineBreak +
  '    function GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '    class function new: TBoletoBancoBrasil;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  StrUtils, DateUtils,' + sLineBreak +
  '  Api.Funcoes;' + sLineBreak +
  '' + sLineBreak +
  '{ TBoletoBancoBrasil }' + sLineBreak +
  '' + sLineBreak +
  'class function TBoletoBancoBrasil.new: TBoletoBancoBrasil;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TBoletoBancoBrasil.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBrasil.GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '// retorna dados da linha digitável' + sLineBreak +
  'var' + sLineBreak +
  '  ValorFormatado, Fator, NossoNum, Linha, DV_Geral: string;' + sLineBreak +
  '  Agencia, Conta, Convenio, Carteira, Livre_Zeros: string;' + sLineBreak +
  '  FormatacaoConvenio: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Fator := TApiFuncoes.FatorVencimento(ABoleto.Titulo.DataVencimento);' + sLineBreak +
  '  ValorFormatado := TApiFuncoes.FormataNumero(FormatFloat(''0.00'', ABoleto.Titulo.Valor), 10, ''0'',''valor'');' + sLineBreak +
  '' + sLineBreak +
  '  Agencia := TApiFuncoes.FormataNumero(ABoleto.Conta.Agencia, 4, ''0'');' + sLineBreak +
  '  Conta   := TApiFuncoes.FormataNumero(ABoleto.Conta.ContaCorrente, 8, ''0'');' + sLineBreak +
  '' + sLineBreak +
  '  Convenio := Trim(ABoleto.Conta.Convenio);' + sLineBreak +
  '  if Convenio = '''' then Convenio := ABoleto.Conta.CodigoCedente;' + sLineBreak +
  '' + sLineBreak +
  '  Carteira := TApiFuncoes.FormataNumero(ABoleto.Conta.Carteira, 2, ''0'');' + sLineBreak +
  '  Livre_Zeros := ''000000'';' + sLineBreak +
  '' + sLineBreak +
  '  FormatacaoConvenio := Length(Convenio); // quantidade de dígitos do convênio' + sLineBreak +
  '  NossoNum := ABoleto.Titulo.NossoNumero;' + sLineBreak +
  '' + sLineBreak +
  '  //''0019'' banco + moeda' + sLineBreak +
  '  // Lógica de montagem conforme o tamanho do convênio' + sLineBreak +
  '  case FormatacaoConvenio of' + sLineBreak +
  '    8: begin' + sLineBreak +
  '      Convenio := TApiFuncoes.FormataNumero(Convenio, 8, ''0'');' + sLineBreak +
  '      NossoNum := TApiFuncoes.FormataNumero(NossoNum, 9, ''0'');' + sLineBreak +
  '      // No BB, para o código de barras, o DV é calculado sobre 43 posições' + sLineBreak +
  '      DV_Geral := Modulo_11(''0019'' + Fator + ValorFormatado + Livre_Zeros + Convenio + NossoNum + Carteira, 9, 0);' + sLineBreak +
  '      Linha := ''0019'' + DV_Geral + Fator + ValorFormatado + Livre_Zeros + Convenio + NossoNum + Carteira;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    7: begin' + sLineBreak +
  '      Convenio := TApiFuncoes.FormataNumero(Convenio, 7, ''0'');' + sLineBreak +
  '      NossoNum := TApiFuncoes.FormataNumero(NossoNum, 10, ''0'');' + sLineBreak +
  '      DV_Geral := Modulo_11(''0019'' + Fator + ValorFormatado + Livre_Zeros + Convenio + NossoNum + Carteira, 9, 0);' + sLineBreak +
  '      Linha := ''0019'' + DV_Geral + Fator + ValorFormatado + Livre_Zeros + Convenio + NossoNum + Carteira;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    6: begin' + sLineBreak +
  '      Convenio := TApiFuncoes.FormataNumero(Convenio, 6, ''0'');' + sLineBreak +
  '      // Regra para convênio de 6 dígitos (Geralmente carteira 16 ou 18)' + sLineBreak +
  '      if Length(NossoNum) <= 5 then' + sLineBreak +
  '      begin' + sLineBreak +
  '        NossoNum := TApiFuncoes.FormataNumero(NossoNum, 5, ''0'');' + sLineBreak +
  '        DV_Geral := Modulo_11(''0019'' + Fator + ValorFormatado + Convenio + NossoNum + Agencia + Conta + Carteira, 9, 0);' + sLineBreak +
  '        Linha := ''0019'' + DV_Geral + Fator + ValorFormatado + Convenio + NossoNum + Agencia + Conta + Carteira;' + sLineBreak +
  '      end' + sLineBreak +
  '      else' + sLineBreak +
  '      begin' + sLineBreak +
  '        // Nosso número de 17 dígitos' + sLineBreak +
  '        NossoNum := TApiFuncoes.FormataNumero(NossoNum, 17, ''0'');' + sLineBreak +
  '        DV_Geral := Modulo_11(''0019'' + Fator + ValorFormatado + Convenio + NossoNum + ''21'', 9, 0);' + sLineBreak +
  '        Linha := ''0019'' + DV_Geral + Fator + ValorFormatado + Convenio + NossoNum + ''21'';' + sLineBreak +
  '      end;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result.CodigoBarras   := linha;' + sLineBreak +
  '  Result.LinhaDigitavel := MontaLinhaDigitavel(linha);' + sLineBreak +
  '  //Result.LinhaDigitavel := StringReplace( MontaLinhaDigitavel(linha), ''.'', '' '', [rfReplaceAll]);' + sLineBreak +
  '  Result.NossoNumero    := NossoNum;' + sLineBreak +
  '  //Result.DesenhoCodigoBarras := TApiFuncoes.DesenhaCodigoBarrasSVG(linha);' + sLineBreak +
  '' + sLineBreak +
  '  ABoleto.Titulo.CodigoBarras   := Result.CodigoBarras;' + sLineBreak +
  '  ABoleto.Titulo.LinhaDigitavel := Result.LinhaDigitavel;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBrasil.Modulo_10(const ADados: string): Integer;' + sLineBreak +
  'var' + sLineBreak +
  '  Total, Fator, I, Res: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Total := 0;' + sLineBreak +
  '  Fator := 2;' + sLineBreak +
  '' + sLineBreak +
  '  for I := Length(ADados) downto 1 do begin' + sLineBreak +
  '    Res := StrToInt(ADados[I]) * Fator;' + sLineBreak +
  '    if Res > 9 then Res := (Res div 10) + (Res mod 10);' + sLineBreak +
  '    Total := Total + Res;' + sLineBreak +
  '    if Fator = 2 then Fator := 1 else Fator := 2;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := (10 - (Total mod 10)) mod 10;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBrasil.Modulo_11(const ADados: string; Base: Integer; R: Integer): string;' + sLineBreak +
  'var' + sLineBreak +
  '  Soma, Fator, I, Resto: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Soma := 0;' + sLineBreak +
  '  Fator := 2;' + sLineBreak +
  '  if Base = 0 then Base := 9;' + sLineBreak +
  '' + sLineBreak +
  '  for I := Length(ADados) downto 1 do begin' + sLineBreak +
  '    Soma := Soma + (StrToInt(ADados[I]) * Fator);' + sLineBreak +
  '    if Fator = Base then Fator := 1;' + sLineBreak +
  '    Inc(Fator);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  if R = 0 then begin' + sLineBreak +
  '    Resto := (Soma * 10) mod 11;' + sLineBreak +
  '    if Resto = 10 then' + sLineBreak +
  '      Result := ''X''' + sLineBreak +
  '    else begin' + sLineBreak +
  '      // Regra específica para a Linha Digitável (43 chars)' + sLineBreak +
  '      if (Length(ADados) = 43) and (Resto = 0) then Result := ''1''' + sLineBreak +
  '      else Result := IntToStr(Resto);' + sLineBreak +
  '    end;' + sLineBreak +
  '  end' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := IntToStr(Soma mod 11);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoBrasil.MontaLinhaDigitavel(const ACodigo: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  P1, P2, P3, DV, Campo1, Campo2, Campo3, Campo4, Campo5: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  // Campo 1' + sLineBreak +
  '  P1 := Copy(ACodigo, 1, 4);' + sLineBreak +
  '  P2 := Copy(ACodigo, 20, 5);' + sLineBreak +
  '  DV := IntToStr(Modulo_10(P1 + P2));' + sLineBreak +
  '  Campo1 := Copy(P1 + P2 + DV, 1, 5) + ''.'' + Copy(P1 + P2 + DV, 6, 5);' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 2' + sLineBreak +
  '  P1 := Copy(ACodigo, 25, 10);' + sLineBreak +
  '  DV := IntToStr(Modulo_10(P1));' + sLineBreak +
  '  Campo2 := Copy(P1 + DV, 1, 5) + ''.'' + Copy(P1 + DV, 6, 6);' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 3' + sLineBreak +
  '  P1 := Copy(ACodigo, 35, 10);' + sLineBreak +
  '  DV := IntToStr(Modulo_10(P1));' + sLineBreak +
  '  Campo3 := Copy(P1 + DV, 1, 5) + ''.'' + Copy(P1 + DV, 6, 6);' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 4' + sLineBreak +
  '  Campo4 := Copy(ACodigo, 5, 1);' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 5' + sLineBreak +
  '  Campo5 := Copy(ACodigo, 6, 14);' + sLineBreak +
  '' + sLineBreak +
  '  Result := Campo1 + '' '' + Campo2 + '' '' + Campo3 + '' '' + Campo4 + '' '' + Campo5;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.bancobrasil.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_CaixaFederal;
var
  s: string;
begin
  s :=
  'unit Boleto.BancoCEF;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// gera informações para o boleto: 104 (Caixa Econômica Federal)' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils,' + sLineBreak +
  '  Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TBoletoBancoCEF }' + sLineBreak +
  '' + sLineBreak +
  '  TBoletoBancoCEF = class' + sLineBreak +
  '  private' + sLineBreak +
  '    function Modulo_10(const Texto: string): Integer;' + sLineBreak +
  '    function Modulo_11(const Texto: string): Integer;' + sLineBreak +
  '  public' + sLineBreak +
  '    function GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '    class function new: TBoletoBancoCEF;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  StrUtils, DateUtils,' + sLineBreak +
  '  Api.Funcoes;' + sLineBreak +
  '' + sLineBreak +
  '{ TBoletoBancoCEF }' + sLineBreak +
  '' + sLineBreak +
  'class function TBoletoBancoCEF.new: TBoletoBancoCEF;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TBoletoBancoCEF.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoCEF.GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '// retorna dados da linha digitável' + sLineBreak +
  'var' + sLineBreak +
  '  Fator, ValorFormatado: string;' + sLineBreak +
  '  Beneficiario, NossoNumero: string;' + sLineBreak +
  '  CampoLivreSemDV, CampoLivre: string;' + sLineBreak +
  '  BaseBarcode, Barra, DV_Geral: string;' + sLineBreak +
  '  C1, C2, C3, Linha: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Fator := TApiFuncoes.FatorVencimento(ABoleto.Titulo.DataVencimento);' + sLineBreak +
  '  ValorFormatado := TApiFuncoes.FormataNumero(FormatFloat(''0.00'', ABoleto.Titulo.Valor), 10, ''0'', ''valor'');' + sLineBreak +
  '  Beneficiario := TApiFuncoes.FormataNumero(ABoleto.Conta.ContaCorrente, 7, ''0'');' + sLineBreak +
  '  NossoNumero := TApiFuncoes.FormataNumero(ABoleto.Titulo.NossoNumero, 17, ''0'');' + sLineBreak +
  '' + sLineBreak +
  '  // 1. Montagem do Campo Livre (Beneficiário 7 dígitos + Nosso Número 15/17(??) dígitos), conforme manual' + sLineBreak +
  '  CampoLivreSemDV := Beneficiario + NossoNumero;' + sLineBreak +
  '  CampoLivre := CampoLivreSemDV + IntToStr(Modulo_10(CampoLivreSemDV));' + sLineBreak +
  '' + sLineBreak +
  '  // 2. Base do Código de Barras (Banco 104 + Moeda 9 + Fator + Valor + Campo Livre)' + sLineBreak +
  '  BaseBarcode := ''1049'' + Fator + ValorFormatado + CampoLivre;' + sLineBreak +
  '  DV_Geral := IntToStr(Modulo_11(BaseBarcode));' + sLineBreak +
  '' + sLineBreak +
  '  // Código de Barras Final (DV na posição 5)' + sLineBreak +
  '  Barra := ''1049'' + DV_Geral + Fator + ValorFormatado + CampoLivre;' + sLineBreak +
  '' + sLineBreak +
  '  // 3. Montagem da Linha Digitável' + sLineBreak +
  '  // Campo 1: 104 + 9 + 5 primeiros do campo livre + DV' + sLineBreak +
  '  C1 := ''1049'' + Copy(CampoLivre, 1, 5);' + sLineBreak +
  '  C1 := C1 + IntToStr(Modulo_10(C1));' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 2: Próximos 10 dígitos do campo livre + DV' + sLineBreak +
  '  C2 := Copy(CampoLivre, 6, 10);' + sLineBreak +
  '  C2 := C2 + IntToStr(Modulo_10(C2));' + sLineBreak +
  '' + sLineBreak +
  '  // Campo 3: Restante 10 dígitos do campo livre + DV' + sLineBreak +
  '  C3 := Copy(CampoLivre, 16, 10);' + sLineBreak +
  '  C3 := C3 + IntToStr(Modulo_10(C3));' + sLineBreak +
  '' + sLineBreak +
  '  // Formatação final' + sLineBreak +
  '  Linha := Format(''%s.%s %s.%s %s.%s %s %s%s'', [' + sLineBreak +
  '    Copy(C1, 1, 5), Copy(C1, 6, 5),' + sLineBreak +
  '    Copy(C2, 1, 5), Copy(C2, 6, 6),' + sLineBreak +
  '    Copy(C3, 1, 5), Copy(C3, 6, 6),' + sLineBreak +
  '    DV_Geral,' + sLineBreak +
  '    Fator,' + sLineBreak +
  '    ValorFormatado' + sLineBreak +
  '  ]);' + sLineBreak +
  '' + sLineBreak +
  '  Result.CodigoBarras   := Barra;' + sLineBreak +
  '  Result.LinhaDigitavel := Linha;' + sLineBreak +
  '  //Result.LinhaDigitavel := StringReplace(Linha, ''.'', '' '', [rfReplaceAll]);' + sLineBreak +
  '  Result.NossoNumero    := NossoNumero;' + sLineBreak +
  '  //Result.DesenhoCodigoBarras := TApiFuncoes.DesenhaCodigoBarrasSVG(linha);' + sLineBreak +
  '' + sLineBreak +
  '  ABoleto.Titulo.CodigoBarras   := Result.CodigoBarras;' + sLineBreak +
  '  ABoleto.Titulo.LinhaDigitavel := Result.LinhaDigitavel;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ Calcula o dígito verificador para os blocos da linha digitável }' + sLineBreak +
  'function TBoletoBancoCEF.Modulo_10(const Texto: string): Integer;' + sLineBreak +
  'var' + sLineBreak +
  '  I, Soma, Peso, Multi: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Soma := 0;' + sLineBreak +
  '  Peso := 2;' + sLineBreak +
  '  for I := Length(Texto) downto 1 do' + sLineBreak +
  '  begin' + sLineBreak +
  '    Multi := StrToInt(Texto[I]) * Peso;' + sLineBreak +
  '    if Multi > 9 then' + sLineBreak +
  '      Multi := (Multi div 10) + (Multi mod 10);' + sLineBreak +
  '    Soma := Soma + Multi;' + sLineBreak +
  '    if Peso = 2 then Peso := 1 else Peso := 2;' + sLineBreak +
  '  end;' + sLineBreak +
  '  Result := 10 - (Soma mod 10);' + sLineBreak +
  '  if Result >= 10 then Result := 0;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  '{ Calcula o DV Geral do Código de Barras (Posição 5) }' + sLineBreak +
  'function TBoletoBancoCEF.Modulo_11(const Texto: string): Integer;' + sLineBreak +
  'var' + sLineBreak +
  '  I, Soma, Peso: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Soma := 0;' + sLineBreak +
  '  Peso := 2;' + sLineBreak +
  '  for I := Length(Texto) downto 1 do' + sLineBreak +
  '  begin' + sLineBreak +
  '    Soma := Soma + (StrToInt(Texto[I]) * Peso);' + sLineBreak +
  '    Inc(Peso);' + sLineBreak +
  '    if Peso > 9 then Peso := 2;' + sLineBreak +
  '  end;' + sLineBreak +
  '  Result := 11 - (Soma mod 11);' + sLineBreak +
  '  if (Result = 0) or (Result = 10) or (Result = 11) then' + sLineBreak +
  '    Result := 1;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.bancocef.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_BancoItau;
var
  s: string;
begin
  s :=
  'unit Boleto.BancoItau;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// gera informações para o boleto: 341' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils,' + sLineBreak +
  '  Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '{ TBoletoBancoItau }' + sLineBreak +
  '' + sLineBreak +
  '  TBoletoBancoItau = class' + sLineBreak +
  '  private' + sLineBreak +
  '    function Modulo_10(const ADados: string): Integer;' + sLineBreak +
  '    function Modulo_11(const ADados: string; ALimiteSup, AFlag: Integer): Integer;' + sLineBreak +
  '    function DigitoVerificadorBarra(const ADados: string): string;' + sLineBreak +
  '    function GeraCodigoBanco(const ADados: string): string;' + sLineBreak +
  '    function MontaLinhaDigitavel(const ACodigo: string): string;' + sLineBreak +
  '  public' + sLineBreak +
  '    function GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '    class function new: TBoletoBancoItau;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  StrUtils, DateUtils,' + sLineBreak +
  '  Api.Funcoes;' + sLineBreak +
  '' + sLineBreak +
  '{ TBoletoBancoItau }' + sLineBreak +
  'class function TBoletoBancoItau.new: TBoletoBancoItau;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TBoletoBancoItau.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoItau.GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '// retorna dados da linha digitável' + sLineBreak +
  'var' + sLineBreak +
  '  linha, fator, valorStr, nossoNumero, carteira: string;' + sLineBreak +
  '  agencia, conta, moeda: string;' + sLineBreak +
  '  dv: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  fator := TApiFuncoes.FatorVencimento( ABoleto.Titulo.DataVencimento );' + sLineBreak +
  '' + sLineBreak +
  '  //carteira pode ser: 109, 175, 174, 104, 109, 178, ou 157' + sLineBreak +
  '  carteira := AddChar(''0'', ABoleto.Conta.Carteira, 3);' + sLineBreak +
  '' + sLineBreak +
  '  //valorStr := FormatFloat(''0000000000'', ABoleto.Titulo.Valor * 100);' + sLineBreak +
  '  valorStr := TApiFuncoes.FormataNumero(FloatToStr(ABoleto.Titulo.Valor), 10, ''0'', ''valor'');' + sLineBreak +
  '' + sLineBreak +
  '  nossoNumero := ABoleto.Titulo.NossoNumero;' + sLineBreak +
  '  if Length(nossoNumero) > 8 then nossoNumero := LeftStr(nossoNumero, 8);' + sLineBreak +
  '  nossoNumero := AddChar(''0'', nossoNumero, 8);' + sLineBreak +
  '' + sLineBreak +
  '  //agencia é 4 digitos' + sLineBreak +
  '  agencia := AddChar(''0'', ABoleto.Conta.Agencia, 4);' + sLineBreak +
  '' + sLineBreak +
  '  //conta é 5 digitos e sem DV' + sLineBreak +
  '  conta := AddChar(''0'', ABoleto.Conta.ContaCorrente, 5);' + sLineBreak +
  '' + sLineBreak +
  '  // tipo da moeda' + sLineBreak +
  '  moeda := ABoleto.Titulo.MoedaTipo;' + sLineBreak +
  '  if moeda = '''' then moeda := ''9'';' + sLineBreak +
  '' + sLineBreak +
  '  linha :=' + sLineBreak +
  '    ABoleto.Conta.BancoCodigo +' + sLineBreak +
  '    moeda +' + sLineBreak +
  '    fator +' + sLineBreak +
  '    valorStr +' + sLineBreak +
  '    carteira +' + sLineBreak +
  '    nossoNumero +' + sLineBreak +
  '    IntToStr(Modulo_10(agencia + conta + carteira + nossoNumero)) +' + sLineBreak +
  '    agencia +' + sLineBreak +
  '    conta +' + sLineBreak +
  '    IntToStr(Modulo_10(agencia + conta)) +' + sLineBreak +
  '    ''000'';' + sLineBreak +
  '' + sLineBreak +
  '  dv := DigitoVerificadorBarra(linha);' + sLineBreak +
  '' + sLineBreak +
  '  linha := Copy(linha, 1, 4) + dv + Copy(linha, 5, Length(linha));' + sLineBreak +
  '' + sLineBreak +
  '  Result.CodigoBarras   := linha;' + sLineBreak +
  '  Result.LinhaDigitavel := MontaLinhaDigitavel(linha);' + sLineBreak +
  '  //Result.LinhaDigitavel := StringReplace( MontaLinhaDigitavel(linha), ''.'', '' '', [rfReplaceAll]);' + sLineBreak +
  '  Result.NossoNumero    := carteira + ''/'' + nossoNumero + ''-'' + IntToStr(modulo_10(agencia + conta + carteira + nossoNumero));' + sLineBreak +
  '  //Result.DesenhoCodigoBarras := TApiFuncoes.DesenhaCodigoBarrasSVG(linha);' + sLineBreak +
  '' + sLineBreak +
  '  ABoleto.Titulo.CodigoBarras   := Result.CodigoBarras;' + sLineBreak +
  '  ABoleto.Titulo.LinhaDigitavel := Result.LinhaDigitavel;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoItau.Modulo_10(const ADados: string): Integer;' + sLineBreak +
  'var' + sLineBreak +
  '  i, mult, total, num, res: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  total := 0;' + sLineBreak +
  '  mult := 2;' + sLineBreak +
  '' + sLineBreak +
  '  for i := Length(ADados) downto 1 do begin' + sLineBreak +
  '    num := StrToIntDef(ADados[i], 0);' + sLineBreak +
  '    res := num * mult;' + sLineBreak +
  '' + sLineBreak +
  '    if res > 9 then' + sLineBreak +
  '      res := (res div 10) + (res mod 10);' + sLineBreak +
  '' + sLineBreak +
  '    total := total + res;' + sLineBreak +
  '' + sLineBreak +
  '    if mult = 2 then mult := 1 else mult := 2;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := (10 - (total mod 10)) mod 10;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoItau.Modulo_11(const ADados: string; ALimiteSup, AFlag: Integer): Integer;' + sLineBreak +
  'var' + sLineBreak +
  '  i, mult, total, num, resto: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  total := 0;' + sLineBreak +
  '  mult := 2;' + sLineBreak +
  '' + sLineBreak +
  '  for i := Length(ADados) downto 1 do begin' + sLineBreak +
  '    num := StrToIntDef(ADados[i], 0);' + sLineBreak +
  '    total := total + (num * mult);' + sLineBreak +
  '' + sLineBreak +
  '    Inc(mult);' + sLineBreak +
  '    if mult > ALimiteSup then mult := 2;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  resto := total mod 11;' + sLineBreak +
  '' + sLineBreak +
  '  if AFlag = 1 then' + sLineBreak +
  '    Result := resto' + sLineBreak +
  '  else' + sLineBreak +
  '  begin' + sLineBreak +
  '    if (resto = 0) or (resto = 1) or (resto = 10) then' + sLineBreak +
  '      Result := 1' + sLineBreak +
  '    else' + sLineBreak +
  '      Result := 11 - resto;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoItau.DigitoVerificadorBarra(const ADados: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  resto, digito: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  resto := Modulo_11(ADados, 9, 1);' + sLineBreak +
  '' + sLineBreak +
  '  if (resto = 0) or (resto = 1) or (resto = 10) then' + sLineBreak +
  '    digito := 1' + sLineBreak +
  '  else' + sLineBreak +
  '    digito := 11 - resto;' + sLineBreak +
  '' + sLineBreak +
  '  Result := IntToStr(digito);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoItau.GeraCodigoBanco(const ADados: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  parte1, parte2: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  parte1 := Copy(ADados, 1, 3);' + sLineBreak +
  '  parte2 := IntToStr(Modulo_11(parte1, 9, 0));' + sLineBreak +
  '  Result := parte1 + ''-'' + parte2;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoItau.MontaLinhaDigitavel(const ACodigo: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  banco, moeda, campo1, campo2, campo3, campo4, campo5: string;' + sLineBreak +
  '  dv1, dv2, dv3: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  banco := Copy(ACodigo, 1, 3);' + sLineBreak +
  '  moeda := Copy(ACodigo, 4, 1);' + sLineBreak +
  '' + sLineBreak +
  '  dv1 := IntToStr(Modulo_10(banco + moeda + Copy(ACodigo, 20, 5)));' + sLineBreak +
  '  dv2 := IntToStr(Modulo_10(Copy(ACodigo, 25, 10)));' + sLineBreak +
  '  dv3 := IntToStr(Modulo_10(Copy(ACodigo, 35, 10)));' + sLineBreak +
  '' + sLineBreak +
  '  campo1 := Copy(banco + moeda + Copy(ACodigo, 20, 5) + dv1, 1, 5) + ''.'' +' + sLineBreak +
  '             Copy(banco + moeda + Copy(ACodigo, 20, 5) + dv1, 6, 5);' + sLineBreak +
  '' + sLineBreak +
  '  campo2 := Copy(Copy(ACodigo, 25, 10) + dv2, 1, 5) + ''.'' +' + sLineBreak +
  '             Copy(Copy(ACodigo, 25, 10) + dv2, 6, 6);' + sLineBreak +
  '' + sLineBreak +
  '  campo3 := Copy(Copy(ACodigo, 35, 10) + dv3, 1, 5) + ''.'' +' + sLineBreak +
  '             Copy(Copy(ACodigo, 35, 10) + dv3, 6, 6);' + sLineBreak +
  '' + sLineBreak +
  '  campo4 := Copy(ACodigo, 5, 1);' + sLineBreak +
  '  campo5 := Copy(ACodigo, 6, 14);' + sLineBreak +
  '' + sLineBreak +
  '  Result := campo1 + '' '' + campo2 + '' '' + campo3 + '' '' + campo4 + '' '' + campo5;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.bancoitau.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_BancoSantander;
var
  s: string;
begin
  s :=
  'unit Boleto.BancoSantander;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// gera informações para o boleto: 033' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils,' + sLineBreak +
  '  Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TBoletoBancoSantander }' + sLineBreak +
  '' + sLineBreak +
  '  TBoletoBancoSantander = class' + sLineBreak +
  '  private' + sLineBreak +
  '    function Modulo_10(const ADados: string): Integer;' + sLineBreak +
  '    function Modulo_11(const ADados: string; ALimiteSup, AFlag: Integer): Integer;' + sLineBreak +
  '    function DigitoVerificador_Barra(const ADados: string): string;' + sLineBreak +
  '    function MontaLinhaDigitavel(const ACodigo: string): string;' + sLineBreak +
  '  public' + sLineBreak +
  '    function GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '    class function new: TBoletoBancoSantander;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  StrUtils, DateUtils,' + sLineBreak +
  '  Api.Funcoes;' + sLineBreak +
  '' + sLineBreak +
  '{ TBoletoBancoSantander }' + sLineBreak +
  '' + sLineBreak +
  'class function TBoletoBancoSantander.new: TBoletoBancoSantander;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TBoletoBancoSantander.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSantander.GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '// retorna dados da linha digitável' + sLineBreak +
  'var' + sLineBreak +
  '  ValorFormatado, Fator, CodigoCliente, NossoNumero, Barra, linha: string;' + sLineBreak +
  '  NumMoeda, Fixo, IOS: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  // tipo da moeda' + sLineBreak +
  '  NumMoeda := ABoleto.Titulo.MoedaTipo;' + sLineBreak +
  '  if NumMoeda = '''' then NumMoeda := ''9'';' + sLineBreak +
  '' + sLineBreak +
  '  Fixo := ''9'';' + sLineBreak +
  '  IOS := ''0''; // Padrão 0 para não seguradoras' + sLineBreak +
  '  Fator := TApiFuncoes.FatorVencimento(ABoleto.Titulo.DataVencimento);' + sLineBreak +
  '' + sLineBreak +
  '  ValorFormatado := TApiFuncoes.FormataNumero(FormatFloat(''0.00'', ABoleto.Titulo.Valor), 10, ''0'', ''valor'');' + sLineBreak +
  '  CodigoCliente  := TApiFuncoes.FormataNumero(ABoleto.Conta.CodigoCedente, 7, ''0'');' + sLineBreak +
  '' + sLineBreak +
  '  // Nosso número no Santander deve ter 13 dígitos' + sLineBreak +
  '  NossoNumero := AddChar(''0'', ABoleto.Titulo.NossoNumero, 13);' + sLineBreak +
  '  NossoNumero := RightStr(NossoNumero, 13);' + sLineBreak +
  '' + sLineBreak +
  '  // Montagem da base para o cálculo do DV do código de barras (43 posições)' + sLineBreak +
  '  Barra := ABoleto.Conta.BancoCodigo + NumMoeda + Fator + ValorFormatado +' + sLineBreak +
  '           Fixo + CodigoCliente + NossoNumero + IOS + ABoleto.Conta.Carteira;' + sLineBreak +
  '' + sLineBreak +
  '  // Cálculo do DV (Dígito na posição 5)' + sLineBreak +
  '  linha := Copy(Barra, 1, 4) + DigitoVerificador_Barra(Barra) + Copy(Barra, 5, Length(Barra));' + sLineBreak +
  '' + sLineBreak +
  '  Result.CodigoBarras   := linha;' + sLineBreak +
  '  Result.LinhaDigitavel := MontaLinhaDigitavel(linha);' + sLineBreak +
  '  //Result.LinhaDigitavel := StringReplace( MontaLinhaDigitavel(linha), ''.'', '' '', [rfReplaceAll]);' + sLineBreak +
  '  Result.NossoNumero    := NossoNumero;' + sLineBreak +
  '  //Result.DesenhoCodigoBarras := TApiFuncoes.DesenhaCodigoBarrasSVG(linha);' + sLineBreak +
  '' + sLineBreak +
  '  ABoleto.Titulo.CodigoBarras   := Result.CodigoBarras;' + sLineBreak +
  '  ABoleto.Titulo.LinhaDigitavel := Result.LinhaDigitavel;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSantander.DigitoVerificador_Barra(const ADados: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  Resto, Digito: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Resto := Modulo_11(ADados, 9, 1);' + sLineBreak +
  '  if (Resto = 0) or (Resto = 1) or (Resto = 10) then' + sLineBreak +
  '    Digito := 1' + sLineBreak +
  '  else' + sLineBreak +
  '    Digito := 11 - Resto;' + sLineBreak +
  '  Result := IntToStr(Digito);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSantander.Modulo_10(const ADados: string): Integer;' + sLineBreak +
  'var' + sLineBreak +
  '  Mult, Total, Res, I: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Mult := (Length(ADados) mod 2) + 1;' + sLineBreak +
  '  Total := 0;' + sLineBreak +
  '' + sLineBreak +
  '  for I := 1 to Length(ADados) do begin' + sLineBreak +
  '    Res := StrToInt(ADados[I]) * Mult;' + sLineBreak +
  '    if Res > 9 then Res := (Res div 10) + (Res mod 10);' + sLineBreak +
  '    Total := Total + Res;' + sLineBreak +
  '    if Mult = 2 then Mult := 1 else Mult := 2;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := (10 - (Total mod 10)) mod 10;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSantander.Modulo_11(const ADados: string; ALimiteSup, AFlag: Integer): Integer;' + sLineBreak +
  'var' + sLineBreak +
  '  Mult, Total, I, Digito: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Mult := 2;' + sLineBreak +
  '  Total := 0;' + sLineBreak +
  '' + sLineBreak +
  '  for I := Length(ADados) downto 1 do begin' + sLineBreak +
  '    Total := Total + (StrToInt(ADados[I]) * Mult);' + sLineBreak +
  '    if Mult = ALimiteSup then Mult := 1;' + sLineBreak +
  '    Inc(Mult);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  if AFlag = 0 then begin' + sLineBreak +
  '    Total := Total * 10;' + sLineBreak +
  '    Digito := Total mod 11;' + sLineBreak +
  '    if Digito = 10 then Digito := 0;' + sLineBreak +
  '    Result := Digito;' + sLineBreak +
  '  end' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := Total mod 11;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSantander.MontaLinhaDigitavel(const ACodigo: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  Campo1, Campo2, Campo3, Campo4, Campo5: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  // Grupo 1: Banco + Moeda + Posição 20 + Posição 21-24 + DV1' + sLineBreak +
  '  Campo1 := Copy(ACodigo, 1, 3) + Copy(ACodigo, 4, 1) + Copy(ACodigo, 20, 1) + Copy(ACodigo, 21, 4);' + sLineBreak +
  '  Campo1 := Campo1 + IntToStr(Modulo_10(Campo1));' + sLineBreak +
  '  Campo1 := Copy(Campo1, 1, 5) + ''.'' + Copy(Campo1, 6, 5);' + sLineBreak +
  '' + sLineBreak +
  '  // Grupo 2: Posições 25 a 34 + DV2' + sLineBreak +
  '  Campo2 := Copy(ACodigo, 25, 10);' + sLineBreak +
  '  Campo2 := Campo2 + IntToStr(Modulo_10(Campo2));' + sLineBreak +
  '  Campo2 := Copy(Campo2, 1, 5) + ''.'' + Copy(Campo2, 6, 6);' + sLineBreak +
  '' + sLineBreak +
  '  // Grupo 3: Posições 35 a 44 + DV3' + sLineBreak +
  '  Campo3 := Copy(ACodigo, 35, 10);' + sLineBreak +
  '  Campo3 := Campo3 + IntToStr(Modulo_10(Campo3));' + sLineBreak +
  '  Campo3 := Copy(Campo3, 1, 5) + ''.'' + Copy(Campo3, 6, 6);' + sLineBreak +
  '' + sLineBreak +
  '  // Grupo 4: DV do Código de Barras' + sLineBreak +
  '  Campo4 := Copy(ACodigo, 5, 1);' + sLineBreak +
  '' + sLineBreak +
  '  // Grupo 5: Fator Vencimento + Valor' + sLineBreak +
  '  Campo5 := Copy(ACodigo, 6, 4) + Copy(ACodigo, 10, 10);' + sLineBreak +
  '' + sLineBreak +
  '  Result := Campo1 + '' '' + Campo2 + '' '' + Campo3 + '' '' + Campo4 + '' '' + Campo5;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.bancosantander.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_BancoSicoob;
var
  s: string;
begin
  s :=
  'unit Boleto.BancoSicoob;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// gera informações para o boleto: 756' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils,' + sLineBreak +
  '  Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TBoletoBancoSicoob }' + sLineBreak +
  '' + sLineBreak +
  '  TBoletoBancoSicoob = class' + sLineBreak +
  '  private' + sLineBreak +
  '    function DigitoLinha(Linha: string): string;' + sLineBreak +
  '    function DigitoBarra(Linha: string): string;' + sLineBreak +
  '    function Multiplo10(Numero: Integer): Integer;' + sLineBreak +
  '    function FormataLinhaDigitavel(S: string): string;' + sLineBreak +
  '    function PegaNossoNumero(TituloNr: string; Agencia: string; CodigoCedente: string): string;' + sLineBreak +
  '  public' + sLineBreak +
  '    function GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '    class function new: TBoletoBancoSicoob;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  StrUtils, DateUtils,' + sLineBreak +
  '  Api.Funcoes;' + sLineBreak +
  '' + sLineBreak +
  '{ TBoletoBancoSicoob }' + sLineBreak +
  '' + sLineBreak +
  'class function TBoletoBancoSicoob.new: TBoletoBancoSicoob;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TBoletoBancoSicoob.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSicoob.GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '// retorna dados da linha digitável' + sLineBreak +
  'var' + sLineBreak +
  '  ValorFormatado, Fator, CampoLivre, Barra, Linha: string;' + sLineBreak +
  '  Agencia, Convenio, NossoNum, Carteira, Modalidade, Parcela: string;' + sLineBreak +
  '  DV1, DV2, DV3, DV4: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Fator := TApiFuncoes.FatorVencimento(ABoleto.Titulo.DataVencimento);' + sLineBreak +
  '  ValorFormatado := TApiFuncoes.FormataNumero(FormatFloat(''0.00'', ABoleto.Titulo.Valor), 10, ''0'', ''valor'');' + sLineBreak +
  '' + sLineBreak +
  '  Agencia := TApiFuncoes.FormataNumero(ABoleto.Conta.Agencia, 4, ''0'');' + sLineBreak +
  '  Carteira := ABoleto.Conta.Carteira; // Geralmente ''1''' + sLineBreak +
  '' + sLineBreak +
  '  Convenio := Trim(ABoleto.Conta.Convenio);' + sLineBreak +
  '  if Convenio = '''' then Convenio := ABoleto.Conta.CodigoCedente;' + sLineBreak +
  '  Convenio := TApiFuncoes.FormataNumero(Convenio, 7, ''0'');' + sLineBreak +
  '' + sLineBreak +
  '  Modalidade := ''01''; // Cobrança Simples' + sLineBreak +
  '  Parcela := ''001'';   // Parcela única' + sLineBreak +
  '' + sLineBreak +
  '  // No Sicoob, o Nosso Número deve incluir o dígito verificador' + sLineBreak +
  '  NossoNum := ABoleto.Titulo.NossoNumero;' + sLineBreak +
  '  if Length(NossoNum) < 8 then' + sLineBreak +
  '    NossoNum := PegaNossoNumero(NossoNum, Agencia, Convenio);' + sLineBreak +
  '' + sLineBreak +
  '  NossoNum := TApiFuncoes.FormataNumero(NossoNum, 8, ''0'');' + sLineBreak +
  '' + sLineBreak +
  '  CampoLivre := Carteira + Agencia + Modalidade + Convenio + NossoNum + Parcela;' + sLineBreak +
  '' + sLineBreak +
  '  // ''7569'' = banco + moeda' + sLineBreak +
  '  // Cálculo dos DVs dos grupos da Linha Digitável' + sLineBreak +
  '  DV1 := DigitoLinha(''7569'' + Carteira + Agencia);' + sLineBreak +
  '  DV2 := DigitoLinha(Modalidade + Convenio + Copy(NossoNum, 1, 1));' + sLineBreak +
  '  DV3 := DigitoLinha(Copy(NossoNum, 2, 7) + Parcela);' + sLineBreak +
  '' + sLineBreak +
  '  // DV do Código de Barras' + sLineBreak +
  '  DV4 := DigitoBarra(''7569'' + Fator + ValorFormatado + CampoLivre);' + sLineBreak +
  '' + sLineBreak +
  '  Barra := ''7569'' + DV4 + Fator + ValorFormatado + CampoLivre;' + sLineBreak +
  '' + sLineBreak +
  '  // Montagem da linha completa para formatação' + sLineBreak +
  '  Linha := ''7569'' + Carteira + Agencia + DV1 + Modalidade + Convenio +' + sLineBreak +
  '           Copy(NossoNum, 1, 1) + DV2 + Copy(NossoNum, 2, 7) + Parcela +' + sLineBreak +
  '           DV3 + DV4 + Fator + ValorFormatado;' + sLineBreak +
  '' + sLineBreak +
  '  Result.CodigoBarras   := Barra;' + sLineBreak +
  '  Result.LinhaDigitavel := FormataLinhaDigitavel(Linha);' + sLineBreak +
  '  //Result.LinhaDigitavel := StringReplace(FormataLinhaDigitavel(Linha), ''.'', '' '', [rfReplaceAll]);' + sLineBreak +
  '  Result.NossoNumero    := NossoNum;' + sLineBreak +
  '  //Result.DesenhoCodigoBarras := TApiFuncoes.DesenhaCodigoBarrasSVG(linha);' + sLineBreak +
  '' + sLineBreak +
  '  ABoleto.Titulo.CodigoBarras   := Result.CodigoBarras;' + sLineBreak +
  '  ABoleto.Titulo.LinhaDigitavel := Result.LinhaDigitavel;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSicoob.DigitoLinha(Linha: string): string;' + sLineBreak +
  '// calcula os dígitos dos campos 1, 2 e 3 (módulo 10)' + sLineBreak +
  'var' + sLineBreak +
  '  Soma, Fator, I, Mult: Integer;' + sLineBreak +
  '  S: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Soma := 0;' + sLineBreak +
  '  Fator := 2;' + sLineBreak +
  '' + sLineBreak +
  '  for I := Length(Linha) downto 1 do begin' + sLineBreak +
  '    Mult := StrToInt(Linha[I]) * Fator;' + sLineBreak +
  '' + sLineBreak +
  '    if Mult > 9 then begin' + sLineBreak +
  '      S := IntToStr(Mult);' + sLineBreak +
  '      Mult := StrToInt(S[1]) + StrToInt(S[2]);' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    Soma := Soma + Mult;' + sLineBreak +
  '    if Fator = 2 then Fator := 1 else Fator := 2;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := IntToStr((Multiplo10(Soma) - Soma));' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSicoob.DigitoBarra(Linha: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  Soma, Fator, I, Digito: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Soma := 0;' + sLineBreak +
  '  Fator := 2;' + sLineBreak +
  '' + sLineBreak +
  '  for I := Length(Linha) downto 1 do begin' + sLineBreak +
  '    Soma := Soma + (StrToInt(Linha[I]) * Fator);' + sLineBreak +
  '    Inc(Fator);' + sLineBreak +
  '    if Fator > 9 then Fator := 2;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Digito := 11 - (Soma mod 11);' + sLineBreak +
  '  if (Digito <= 1) or (Digito > 9) then Digito := 1;' + sLineBreak +
  '  Result := IntToStr(Digito);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSicoob.Multiplo10(Numero: Integer): Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := Numero;' + sLineBreak +
  '  while (Result mod 10) <> 0 do Inc(Result);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSicoob.FormataLinhaDigitavel(S: string): string;' + sLineBreak +
  '// 01234.56789 01234.567890 12345.678901 2 34567890123456' + sLineBreak +
  '// 75693.44398 03000.000004 00002.180016 8 76580000008990 = 47 (sem formatação)' + sLineBreak +
  'begin' + sLineBreak +
  '  if Length(S) = 47 then' + sLineBreak +
  '    Result := Copy(S, 1, 5) + ''.'' + Copy(S, 6, 5) + '' '' +' + sLineBreak +
  '              Copy(S, 11, 5) + ''.'' + Copy(S, 16, 6) + '' '' +' + sLineBreak +
  '              Copy(S, 22, 5) + ''.'' + Copy(S, 27, 6) + '' '' +' + sLineBreak +
  '              Copy(S, 33, 1) + '' '' + Copy(S, 34, 14)' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := S;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoBancoSicoob.PegaNossoNumero(TituloNr: string; Agencia: string; CodigoCedente: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  Sequencia: string;' + sLineBreak +
  '  Constante, Cont, CalculoDv, I, DV, Resto: Integer;' + sLineBreak +
  '  NNum: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  NNum := TApiFuncoes.FormataNumero(TituloNr, 7, ''0'');' + sLineBreak +
  '  Sequencia := TApiFuncoes.FormataNumero(Agencia, 4, ''0'') +' + sLineBreak +
  '               TApiFuncoes.FormataNumero(CodigoCedente, 10, ''0'') +' + sLineBreak +
  '               NNum;' + sLineBreak +
  '  Cont := 0;' + sLineBreak +
  '  CalculoDv := 0;' + sLineBreak +
  '' + sLineBreak +
  '  for I := 1 to Length(Sequencia) do' + sLineBreak +
  '  begin' + sLineBreak +
  '    Inc(Cont);' + sLineBreak +
  '    case Cont of' + sLineBreak +
  '      1: Constante := 3;' + sLineBreak +
  '      2: Constante := 1;' + sLineBreak +
  '      3: Constante := 9;' + sLineBreak +
  '      4: begin' + sLineBreak +
  '           Constante := 7;' + sLineBreak +
  '           Cont := 0;' + sLineBreak +
  '         end;' + sLineBreak +
  '    end;' + sLineBreak +
  '    CalculoDv := CalculoDv + (StrToInt(Sequencia[I]) * Constante);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Resto := CalculoDv mod 11;' + sLineBreak +
  '  DV := 11 - Resto;' + sLineBreak +
  '  if (DV = 0) or (DV = 1) or (DV > 9) then DV := 0;' + sLineBreak +
  '' + sLineBreak +
  '  Result := NNum + IntToStr(DV);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak ;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.bancosicoob.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_Layout;
var
  s: string;
begin
  s :=
  'unit Boleto.Layout;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Layout para boleto bancário' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils,' + sLineBreak +
  '  Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TBoletoLayout }' + sLineBreak +
  '' + sLineBreak +
  '  TBoletoLayout = class' + sLineBreak +
  '    public' + sLineBreak +
  '      function GetBoleto(ABoleto: TBoletoDados; AProtegeCPF: Boolean; AApenasFichaComp, APdf: Boolean): string;' + sLineBreak +
  '      function GetFatura(ABoleto: TBoletoDados; AProtegeCPF, APdf, AExibirPix: Boolean): string;' + sLineBreak +
  '      class function new: TBoletoLayout;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Api.Funcoes, Boleto.LinhaDigitavel, Boleto.Pix;' + sLineBreak +
  '' + sLineBreak +
  '{ TBoletoLayout }' + sLineBreak +
  '' + sLineBreak +
  'class function TBoletoLayout.new: TBoletoLayout;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TBoletoLayout.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoLayout.GetBoleto(ABoleto: TBoletoDados; AProtegeCPF: Boolean; AApenasFichaComp, APdf: Boolean): string;' + sLineBreak +
  'var' + sLineBreak +
  '  url_imagens, banco_logo, banco_numero_dv, agencia_conta: string;' + sLineBreak +
  '  nossonumero, quantidade: string;' + sLineBreak +
  '  data_vencimento, data_documento, data_processamento, valor_boleto: string;' + sLineBreak +
  '  valor_unitario, pagavel_em: string;' + sLineBreak +
  '  empresa_nome, empresa_cnpj, empresa_endereco: string;' + sLineBreak +
  '  pagador_nome, pagador_cpf, pagador_endereco, pagador_cidade, pagador_cep: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  // linha digitável e código de barras' + sLineBreak +
  '  TLinhaDigitavel.GetLinhaDigitavel( ABoleto );' + sLineBreak +
  '' + sLineBreak +
  '  if APdf then' + sLineBreak +
  '    url_imagens := ''images/''' + sLineBreak +
  '  else' + sLineBreak +
  '    url_imagens := ''/images/'';' + sLineBreak +
  '' + sLineBreak +
  '  // banco' + sLineBreak +
  '' + sLineBreak +
  '  case StrToIntDef(ABoleto.Conta.BancoCodigo, 0) of' + sLineBreak +
  '    001: banco_logo := ''logobb.png'';' + sLineBreak +
  '    033: banco_logo := ''logosantander.png'';' + sLineBreak +
  '    104: banco_logo := ''logocaixa.png'';' + sLineBreak +
  '    237: banco_logo := ''logobradesco.png'';' + sLineBreak +
  '    341: banco_logo := ''logoitau.png'';' + sLineBreak +
  '    756: banco_logo := ''logosicoob.png'';' + sLineBreak +
  '  else' + sLineBreak +
  '    Exit('''');' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  banco_numero_dv := ABoleto.Conta.BancoCodigo + ''-'' + ABoleto.Conta.BancoCodigoDV;' + sLineBreak +
  '  agencia_conta   := ABoleto.Conta.Agencia + '' / '' +' + sLineBreak +
  '                     ABoleto.Conta.ContaCorrente + ''-'' +' + sLineBreak +
  '                     ABoleto.Conta.ContaCorrenteDV;' + sLineBreak +
  '' + sLineBreak +
  '  // cedente' + sLineBreak +
  '  empresa_nome     := ABoleto.Cedente.Nome;' + sLineBreak +
  '  empresa_cnpj     := ABoleto.Cedente.CNPJCPF;' + sLineBreak +
  '  empresa_endereco := ABoleto.Cedente.Endereco;' + sLineBreak +
  '' + sLineBreak +
  '  // sacado' + sLineBreak +
  '  pagador_nome     := ABoleto.Sacado.Nome;' + sLineBreak +
  '  pagador_cpf      := ABoleto.Sacado.CNPJCPF; // cpf ou cnpj' + sLineBreak +
  '  pagador_endereco := ABoleto.Sacado.Endereco;' + sLineBreak +
  '  pagador_cidade   := ABoleto.Sacado.Cidade + ''-'' + ABoleto.Sacado.UF;' + sLineBreak +
  '  pagador_cep      := ABoleto.Sacado.CEP;' + sLineBreak +
  '' + sLineBreak +
  '  if ABoleto.Sacado.Bairro <> '''' then' + sLineBreak +
  '    pagador_endereco := ABoleto.Sacado.Endereco + '' - '' + ABoleto.Sacado.Bairro;' + sLineBreak +
  '' + sLineBreak +
  '  // não exibe o CPF completo' + sLineBreak +
  '  if  AProtegeCPF and (Length(pagador_cpf) > 10) then begin' + sLineBreak +
  '    pagador_cpf[1] := ''*'';' + sLineBreak +
  '    pagador_cpf[2] := ''*'';' + sLineBreak +
  '    pagador_cpf[3] := ''*'';' + sLineBreak +
  '    pagador_cpf[High(pagador_cpf)-1] := ''*'';' + sLineBreak +
  '    pagador_cpf[High(pagador_cpf)]   := ''*'';' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  // titulo' + sLineBreak +
  '  nossonumero        := ABoleto.Titulo.NossoNumero;' + sLineBreak +
  '  nossonumero        := nossonumero.Insert(Length(nossonumero)-1, ''-'');' + sLineBreak +
  '  data_vencimento    := FormatDateTime(''dd/mm/yyyy'', ABoleto.Titulo.DataVencimento);' + sLineBreak +
  '  data_documento     := FormatDateTime(''dd/mm/yyyy'', ABoleto.Titulo.DataDocumento);' + sLineBreak +
  '  data_processamento := FormatDateTime(''dd/mm/yyyy'', ABoleto.Titulo.DataProcessamento);' + sLineBreak +
  '  valor_boleto       := TApiFuncoes.NumeroParaReal(ABoleto.Titulo.Valor, 2, True); // R$ 95,67' + sLineBreak +
  '  pagavel_em         := ''PAGÁVEL EM QUALQUER BANCO ATÉ O VENCIMENTO'';' + sLineBreak +
  '  quantidade         := '''';' + sLineBreak +
  '  valor_unitario     := '''';' + sLineBreak +
  '' + sLineBreak +
  '  if ABoleto.Titulo.EspecieValor <> '''' then' + sLineBreak +
  '    valor_boleto := ABoleto.Titulo.EspecieValor + '' '' + valor_boleto;' + sLineBreak +
  '' + sLineBreak +
  '  Result := ''<HTML> '';' + sLineBreak +
  '  Result := Result + ''<head> '';' + sLineBreak +
  '  Result := Result + ''<title>'' + ABoleto.Cedente.Nome + ''</title> '';' + sLineBreak +
  '  Result := Result + ''<meta http-equiv="Content-Type" content="text/html" charset="UTF-8"> '';' + sLineBreak +
  '  Result := Result + ''<meta name="Generator" content="'' + ABoleto.Cedente.Email + ''" /> '';' + sLineBreak +
  '  Result := Result + ''<style type="text/css"> '';' + sLineBreak +
  '  Result := Result + '' @page {'';  { remove headers no PDF }' + sLineBreak +
  '  Result := Result + ''   margin: 0;'';' + sLineBreak +
  '  Result := Result + ''   size : A4 portrait;'';' + sLineBreak +
  '  Result := Result + '' }'';' + sLineBreak +
  '  Result := Result + '' .cp {font: bold 10px Arial; color: black} '';' + sLineBreak +
  '  Result := Result + '' .ti {font: 9px Arial, Helvetica, sans-serif} '';' + sLineBreak +
  '  Result := Result + '' .ld {font: bold 15px Arial; color: #000000} '';' + sLineBreak +
  '  Result := Result + '' .ct {font: 9px "Arial Narrow"; COLOR: #000033} '';' + sLineBreak +
  '  Result := Result + '' .cn {font: 9px Arial; COLOR: black } '';' + sLineBreak +
  '  Result := Result + '' .bc {font: bold 20px Arial; color: #000000 } '';' + sLineBreak +
  '  Result := Result + '' .ld2 {font: bold 12px Arial; color: #000000 } '';' + sLineBreak +
  '  Result := Result + ''</style>  '';' + sLineBreak +
  '  Result := Result + ''</head> '';' + sLineBreak +
  '  Result := Result + ''<BODY text=#000000 bgColor=#ffffff topMargin=0 rightMargin=0><BR> '';' + sLineBreak +
  '' + sLineBreak +
  '  // Comprovante do sacado' + sLineBreak +
  '' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 width=666 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp width=150><span class="campo"><IMG src="'' + url_imagens + banco_logo + ''" width="150" height="40" border=0></span></td> '';' + sLineBreak +
  '  Result := Result + '' <td width=3 valign=bottom><img height=22 src="'' + url_imagens + ''3.png" width=2 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cpt width=58 valign=bottom><div align=center><font class=bc>'' + banco_numero_dv + ''</font></div></td> '';' + sLineBreak +
  '  Result := Result + '' <td width=3 valign=bottom><img height=22 src="'' + url_imagens + ''3.png" width=2 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ld align=right width=453 valign=bottom><span class=ld><span class="campotitulo">'' + ABoleto.Titulo.LinhaDigitavel + ''</span></span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tbody><tr><td colspan=5><img height=2 src="'' + url_imagens + ''2.png" width=666 border=0></td></tr></tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=298 height=13>Benefici&aacute;rio</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=126 height=13>Ag&ecirc;ncia/C&oacute;digo Benefici&aacute;rio</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=34 height=13>Esp&eacute;cie</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=53 height=13>Quantidade</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=120 height=13>Nosso n&uacute;mero</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=298 height=12><span class="campo">'' + empresa_nome + ''&nbsp;&nbsp;-&nbsp;&nbsp;'' + empresa_endereco + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=126 height=12><span class="campo">'' + agencia_conta + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=34 height=12><span class="campo">'' + ABoleto.Titulo.EspecieValor + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=53 height=12><span class="campo">'' + quantidade + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=120 height=12><span class="campo">'' + nossonumero + ''</span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=298 height=1><img height=1 src="'' + url_imagens + ''2.png" width=298 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=126 height=1><img height=1 src="'' + url_imagens + ''2.png" width=126 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=34 height=1><img height=1 src="'' + url_imagens + ''2.png" width=34 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=53 height=1><img height=1 src="'' + url_imagens + ''2.png" width=53 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=120 height=1><img height=1 src="'' + url_imagens + ''2.png" width=120 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top colspan=3 height=13>N&uacute;mero do documento</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=132 height=13>CPF/CNPJ Benefici&aacute;rio</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=134 height=13><u>V</u>encimento</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=180 height=13>Valor do Documento</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top colspan=3 height=12><span class="campo">'' + ABoleto.Titulo.NumeroDocumento + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=132 height=12><span class="campo">'' + empresa_cnpj + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=134 height=12><span class="campo">'' + data_vencimento + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=180 height=12><span class="campo">'' + valor_boleto + ''</span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=113 height=1><img height=1 src="'' + url_imagens + ''2.png" width=113 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=72 height=1><img height=1 src="'' + url_imagens + ''2.png" width=72 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=132 height=1><img height=1 src="'' + url_imagens + ''2.png" width=132 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=134 height=1><img height=1 src="'' + url_imagens + ''2.png" width=134 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=113 height=13>(-) Desconto / Abatimentos</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=112 height=13>(-) Outras dedu&ccedil;&otilde;es</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=113 height=13>(+) Mora / Multa</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=113 height=13>(+) Outros acr&eacute;scimos</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=180 height=13>(=) Valor cobrado</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=113 height=12></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=112 height=12></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=113 height=12></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=113 height=12></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=180 height=12></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=113 height=1><img height=1 src="'' + url_imagens + ''2.png" width=113 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=112 height=1><img height=1 src="'' + url_imagens + ''2.png" width=112 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=113 height=1><img height=1 src="'' + url_imagens + ''2.png" width=113 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=113 height=1><img height=1 src="'' + url_imagens + ''2.png" width=113 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=659 height=13><u>P</u>agador</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=659 height=12><span class="campo">'' + pagador_nome + ''&nbsp;&nbsp;&nbsp;&nbsp;CPF/CNPJ: '' + pagador_cpf + ''</span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=659 height=1><img height=1 src="'' + url_imagens + ''2.png" width=659 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct  width=7 height=12></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct  width=564 >Demonstrativo</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct  width=7 height=12></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct  width=88 >Autentica&ccedil;&atilde;o mec&acirc;nica</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td  width=7 ></td><td class=cp width=564 > '';' + sLineBreak +
  '  Result := Result + ''  <span class="campo"> '';' + sLineBreak +
  '  Result := Result + ''   '' + ABoleto.Titulo.Demonstrativo[0] + ''<br> '';' + sLineBreak +
  '  Result := Result + ''   '' + ABoleto.Titulo.Demonstrativo[1] + ''<br> '';' + sLineBreak +
  '  Result := Result + ''   '' + ABoleto.Titulo.Demonstrativo[2] + ''<br> '';' + sLineBreak +
  '  Result := Result + ''  </span> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + '' <td  width=7 ></td><td width=88 ></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 width=666 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td width=7></td><td  width=500 class=cp><br><br><br></td> '';' + sLineBreak +
  '  Result := Result + '' <td width=159></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  // cortar aqui' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 width=666 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct width=666></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct width=666><div align=right>Corte na linha pontilhada</div></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct width=666><img height=1 src="'' + url_imagens + ''6.png" width=665 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<br>'';' + sLineBreak +
  '' + sLineBreak +
  '  // Ficha de compensação' + sLineBreak +
  '  if AApenasFichaComp then' + sLineBreak +
  '    Result := '''';' + sLineBreak +
  '' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 width=666 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp width=150><span class="campo"><IMG src="'' + url_imagens + banco_logo + ''" width="150" height="40" border=0></span></td> '';' + sLineBreak +
  '  Result := Result + '' <td width=3 valign=bottom><img height=22 src="'' + url_imagens + ''3.png" width=2 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cpt width=58 valign=bottom><div align=center><font class=bc>'' + banco_numero_dv + ''</font></div></td> '';' + sLineBreak +
  '  Result := Result + '' <td width=3 valign=bottom><img height=22 src="'' + url_imagens + ''3.png" width=2 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ld align=right width=453 valign=bottom><span class=ld><span class="campotitulo">'' + ABoleto.Titulo.LinhaDigitavel + ''</span></span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td colspan=5><img height=2 src="'' + url_imagens + ''2.png" width=666 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=472 height=13>Local de pagamento</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=180 height=13>Vencimento</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=472 height=12>'' + pagavel_em + ''</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=180 height=12><span class="campo">'' + data_vencimento + ''</span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=472 height=1><img height=1 src="'' + url_imagens + ''2.png" width=472 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=472 height=13>Benefici&aacute;rio</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=180 height=13>Ag&ecirc;ncia/C&oacute;digo Benefici&aacute;rio</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=472 height=12><span class="campo">'' + empresa_nome + ''&nbsp;&nbsp;-&nbsp;&nbsp;'' + empresa_endereco + ''&nbsp;&nbsp;- CNPJ&nbsp;&nbsp;'' + empresa_cnpj + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=180 height=12><span class="campo">'' + agencia_conta + ''</span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=472 height=1><img height=1 src="'' + url_imagens + ''2.png" width=472 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=113 height=13>Data do documento</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=153 height=13>N<u>o</u> documento</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13> <img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=62 height=13>Esp&eacute;cie doc.</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13> <img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=34 height=13>Aceite</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=82 height=13>Data processamento</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13> <img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=180 height=13>Nosso n&uacute;mero</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=113 height=12><div align=left><span class="campo">'' + data_documento + ''</span></div></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=153 height=12><span class="campo">'' + ABoleto.Titulo.NumeroDocumento + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=62 height=12><div align=left><span class="campo">'' + ABoleto.Titulo.EspecieDocumento + ''</span></div></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=34 height=12><div align=left><span class="campo">'' + ABoleto.Titulo.Aceite + ''</span></div></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens+ ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=82 height=12><div align=left><span class="campo">'' + data_processamento + ''</span></div></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=180 height=12><span class="campo">'' + nossonumero + ''</span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=113 height=1><img height=1 src="'' + url_imagens + ''2.png" width=113 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=153 height=1><img height=1 src="'' + url_imagens + ''2.png" width=153 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=62 height=1><img height=1 src="'' + url_imagens + ''2.png" width=62 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=34 height=1><img height=1 src="'' + url_imagens + ''2.png" width=34 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=82 height=1><img height=1 src="'' + url_imagens + ''2.png" width=82 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr>  '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13> <img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top COLSPAN="3" height=13>Uso do banco</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top height=13 width=7> <img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=83 height=13>Carteira</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top height=13 width=7><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=53 height=13>Esp&eacute;cie</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top height=13 width=7><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=123 height=13>Quantidade</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top height=13 width=7><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=72 height=13>Valor</td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=180 height=13>(=) Valor do Documento</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr>  '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top class=cp height=12 COLSPAN="3"><div align=left></div></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=83><div align=left> <span class="campo">'' + ABoleto.Conta.Carteira + ''</span></div></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=53><div align=left><span class="campo">'' + ABoleto.Titulo.EspecieValor + ''</span></div></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=123><span class="campo">'' + quantidade + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top  width=72><span class="campo">'' + valor_unitario + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12> <img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top align=right width=180 height=12><span class="campo">'' + valor_boleto + ''</span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1> <img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=75 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=31 height=1><img height=1 src="'' + url_imagens + ''2.png" width=31 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=83 height=1><img height=1 src="'' + url_imagens + ''2.png" width=83 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=53 height=1><img height=1 src="'' + url_imagens + ''2.png" width=53 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=123 height=1><img height=1 src="'' + url_imagens + ''2.png" width=123 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=72 height=1><img height=1 src="'' + url_imagens + ''2.png" width=72 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody>  '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 width=666 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=10> '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0 align=left> '';' + sLineBreak +
  '  Result := Result + ''  <tbody>  '';' + sLineBreak +
  '  Result := Result + ''  <tr><td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody> '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=468 rowspan=5> '';' + sLineBreak +
  '  Result := Result + ''  <font class=ct>Instru&ccedil;&otilde;es (Texto de responsabilidade do benefici&aacute;rio)</font><br><br> '';' + sLineBreak +
  '  Result := Result + ''  <span class=cp> <FONT class=campo> '';' + sLineBreak +
  '  Result := Result + ''  '' + ABoleto.Titulo.Instrucoes[0] + ''<br> '';' + sLineBreak +
  '  Result := Result + ''  '' + ABoleto.Titulo.Instrucoes[1] + ''<br> '';' + sLineBreak +
  '  Result := Result + ''  '' + ABoleto.Titulo.Instrucoes[2] + ''<br> '';' + sLineBreak +
  '  Result := Result + ''  '' + ABoleto.Titulo.Instrucoes[3] + ''<br> '';' + sLineBreak +
  '  Result := Result + ''  '' + ABoleto.Titulo.Instrucoes[4] + ''<br> '';' + sLineBreak +
  '  Result := Result + ''  '' + ABoleto.Titulo.Instrucoes[5] + ''<br> '';' + sLineBreak +
  '  Result := Result + ''  '' + ABoleto.Titulo.Instrucoes[6] + ''</font><br><br>  '';' + sLineBreak +
  '  Result := Result + ''  </span> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=188> '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''  <tbody> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=180 height=13>(-) Desconto / Abatimentos</td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr>  '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top align=right width=180 height=12></td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr>  '';' + sLineBreak +
  '  Result := Result + ''   <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody> '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=10>  '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0 align=left> '';' + sLineBreak +
  '  Result := Result + ''  <tbody> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody> '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=188> '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''  <tbody> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=180 height=13>(-) Outras dedu&ccedil;&otilde;es</td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top width=7 height=12> <img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top align=right width=180 height=12></td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody> '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=10>  '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0 align=left> '';' + sLineBreak +
  '  Result := Result + ''  <tbody> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody> '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=188>  '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''  <tbody> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=180 height=13>(+) Mora / Multa</td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top align=right width=180 height=12></td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr>  '';' + sLineBreak +
  '  Result := Result + ''   <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody> '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=10> '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0 align=left> '';' + sLineBreak +
  '  Result := Result + ''  <tbody><tr><td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody> '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=188>  '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''  <tbody> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=180 height=13>(+) Outros acr&eacute;scimos</td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr>  '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top align=right width=180 height=12></td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody> '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=10> '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0 align=left> '';' + sLineBreak +
  '  Result := Result + ''  <tbody> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr><td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody> '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + '' <td align=right width=188> '';' + sLineBreak +
  '  Result := Result + ''  <table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''  <tbody> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=ct valign=top width=180 height=13>(=) Valor cobrado</td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  <tr> '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''   <td class=cp valign=top align=right width=180 height=12></td> '';' + sLineBreak +
  '  Result := Result + ''  </tr> '';' + sLineBreak +
  '  Result := Result + ''  </tbody>  '';' + sLineBreak +
  '  Result := Result + ''  </table> '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 width=666 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr><td valign=top width=666 height=1><img height=1 src="'' + url_imagens + ''2.png" width=666 border=0></td></tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=659 height=13><u>P</u>agador</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=659 height=12><span class="campo"> '';' + sLineBreak +
  '  Result := Result + '' '' + pagador_nome + ''&nbsp;&nbsp;&nbsp;&nbsp;CPF/CNPJ: '' + pagador_cpf + ''  '';' + sLineBreak +
  '  Result := Result + '' </span>  '';' + sLineBreak +
  '  Result := Result + '' </td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=7 height=12><img height=12 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=659 height=12><span class="campo">'' + pagador_endereco + ''</span></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<table cellspacing=0 cellpadding=0 border=0> '';' + sLineBreak +
  '  Result := Result + ''<tbody> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=cp valign=top width=472 height=13><span class="campo">'' + pagador_cep + '' - '' + pagador_cidade + ''</span></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=7 height=13><img height=13 src="'' + url_imagens + ''1.png" width=1 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td class=ct valign=top width=180 height=13>C&oacute;d. baixa</td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''<tr> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=472 height=1><img height=1 src="'' + url_imagens + ''2.png" width=472 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=7 height=1><img height=1 src="'' + url_imagens + ''2.png" width=7 border=0></td> '';' + sLineBreak +
  '  Result := Result + '' <td valign=top width=180 height=1><img height=1 src="'' + url_imagens + ''2.png" width=180 border=0></td> '';' + sLineBreak +
  '  Result := Result + ''</tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<TABLE cellSpacing=0 cellPadding=0 border=0 width=666> '';' + sLineBreak +
  '  Result := Result + ''<TBODY> '';' + sLineBreak +
  '  Result := Result + ''<TR> '';' + sLineBreak +
  '  Result := Result + '' <TD class=ct  width=7 height=12></TD> '';' + sLineBreak +
  '  Result := Result + '' <TD class=ct  width=409 >Sacador/Avalista</TD> '';' + sLineBreak +
  '  Result := Result + '' <TD class=ct  width=250 ><div align=right>Autentica&ccedil;&atilde;o mec&acirc;nica - <b class=cp>Ficha de Compensa&ccedil;&atilde;o</b></div></TD> '';' + sLineBreak +
  '  Result := Result + ''</TR> '';' + sLineBreak +
  '  Result := Result + ''<TR><TD class=ct  colspan=3 ></TD></tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''<TABLE cellSpacing=0 cellPadding=0 width=666 border=0> '';' + sLineBreak +
  '  Result := Result + ''<TBODY> '';' + sLineBreak +
  '  Result := Result + ''<tr><td vAlign=bottom align=left height=50>&nbsp;&nbsp;'' + TApiFuncoes.DesenhaCodigoBarrasSVG(ABoleto.Titulo.CodigoBarras) + ''</td></tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '' + sLineBreak +
  '  if AApenasFichaComp then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  { linha pontilhada }' + sLineBreak +
  '' + sLineBreak +
  '  Result := Result + ''<TABLE cellSpacing=0 cellPadding=0 width=666 border=0> '';' + sLineBreak +
  '  Result := Result + ''<TR><TD class=ct width=666></TD></TR> '';' + sLineBreak +
  '  Result := Result + ''<TBODY> '';' + sLineBreak +
  '  Result := Result + ''<TR><TD class=ct width=666><div align=right>Corte na linha pontilhada</div></TD></TR> '';' + sLineBreak +
  '  Result := Result + ''<TR><TD class=ct width=666><img height=1 src="'' + url_imagens + ''6.png" width=665 border=0></TD></tr> '';' + sLineBreak +
  '  Result := Result + ''</tbody> '';' + sLineBreak +
  '  Result := Result + ''</table> '';' + sLineBreak +
  '  Result := Result + ''</BODY></HTML> '';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoLayout.GetFatura(ABoleto: TBoletoDados; AProtegeCPF, APdf, AExibirPix: Boolean): string;' + sLineBreak +
  '// Boleto em formato de fatura moderna' + sLineBreak +
  'var' + sLineBreak +
  '  url_imagens, sub_titulo, pagador_nome, pagador_cpf: string;' + sLineBreak +
  '  pagador_endereco, pagador_cidade, pagador_cep: string;' + sLineBreak +
  '  data_vencimento, valor_boleto, lBoleto, linha_digitavel: string;' + sLineBreak +
  '  PixString, LNome, LCidade, LValorPix, LChave, LIdentificador: string;' + sLineBreak +
  '  pix_label, data_emissao: string;' + sLineBreak +
  '  lateral_mensagem1, lateral_mensagem2, lateral_mensagem3, lateral_mensagem4,' + sLineBreak +
  '  footer_mensagem1, footer_mensagem2, footer_mensagem3, pagador_bairro: String;' + sLineBreak +
  '  i: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  if APdf then' + sLineBreak +
  '    url_imagens := ''images/''' + sLineBreak +
  '  else' + sLineBreak +
  '    url_imagens := ''/images/'';' + sLineBreak +
  '' + sLineBreak +
  '  sub_titulo := ''viva essa experiência!'';' + sLineBreak +
  '' + sLineBreak +
  '  // PIX' + sLineBreak +
  '  PixString := '''';' + sLineBreak +
  '  pix_label := '''';' + sLineBreak +
  '' + sLineBreak +
  '  if AExibirPix and (ABoleto.Cedente.ChavePix <> '''') then begin' + sLineBreak +
  '    LChave := ABoleto.Cedente.ChavePix;' + sLineBreak +
  '    LNome := UpperCase( TApiFuncoes.OnlyAlfabetic( TApiFuncoes.RemoverAcentos(ABoleto.Cedente.Nome) ) );' + sLineBreak +
  '    LCidade := UpperCase( TApiFuncoes.OnlyAlfabetic( TApiFuncoes.RemoverAcentos(ABoleto.Cedente.Cidade) ) );' + sLineBreak +
  '    LValorPix := TApiFuncoes.FormatFloatNotRounded(''0.00'', ABoleto.Titulo.Valor, 2);' + sLineBreak +
  '    LIdentificador := ABoleto.Titulo.NumeroDocumento;' + sLineBreak +
  '    pix_label := ''PIX-PAG'';' + sLineBreak +
  '' + sLineBreak +
  '    if Length(LIdentificador)>0 then' + sLineBreak +
  '      LIdentificador := UpperCase(LIdentificador);' + sLineBreak +
  '' + sLineBreak +
  '    PixString := TBoletoPix.new.GerarPixPayload(LChave, LNome, LCidade, LValorPix, LIdentificador);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  linha_digitavel := TLinhaDigitavel.GetLinhaDigitavel( ABoleto ).LinhaDigitavel;' + sLineBreak +
  '' + sLineBreak +
  '  lBoleto := GetBoleto(ABoleto, True, True, APdf);' + sLineBreak +
  '' + sLineBreak +
  '  // sacado' + sLineBreak +
  '  pagador_nome     := ABoleto.Sacado.Nome.ToUpper;' + sLineBreak +
  '  pagador_cpf      := ABoleto.Sacado.CNPJCPF; // cpf ou cnpj' + sLineBreak +
  '  pagador_endereco := ABoleto.Sacado.Endereco;' + sLineBreak +
  '  pagador_bairro   := ABoleto.Sacado.Bairro;' + sLineBreak +
  '  pagador_cidade   := ABoleto.Sacado.Cidade + ''-'' + ABoleto.Sacado.UF;' + sLineBreak +
  '  pagador_cep      := ABoleto.Sacado.CEP;' + sLineBreak +
  '' + sLineBreak +
  '  if ABoleto.Sacado.Bairro <> '''' then' + sLineBreak +
  '    pagador_endereco := ABoleto.Sacado.Endereco + '' - '' + ABoleto.Sacado.Bairro;' + sLineBreak +
  '' + sLineBreak +
  '  // não exibe o CPF completo' + sLineBreak +
  '  if  AProtegeCPF and (Length(pagador_cpf) > 10) then begin' + sLineBreak +
  '    pagador_cpf[1] := ''*'';' + sLineBreak +
  '    pagador_cpf[2] := ''*'';' + sLineBreak +
  '    pagador_cpf[3] := ''*'';' + sLineBreak +
  '    pagador_cpf[High(pagador_cpf)-1] := ''*'';' + sLineBreak +
  '    pagador_cpf[High(pagador_cpf)]   := ''*'';' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  data_vencimento := FormatDateTime(''dd/mm/yyyy'', ABoleto.Titulo.DataVencimento);' + sLineBreak +
  '  data_emissao    := FormatDateTime(''dd/mm/yyyy'', ABoleto.Titulo.DataDocumento);' + sLineBreak +
  '  valor_boleto    := TApiFuncoes.NumeroParaReal(ABoleto.Titulo.Valor, 2, True); // R$ 95,67' + sLineBreak +
  '' + sLineBreak +
  '  if ABoleto.Titulo.EspecieValor <> '''' then' + sLineBreak +
  '    valor_boleto := ABoleto.Titulo.EspecieValor + '' '' + valor_boleto;' + sLineBreak +
  '' + sLineBreak +
  '  // Mensagens nas laterais e rodapé' + sLineBreak +
  '' + sLineBreak +
  '  lateral_mensagem1 := ''VIVA ESSA EXPERIÊNCIA!'';' + sLineBreak +
  '  lateral_mensagem2 := ''<p>Consulte a sua fatura online.</p>'' +' + sLineBreak +
  '                       ''<p>É <span class="highlight-green">simples e do seu jeito!</span></p>'';' + sLineBreak +
  '  lateral_mensagem3 := ''<p>Baixe o nosso app no</p><p><span class="highlight-green">App Store</span>'' +' + sLineBreak +
  '                       '' ou <span class="highlight-blue">Google Play</span>.</p>'';' + sLineBreak +
  '  lateral_mensagem4 := ''<p>Acesse a central do assinante</p>'' +' + sLineBreak +
  '                       ''<a href="'' + ABoleto.Cedente.CentralAtendimento +''" class="link-text" target="_blank">'' +' + sLineBreak +
  '                        ABoleto.Cedente.CentralAtendimento + ''</a>'';' + sLineBreak +
  '  footer_mensagem1 := ''Evite o bloqueio do serviço, efetuando o <span class="bold">pagamento</span> '' +' + sLineBreak +
  '                      ''até a data do <span class="bold">vencimento</span>.'';' + sLineBreak +
  '  footer_mensagem2 := ''Caso existam <span class="bold">serviços</span> prestados e <span class="bold">'' +' + sLineBreak +
  '                      ''não cobrados</span>, esses serão inclusos nas suas <span class="bold">'' +' + sLineBreak +
  '                      ''próximas faturas</span>.'';' + sLineBreak +
  '  footer_mensagem3 := ''Para solicitar atendimento entre em contato através do <span class="bold">'' +' + sLineBreak +
  '                      ''whatsapp</span> <span class="contact-highlight">'' + ABoleto.Cedente.WhatsApp + ''</span><br>'' +' + sLineBreak +
  '                      '' ou <span class="bold">telefone</span> <span class="contact-highlight">'' +' + sLineBreak +
  '                      ABoleto.Cedente.Telefone + ''</span>'';' + sLineBreak +
  '' + sLineBreak +
  '  Result :=' + sLineBreak +
  '  ''<html>'' + sLineBreak +' + sLineBreak +
  '  ''<head>'' + sLineBreak +' + sLineBreak +
  '  ''    <title>'' + ABoleto.Cedente.Nome + ''</title>'' + sLineBreak +' + sLineBreak +
  '  ''    <meta http-equiv="Content-Type" content="text/html" charset="UTF-8">'' + sLineBreak +' + sLineBreak +
  '  ''    <meta name="Generator" content="'' + ABoleto.Cedente.Email + ''" /> '' + sLineBreak +' + sLineBreak +
  '  ''    <link rel="icon" type="image/x-icon" href="/favicon.ico">'';' + sLineBreak +
  '' + sLineBreak +
  '  if PixString<>'''' then' + sLineBreak +
  '    Result := Result +' + sLineBreak +
  '    ''    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>'';' + sLineBreak +
  '' + sLineBreak +
  '  Result := Result +' + sLineBreak +
  '  ''    <style type="text/css">'' + sLineBreak +' + sLineBreak +
  '  ''        @page {'' + sLineBreak + { remove headers no PDF }' + sLineBreak +
  '  ''           margin: 0;'' + sLineBreak +' + sLineBreak +
  '  ''           size : A4 portrait;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        * {'' + sLineBreak +' + sLineBreak +
  '  ''            box-sizing: border-box;'' + sLineBreak +' + sLineBreak +
  '  ''            font-family: Arial, sans-serif;'' + sLineBreak +' + sLineBreak +
  '  ''            margin: 0;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 0;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        body {'' + sLineBreak +' + sLineBreak +
  '  ''            background-color: #ffffff;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #000000;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 20px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11px;'' + sLineBreak +' + sLineBreak +
  '  ''            line-height: 1.4;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .invoice-container {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            max-width: 800px;'' + sLineBreak +' + sLineBreak +
  '  ''            margin: 0 auto;'' + sLineBreak +' + sLineBreak +
  '  ''            position: relative;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .boleto-container {'' + sLineBreak +' + sLineBreak +
  '  ''            font-family: Arial, Helvetica, sans-serif;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 8px;'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            max-width: 800px;'' + sLineBreak +' + sLineBreak +
  '  ''            margin: 0 auto;'' + sLineBreak +' + sLineBreak +
  '  ''            position: relative;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .header-table {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            border-collapse: collapse;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 15px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .header-table td {'' + sLineBreak +' + sLineBreak +
  '  ''            vertical-align: top;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .logo-section {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 20%;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .logo-title {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 28px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #1a3d6c;'' + sLineBreak +' + sLineBreak +
  '  ''            letter-spacing: -1px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .logo-subtitle {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 9px;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #777;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-top: -4px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .client-section {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 30%;'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 0 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .client-name {'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .doc-section {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 20%;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            padding-left: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .doc-section div {'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 2px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .value-section {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 13%;'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .val-title {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #555;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .val-date {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 15px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 8px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .val-price {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 16px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .pix-section {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 165px;'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: right;'' + sLineBreak +' + sLineBreak +
  '  ''            position: relative;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .pix-container {'' + sLineBreak +' + sLineBreak +
  '  ''            display: inline-block;'' + sLineBreak +' + sLineBreak +
  '  ''            vertical-align: top;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .pix-qrcode {'' + sLineBreak +' + sLineBreak +
  '  ''          width: 140px;'' + sLineBreak +' + sLineBreak +
  '  ''          height: 140px;'' + sLineBreak +' + sLineBreak +
  '  ''          display: inline-block;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .pix-label {'' + sLineBreak +' + sLineBreak +
  '  ''            display: inline-block;'' + sLineBreak +' + sLineBreak +
  '  ''            width: 12px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 12px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            letter-spacing: 2px;'' + sLineBreak +' + sLineBreak +
  '  ''            word-wrap: break-word;'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''            vertical-align: top;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-left: 4px;'' + sLineBreak +' + sLineBreak +
  '  ''            line-height: 1.1;'' + sLineBreak +' + sLineBreak +
  '  ''            padding-top: 2px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        '' + sLineBreak +' + sLineBreak +
  '  ''        /* Linha Digitável Box */'' + sLineBreak +' + sLineBreak +
  '  ''        .linha-digitavel-bar {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            border-top: 2px solid #000;'' + sLineBreak +' + sLineBreak +
  '  ''            padding-top: 4px;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .linha-label {'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .linha-num {'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: normal;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .recibo-label {'' + sLineBreak +' + sLineBreak +
  '  ''            float: right;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        '' + sLineBreak +' + sLineBreak +
  '  ''        /* Main Content Layout splits into Left and Right columns */'' + sLineBreak +' + sLineBreak +
  '  ''        .main-content {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 9px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .col-left {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 68%;'' + sLineBreak +' + sLineBreak +
  '  ''            display: inline-block;'' + sLineBreak +' + sLineBreak +
  '  ''            vertical-align: top;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .col-right {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 30%;'' + sLineBreak +' + sLineBreak +
  '  ''            display: inline-block;'' + sLineBreak +' + sLineBreak +
  '  ''            vertical-align: top;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-left: 1.5%;'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        '' + sLineBreak +' + sLineBreak +
  '  ''        /* Services Box */'' + sLineBreak +' + sLineBreak +
  '  ''        .services-box {'' + sLineBreak +' + sLineBreak +
  '  ''            border: 1.5px solid #000000;'' + sLineBreak +' + sLineBreak +
  '  ''            border-radius: 12px;'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            min-height: 260px;'' + sLineBreak +' + sLineBreak +
  '  ''            overflow: hidden;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .services-title {'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 6px 12px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .services-table {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            border-collapse: collapse;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .services-table th {'' + sLineBreak +' + sLineBreak +
  '  ''            border-top: 1px solid #000;'' + sLineBreak +' + sLineBreak +
  '  ''            border-bottom: 1px solid #000;'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: left;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 5px 12px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .services-table td {'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 5px 12px;'' + sLineBreak +' + sLineBreak +
  '  ''            border-bottom: 1px solid #e0e0e0;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 10.5px;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #333;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .services-table tr:last-child td {'' + sLineBreak +' + sLineBreak +
  '  ''            border-bottom: none;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        '' + sLineBreak +' + sLineBreak +
  '  ''        /* Right Side Content Elements */'' + sLineBreak +' + sLineBreak +
  '  ''        .experience-box {'' + sLineBreak +' + sLineBreak +
  '  ''            border: 1.5px solid #000000;'' + sLineBreak +' + sLineBreak +
  '  ''            border-radius: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 22px 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 14px;'' + sLineBreak +' + sLineBreak +
  '  ''            letter-spacing: 0.5px;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 25px;'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .info-group {'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 28px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 12px;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #333;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .info-group p {'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 2px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .highlight-green {'' + sLineBreak +' + sLineBreak +
  '  ''            color: #00b094;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .highlight-blue {'' + sLineBreak +' + sLineBreak +
  '  ''            color: #0056b3;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .link-text {'' + sLineBreak +' + sLineBreak +
  '  ''            color: #00b094;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            word-break: break-all;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11.5px;'' + sLineBreak +' + sLineBreak +
  '  ''            text-decoration: none;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        '' + sLineBreak +' + sLineBreak +
  '  ''        /* Footer Layout */'' + sLineBreak +' + sLineBreak +
  '  ''        .footer-info {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            border-collapse: collapse;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-top: 8px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .footer-info td {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 33.33%;'' + sLineBreak +' + sLineBreak +
  '  ''            vertical-align: top;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 0 8px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .footer-info td:first-child {'' + sLineBreak +' + sLineBreak +
  '  ''            padding-left: 0;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .footer-info td:last-child {'' + sLineBreak +' + sLineBreak +
  '  ''            padding-right: 0;'' + sLineBreak +' + sLineBreak +
  '  ''            border-left: none;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .text-left {'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: left;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .text-center {'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .text-right {'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: right;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .bold {'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .contact-highlight {'' + sLineBreak +' + sLineBreak +
  '  ''            color: #00b094;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        '' + sLineBreak +' + sLineBreak +
  '  ''        /* Tear-off Line */'' + sLineBreak +' + sLineBreak +
  '  ''        .dashed-line-container {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-top: 35px;'' + sLineBreak +' + sLineBreak +
  '  ''            position: relative;'' + sLineBreak +' + sLineBreak +
  '  ''            border-top: 1.5px dashed #000;'' + sLineBreak +' + sLineBreak +
  '  ''            padding-top: 3px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .dashed-text {'' + sLineBreak +' + sLineBreak +
  '  ''            float: right;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #444;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        '' + sLineBreak +' + sLineBreak +
  '  ''        /* Utility clear float */'' + sLineBreak +' + sLineBreak +
  '  ''        .clear {'' + sLineBreak +' + sLineBreak +
  '  ''            clear: both;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .cp {font: bold 10px Arial; color: black}'' + sLineBreak +' + sLineBreak +
  '  ''        .ti {font: 9px Arial, Helvetica, sans-serif}'' + sLineBreak +' + sLineBreak +
  '  ''        .ld {font: bold 15px Arial; color: #000000}'' + sLineBreak +' + sLineBreak +
  '  ''        .ct {font: 9px "Arial Narrow"; COLOR: #000033}'' + sLineBreak +' + sLineBreak +
  '  ''        .cn {font: 9px Arial; COLOR: black }'' + sLineBreak +' + sLineBreak +
  '  ''        .bc {font: bold 20px Arial; color: #000000 }'' + sLineBreak +' + sLineBreak +
  '  ''        .ld2 {font: bold 12px Arial; color: #000000 }'' + sLineBreak +' + sLineBreak +
  '  ''    </style>'' + sLineBreak +' + sLineBreak +
  '  ''</head>'' + sLineBreak +' + sLineBreak +
  '  ''<body>'' + sLineBreak +' + sLineBreak +
  '  '''' + sLineBreak +' + sLineBreak +
  '  ''<div class="invoice-container">'' + sLineBreak +' + sLineBreak +
  '  ''    '' + sLineBreak +' + sLineBreak +
  '' + sLineBreak +
  '  ''    <!-- HEADER -->'' + sLineBreak +' + sLineBreak +
  '' + sLineBreak +
  '  ''    <table class="header-table">'' + sLineBreak +' + sLineBreak +
  '  ''        <tr>'' + sLineBreak +' + sLineBreak +
  '  ''            <!-- Logo Section -->'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="logo-section">'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="logo-title"><img src="'' + url_imagens + ''logo.png"></div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="logo-subtitle">'' + sub_titulo + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            '' + sLineBreak +' + sLineBreak +
  '  ''            <!-- Client Section -->'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="client-section">'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="client-name">'' + pagador_nome + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="bold">'' + pagador_cpf + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div>'' + pagador_endereco + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div>'' + pagador_cep + '' - '' + pagador_cidade + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            '' + sLineBreak +' + sLineBreak +
  '  ''            <!-- Document Info Section -->'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="doc-section">'' + sLineBreak +' + sLineBreak +
  '  ''                <div><span class="bold">Emissão: </span>'' + data_emissao + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div><span class="bold">Nosso Número:</span></div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div style="padding-left: 5px;">'' + ABoleto.Titulo.NossoNumero + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div><span class="bold">Nº documento:</span></div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div style="padding-left: 5px;">'' + ABoleto.Titulo.NumeroDocumento + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            '' + sLineBreak +' + sLineBreak +
  '  ''            <!-- Due Date and Value Section -->'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="value-section">'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="val-title">Vencimento</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="val-date">'' + data_vencimento + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="val-title">Valor</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="val-price">'' + valor_boleto + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            '' + sLineBreak +' + sLineBreak +
  '  ''            <!-- PIX QR Code Section -->'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="pix-section">'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="pix-container">'' + sLineBreak +' + sLineBreak +
  '  ''                    <div id="qrcode" class="pix-qrcode"></div>'' + sLineBreak +' + sLineBreak +
  '  ''                </div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="pix-label">'' + sLineBreak +' + sLineBreak +
  '  ''              <div>'' + pix_label + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''        </tr>'' + sLineBreak +' + sLineBreak +
  '  ''    </table>'' + sLineBreak +' + sLineBreak +
  '  ''    '' + sLineBreak +' + sLineBreak +
  '' + sLineBreak +
  '  ''    <!-- LINHA DIGITÁVEL -->'' + sLineBreak +' + sLineBreak +
  '' + sLineBreak +
  '  ''    <div class="linha-digitavel-bar">'' + sLineBreak +' + sLineBreak +
  '  ''        <span class="linha-label">Linha Digitável:</span>'' + sLineBreak +' + sLineBreak +
  '  ''        <span class="linha-num">'' + linha_digitavel + ''</span>'' + sLineBreak +' + sLineBreak +
  '  ''        <span class="recibo-label">Recibo do Pagador</span>'' + sLineBreak +' + sLineBreak +
  '  ''        <div class="clear"></div>'' + sLineBreak +' + sLineBreak +
  '  ''    </div>'' + sLineBreak +' + sLineBreak +
  '  ''    '' + sLineBreak +' + sLineBreak +
  '' + sLineBreak +
  '  ''    <!-- MAIN CONTENT BODY -->'' + sLineBreak +' + sLineBreak +
  '' + sLineBreak +
  '  ''    <div class="main-content">'' + sLineBreak +' + sLineBreak +
  '  ''        '' + sLineBreak +' + sLineBreak +
  '  ''        <!-- LEFT COLUMN: SERVICES -->'' + sLineBreak +' + sLineBreak +
  '  ''        <div class="col-left">'' + sLineBreak +' + sLineBreak +
  '  ''            <div class="services-box">'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="services-title">Resumo dos serviços</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <table class="services-table">'' + sLineBreak +' + sLineBreak +
  '  ''                    <thead>'' + sLineBreak +' + sLineBreak +
  '  ''                        <tr>'' + sLineBreak +' + sLineBreak +
  '  ''                            <th colspan="2">Descrição</th>'' + sLineBreak +' + sLineBreak +
  '  ''                        </tr>'' + sLineBreak +' + sLineBreak +
  '  ''                    </thead>'' + sLineBreak +' + sLineBreak +
  '  ''                    <tbody>'' + sLineBreak;' + sLineBreak +
  '' + sLineBreak +
  '  for i := 0 to High(ABoleto.Fatura.Descricao) do' + sLineBreak +
  '  begin' + sLineBreak +
  '    if ABoleto.Fatura.Descricao[i]<>'''' then begin' + sLineBreak +
  '      Result := Result +' + sLineBreak +
  '      ''                        <tr><td>'' + ABoleto.Fatura.Descricao[i] + ''</td>'' +' + sLineBreak +
  '      ''<td style="text-align: right">'' + ABoleto.Titulo.EspecieValor + '' '' + TApiFuncoes.NumeroParaReal(ABoleto.Fatura.Valor[i], 2, True) + ''</td></tr>'' + sLineBreak;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := Result +' + sLineBreak +
  '  ''                        <tr><td> </td><td style="text-align: right"><b>'' + valor_boleto + ''</b></td></tr>'' + sLineBreak;' + sLineBreak +
  '' + sLineBreak +
  '  if ABoleto.Fatura.MensagemAdicional<>'''' then' + sLineBreak +
  '    Result := Result +' + sLineBreak +
  '    ''                        <tr><td> </td><td> </td></tr>'' + sLineBreak;' + sLineBreak +
  '' + sLineBreak +
  '  Result := Result +' + sLineBreak +
  '  ''                    </tbody>'' + sLineBreak +' + sLineBreak +
  '  ''                </table>'' + sLineBreak +' + sLineBreak +
  '  ''                <div style="padding: 10px;">'' + ABoleto.Fatura.MensagemAdicional + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </div>'' + sLineBreak +' + sLineBreak +
  '  ''        </div>'' + sLineBreak +' + sLineBreak +
  '  ''        '' + sLineBreak +' + sLineBreak +
  '' + sLineBreak +
  '  ''        <!-- RIGHT COLUMN: MARGIN DETAILS -->'' + sLineBreak +' + sLineBreak +
  '' + sLineBreak +
  '  ''        <div class="col-right">'' + sLineBreak +' + sLineBreak +
  '  ''            <div class="experience-box">'' + sLineBreak +' + sLineBreak +
  '  ''               '' + lateral_mensagem1 + sLineBreak +' + sLineBreak +
  '  ''            </div>'' + sLineBreak +' + sLineBreak +
  '  ''            '' + sLineBreak +' + sLineBreak +
  '  ''            <div class="info-group">'' + sLineBreak +' + sLineBreak +
  '  ''                '' + lateral_mensagem2 + sLineBreak +' + sLineBreak +
  '  ''            </div>'' + sLineBreak +' + sLineBreak +
  '  ''            '' + sLineBreak +' + sLineBreak +
  '  ''            <div class="info-group">'' + sLineBreak +' + sLineBreak +
  '  ''                '' + lateral_mensagem3 + sLineBreak +' + sLineBreak +
  '  ''            </div>'' + sLineBreak +' + sLineBreak +
  '  ''            '' + sLineBreak +' + sLineBreak +
  '  ''            <div class="info-group">'' + sLineBreak +' + sLineBreak +
  '  ''                '' + lateral_mensagem4 + sLineBreak +' + sLineBreak +
  '  ''            </div>'' + sLineBreak +' + sLineBreak +
  '  ''        </div>'' + sLineBreak +' + sLineBreak +
  '  ''        <div class="clear"></div>'' + sLineBreak +' + sLineBreak +
  '  ''    </div>'' + sLineBreak +' + sLineBreak +
  '  ''    '' + sLineBreak +' + sLineBreak +
  '  ''    <!-- FOOTER MESSAGES -->'' + sLineBreak +' + sLineBreak +
  '  ''    <table class="footer-info">'' + sLineBreak +' + sLineBreak +
  '  ''        <tr>'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="text-center">'' + sLineBreak +' + sLineBreak +
  '  ''                '' + footer_mensagem1 + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="text-center">'' + sLineBreak +' + sLineBreak +
  '  ''                '' + footer_mensagem2 + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="text-center"> <!-- text-right -->'' + sLineBreak +' + sLineBreak +
  '  ''                '' + footer_mensagem3 + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''        </tr>'' + sLineBreak +' + sLineBreak +
  '  ''    </table>'' + sLineBreak +' + sLineBreak +
  '  ''    '' + sLineBreak +' + sLineBreak +
  '  ''    <!-- DASHED LINE -->'' + sLineBreak +' + sLineBreak +
  '  ''    <div class="dashed-line-container">'' + sLineBreak +' + sLineBreak +
  '  ''        <span class="dashed-text">Corte na linha pontilhada</span>'' + sLineBreak +' + sLineBreak +
  '  ''        <div class="clear"></div>'' + sLineBreak +' + sLineBreak +
  '  ''    </div>'' + sLineBreak +' + sLineBreak +
  '  ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''<div class="boleto-container">'' + sLineBreak +' + sLineBreak +
  '  lBoleto +' + sLineBreak +
  '  ''</div>'' +' + sLineBreak +
  '  ''<br>'' + sLineBreak +' + sLineBreak +
  '  '''' + sLineBreak;' + sLineBreak +
  '' + sLineBreak +
  '  if PixString<>'''' then' + sLineBreak +
  '    Result := Result +' + sLineBreak +
  '    ''<script> '' +' + sLineBreak +
  '      ''  var qrcode = new QRCode(document.getElementById("qrcode"), { '' +' + sLineBreak +
  '      ''    text: "'' + PixString + ''", '' +' + sLineBreak +
  '      ''    width: 140, '' +' + sLineBreak +
  '      ''    height: 140, '' +' + sLineBreak +
  '      ''    colorDark : "#000000", '' +' + sLineBreak +
  '      ''    colorLight : "#ffffff", '' +' + sLineBreak +
  '      ''    correctLevel : QRCode.CorrectLevel.H '' + //CRUCIAL: Nível High' + sLineBreak +
  '      ''  }); '' +' + sLineBreak +
  '      ''</script> '';' + sLineBreak +
  '' + sLineBreak +
  '  Result := Result +' + sLineBreak +
  '  ''</body>'' + sLineBreak +' + sLineBreak +
  '  ''</html>'' + sLineBreak;' + sLineBreak +
  '' + sLineBreak +
  '  lBoleto := '''';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.layout.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_LinhaDigitavel;
var
  s: string;
begin
  s :=
  'unit Boleto.LinhaDigitavel;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// obtém o código de barras, a linha digitável e nosso número formatado' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils,' + sLineBreak +
  '  Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TLinhaDigitavel }' + sLineBreak +
  '' + sLineBreak +
  '  TLinhaDigitavel = class' + sLineBreak +
  '  public' + sLineBreak +
  '    class function GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  '    class function GetDesenhoCodigoBarrasSVG(ACodigoBarras: string): string;' + sLineBreak +
  '    class function GetDesenhoCodigoBarrasHTML(ACodigoBarras: string): string;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Api.Funcoes,' + sLineBreak +
  '  Boleto.BancoBrasil,' + sLineBreak +
  '  Boleto.BancoSantander,' + sLineBreak +
  '  Boleto.BancoCEF,' + sLineBreak +
  '  Boleto.BancoBradesco,' + sLineBreak +
  '  Boleto.BancoItau,' + sLineBreak +
  '  Boleto.BancoSicoob;' + sLineBreak +
  '' + sLineBreak +
  '{ TLinhaDigitavel }' + sLineBreak +
  '' + sLineBreak +
  'class function TLinhaDigitavel.GetLinhaDigitavel(var ABoleto: TBoletoDados): TLinhaDigitavelInfo;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result.CodigoBarras   := '''';' + sLineBreak +
  '  Result.LinhaDigitavel := '''';' + sLineBreak +
  '  Result.NossoNumero    := '''';' + sLineBreak +
  '' + sLineBreak +
  '  case StrToIntDef(''0'' + ABoleto.Conta.BancoCodigo, 0) of' + sLineBreak +
  '      1: begin { BANCO DO BRASIL }' + sLineBreak +
  '           ABoleto.Conta.BancoCodigoDV := ''9'';' + sLineBreak +
  '           Result := TBoletoBancoBrasil.new.GetLinhaDigitavel( ABoleto );' + sLineBreak +
  '         end;' + sLineBreak +
  '     33: begin { SANTANDER }' + sLineBreak +
  '           ABoleto.Conta.BancoCodigoDV := ''7'';' + sLineBreak +
  '           Result := TBoletoBancoSantander.new.GetLinhaDigitavel( ABoleto );' + sLineBreak +
  '         end;' + sLineBreak +
  '    104: begin { CAIXA ECONÔMICA FEDERAL}' + sLineBreak +
  '           ABoleto.Conta.BancoCodigoDV := ''0'';' + sLineBreak +
  '           Result := TBoletoBancoCEF.new.GetLinhaDigitavel( ABoleto );' + sLineBreak +
  '         end;' + sLineBreak +
  '    237: begin { BRADESCO }' + sLineBreak +
  '           ABoleto.Conta.BancoCodigoDV := ''2'';' + sLineBreak +
  '           Result := TBoletoBancoBradesco.new.GetLinhaDigitavel( ABoleto );' + sLineBreak +
  '         end;' + sLineBreak +
  '    341: begin { ITAU }' + sLineBreak +
  '           ABoleto.Conta.BancoCodigoDV := ''7'';' + sLineBreak +
  '           Result := TBoletoBancoItau.new.GetLinhaDigitavel( ABoleto );' + sLineBreak +
  '         end;' + sLineBreak +
  '    756: begin { SICOOB }' + sLineBreak +
  '           ABoleto.Conta.BancoCodigoDV := ''0'';' + sLineBreak +
  '           Result := TBoletoBancoSicoob.new.GetLinhaDigitavel( ABoleto );' + sLineBreak +
  '         end;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TLinhaDigitavel.GetDesenhoCodigoBarrasSVG(ACodigoBarras: string): string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TApiFuncoes.DesenhaCodigoBarrasSVG( ACodigoBarras );' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class function TLinhaDigitavel.GetDesenhoCodigoBarrasHTML(ACodigoBarras: string): string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TApiFuncoes.DesenhaCodigoBarrasHtml( ACodigoBarras );' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.linhadigitavel.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_Models;
var
  s: string;
begin
  s :=
  'unit Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '  { dados da linha digitável e código de barras }' + sLineBreak +
  '  TLinhaDigitavelInfo = record' + sLineBreak +
  '    LinhaDigitavel: string;' + sLineBreak +
  '    CodigoBarras: string;' + sLineBreak +
  '    NossoNumero: string;' + sLineBreak +
  '    //DesenhoCodigoBarras: string;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  { Dados Bancários da Conta que emitirá o boleto }' + sLineBreak +
  '  TContaDados = record' + sLineBreak +
  '    BancoCodigo: string;     // Ex: ''237''' + sLineBreak +
  '    BancoCodigoDV: string;   // Ex: ''1''' + sLineBreak +
  '    Agencia: string;         // Ex: ''0134''' + sLineBreak +
  '    AgenciaDV: string;       // Ex: ''9''' + sLineBreak +
  '    ContaCorrente: string;   // Ex: ''98063''' + sLineBreak +
  '    ContaCorrenteDV: string; // Ex: ''1''' + sLineBreak +
  '    Carteira: string;        // Ex: ''09''' + sLineBreak +
  '    CodigoCedente: string;   // Código do beneficiário junto ao banco' + sLineBreak +
  '    Convenio: string;        // Número do convênio, se houver' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  { Dados de quem está recebendo (Sua Empresa / Cliente) }' + sLineBreak +
  '  TCedenteDados = record' + sLineBreak +
  '    Nome: string;' + sLineBreak +
  '    CNPJCPF: string;   // formatado' + sLineBreak +
  '    Endereco: string;' + sLineBreak +
  '    Bairro: string;' + sLineBreak +
  '    Cidade: string;' + sLineBreak +
  '    UF: string;' + sLineBreak +
  '    CEP: string; // formatado' + sLineBreak +
  '    Email: string;' + sLineBreak +
  '    ChavePix: string;' + sLineBreak +
  '    Telefone: string;' + sLineBreak +
  '    WhatsApp: string;' + sLineBreak +
  '    Www: string;' + sLineBreak +
  '    CentralAtendimento: string;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  { Dados de quem pagará o boleto (O Cliente dele) }' + sLineBreak +
  '  TSacadoDados = record' + sLineBreak +
  '    Nome: string;' + sLineBreak +
  '    CNPJCPF: string; // formatado' + sLineBreak +
  '    Endereco: string;' + sLineBreak +
  '    Bairro: string;' + sLineBreak +
  '    Cidade: string;' + sLineBreak +
  '    UF: string;' + sLineBreak +
  '    CEP: string; // formatado' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  { Dados específicos do Título/Boleto }' + sLineBreak +
  '  TTituloDados = record' + sLineBreak +
  '    NossoNumero: string;      // Número gerado pelo banco ou pelo seu sistema, incluindo o DV' + sLineBreak +
  '    NumeroDocumento: string;  // Seu controle interno (Ex: número da nota)' + sLineBreak +
  '    DataDocumento: TDateTime; // data da geração' + sLineBreak +
  '    DataProcessamento: TDateTime; // data de processamento pelo banco' + sLineBreak +
  '    DataVencimento: TDateTime;    // data de vencimento do boleto' + sLineBreak +
  '    Valor: Currency;              // valor final do boleto' + sLineBreak +
  '    Demonstrativo: array[0..2] of string; // Até 3 linhas de informações no comprovante do sacado' + sLineBreak +
  '    Instrucoes: array[0..6] of string;    // Até 7 linhas de instruções' + sLineBreak +
  '    Aceite: string;            // ''N'' ou ''S''' + sLineBreak +
  '    EspecieDocumento: string;  // ''DM'' (Duplicata Mercantil), etc.' + sLineBreak +
  '    MoedaTipo: string;         // ''9'' = Real' + sLineBreak +
  '    EspecieValor: string;      // ''R$''' + sLineBreak +
  '    LinhaDigitavel: string;    // dados da linha digitável do boleto' + sLineBreak +
  '    CodigoBarras: string;      // dados para desenhar o código de barras' + sLineBreak +
  '    IdentificadoPix: string;   //seu código para identificar o pagamento' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  { TFaturaDados }' + sLineBreak +
  '  TFaturaDados = record' + sLineBreak +
  '    Descricao: array[0..6] of string; // Até 7 linhas de descrições' + sLineBreak +
  '    Valor: array[0..6] of Currency;   // Até 7 valores' + sLineBreak +
  '    MensagemAdicional: string;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  { Agrupamento dos dados }' + sLineBreak +
  '  TBoletoDados = record' + sLineBreak +
  '    Conta: TContaDados;' + sLineBreak +
  '    Cedente: TCedenteDados;' + sLineBreak +
  '    Sacado: TSacadoDados;' + sLineBreak +
  '    Titulo: TTituloDados;' + sLineBreak +
  '    Fatura: TFaturaDados;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.models.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_Pix;
var
  s: string;
begin
  s :=
  'unit Boleto.Pix;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils,' + sLineBreak +
  '  Boleto.Models;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TBoletoPix }' + sLineBreak +
  '' + sLineBreak +
  '  TBoletoPix = class' + sLineBreak +
  '    private' + sLineBreak +
  '      function CalcularCRC16(const S: string): string;' + sLineBreak +
  '      function FormatarCampoPix(AID, AValor: string): string;' + sLineBreak +
  '      function GerarMailtoURI(AEmail, ASubject, ABody: string): string;' + sLineBreak +
  '      function QRCodeHTML(ADados: string; AUsarLogo, APdf: Boolean): string;' + sLineBreak +
  '    public' + sLineBreak +
  '      function GerarPixPayload(AChavePix, ANome, ACidade, AValor, AIdendificador: string): string;' + sLineBreak +
  '      function GetPix(ABoleto: TBoletoDados; AProtegeCPF, APdf: Boolean): string;' + sLineBreak +
  '      function GetQRCode(AContentOrEmail: string; AEmailSubject, AEmailBody: string; AUsarLogo, APdf: Boolean): string;' + sLineBreak +
  '      class function new: TBoletoPix;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  LazUTF8, HTTPDefs, Api.Funcoes;' + sLineBreak +
  '' + sLineBreak +
  'class function TBoletoPix.new: TBoletoPix;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TBoletoPix.Create;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoPix.CalcularCRC16(const S: string): string;' + sLineBreak +
  'var' + sLineBreak +
  '  I, J: Integer;' + sLineBreak +
  '  CRC: Word;' + sLineBreak +
  'begin' + sLineBreak +
  '  CRC := $FFFF;' + sLineBreak +
  '' + sLineBreak +
  '  for I := 1 to Length(S) do begin' + sLineBreak +
  '    CRC := CRC xor (Word(Ord(S[I])) shl 8);' + sLineBreak +
  '    for J := 1 to 8 do begin' + sLineBreak +
  '      if (CRC and $8000) <> 0 then' + sLineBreak +
  '        CRC := (CRC shl 1) xor $1021' + sLineBreak +
  '      else' + sLineBreak +
  '        CRC := CRC shl 1;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := IntToHex(CRC and $FFFF, 4);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoPix.FormatarCampoPix(AID, AValor: string): string;' + sLineBreak +
  'begin' + sLineBreak +
  '  //Result := AID + Format(''%.2d'', [Length(AValor)]) + AValor;' + sLineBreak +
  '  Result := AID + FormatFloat(''00'', Length(AValor)) + AValor;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoPix.GerarPixPayload(AChavePix, ANome, ACidade, AValor, AIdendificador: string): string;' + sLineBreak +
  '// AIdentificador: Seu código que identifique o motivo do pagamento deste pix' + sLineBreak +
  '// https://www.bcb.gov.br/estabilidadefinanceira/pix' + sLineBreak +
  'var' + sLineBreak +
  '  Payload, InfoConta: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  if AIdendificador = '''' then AIdendificador := ''***'';' + sLineBreak +
  '  if Length(AIdendificador)>25 then AIdendificador := LeftStr(AIdendificador, 25);' + sLineBreak +
  '' + sLineBreak +
  '  // 00: Payload Format Indicator' + sLineBreak +
  '  Payload := FormatarCampoPix(''00'', ''01'');' + sLineBreak +
  '' + sLineBreak +
  '  // 26: Merchant Account Information (Chave Pix)' + sLineBreak +
  '  InfoConta := FormatarCampoPix(''00'', ''br.gov.bcb.pix'') + FormatarCampoPix(''01'', AChavePix);' + sLineBreak +
  '  Payload := Payload + FormatarCampoPix(''26'', InfoConta);' + sLineBreak +
  '' + sLineBreak +
  '  // 52: Merchant Category Code' + sLineBreak +
  '  Payload := Payload + FormatarCampoPix(''52'', ''0000'');' + sLineBreak +
  '  // 53: Transaction Currency (986 = Real)' + sLineBreak +
  '  Payload := Payload + FormatarCampoPix(''53'', ''986'');' + sLineBreak +
  '  // 54: Transaction Amount' + sLineBreak +
  '  Payload := Payload + FormatarCampoPix(''54'', AValor); // ex: 10.95' + sLineBreak +
  '  // 58: Country Code' + sLineBreak +
  '  Payload := Payload + FormatarCampoPix(''58'', ''BR'');' + sLineBreak +
  '  // 59: Merchant Name' + sLineBreak +
  '  Payload := Payload + FormatarCampoPix(''59'', ANome);' + sLineBreak +
  '  // 60: Merchant City' + sLineBreak +
  '  Payload := Payload + FormatarCampoPix(''60'', ACidade);' + sLineBreak +
  '  // 62: Additional Data Field (TXID) - Transaction Amount (Livre)' + sLineBreak +
  '  Payload := Payload + FormatarCampoPix(''62'', FormatarCampoPix(''05'', AIdendificador));' + sLineBreak +
  '' + sLineBreak +
  '  // 63: CRC16 (Início do campo)' + sLineBreak +
  '  Payload := Payload + ''6304'';' + sLineBreak +
  '  Result := Payload + CalcularCRC16(Payload);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoPix.GetPix(ABoleto: TBoletoDados; AProtegeCPF, APdf: Boolean): string;' + sLineBreak +
  '// Gera o HTML do PIX' + sLineBreak +
  'var' + sLineBreak +
  '  LChave, LValorPix, PixString, LNome, LCidade, LIdentificador,' + sLineBreak +
  '    footer_mensagem1, footer_mensagem2, footer_mensagem3, url_imagens,' + sLineBreak +
  '    sub_titulo, valor_boleto, pagador_nome, pagador_cpf,' + sLineBreak +
  '    pagador_endereco, pagador_bairro, pagador_cidade, pagador_cep,' + sLineBreak +
  '    data_vencimento, data_emissao: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := '''';' + sLineBreak +
  '' + sLineBreak +
  '  if APdf then' + sLineBreak +
  '    url_imagens := ''images/''' + sLineBreak +
  '  else' + sLineBreak +
  '    url_imagens := ''/images/'';' + sLineBreak +
  '' + sLineBreak +
  '  (*' + sLineBreak +
  '  **** Importante: Sem acentuação ****' + sLineBreak +
  '  LChave  := ''suachave@email.com'';' + sLineBreak +
  '  LNome   := ''FULANO DE TAL'';' + sLineBreak +
  '  LCidade := ''SAO PAULO'';' + sLineBreak +
  '  LValor  := ''10.50''; // Use ponto para decimais' + sLineBreak +
  '  LIdentificador := ''TIT984209''; //Seu código que identifique o motivo do pagamento deste pix' + sLineBreak +
  '  *)' + sLineBreak +
  '' + sLineBreak +
  '  LNome := UpperCase( TApiFuncoes.OnlyAlfabetic( TApiFuncoes.RemoverAcentos(ABoleto.Cedente.Nome) ) );' + sLineBreak +
  '  LCidade := UpperCase( TApiFuncoes.OnlyAlfabetic( TApiFuncoes.RemoverAcentos(ABoleto.Cedente.Cidade) ) );' + sLineBreak +
  '  LValorPix := TApiFuncoes.FormatFloatNotRounded(''0.00'', ABoleto.Titulo.Valor, 2);' + sLineBreak +
  '  LChave := ABoleto.Cedente.ChavePix;' + sLineBreak +
  '  LIdentificador := ABoleto.Titulo.IdentificadoPix;' + sLineBreak +
  '' + sLineBreak +
  '  if Length(LIdentificador)>0 then' + sLineBreak +
  '    LIdentificador := UpperCase(LIdentificador);' + sLineBreak +
  '' + sLineBreak +
  '  // código do PIX' + sLineBreak +
  '  PixString := GerarPixPayload(LChave, LNome, LCidade, LValorPix, LIdentificador);' + sLineBreak +
  '' + sLineBreak +
  '  // sacado' + sLineBreak +
  '  pagador_nome     := ABoleto.Sacado.Nome.ToUpper;' + sLineBreak +
  '  pagador_cpf      := ABoleto.Sacado.CNPJCPF; // cpf ou cnpj' + sLineBreak +
  '  pagador_endereco := ABoleto.Sacado.Endereco;' + sLineBreak +
  '  pagador_bairro   := ABoleto.Sacado.Bairro;' + sLineBreak +
  '  pagador_cidade   := ABoleto.Sacado.Cidade + ''-'' + ABoleto.Sacado.UF;' + sLineBreak +
  '  pagador_cep      := ABoleto.Sacado.CEP;' + sLineBreak +
  '' + sLineBreak +
  '  if ABoleto.Sacado.Bairro <> '''' then' + sLineBreak +
  '    pagador_endereco := ABoleto.Sacado.Endereco + '' - '' + ABoleto.Sacado.Bairro;' + sLineBreak +
  '' + sLineBreak +
  '  // não exibe o CPF completo' + sLineBreak +
  '  if AProtegeCPF and (Length(pagador_cpf) > 10) then begin' + sLineBreak +
  '    pagador_cpf[1] := ''*'';' + sLineBreak +
  '    pagador_cpf[2] := ''*'';' + sLineBreak +
  '    pagador_cpf[3] := ''*'';' + sLineBreak +
  '    pagador_cpf[High(pagador_cpf)-1] := ''*'';' + sLineBreak +
  '    pagador_cpf[High(pagador_cpf)]   := ''*'';' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  data_vencimento := FormatDateTime(''dd/mm/yyyy'', ABoleto.Titulo.DataVencimento);' + sLineBreak +
  '  data_emissao    := FormatDateTime(''dd/mm/yyyy'', ABoleto.Titulo.DataDocumento);' + sLineBreak +
  '  valor_boleto    := TApiFuncoes.NumeroParaReal(ABoleto.Titulo.Valor, 2, True); // R$ 95,67' + sLineBreak +
  '' + sLineBreak +
  '  if ABoleto.Titulo.EspecieValor <> '''' then' + sLineBreak +
  '    valor_boleto := ABoleto.Titulo.EspecieValor + '' '' + valor_boleto;' + sLineBreak +
  '' + sLineBreak +
  '  // mensagens' + sLineBreak +
  '  sub_titulo := ''viva essa experiência!'';' + sLineBreak +
  '  footer_mensagem1 := ''Evite o bloqueio do serviço, efetuando o <span class="bold">pagamento</span> '' +' + sLineBreak +
  '                      ''até a data do <span class="bold">vencimento</span>.'';' + sLineBreak +
  '  footer_mensagem2 := ''Caso existam <span class="bold">serviços</span> prestados e <span class="bold">'' +' + sLineBreak +
  '                      ''não cobrados</span>, esses serão inclusos nas suas <span class="bold">'' +' + sLineBreak +
  '                      ''próximas faturas</span>.'';' + sLineBreak +
  '  footer_mensagem3 := ''Para solicitar atendimento entre em contato através do <span class="bold">'' +' + sLineBreak +
  '                      ''whatsapp</span> <span class="contact-highlight">'' + ABoleto.Cedente.WhatsApp + ''</span><br>'' +' + sLineBreak +
  '                      ''ou <span class="bold">telefone</span> <span class="contact-highlight">'' +' + sLineBreak +
  '                      ABoleto.Cedente.Telefone + ''</span>'';' + sLineBreak +
  '' + sLineBreak +
  '  Result :=' + sLineBreak +
  '  ''<!DOCTYPE html>'' + sLineBreak +' + sLineBreak +
  '  ''<html lang="pt-BR">'' + sLineBreak +' + sLineBreak +
  '  ''<head>'' + sLineBreak +' + sLineBreak +
  '  ''    <title>PIX - '' + ABoleto.Cedente.Nome + ''</title>'' + sLineBreak +' + sLineBreak +
  '  ''    <meta http-equiv="Content-Type" content="text/html" charset="UTF-8">'' + sLineBreak +' + sLineBreak +
  '  ''    <meta name="Generator" content="'' + ABoleto.Cedente.Email + ''" /> '' + sLineBreak +' + sLineBreak +
  '  ''    <link rel="icon" type="image/x-icon" href="/favicon.ico">'' + sLineBreak +' + sLineBreak +
  '  ''    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>'' + sLineBreak +' + sLineBreak +
  '  ''    <style>'' + sLineBreak +' + sLineBreak +
  '  ''        @page {  '' + sLineBreak +' + sLineBreak +
  '  ''          margin: 0;'' + sLineBreak +' + sLineBreak +
  '  ''          size : A4 portrait;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        * {'' + sLineBreak +' + sLineBreak +
  '  ''            box-sizing: border-box;'' + sLineBreak +' + sLineBreak +
  '  ''            font-family: Arial, sans-serif;'' + sLineBreak +' + sLineBreak +
  '  ''            margin: 0;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 0;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        body {'' + sLineBreak +' + sLineBreak +
  '  ''            background-color: #ffffff;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #000000;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 20px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11px;'' + sLineBreak +' + sLineBreak +
  '  ''            line-height: 1.4;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .invoice-container {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            max-width: 800px;'' + sLineBreak +' + sLineBreak +
  '  ''            margin: 0 auto;'' + sLineBreak +' + sLineBreak +
  '  ''            position: relative;'' + sLineBreak +' + sLineBreak +
  '  ''        }        '' + sLineBreak +' + sLineBreak +
  '  ''        .header-table {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            border-collapse: collapse;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 15px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .header-table td {'' + sLineBreak +' + sLineBreak +
  '  ''            vertical-align: top;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .logo-section {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 20%;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .logo-title {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 28px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #1a3d6c;'' + sLineBreak +' + sLineBreak +
  '  ''            letter-spacing: -1px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .logo-subtitle {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 9px;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #777;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-top: -4px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .client-section {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 30%;'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 0 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .client-name {'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .doc-section {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 20%;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            padding-left: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .doc-section div {'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 2px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .value-section {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 13%;'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .val-title {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 10px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            color: #555;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .val-date {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 15px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 8px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .val-price {'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 16px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }        '' + sLineBreak +' + sLineBreak +
  '  ''        .main-content {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-bottom: 25px;'' + sLineBreak +' + sLineBreak +
  '  ''            content-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .highlight-green {'' + sLineBreak +' + sLineBreak +
  '  ''            color: #00b094;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .highlight-blue {'' + sLineBreak +' + sLineBreak +
  '  ''            color: #0056b3;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .link-text {'' + sLineBreak +' + sLineBreak +
  '  ''            color: #00b094;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''            word-break: break-all;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11.5px;'' + sLineBreak +' + sLineBreak +
  '  ''            text-decoration: none;'' + sLineBreak +' + sLineBreak +
  '  ''        }        '' + sLineBreak +' + sLineBreak +
  '  ''        .footer-info {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 100%;'' + sLineBreak +' + sLineBreak +
  '  ''            border-collapse: collapse;'' + sLineBreak +' + sLineBreak +
  '  ''            margin-top: 15px;'' + sLineBreak +' + sLineBreak +
  '  ''            font-size: 11px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .footer-info td {'' + sLineBreak +' + sLineBreak +
  '  ''            width: 33.33%;'' + sLineBreak +' + sLineBreak +
  '  ''            vertical-align: top;'' + sLineBreak +' + sLineBreak +
  '  ''            padding: 0 10px;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .footer-info td:first-child {'' + sLineBreak +' + sLineBreak +
  '  ''            padding-left: 0;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .footer-info td:last-child {'' + sLineBreak +' + sLineBreak +
  '  ''            padding-right: 0;'' + sLineBreak +' + sLineBreak +
  '  ''            border-left: none;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .text-left {'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: left;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .text-center {'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: center;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .text-right {'' + sLineBreak +' + sLineBreak +
  '  ''            text-align: right;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .bold {'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }'' + sLineBreak +' + sLineBreak +
  '  ''        .contact-highlight {'' + sLineBreak +' + sLineBreak +
  '  ''            color: #00b094;'' + sLineBreak +' + sLineBreak +
  '  ''            font-weight: bold;'' + sLineBreak +' + sLineBreak +
  '  ''        }       '' + sLineBreak +' + sLineBreak +
  '  ''    </style>'' + sLineBreak +' + sLineBreak +
  '  ''</head>'' + sLineBreak +' + sLineBreak +
  '  ''<body>'' + sLineBreak +' + sLineBreak +
  '  ''<div class="invoice-container"> '' + sLineBreak +' + sLineBreak +
  '  ''    <!-- HEADER -->'' + sLineBreak +' + sLineBreak +
  '  ''    <table class="header-table">'' + sLineBreak +' + sLineBreak +
  '  ''        <tr>'' + sLineBreak +' + sLineBreak +
  '  ''            <!-- Logo Section -->'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="logo-section">'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="logo-title"><img src="'' + url_imagens + ''logo.png"></div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="logo-subtitle">'' + sub_titulo + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            <!-- empresa Section -->'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="client-section">'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="client-name">'' + pagador_nome + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="bold">'' + pagador_cpf + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div>'' + pagador_endereco + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div>'' + pagador_cep + '' - '' + pagador_cidade + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            <!-- Document Info Section -->'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="doc-section">'' + sLineBreak +' + sLineBreak +
  '  ''                <div><span class="bold">Emissão: </span>'' + data_emissao + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div><span class="bold">Nosso Número:</span></div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div style="padding-left: 5px;">'' + ABoleto.Titulo.NossoNumero + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div><span class="bold">Nº documento:</span></div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div style="padding-left: 5px;">'' + ABoleto.Titulo.NumeroDocumento + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            '' + sLineBreak +' + sLineBreak +
  '  ''            <!-- Due Date and Value Section -->'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="value-section">'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="val-title">Vencimento</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="val-date">'' + data_vencimento + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="val-title">Valor</div>'' + sLineBreak +' + sLineBreak +
  '  ''                <div class="val-price">'' + valor_boleto + ''</div>'' + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''        </tr>'' + sLineBreak +' + sLineBreak +
  '  ''    </table> '' + sLineBreak +' + sLineBreak +
  '  ''    <hr><br><br>'' + sLineBreak +' + sLineBreak +
  '  ''    <!-- MAIN CONTENT BODY -->'' + sLineBreak +' + sLineBreak +
  '  ''    <div class="main-content">'' + sLineBreak +' + sLineBreak +
  '  ''     <center>'' + sLineBreak +' + sLineBreak +
  '  ''      <div id="qrcode-container" style="position: relative; width: 200px; height: 200px;">'' + sLineBreak +' + sLineBreak +
  '  ''        <div id="qrcode"></div> '' + sLineBreak +' + sLineBreak +
  '  ''        <img id="logo" src="'' + url_imagens + ''logo_qr.png" '' + sLineBreak +' + sLineBreak +
  '  ''             style="position: absolute; top: 50%; left: 50%; '' + sLineBreak +' + sLineBreak +
  '  ''                    transform: translate(-50%, -50%); '' + sLineBreak +' + sLineBreak +
  '  ''                    width: 50px; height: 50px; '' + sLineBreak +' + sLineBreak +
  '  ''                    border: 4px solid white; background: white; border-radius: 8px;"> '' + sLineBreak +' + sLineBreak +
  '  ''      </div>'' + sLineBreak +' + sLineBreak +
  '  ''      <br>'' + sLineBreak +' + sLineBreak +
  '  ''      <h3>Chave PIX: '' + LChave + ''</h3>'' + sLineBreak +' + sLineBreak +
  '  ''      </center> '' + sLineBreak +' + sLineBreak +
  '  ''    </div>'' + sLineBreak +' + sLineBreak +
  '  ''    <hr>'' + sLineBreak +' + sLineBreak +
  '  ''    <!-- FOOTER MESSAGES -->'' + sLineBreak +' + sLineBreak +
  '  ''    <table class="footer-info">'' + sLineBreak +' + sLineBreak +
  '  ''        <tr>'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="text-center">'' + sLineBreak +' + sLineBreak +
  '  ''                '' + footer_mensagem1 + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="text-center">'' + sLineBreak +' + sLineBreak +
  '  ''                '' + footer_mensagem2 + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''            <td class="text-center">'' + sLineBreak +' + sLineBreak +
  '  ''                '' + footer_mensagem3 + sLineBreak +' + sLineBreak +
  '  ''            </td>'' + sLineBreak +' + sLineBreak +
  '  ''        </tr>'' + sLineBreak +' + sLineBreak +
  '  ''    </table>'' + sLineBreak +' + sLineBreak +
  '  ''</div>'' + sLineBreak +' + sLineBreak +
  '  '' <script> '' + sLineBreak +' + sLineBreak +
  '  ''   var qrcode = new QRCode(document.getElementById("qrcode"), { '' + sLineBreak +' + sLineBreak +
  '  ''          text: "'' + PixString + ''", '' + sLineBreak +' + sLineBreak +
  '  ''          width: 200, '' + sLineBreak +' + sLineBreak +
  '  ''          height: 200, '' + sLineBreak +' + sLineBreak +
  '  ''          colorDark : "#000000", '' + sLineBreak +' + sLineBreak +
  '  ''          colorLight : "#ffffff", '' + sLineBreak +' + sLineBreak +
  '  ''          correctLevel : QRCode.CorrectLevel.H '' + sLineBreak +' + sLineBreak +
  '  ''       }); '' + sLineBreak +' + sLineBreak +
  '  '' </script>'' + sLineBreak +' + sLineBreak +
  '  ''</body>'' + sLineBreak +' + sLineBreak +
  '  ''</html>'';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoPix.GerarMailtoURI(AEmail, ASubject, ABody: string): string;' + sLineBreak +
  'begin' + sLineBreak +
  '  // O HTTPEncode converte espaços em ''+'' ou ''%20'' e protege caracteres especiais' + sLineBreak +
  '  Result := ''mailto:'' + AEmail;' + sLineBreak +
  '  if ASubject <> '''' then Result := Result + ''?subject='' + HTTPEncode(ASubject);' + sLineBreak +
  '  if ABody <> '''' then Result := Result + ''&body='' + HTTPEncode(ABody);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoPix.GetQRCode(AContentOrEmail: string; AEmailSubject, AEmailBody: string; AUsarLogo, APdf: Boolean): string;' + sLineBreak +
  '// Gera o HTML do QRCode' + sLineBreak +
  '// AContentOrEmail = seu_email@exemplo.com.br  OU  www.sua_empresa.com.br' + sLineBreak +
  'begin' + sLineBreak +
  '  if AContentOrEmail = '''' then Exit('''');' + sLineBreak +
  '  if (Pos(''@'', AContentOrEmail) > 1) then begin' + sLineBreak +
  '    AContentOrEmail := GerarMailtoURI(AContentOrEmail, AEmailSubject, AEmailBody);' + sLineBreak +
  '  end' + sLineBreak +
  '  else if (Pos(''http'', AContentOrEmail) > 0) or (Pos(''www'', AContentOrEmail) > 0) then begin' + sLineBreak +
  '    AContentOrEmail := StringReplace(AContentOrEmail, '' '', ''%20'', [rfReplaceAll]);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  Result := QRCodeHTML(AContentOrEmail, AUsarLogo, APdf);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'function TBoletoPix.QRCodeHTML(ADados: string; AUsarLogo, APdf: Boolean): string;' + sLineBreak +
  '// monta o QRCode' + sLineBreak +
  'var' + sLineBreak +
  '  sUrlLogo: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  if APdf then' + sLineBreak +
  '    sUrlLogo := ''images/logo_qr.png''' + sLineBreak +
  '  else' + sLineBreak +
  '    sUrlLogo := ''/images/logo_qr.png'';' + sLineBreak +
  '' + sLineBreak +
  '  Result :=' + sLineBreak +
  '    ''<html><head><title>QRCode</title>'' +' + sLineBreak +
  '    ''<style type="text/css">'' +' + sLineBreak +
  '    '' @page {'' +  { remove headers no PDF }' + sLineBreak +
  '    ''   margin: 0;'' +' + sLineBreak +
  '    ''   size : A4 portrait;'' +' + sLineBreak +
  '    '' }'' +' + sLineBreak +
  '    ''</style>'' +' + sLineBreak +
  '    ''<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script> '' +' + sLineBreak +
  '    ''</head><body>'';' + sLineBreak +
  '' + sLineBreak +
  '  if AUsarLogo then' + sLineBreak +
  '    Result := Result +' + sLineBreak +
  '      ''<div id="qrcode-container" style="position: relative; width: 256px; height: 256px;"> '' +' + sLineBreak +
  '      ''  <div id="qrcode"></div> '' +' + sLineBreak +
  '      ''  <img id="logo" src="'' + sUrlLogo + ''" '' +' + sLineBreak +
  '      ''       style="position: absolute; top: 50%; left: 50%; '' +' + sLineBreak +
  '      ''              transform: translate(-50%, -50%); '' +' + sLineBreak +
  '      ''              width: 50px; height: 50px; '' +' + sLineBreak +
  '      ''              border: 4px solid white; background: white; border-radius: 8px;"> '' +' + sLineBreak +
  '      ''</div> '' +' + sLineBreak +
  '      ''<script> '' +' + sLineBreak +
  '      ''  var qrcode = new QRCode(document.getElementById("qrcode"), { '' +' + sLineBreak +
  '      ''    text: "'' + ADados + ''", '' +' + sLineBreak +
  '      ''    width: 256, '' +' + sLineBreak +
  '      ''    height: 256, '' +' + sLineBreak +
  '      ''    colorDark : "#000000", '' +' + sLineBreak +
  '      ''    colorLight : "#ffffff", '' +' + sLineBreak +
  '      ''    correctLevel : QRCode.CorrectLevel.H '' + //CRUCIAL: Nível High' + sLineBreak +
  '      ''  }); '' +' + sLineBreak +
  '      ''</script> ''' + sLineBreak +
  '  else' + sLineBreak +
  '    Result := Result +' + sLineBreak +
  '     ''<div id="qrcode"></div>'' +' + sLineBreak +
  '     ''<script>'' +' + sLineBreak +
  '     ''  new QRCode(document.getElementById("qrcode"), "'' + ADados + ''");'' +' + sLineBreak +
  '     ''</script>'';' + sLineBreak +
  '' + sLineBreak +
  '  Result := Result + ''</body></html>'';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaUtil + 'boleto.pix.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.Boleto_RouteFinanceiro;
var
  s: string;
begin
  s :=
  'unit Route.Financeiro;' + sLineBreak +
  '' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '// Exemplo de uso para Boleto bancário / PIX' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Core.Router;' + sLineBreak +
  '' + sLineBreak +
  'procedure RegisterRoutesFinanceiro_v1(Router: TRouter);' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  sysutils, StrUtils, DateUtils, fpjson, jsonparser,' + sLineBreak +
  '  Core.HttpContext, Core.JWT, Core.HtmlToPdf, Core.Util,' + sLineBreak +
  '  Boleto.Models, Boleto.Pix, Boleto.Layout;' + sLineBreak +
  '' + sLineBreak +
  'function GetDadosExemplo(idcliente, idboleto: Integer): TBoletoDados;' + sLineBreak +
  '// ACodigo: Código para localizar os dados do boleto/cliente/sacado/conta, no banco de dados' + sLineBreak +
  'begin' + sLineBreak +
  '  {' + sLineBreak +
  '    INFORMAÇÕES A SEREM OBTIDAS DO BANCO DE DADOS' + sLineBreak +
  '    EX:' + sLineBreak +
  '    SELECT campos_necessario FROM tabela_cobranca WHERE idcliente = :idcliente and idboleto = :idboleto' + sLineBreak +
  '  }' + sLineBreak +
  '' + sLineBreak +
  '  // DADOS FICTÍCIOS' + sLineBreak +
  '' + sLineBreak +
  '  with Result do begin' + sLineBreak +
  '    { DADOS DA CONTA DO CEDENTE }' + sLineBreak +
  '' + sLineBreak +
  '    Conta.BancoCodigo     := ''237''; // 001, 033, 104, 237, 341, 756' + sLineBreak +
  '    Conta.Agencia         := ''0144'';' + sLineBreak +
  '    Conta.AgenciaDV       := ''9'';' + sLineBreak +
  '    Conta.ContaCorrente   := ''98063'';' + sLineBreak +
  '    Conta.ContaCorrenteDV := ''5'';' + sLineBreak +
  '    Conta.Carteira        := ''09'';' + sLineBreak +
  '    Conta.CodigoCedente   := ''478394''; // Código do beneficiário junto ao banco' + sLineBreak +
  '    Conta.Convenio        := '''';       // Número do convênio, se houver' + sLineBreak +
  '' + sLineBreak +
  '    { DADOS DO CEDENTE}' + sLineBreak +
  '' + sLineBreak +
  '    Cedente.Nome       := ''Empresa Modelo Ltda'';' + sLineBreak +
  '    Cedente.CNPJCPF    := ''10.101.904/0001-73'';' + sLineBreak +
  '    Cedente.Endereco   := ''Rua Empresarial, 100'';' + sLineBreak +
  '    Cedente.Bairro     := ''Centro'';' + sLineBreak +
  '    Cedente.Cidade     := ''Barretos'';' + sLineBreak +
  '    Cedente.UF         := ''SP'';' + sLineBreak +
  '    Cedente.CEP        := ''14790-123'';' + sLineBreak +
  '    Cedente.Email      := ''contato@modelo.com.br'';' + sLineBreak +
  '    Cedente.ChavePix   := ''pix@modelo.com.br'';' + sLineBreak +
  '    Cedente.Telefone   := ''0800 123 4567'';' + sLineBreak +
  '    Cedente.WhatsApp   := ''(17) 1234-5678'';' + sLineBreak +
  '    Cedente.Www        := ''https://www.empresa.com.br'';' + sLineBreak +
  '    Cedente.CentralAtendimento := ''https://central.empresa.com.br'';' + sLineBreak +
  '' + sLineBreak +
  '    { DADOS DO SACADO }' + sLineBreak +
  '' + sLineBreak +
  '    Sacado.Nome     := ''Jose da Silva Virtual'';' + sLineBreak +
  '    Sacado.CNPJCPF  := ''123.234.456-78'';' + sLineBreak +
  '    Sacado.Endereco := ''Rua Esmeralda, 275'';' + sLineBreak +
  '    Sacado.Bairro   := ''Esperança'';' + sLineBreak +
  '    Sacado.Cidade   := ''Barretos'';' + sLineBreak +
  '    Sacado.UF       := ''SP'';' + sLineBreak +
  '    Sacado.CEP      := ''14783-145'';' + sLineBreak +
  '' + sLineBreak +
  '    { DADOS DO TÍTULO }' + sLineBreak +
  '' + sLineBreak +
  '    Titulo.NossoNumero       := ''93849348'';  // Informado pelo banco ou gerado pelo seu sistema' + sLineBreak +
  '    Titulo.NumeroDocumento   := ''45679'';     // Seu controle interno (Ex: número da nota)' + sLineBreak +
  '    Titulo.DataDocumento     := Now;' + sLineBreak +
  '    Titulo.DataProcessamento := Now + 2;' + sLineBreak +
  '    Titulo.DataVencimento    := Now + 15;' + sLineBreak +
  '    Titulo.Valor             := 90.90; // valor final' + sLineBreak +
  '    Titulo.Demonstrativo[0]  := ''Desmonstrativo 1''; // até 3 linhas (0..2)' + sLineBreak +
  '    Titulo.Demonstrativo[1]  := ''Desmonstrativo 2'';' + sLineBreak +
  '    Titulo.Demonstrativo[2]  := ''Desmonstrativo 3'';' + sLineBreak +
  '    Titulo.Instrucoes[0]     := ''APÓS O VENCIMENTO COBRAR 2% DE MULTA MAIS 1% DE MORA AO MÊS''; // Até 7 linhas de instrução (0..6)' + sLineBreak +
  '    Titulo.Instrucoes[1]     := ''ESTE BOLETO NÃO QUITA DÉBITOS ANTERIORES'';' + sLineBreak +
  '    Titulo.Instrucoes[2]     := ''SERVIÇO - Maio/2026'';' + sLineBreak +
  '    Titulo.Instrucoes[3]     := ''Outras informações'';' + sLineBreak +
  '    Titulo.Instrucoes[4]     := ''Instrução 5'';' + sLineBreak +
  '    Titulo.Instrucoes[5]     := ''Instrução 6'';' + sLineBreak +
  '    Titulo.Instrucoes[6]     := ''Instrução 7'';' + sLineBreak +
  '    Titulo.Aceite            := ''N'';      // ''N'' ou ''S''' + sLineBreak +
  '    Titulo.EspecieDocumento  := ''DM'';     // ''DM'' (Duplicata Mercantil), etc.' + sLineBreak +
  '    Titulo.MoedaTipo         := ''9'';      // ''9'' = Real' + sLineBreak +
  '    Titulo.EspecieValor      := ''R$'';' + sLineBreak +
  '    Titulo.IdentificadoPix   := Titulo.NumeroDocumento ; // seu código para identificar o pagamento' + sLineBreak +
  '                                                         // via pix no retorno da api do seu banco' + sLineBreak +
  '    { FATURA }' + sLineBreak +
  '' + sLineBreak +
  '    Fatura.Descricao[0] := ''SERVIÇO - COMBO - Maio/2026''; { SERVIÇO PRINCIPAL }' + sLineBreak +
  '    Fatura.Valor[0]     := 99.90;           { VALOR CHEIO DO SERVIÇO PRINCIPAL}' + sLineBreak +
  '    Fatura.Descricao[1] := ''DESCONTO PROMOCIONAL'';' + sLineBreak +
  '    Fatura.Valor[1]     := 9.00;' + sLineBreak +
  '    Fatura.Descricao[2] := ''ATENDIMENTO PRIME'';' + sLineBreak +
  '    Fatura.Valor[2]     := 0.00;' + sLineBreak +
  '    Fatura.Descricao[3] := ''CLUBE DO LIVRO'';' + sLineBreak +
  '    Fatura.Valor[3]     := 0.00;' + sLineBreak +
  '    Fatura.Descricao[4] := '''';' + sLineBreak +
  '    Fatura.Valor[4]     := 0.00;' + sLineBreak +
  '    Fatura.Descricao[5] := '''';' + sLineBreak +
  '    Fatura.Valor[5]     := 0.00;' + sLineBreak +
  '    Fatura.Descricao[6] := '''';' + sLineBreak +
  '    Fatura.Valor[6]     := 0.00;' + sLineBreak +
  '    Fatura.MensagemAdicional := ''Mensagem adicional...'';' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure RouterFinanceiro_v1_GetBoleto(ctx:THttpContext);' + sLineBreak +
  'var' + sLineBreak +
  '  lHtml: string;' + sLineBreak +
  '  idcliente, idboleto: Integer;' + sLineBreak +
  '  lPdf: Boolean;' + sLineBreak +
  'begin' + sLineBreak +
  '  idcliente := ctx.QueryInt(''idcliente'');' + sLineBreak +
  '  idboleto := ctx.QueryInt(''idboleto'');' + sLineBreak +
  '  lPdf := (ctx.Query(''modelo'').ToLower = ''pdf'');' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    lHtml := TBoletoLayout.new.GetBoleto( GetDadosExemplo(idcliente, idboleto), True, False, lPdf );' + sLineBreak +
  '' + sLineBreak +
  '    if lPdf then' + sLineBreak +
  '      ctx.SendPDF(THtmlToPdf.new.HtmlToPdfStream(lHtml), ''boleto.pdf'')' + sLineBreak +
  '    else' + sLineBreak +
  '      ctx.SendHTML(lHtml);' + sLineBreak +
  '  except' + sLineBreak +
  '    ctx.Code(500).SendTEXT(''Internal server error'');' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  lHtml := '''';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure RouterFinanceiro_v1_GetFatura(ctx:THttpContext);' + sLineBreak +
  'var' + sLineBreak +
  '  lHtml: string;' + sLineBreak +
  '  idcliente, idboleto: Integer;' + sLineBreak +
  '  lPdf: Boolean;' + sLineBreak +
  'begin' + sLineBreak +
  '  idcliente := ctx.QueryInt(''idcliente'');' + sLineBreak +
  '  idboleto := ctx.QueryInt(''idboleto'');' + sLineBreak +
  '  lPdf := (ctx.Query(''modelo'').ToLower = ''pdf'');' + sLineBreak +
  '' + sLineBreak +
  '  // busque as informações no DB' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    lHtml := TBoletoLayout.new.GetFatura( GetDadosExemplo(idcliente, idboleto), True, lPdf, True);' + sLineBreak +
  '' + sLineBreak +
  '    if lPdf then' + sLineBreak +
  '      ctx.SendPDF(THtmlToPdf.new.HtmlToPdfStream(lHtml), ''fatura.pdf'')' + sLineBreak +
  '    else' + sLineBreak +
  '      ctx.SendHTML(lHtml);' + sLineBreak +
  '  except' + sLineBreak +
  '    ctx.Code(500).SendTEXT(''Internal server error'');' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  lHtml := '''';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure RouterFinanceiro_v1_GetPix(ctx:THttpContext);' + sLineBreak +
  'var' + sLineBreak +
  '  lHtml: string;' + sLineBreak +
  '  idcliente, idboleto: Integer;' + sLineBreak +
  '  lPdf: Boolean;' + sLineBreak +
  'begin' + sLineBreak +
  '  idcliente := ctx.QueryInt(''idcliente'');' + sLineBreak +
  '  idboleto := ctx.QueryInt(''idboleto'');' + sLineBreak +
  '  lPdf := (ctx.Query(''modelo'').ToLower = ''pdf'');' + sLineBreak +
  '' + sLineBreak +
  '  // busque as informações no DB' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    lHtml := TBoletoPix.new.GetPix( GetDadosExemplo(idcliente, idboleto), True, lPdf );' + sLineBreak +
  '' + sLineBreak +
  '    if lPdf then' + sLineBreak +
  '      ctx.SendPDF(THtmlToPdf.new.HtmlToPdfStream(lHtml), ''pix.pdf'')' + sLineBreak +
  '    else' + sLineBreak +
  '      ctx.SendHTML(lHtml);' + sLineBreak +
  '  except' + sLineBreak +
  '    ctx.Code(500).SendTEXT(''Internal server error'');' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  lHtml := '''';' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'procedure RegisterRoutesFinanceiro_v1(Router: TRouter);' + sLineBreak +
  'begin' + sLineBreak +
  '  Router.Get(''/api/v1/boleto/{idcliente}/{idboleto}/{modelo}'', @RouterFinanceiro_v1_GetBoleto, False);' + sLineBreak +
  '  Router.Get(''/api/v1/fatura/{idcliente}/{idboleto}/{modelo}'', @RouterFinanceiro_v1_GetFatura, False);' + sLineBreak +
  '  Router.Get(''/api/v1/pix/{idcliente}/{idboleto}/{modelo}'', @RouterFinanceiro_v1_GetPix, False);' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaRoutes + 'route.financeiro.pas', s);
  s := '';
end;

procedure TProjetoLazarusAPI.GerarReDoc;
// documentação REDOC
var
  s, sHostVersao: string;
begin
  sHostVersao := Projeto.ApiHost + ':' + Projeto.ApiPorta + '/' + FVersaoAbreviada; // http://localhost:8283/v1
  s :=
  '<!DOCTYPE html>' + sLineBreak +
  '<html>' + sLineBreak +
  '<head>' + sLineBreak +
  '  <meta charset="UTF-8">' + sLineBreak +
  '  <title> REDOC - ' + Projeto.ApiTitulo + '</title>     ' + sLineBreak +
  '  <style>' + sLineBreak +
  '    .container-one {  ' + sLineBreak +
  '      width: 70px;  ' + sLineBreak +
  '      height: 90%;  ' + sLineBreak +
  '      float: left;  ' + sLineBreak +
  '      align-content: center;  ' + sLineBreak +
  '      border-radius: 5px;  ' + sLineBreak +
  '      font-size: 14px;  ' + sLineBreak +
  '      text-align: center;  ' + sLineBreak +
  '      color: #fff;  ' + sLineBreak +
  '    }' + sLineBreak +
  '    .container-two {  ' + sLineBreak +
  '      margin-left: 90px;              ' + sLineBreak +
  '      height: 90%;  ' + sLineBreak +
  '      align-content: center;  ' + sLineBreak +
  '    }' + sLineBreak +
  '    .mb-4 {' + sLineBreak +
  '      margin-bottom:1.1rem!important' + sLineBreak +
  '    }' + sLineBreak +
  '    header {  ' + sLineBreak +
  '      height: 140px; ' + sLineBreak +
  '      margin-top: 5px;  ' + sLineBreak +
  '      padding: 10px;  ' + sLineBreak +
  '      background-color: #343a40;  ' + sLineBreak +
  '      color: white;  ' + sLineBreak +
  '      text-align: center;  ' + sLineBreak +
  '      border-radius: 5px;  ' + sLineBreak +
  '    }  ' + sLineBreak +
  '    header h1 {  ' + sLineBreak +
  '      text-decoration: none;  ' + sLineBreak +
  '      color: white;  ' + sLineBreak +
  '    }  ' + sLineBreak +
  '    footer {  ' + sLineBreak +
  '      margin-top: 50px;  ' + sLineBreak +
  '      padding: 10px;  ' + sLineBreak +
  '      background-color: #343a40;  ' + sLineBreak +
  '      color: white;  ' + sLineBreak +
  '      text-align: center;  ' + sLineBreak +
  '      border-radius: 5px;  ' + sLineBreak +
  '    }    ' + sLineBreak +
  '    footer a {  ' + sLineBreak +
  '      color: #fff;  ' + sLineBreak +
  '      text-decoration: none;  ' + sLineBreak +
  '    }  ' + sLineBreak +
  '    footer a:hover {  ' + sLineBreak +
  '      text-decoration: underline;  ' + sLineBreak +
  '    } ' + sLineBreak +
  '    .spinner-overlay {' + sLineBreak +
  '      position: fixed;' + sLineBreak +
  '      top: 0;' + sLineBreak +
  '      left: 0;' + sLineBreak +
  '      width: 100%;' + sLineBreak +
  '      height: 100%;' + sLineBreak +
  '      background: rgba(255,255,255,0.7);' + sLineBreak +
  '      display: flex;' + sLineBreak +
  '      justify-content: center;' + sLineBreak +
  '      align-items: center;' + sLineBreak +
  '      z-index: 9999;' + sLineBreak +
  '    }' + sLineBreak +
  '    .spinner {' + sLineBreak +
  '      border: 8px solid #e1e1e1;       /* cor do fundo */' + sLineBreak +
  '      border-top: 8px solid #62e1b2;   /* cor laranja (ativa) */' + sLineBreak +
  '      border-radius: 50%;' + sLineBreak +
  '      width: 160px;' + sLineBreak +
  '      height: 160px;' + sLineBreak +
  '      animation: spin 1s linear infinite;' + sLineBreak +
  '    }' + sLineBreak +
  '    @keyframes spin {' + sLineBreak +
  '      0%   { transform: rotate(0deg); }' + sLineBreak +
  '      100% { transform: rotate(360deg); }' + sLineBreak +
  '    }' + sLineBreak +
  '  </style>' + sLineBreak +
  '</head>' + sLineBreak +
  '<body>' + sLineBreak +
  ' <div id="loadingSpinner" class="spinner-overlay">' + sLineBreak +
  '   <div class="spinner"></div>' + sLineBreak +
  ' </div>' + sLineBreak +
  ' <header class="mb-4"> ' + sLineBreak +
  '    <div class="container-one" style="height:140px; vertical-align:middle;"> ' + sLineBreak +
  '      <img src="/images/apidoc.png" width="128" height="128" border="0" alt="Logo">' + sLineBreak +
  '    </div>' + sLineBreak +
  '    <div class="container-two">' + sLineBreak +
  '      <h1>' + Projeto.ApiHeader1 + ' - REDOC</h1> ' + sLineBreak +
  '      <p>' + Projeto.ApiHeader2 + '</p> ' + sLineBreak +
  '      <p>' + Projeto.ApiHeader3 + '</p> ' + sLineBreak +
  '    </div>' + sLineBreak +
  ' </header>  ' + sLineBreak +
  ' <section>' + sLineBreak +
  '   <div id="redoc-container"></div>' + sLineBreak +
  ' </section> ' + sLineBreak +
  ' <footer> ' + sLineBreak +
  '   <p>' + Projeto.ApiFooter1 + '</p> ' + sLineBreak +
  '   <p>' + Projeto.ApiFooter2 + '</p> ' + sLineBreak +
  '   <font style="font-size:10px;">Criado via TOPAZZIO - ' + FormatDateTime('dd/mm/yyyy hh:nn:ss', now) + '</font>' + sLineBreak +
  ' </footer>' + sLineBreak +
  ' ' + sLineBreak +
  ' <script src="https://cdn.redoc.ly/redoc/latest/bundles/redoc.standalone.js"> </script>' + sLineBreak +
  ' <script>' + sLineBreak +
  '  Redoc.init(' + sLineBreak +
  '      ''' + sHostVersao + '/swagger/swagger.json'',' + sLineBreak +
  '      {' + sLineBreak +
  '          requiredPropsFirst: true,' + sLineBreak +
  '          theme: {' + sLineBreak +
  '              sidebar: {' + sLineBreak +
  '                  backgroundColor: ''lightblue''' + sLineBreak +
  '              }' + sLineBreak +
  '          }' + sLineBreak +
  '      },' + sLineBreak +
  '      document.getElementById(''redoc-container''),' + sLineBreak +
  '      function() {' + sLineBreak +
  '          document.getElementById(''loadingSpinner'').style.display = ''none'';' + sLineBreak +
  '      }' + sLineBreak +
  '  );' + sLineBreak +
  ' </script>' + sLineBreak +
  '</body>' + sLineBreak +
  '</html>' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(FPastaDocumentacaoSwagger + PathDelim + 'redoc.html', s);
  s := '';
end;

procedure TProjetoLazarusAPI.CriarScriptTabelaAuditagem(AProtocolo: string);
// script tabela de auditagem
var
  s: string;
begin
  if AProtocolo = '' then Exit;

  s := 'CREATE TABLE tpzapi_audit (' + sLineBreak;

  if AProtocolo.Contains('oracle') then
    s := s + ' idlog           NUMBER(10) GENERATED ALWAYS AS IDENTITY,' + sLineBreak;

  if AProtocolo.Contains('mssql') then
    s := s + ' idlog           BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,' + sLineBreak;

  if AProtocolo.Contains('postgresql') then
    s := s + ' idlog           BIGSERIAL PRIMARY KEY,' + sLineBreak;

  if AProtocolo.Contains('mysql') then
    s := s + ' idlog           BIGINT AUTO_INCREMENT PRIMARY KEY,' + sLineBreak;

  if AProtocolo.Contains('mariadb') then
    s := s + ' idlog           BIGINT AUTO_INCREMENT PRIMARY KEY,' + sLineBreak;

  if AProtocolo.Contains('firebird') then
    s := s + ' idlog           INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,' + sLineBreak;

  if AProtocolo.Contains('sqlite') then
    s := s + ' idlog           INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,' + sLineBreak;

  s := s +
    ' date_occurrency DATETIME,' + sLineBreak +
    ' user_id         INTEGER,' + sLineBreak +
    ' user_name       VARCHAR(100),' + sLineBreak +
    ' user_login      VARCHAR(50),' + sLineBreak +
    ' method          VARCHAR(10),' + sLineBreak +  // GET, POST, PUT, DELETE
    ' route           VARCHAR(255),' + sLineBreak + // /api/products/10
    ' table_name      VARCHAR(100),' + sLineBreak + // products
    ' record_id       INTEGER,' + sLineBreak +      // 10
    ' ip_address      VARCHAR(45),' + sLineBreak +  //IPv4/IPv6
    ' user_agent      VARCHAR(500),' + sLineBreak +
    ' message         VARCHAR(100),' + sLineBreak +
    ' success         INTEGER,' + sLineBreak +
    ' request_body    TEXT';

 if AProtocolo.Contains('oracle') then
    s := s + ', ' + sLineBreak +' PRIMARY KEY ("idlog")';

  s := s +
    sLineBreak + '); ' + sLineBreak + sLineBreak +
    'create index idx_apiaudit on tpzapi_audit (idlog, date_occurrency, table_name); ';

  TUtilCommon.SalvarArquivo('tpzapi_audit.sql', s);
  s := '';
end;

end.

