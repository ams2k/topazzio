unit Util.SwaggerGen;

// Gera arquivo swagger.json com as rotas da API
//
// https://learn.openapis.org/examples/v3.0/link-example.html

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Contnrs, fpjson, jsonparser;

type

  { TSwaggerSchemaProperty }

  TSwaggerSchemaProperty = class
  public
    Name: String;
    DataType: String;
    Format: String;
    Required: Boolean;
    DefaultValue: String;
    ExampleValue: String;
    Description: String;
    RefSchema: String;
    IsArray: Boolean;
    ArrayRefSchema: String;
  end;

  { TSwaggerSchema }

  TSwaggerSchema = class
  private
    FProperties: TObjectList;
    FRequired: TStringList;
  public
    Name: String;

    constructor Create;
    destructor Destroy; override;

    property GetProperties: TObjectList read FProperties;

    procedure AddProperty(const AName, AType: String; const AFormat: String = '';
      ARequired: Boolean = False; const ADefault: String = '';
      const AExample: String = ''; const ADescription: String = '');
    procedure AddRef(const AName, ARefSchema: String; ARequired: Boolean = False);
    procedure AddArrayRef(const AName, ARefSchema: String; ARequired: Boolean = False);
    function ToJSON: TJSONObject;
  end;

  { TSwaggerParameter }

  TSwaggerParameter = class
  public
    Name: String;
    InType: String;
    DataType: String;
    Format: String;
    Required: Boolean;
    Description: String;
    DefaultValue: String;
    ExampleValue: String;
  end;

  { TSwaggerResponse }

  TSwaggerResponse = class
  public
    Code: String;
    Description: String;
    SchemaRef: String;
    InlineSchema: String;
  end;

  { TSwaggerRoute }

  TSwaggerRoute = class
  private
    FParameters: TObjectList;
    FResponses: TObjectList;
  public
    Path: String;
    Method: String;
    Summary: String;
    Tag: String;
    RequestSchema: String;
    Secure: Boolean;

    constructor Create;
    destructor Destroy; override;

    property GetParameters: TObjectList read FParameters;
    property GetResponses: TObjectList read FResponses;

    procedure AddParameter(const AName, AInType, ADataType: String; ARequired: Boolean;
      const ADescription: String; const ADefault: String = '';
      const AExample: String = ''; const AFormat: String = '');
    procedure AddResponse(const ACode, ADescription: string;
      const ASchemaRef: String = ''; const AInlineSchema: String = '');

    function ToJSON: TJSONObject;
  end;

  { TSwaggerDocument }

  TSwaggerDocument = class
  private
    FPaths: TObjectList;
    FSchemas: TObjectList;
    function GeneratePostman(ASwagger: TSwaggerDocument): TPostmanCollection;
  public
    Title: String;
    Description: String;
    Version: String;

    constructor Create;
    destructor Destroy; override;

    property GetRoutes: TObjectList read FPaths;
    property GetSchemas: TObjectList read FSchemas;

    procedure AddRoute(ARoute: TSwaggerRoute);
    procedure AddSchema(ASchema: TSwaggerSchema);

    function GenerateJSON: String;
    procedure SaveToFile(const AFileName: String);
  end;

implementation

{ TSwaggerSchema }

constructor TSwaggerSchema.Create;
begin
  FProperties := TObjectList.Create(True);
  FRequired := TStringList.Create;
end;

destructor TSwaggerSchema.Destroy;
begin
  FProperties.Free;
  FRequired.Free;
  inherited Destroy;
end;

procedure TSwaggerSchema.AddProperty(const AName, AType: String;
  const AFormat: String; ARequired: Boolean; const ADefault: String;
  const AExample: String; const ADescription: String);
var
  P: TSwaggerSchemaProperty;
begin
  P := TSwaggerSchemaProperty.Create;
  P.Name := AName;
  P.DataType := AType;
  P.Format := AFormat;
  P.Required := ARequired;
  P.DefaultValue := ADefault;
  P.ExampleValue := AExample;
  P.Description := ADescription;

  FProperties.Add(P);

  if ARequired then
    FRequired.Add(AName);
end;

procedure TSwaggerSchema.AddRef(const AName, ARefSchema: String; ARequired: Boolean);
var
  P: TSwaggerSchemaProperty;
begin
  P := TSwaggerSchemaProperty.Create;

  P.Name := AName;
  P.RefSchema := ARefSchema;
  P.Required := ARequired;

  FProperties.Add(P);

  if ARequired then
    FRequired.Add(AName);
end;

procedure TSwaggerSchema.AddArrayRef(const AName, ARefSchema: String; ARequired: Boolean);
var
  P: TSwaggerSchemaProperty;
begin
  P := TSwaggerSchemaProperty.Create;

  P.Name := AName;
  P.IsArray := True;
  P.ArrayRefSchema := ARefSchema;
  P.Required := ARequired;

  FProperties.Add(P);

  if ARequired then
    FRequired.Add(AName);
end;

function TSwaggerSchema.ToJSON: TJSONObject;
var
  Obj: TJSONObject;
  Props: TJSONObject;
  Arr: TJSONArray;
  I: Integer;
  P: TSwaggerSchemaProperty;
  Item: TJSONObject;
begin
  Obj := TJSONObject.Create;
  Obj.Add('type', 'object');

  Props := TJSONObject.Create;

  for I := 0 to FProperties.Count - 1 do
  begin
    P := TSwaggerSchemaProperty(FProperties[I]);

    Item := TJSONObject.Create;

    if P.RefSchema <> '' then
    begin
      Item.Add('$ref', '#/components/schemas/' + P.RefSchema);
    end
    else
    if P.IsArray then
    begin
      Item.Add('type', 'array');

      Item.Add('items',
          TJSONObject.Create([
           '$ref',
           '#/components/schemas/' + P.ArrayRefSchema
          ])
      );
    end
    else
    begin
      Item.Add('type', P.DataType);

      if P.Format <> '' then
        Item.Add('format', P.Format);

      if P.Description <> '' then
        Item.Add('description', P.Description);

      if P.DefaultValue <> '' then
      begin
        if P.DataType = 'integer' then
          Item.Add('default', StrToIntDef(P.DefaultValue, 0))
        else
        if P.DataType = 'number' then
          Item.Add('default', StrToFloatDef(P.DefaultValue, 0))
        else
        if P.DataType = 'boolean' then
          Item.Add('default', SameText(P.DefaultValue, 'true'))
        else
          Item.Add('default', P.DefaultValue);
      end;

      if P.ExampleValue <> '' then
      begin
        if P.DataType = 'integer' then
          Item.Add('example', StrToIntDef(P.ExampleValue, 0))
        else
        if P.DataType = 'number' then
          Item.Add('example', StrToFloatDef(P.ExampleValue, 0))
        else
        if P.DataType = 'boolean' then
          Item.Add('example', SameText(P.ExampleValue, 'true'))
        else
          Item.Add('example', P.ExampleValue);
      end;
    end;

    Props.Add(P.Name, Item);
  end;

  Obj.Add('properties', Props);

  if FRequired.Count > 0 then
  begin
    Arr := TJSONArray.Create;

    for I := 0 to FRequired.Count - 1 do
      Arr.Add(FRequired[I]);

    Obj.Add('required', Arr);
  end;

  Result := Obj;
end;

{ TSwaggerRoute }

constructor TSwaggerRoute.Create;
begin
  FParameters := TObjectList.Create(True);
  FResponses := TObjectList.Create(True);
end;

destructor TSwaggerRoute.Destroy;
begin
  FParameters.Free;
  FResponses.Free;
  inherited Destroy;
end;

procedure TSwaggerRoute.AddParameter(const AName, AInType, ADataType: String;
  ARequired: Boolean; const ADescription: String; const ADefault: String;
  const AExample: String; const AFormat: String);
var
  P: TSwaggerParameter;
begin
  P := TSwaggerParameter.Create;
  P.Name := AName;
  P.InType := AInType;
  P.DataType := ADataType;
  P.Required := ARequired;
  P.Description := ADescription;
  P.DefaultValue := ADefault;
  P.ExampleValue := AExample;
  P.Format := AFormat;

  FParameters.Add(P);
end;

procedure TSwaggerRoute.AddResponse(const ACode, ADescription: string;
  const ASchemaRef: String; const AInlineSchema: String);
var
  R: TSwaggerResponse;
begin
  R := TSwaggerResponse.Create;
  R.Code := ACode;
  R.Description := ADescription;
  R.SchemaRef := ASchemaRef; // referência a um objeto, ex: ("$ref": "#/components/links/UserRepositories")
  R.InlineSchema := AInlineSchema; // para um objeto json

  FResponses.Add(R);
end;

function TSwaggerRoute.ToJSON: TJSONObject;
var
  SchemaObj: TJSONObject;
  Obj: TJSONObject;
  Params: TJSONArray;
  Responses: TJSONObject;
  Security: TJSONArray;

  I: Integer;

  P: TSwaggerParameter;
  R: TSwaggerResponse;

  PObj: TJSONObject;
  RespObj: TJSONObject;
  ContentObj: TJSONObject;
  AppJson: TJSONObject;
begin
  Obj := TJSONObject.Create;

  Obj.Add('summary', Summary);
  Obj.Add('tags', TJSONArray.Create([Tag]));

  if Secure then
  begin
    Security := TJSONArray.Create;
    Security.Add(
      TJSONObject.Create([
        'BearerAuth',
        TJSONArray.Create
      ])
    );

    Obj.Add('security', Security);
  end;

  if FParameters.Count > 0 then
  begin
    Params := TJSONArray.Create;

    for I := 0 to FParameters.Count - 1 do
    begin
      P := TSwaggerParameter(FParameters[I]);

      PObj := TJSONObject.Create;
      PObj.Add('name', P.Name);
      PObj.Add('in', P.InType);
      PObj.Add('required', P.Required);
      PObj.Add('description', P.Description);

      SchemaObj := TJSONObject.Create;

      SchemaObj.Add('type', P.DataType);

      if P.Format <> '' then
        SchemaObj.Add('format', P.Format);

      if P.DefaultValue <> '' then
      begin
        if P.DataType = 'integer' then
          SchemaObj.Add('default', StrToIntDef('0' +P.DefaultValue, 0))
        else
        if P.DataType = 'number' then
          SchemaObj.Add('default', StrToFloatDef('0' + P.DefaultValue, 0))
        else
        if P.DataType = 'boolean' then
          SchemaObj.Add('default', SameText(P.DefaultValue, 'true'))
        else
          SchemaObj.Add('default', P.DefaultValue);
      end;

      if P.ExampleValue <> '' then
      begin
        if P.DataType = 'integer' then
          SchemaObj.Add('example', StrToIntDef('0' +P.ExampleValue, 0))
        else
        if P.DataType = 'number' then
          SchemaObj.Add('example', StrToFloatDef('0' +P.ExampleValue, 0))
        else
        if P.DataType = 'boolean' then
          SchemaObj.Add('example', SameText(P.ExampleValue, 'true'))
        else
          SchemaObj.Add('example', P.ExampleValue);
      end;

      PObj.Add('schema', SchemaObj);

      Params.Add(PObj);
    end;

    Obj.Add('parameters', Params);
  end;

  if RequestSchema <> '' then
  begin
    Obj.Add(
      'requestBody',
      TJSONObject.Create([
        'required', True,
        'content',
        TJSONObject.Create([
          'application/json',
          TJSONObject.Create([
            'schema',
            TJSONObject.Create([
              '$ref',
              '#/components/schemas/' + RequestSchema
            ])
          ])
        ])
      ])
    );
  end;

  Responses := TJSONObject.Create;

  for I := 0 to FResponses.Count - 1 do
  begin
    R := TSwaggerResponse(FResponses[I]);

    RespObj := TJSONObject.Create;
    RespObj.Add('description', R.Description);

    if (R.SchemaRef <> '') or (R.InlineSchema <> '') then
    begin
      ContentObj := TJSONObject.Create;

      if R.SchemaRef <> '' then
      begin
        AppJson := TJSONObject.Create([
          'schema',
          TJSONObject.Create([
            '$ref',
            '#/components/schemas/' + R.SchemaRef
          ])
        ]);
      end
      else
      begin
        AppJson := TJSONObject.Create([
          'schema',
          GetJSON(R.InlineSchema)
        ]);
      end;

      ContentObj.Add('application/json', AppJson);

      RespObj.Add('content', ContentObj);
    end;

    Responses.Add(R.Code, RespObj);
  end;

  Obj.Add('responses', Responses);

  Result := Obj;
end;

{ TSwaggerDocument }

constructor TSwaggerDocument.Create;
begin
  FPaths := TObjectList.Create(True);
  FSchemas := TObjectList.Create(True);
end;

destructor TSwaggerDocument.Destroy;
begin
  FPaths.Free;
  FSchemas.Free;
  inherited Destroy;
end;

procedure TSwaggerDocument.AddRoute(ARoute: TSwaggerRoute);
begin
  FPaths.Add(ARoute);
end;

procedure TSwaggerDocument.AddSchema(ASchema: TSwaggerSchema);
begin
  FSchemas.Add(ASchema);
end;

function TSwaggerDocument.GenerateJSON: String;
var
  Root: TJSONObject;
  Info: TJSONObject;
  PathsObj: TJSONObject;
  ComponentsObj: TJSONObject;
  SchemasObj: TJSONObject;

  RouteObj: TJSONObject;

  I: Integer;

  Route: TSwaggerRoute;
  Schema: TSwaggerSchema;
begin
  Root := TJSONObject.Create;

  try

    Root.Add('openapi', '3.0.0');

    Info := TJSONObject.Create;
    Info.Add('title', Title);
    Info.Add('description', Description);
    Info.Add('version', Version);

    Root.Add('info', Info);

    PathsObj := TJSONObject.Create;

    for I := 0 to FPaths.Count - 1 do
    begin
      Route := TSwaggerRoute(FPaths[I]);

      if PathsObj.Find(Route.Path) = nil then
        PathsObj.Add(Route.Path, TJSONObject.Create);

      RouteObj := TJSONObject(PathsObj.Objects[Route.Path]);

      RouteObj.Add(LowerCase(Route.Method), Route.ToJSON);
    end;

    // rotas
    Root.Add('paths', PathsObj);

    // modo de autenticação das rotas
    ComponentsObj := TJSONObject.Create;

    ComponentsObj.Add(
      'securitySchemes',
      TJSONObject.Create([
        'BearerAuth',
        TJSONObject.Create([
          'type', 'http',
          'scheme', 'bearer',
          'bearerFormat', 'JWT',
          'description', 'Insira o token JWT gerado na rota /auth para acessar este recurso.'
        ])
      ])
    );

    // adiciona schemas
    SchemasObj := TJSONObject.Create;

    for I := 0 to FSchemas.Count - 1 do
    begin
      Schema := TSwaggerSchema(FSchemas[I]);
      SchemasObj.Add(
        Schema.Name,
        Schema.ToJSON
      );
    end;

    ComponentsObj.Add('schemas', SchemasObj);

    Root.Add('components', ComponentsObj);

    Result := Root.FormatJSON;

  finally
    Root.Free;
  end;
end;

procedure TSwaggerDocument.SaveToFile(const AFileName: String);
var
  SL: TStringList;
begin
  SL := TStringList.Create;

  try
    SL.Text := GenerateJSON;
    SL.SaveToFile(AFileName);
  finally
    SL.Free;
  end;
end;

end.

