unit Util.AbrirPastaProjeto;

// abre a pasta do projeto, no gerenciador de arquivos do OS

{$mode ObjFPC}{$H+}

interface

uses
  Classes, Dialogs,
  {$IFDEF WINDOWS}
  ShellApi, windows,
  {$ENDIF}
  {$IFDEF UNIX}
  Unix,
  {$ENDIF}
  SysUtils;

type

  { TUtilPastaProjeto }

  TUtilPastaProjeto = class

    public
      class procedure AbrirPastaProjeto(const pastaProjeto: string);
  end;

implementation

{ TUtilPastaProjeto }

class procedure TUtilPastaProjeto.AbrirPastaProjeto(const pastaProjeto: string);
begin
  if not DirectoryExists(pastaProjeto) then
  begin
    ShowMessage('O diretório não existe ! ' + sLineBreak + pastaProjeto);
    Exit;
  end;

  {$IFDEF WINDOWS}
  ShellExecute(0, 'open', PChar(pastaProjeto), nil, nil, SW_SHOWNORMAL);
  {$ENDIF}
  {$IFDEF UNIX}
  // No Linux, você pode tentar abrir diretamente ou tentar invocar um comando shell
  // Aqui, estamos usando OpenFile, que geralmente é a melhor opção.
  // Em alguns casos, pode ser necessário executar um comando como 'xdg-open',
  // mas OpenFile costuma ser suficiente para diretórios.
  fpSystem('xdg-open "' + pastaProjeto + '"');
  {$ENDIF}
end;

end.

