unit Util.ProjetoCommon;

// funções comuns para Util.ProjetoLazarus e Util.ProjetoLazarusAPI

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ExtCtrls, Graphics, Controls, LCLIntf, LCLType, TypInfo, Math,
  ZDataset, BGRABitmap, BGRABitmapTypes, FPImage, FPReadPNG, FPWritePNG, FPImgCanv;

type
  TTipoBanco = (POSTGRE, MYSQL, FIREBIRD, SQLITE, SQLSERVER, ORACLE, MARIADB, ACCESS, NONE);

  TIconDir = packed record
    idReserved: Word;
    idType: Word;
    idCount: Word;
  end;

  TIconDirEntry = packed record
    bWidth: Byte;
    bHeight: Byte;
    bColorCount: Byte;
    bReserved: Byte;
    wPlanes: Word;
    wBitCount: Word;
    dwBytesInRes: DWord;
    dwImageOffset: DWord;
  end;

  { TUtilCommon }

  TUtilCommon = class
    public
      class function CapitalizaTexto(AValue: String): String;
      class function InformacoesLegais: String;
      class function LerArquivo(APathFile: String): String;
      class function GetProtocoloSGDB(ATipoBanco: TTipoBanco): string;
      class function RemoveFieldUnderscore(AValue: String): String;
      class function ScriptTableToFields(AScript: string): TStringList;

      class function ImageToHex(AImage: TImage; ASize: Integer): string;
      class function ImageToHexPNG(const AImage: TImage; ASize: Integer): string;
      class procedure SaveAsIcon(const AImage: TImage; ASize: Integer; const AFileName: string);
      class function BitmapToPNGStream(const ABitmap: TBitmap; ASize: Integer): TMemoryStream;
      class function ResizeImagem(const AImage: TImage; AWidth, AHeight: Integer; ABackColor: TColor): TBitmap;
      class function ImageToHexPNG_New(const AImage: TImage; ASize: Integer): string;

      class procedure CriarPasta(APasta: String);
      class procedure SalvarArquivo(APathFilename, AContent: String);

      class procedure GerarDatamodule(AIdProjeto: Integer; AProtocolo, AListaTabelasID, APastaDataModule, AINIFileName: string);
      class procedure GerarDatamoduleMSSQL(APastaDataModule, AINIFileName: string); //exclusivo para sqlserver
  end;

implementation

uses
  Service.Tabela;

{ TUtilCommon }

class function TUtilCommon.CapitalizaTexto(AValue: String): String;
//Transforma a primeira letra em maiúscula
begin
  if AValue.Length > 1 then
     Result := UpperCase(AValue.Substring(0, 1)) + AValue.Substring(1)
  else
    Result := AValue.ToUpper;
end;

class function TUtilCommon.InformacoesLegais: String;
//informações de criação do arquivo
begin
  Result := '{ ' + sLineBreak +
            ' Created by Topazzio at ' + FormatDateTime('yyyy-mm-dd hh:nn:ss', now) + sLineBreak +
            ' Developed by Aldo Márcio Soares  |  ams2kg@gmail.com  |  CopyLeft 2025' + sLineBreak +
            '} ' + sLineBreak + sLineBreak;
end;

class function TUtilCommon.LerArquivo(APathFile: String): String;
//ler dados do arquivo indicado
var
  lArquivo: TextFile;
  sTexto: String;
  i: Integer;
begin
  Result := '';
  i := 0;

  if FileExists(APathFile) then begin

    AssignFile(lArquivo, APathFile);
    Reset(lArquivo);

    try
       while not EOF(lArquivo) do begin
         sTexto := '';
         ReadLn (lArquivo, sTexto);

         if i > 0 then
           Result := Result + sLineBreak;

         Result := Result + sTexto;
         inc(i);
       end;
    finally
       CloseFile(lArquivo);
    end;
  end;
end;

class function TUtilCommon.GetProtocoloSGDB(ATipoBanco: TTipoBanco): string;
//retorno o protocolo do banco de dados
begin
  case TTipoBanco(ATipoBanco) of
    POSTGRE:
      Result := 'postgresql';
    MYSQL:
      Result := 'mysql';
    FIREBIRD:
      Result := 'firebird';
    SQLITE:
      Result := 'sqlite';
    SQLSERVER:
      Result := 'mssql';
    ORACLE:
      Result := 'oracle';
    MARIADB:
      Result := 'mariadb';
  else
    Result := 'sqlite';
  end;
end;

class function TUtilCommon.RemoveFieldUnderscore(AValue: String): String;
//remove o underscore entre as palavras: Ex: id_produto --> IdProduto
var
  s: array of string;
  i: Integer;
begin
  Result := Trim( AValue );

  if AValue.IndexOf('_') > 0 then begin
    s := AValue.Split(['_'], TStringSplitOptions.ExcludeEmpty);
    Result := '';

    for i := 0 to High(s) do
      Result := Result + TUtilCommon.CapitalizaTexto( s[i].Trim() );

    SetLength(s, 0);
  end
  else
    Result := TUtilCommon.CapitalizaTexto( Result );
end;

class function TUtilCommon.ScriptTableToFields(AScript: string): TStringList;
//pega o script de criação de tabelas e retorna as linhas dos campos
// prepara o script no caso de number(8,2) quando usar o Split([','], TStringSplitOptions.ExcludeEmpty)
var
  FArray: array of string;
  i, j, k, count: integer;
  s: string;
begin
  count  := 0;
  i      := 0;
  s      := '';
  Result := TStringList.Create;

  //checa se é um script de criação de tabela
  i := AScript.ToLower.IndexOf('create table ');
  if i < 0 then Exit;

  //adiciona o if not exists
  i := AScript.ToLower.IndexOf('not exists ');
  if i < 0 then
    AScript := AScript.ToLower.Replace('create table ', 'create table if not exists ');

  //evitar de o primeiro campo ficar na linha do create table
  i := AScript.IndexOf('(');
  if i>0 then
    AScript := AScript.Substring(0, i) + '(,' + AScript.Substring(i+1);

  while True do begin
     j := LowerCase(AScript).IndexOf('number', i);
     if j < 0 then Break;

     i := j;
     j := LowerCase(AScript).IndexOf('(', i);

     if j >= 0 then begin
       i := j;
       j := LowerCase(AScript).IndexOf(')', i);

       if j > i then begin
         k := LowerCase(AScript).IndexOf(',', i);

         if (k > 0) and (k < j) then begin
            AScript := AScript.Substring(0, k) + '!' + AScript.Substring(k + 1);
            i := k;
         end;
       end;
     end;

     count := count + 1;
     if count > 10 then Break;
  end;

  // split das colunas
  AScript := AScript.Replace(sLineBreak, '', [rfReplaceAll]);
  FArray  := AScript.Split([','], TStringSplitOptions.ExcludeEmpty);

  for i := 0 to High(FArray) do begin
    s := FArray[i].Trim;
    if s = '' then Continue;
    s := s.Replace('!', ',');
    if (i > 0) and (i < High(FArray)) then s := s + ',';
    Result.Add(s)
  end;

  SetLength(FArray, 0);
end;

class function TUtilCommon.ImageToHexPNG(const AImage: TImage; ASize: Integer): string;
// Retorna: Picture.Data { ... }
// Obtém o código Hexadecimal que representa uma imagem contida no objeto TImage
var
  lImage: TImage;
  BinStream: TMemoryStream;
  TxtStream: TStringStream;
  Png: TPortableNetworkGraphic;
  i: integer;
begin
  if not Assigned(AImage.Picture.Graphic) then
    raise Exception.Create('Invalid image');

  ASize := EnsureRange(ASize, 1, 2048);

  lImage := TImage.Create(nil);
  Png := TPortableNetworkGraphic.Create;
  BinStream := TMemoryStream.Create;
  TxtStream := TStringStream.Create('');

  try
    Png.LoadFromStream( BitmapToPNGStream(AImage.Picture.Bitmap, ASize) );

    //lImage.Picture.LoadFromStream( BitmapToPNGStream(AImage.Picture.Bitmap, ASize) );
    lImage.Picture.Assign( Png );

    // serializa como o Lazarus (.lfm)
    BinStream.WriteComponent(lImage);
    BinStream.Position := 0;

    // ObjectBinaryToText(BinStream, TxtStream);
    ObjectBinaryToText(BitmapToPNGStream(AImage.Picture.Bitmap, ASize), TxtStream);

    Result := TxtStream.DataString;

    i := Pos('Picture.Data', Result);
    if i > 0 then begin
      Result := Copy(Result, i, Length(Result));
      i := Pos('}', Result);
      if i > 0 then begin
        Result := Copy(Result, 1, i);
      end;
    end;

  finally
    TxtStream.Free;
    BinStream.Free;
    lImage.Free;
    Png.Free;
  end;
end;

class function TUtilCommon.ImageToHexPNG_New(const AImage: TImage; ASize: Integer): string;
var
  OrigPic: TPicture;
  NewPic: TPicture;
  BinStream: TMemoryStream;
  TxtStream: TStringStream;
  PNGStream: TMemoryStream;
  i: integer;
begin
  if not Assigned(AImage.Picture.Graphic) then
    raise Exception.Create('Invalid image');

  ASize := EnsureRange(ASize, 1, 1024);

  OrigPic := TPicture.Create;
  NewPic  := TPicture.Create;
  BinStream := TMemoryStream.Create;
  TxtStream := TStringStream.Create('');
  try
    // backup
    OrigPic.Assign(AImage.Picture);

    // gera PNG
    PNGStream := BitmapToPNGStream(AImage.Picture.Bitmap, ASize);
    PNGStream.Position := 0;
    PNGStream.SaveToFile('/home/marcio/picture_data.png');
    try
      NewPic.Clear;
      NewPic.LoadFromStream(PNGStream); // <-- carrega como PNG real
    finally
      PNGStream.Free;
    end;

    // substitui completamente o Picture
    AImage.Picture.Assign(nil);
    AImage.Picture.Assign(NewPic);

    // sanity check (debug opcional)
    if AImage.Picture.Graphic.ClassName <> 'TPortableNetworkGraphic' then
      raise Exception.Create('Imagem não está em PNG');

    // serializa
    BinStream.WriteComponent(AImage);
    BinStream.Position := 0;

    ObjectBinaryToText(BinStream, TxtStream);

    Result := TxtStream.DataString;

    i := Pos('Picture.Data', Result);
    if i > 0 then begin
      Result := Copy(Result, i, Length(Result));
      i := Pos('}', Result);
      if i > 0 then begin
        Result := Copy(Result, 1, i);
      end;
    end;

  finally
    // restaura
    AImage.Picture.Assign(OrigPic);

    TxtStream.Free;
    BinStream.Free;
    NewPic.Free;
    OrigPic.Free;
  end;
end;

class function TUtilCommon.ImageToHex(AImage: TImage; ASize: Integer): string;
// Retorna: Picture.Data { ... }
// Obtém o código Hexadecimal que representa uma imagem contida no objeto TImage
var
  Bmp: TBitmap;
  OrigPic: TPicture;
  BinStream: TMemoryStream;
  TxtStream: TStringStream;
  i: integer;
begin
  if not Assigned(AImage.Picture.Graphic) then
    raise Exception.Create('Invalid image');

  ASize := EnsureRange(ASize, 1, 2048);

  OrigPic := TPicture.Create;
  Bmp := TBitmap.Create;
  BinStream := TMemoryStream.Create;
  TxtStream := TStringStream.Create('');
  try
    // backup da imagem original
    OrigPic.Assign(AImage.Picture);

    // cria bitmap redimensionado
    Bmp.SetSize(ASize, ASize);
    Bmp.Canvas.StretchDraw(Rect(0, 0, ASize, ASize), OrigPic.Graphic);

    // substitui temporariamente
    AImage.Picture.Assign(Bmp);

    // serializa como o Lazarus (.lfm)
    BinStream.WriteComponent(AImage);
    BinStream.Position := 0;

    ObjectBinaryToText(BinStream, TxtStream);

    Result := TxtStream.DataString;

    i := Pos('Picture.Data', Result);
    if i > 0 then begin
      Result := Copy(Result, i, Length(Result));
      i := Pos('}', Result);
      if i > 0 then begin
        Result := Copy(Result, 1, i);
      end;
    end;

  finally
    // restaura imagem original
    AImage.Picture.Assign(OrigPic);

    TxtStream.Free;
    BinStream.Free;
    Bmp.Free;
    OrigPic.Free;
  end;
end;

class procedure TUtilCommon.SaveAsIcon(const AImage: TImage; ASize: Integer; const AFileName: string);
// cria um ícone / favicon.ico
var
  FS: TFileStream;
  IconDir: TIconDir;
  Entry: TIconDirEntry;
  PNGStream: TMemoryStream;
begin
  if not Assigned(AImage.Picture.Graphic) then
    raise Exception.Create('Invalid image');

  // normalização de tamanho
  ASize := EnsureRange(ASize, 16, 256);

  // gera PNG com alta qualidade (BGRABitmap)
  PNGStream := BitmapToPNGStream(AImage.Picture.Bitmap, ASize);

  FS := TFileStream.Create(AFileName, fmCreate);
  try
    // header ICO
    IconDir.idReserved := 0;
    IconDir.idType := 1;
    IconDir.idCount := 1;
    FS.WriteBuffer(IconDir, SizeOf(IconDir));

    // entrada única
    FillChar(Entry, SizeOf(Entry), 0);
    Entry.bWidth  := IfThen(ASize = 256, 0, ASize);
    Entry.bHeight := IfThen(ASize = 256, 0, ASize);
    Entry.wPlanes := 1;
    Entry.wBitCount := 32;
    Entry.dwBytesInRes := PNGStream.Size;
    Entry.dwImageOffset := SizeOf(IconDir) + SizeOf(TIconDirEntry);

    FS.WriteBuffer(Entry, SizeOf(Entry));

    // dados PNG
    FS.CopyFrom(PNGStream, PNGStream.Size);

  finally
    FS.Free;
    PNGStream.Free;
  end;
end;

class function TUtilCommon.BitmapToPNGStream(const ABitmap: TBitmap; ASize: Integer): TMemoryStream;
// redimensiona o bitmap
var
  src, resized: TBGRABitmap;
begin
  Result := TMemoryStream.Create;

  if (ABitmap = nil) or (ABitmap.Width < 1) then
    raise Exception.Create('Invalid image');

  src := TBGRABitmap.Create(ABitmap);
  try
    src.ResampleFilter := rfBestQuality;

    resized := src.Resample(ASize, ASize) as TBGRABitmap;
    try
      resized.SaveToStreamAsPng(Result);
      Result.Position := 0;
    finally
      resized.Free;
    end;

  finally
    src.Free;
  end;
end;

class function TUtilCommon.ResizeImagem(const AImage: TImage; AWidth, AHeight: Integer; ABackColor: TColor): TBitmap;
// redimensiona a imagem
begin
  Result := TBitmap.Create;
  //Result.Canvas.Brush.Color := clWhite;
  //Result.PixelFormat := pf24bit;
  Result.SetSize(AWidth, AHeight);
  Result.Canvas.StretchDraw(Rect(0, 0, AWidth, AHeight), AImage.Picture.Graphic);
end;

class procedure TUtilCommon.CriarPasta(APasta: String);
// cria pastas
begin
  APasta := APasta.Replace(PathDelim + PathDelim, PathDelim);// remove (//) barras duplas

  try
    if not DirectoryExists(APasta) then
      CreateDir(APasta);
  except
  end;
end;

class procedure TUtilCommon.SalvarArquivo(APathFilename, AContent: String);
//salva o arquivo informado
var
  docFile: TextFile;
begin
  // deleta o arquivo, se existir
  if FileExists(APathFilename) then
    DeleteFile(APathFilename);

  // Define o arquivo a ser criado
  AssignFile(docFile, APathFilename);

  // Use isso para permitir capturar exceções. Não precisa usar se não quiser.
  {$I+}

  try
    // Cria ou sobrescreve o arquivo
    Rewrite(docFile);

    // grava o conteúdo do arquivo
    WriteLn(docFile, AContent);

    // fecha o arquivo
    CloseFile(docFile);
  except
    //on E: EInOutError do
    // s := 'Erro no arquivo.' + sLineBreak + APathFilename + sLineBreak + E.ClassName + sLineBreak + E.Message;
  end;
end;

class procedure TUtilCommon.GerarDatamodule(AIdProjeto: Integer; AProtocolo, AListaTabelasID,
  APastaDataModule, AINIFileName: string);
// cria o datamodule
var
  q: TZQuery;
  t: TServiceTabela;
  s, lVersaoNome, lVersaoQuery: string;
  lTabela: TStringList;
  i: integer;
begin
  // CÓDIGO .PAS
  t := TServiceTabela.Create( AIdProjeto );
  q := t.QueryScripts( AListaTabelasID );

  s :=
  'unit DM.Server; ' + sLineBreak +
  ' ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+} ' + sLineBreak +
  ' ' + sLineBreak +
  'interface ' + sLineBreak +
  ' ' + sLineBreak +
  'uses ' + sLineBreak +
  '  Classes, SysUtils, FileUtil, ZConnection, ZDataset, DB, SQLDB, ZDatasetUtils, IniFiles; ' + sLineBreak +
  ' ' + sLineBreak +
  'type ' + sLineBreak +
  ' ' + sLineBreak +
  '  { TDMServer } ' + sLineBreak +
  ' ' + sLineBreak +
  '  TDMServer = class(TDataModule) ' + sLineBreak +
  '    Connection: TZConnection; ' + sLineBreak +
  '    procedure DataModuleCreate(Sender: TObject); ' + sLineBreak +
  '    procedure DataModuleDestroy(Sender: TObject); ' + sLineBreak +
  '  private ' + sLineBreak +
  '    FMsgErro, FVersao: string; ' + sLineBreak +
  '    FPathDLL, FPathBanco, FHost: String; ' + sLineBreak +
  '    FProtocolo, FBanco, FUsername, FSenha, FOdbc: String; ' + sLineBreak +
  '    FPorta: Integer; ' + sLineBreak +
  '    FCriarTabelas: Boolean; ' + sLineBreak;

  if AProtocolo.Contains('sqlite') then
    s := s +
  '    procedure ChecaTabelas; ' + sLineBreak;

  s := s +
  '    procedure LerConfig; ' + sLineBreak +
  '    procedure GetVersao; ' + sLineBreak +
  '  public ' + sLineBreak +
  '    property GetMsgErro: string read FMsgErro; ' + sLineBreak +
  '    property GetVersaoServidor: string read FVersao; ' + sLineBreak +
  '    procedure Conectar; ' + sLineBreak +
  '    procedure Desconectar; ' + sLineBreak +
  '    procedure Reconectar; ' + sLineBreak +
  '    procedure ChecaConexao; ' + sLineBreak +
  '    procedure TransactionPrepare; ' + sLineBreak +
  '    procedure TransactionCommit; ' + sLineBreak +
  '    procedure TransactionRollback; ' + sLineBreak +
  '    function IsConnected: Boolean; ' + sLineBreak +
  '    function LastInsertedID(APrimaryKey, ATable: string): Integer; ' + sLineBreak +
  '    function NewQuery(): TZQuery; ' + sLineBreak +
  '  end; ' + sLineBreak +
  ' ' + sLineBreak +
  'var ' + sLineBreak +
  '  DMServer: TDMServer; ' + sLineBreak +
  ' ' + sLineBreak +
  'implementation ' + sLineBreak +
  ' ' + sLineBreak +
  ' uses ' + sLineBreak +
  '   Util.Criptografia; ' + sLineBreak +
  ' ' + sLineBreak +
  '{$R *.lfm} ' + sLineBreak +
  ' ' + sLineBreak +
  '{ TDMServer } ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.DataModuleCreate(Sender: TObject); ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Conectar; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.DataModuleDestroy(Sender: TObject); ' + sLineBreak +
  '// desconecta do banco de daddos ao destruir este módulo ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Desconectar; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.Conectar; ' + sLineBreak +
  '//estabelece a conexão ' + sLineBreak +
  'begin ' + sLineBreak +
  '  FMsgErro      := ''''; ' + sLineBreak +
  '  FVersao       := ''''; ' + sLineBreak +
  '  LerConfig; ' + sLineBreak +
  '  FPathBanco    := ExtractFileDir( ParamStr(0) ) + PathDelim; ' + sLineBreak +
  '  FPathDLL      := FPathBanco; //windows ' + sLineBreak +
  '  FCriarTabelas := not FileExists( FPathBanco ); ' + sLineBreak +
  ' ' + sLineBreak +
  '  if (FProtocolo.Contains(''sqlite'')) and not (FBanco.Contains(PathDelim)) then ' + sLineBreak +
  '    FBanco := FPathBanco + FBanco; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    with Connection do begin ' + sLineBreak +
  '     HostName   := FHost; ' + sLineBreak +
  '     Protocol   := FProtocolo; ' + sLineBreak;

  if AProtocolo = 'oracle' then
    s := s +
    '     Database   := FHost + '':'' + IntToStr(FPorta) + ''/'' + FBanco; ' + sLineBreak
  else
    s := s +
    '     Database   := FBanco; ' + sLineBreak;

  s := s +
  '     User       := FUsername; ' + sLineBreak +
  '     Password   := FSenha; ' + sLineBreak +
  '     Port       := FPorta; ' + sLineBreak;

  s := s +
  '     AutoCommit := True; ' + sLineBreak +
  ' ' + sLineBreak +
  '     {$IFDEF WINDOWS} ' + sLineBreak +
  '        if Protocol.Contains(''sqlite'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''sqlite3.dll''; ' + sLineBreak +
  '        if Protocol.Contains(''firebird'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''fbclient.dll''; ' + sLineBreak +
  '        if Protocol.Contains(''mariadb'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''libmariadb.dll''; // 32 bits ' + sLineBreak +
  '        if Protocol.Contains(''mysql'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''libmysql.dll'';  // 32 bits ' + sLineBreak +
  '        if Protocol.Contains(''postgresql'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''libpq-15.dll''; ' + sLineBreak +
  '        if Protocol.Contains(''oracle'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''oci.dll''; ' + sLineBreak +
  '        if Protocol.Contains(''mssql'') then ' + sLineBreak +
  '          //driver: libsybdb-5.dll ou ntwdblib.dll ou dblib.dll ou libsybdb.so (linux) ou libsybdb.dylib (macos) ' + sLineBreak +
  '          //Database := ''Provider=SQLOLEDB.1;Persist Security Info=True;Data Source='' + p.HostServidor +'',''+ p.Porta + ''; Initial Catalog='' + p.BancoDados+ ''; User ID='' +  p.Username + '';password='' + p.Senha; ' + sLineBreak +
  '          //Protocol := ''ado''; ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''dblib.dll''; ' + sLineBreak +
  '     {$ENDIF}  ' + sLineBreak +   ' ' + sLineBreak +
  '     Connect; ' + sLineBreak +
  '     GetVersao; ' + sLineBreak +
  '    end; ' + sLineBreak +
  ' ' + sLineBreak;

  if AProtocolo.Contains('sqlite') then
    s := s +
    '    ChecaTabelas; ' + sLineBreak;

  s := s +
  '  except ' + sLineBreak +
  '    on E: Exception do ' + sLineBreak +
  '       FMsgErro := E.Message; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak;

  if AProtocolo.Contains('sqlite') then begin
    s := s +
    'procedure TDMServer.ChecaTabelas; ' + sLineBreak +
    '// Cria as tabelas se não existir ' + sLineBreak +
    'begin ' + sLineBreak +
    '  if not FCriarTabelas then Exit; ' + sLineBreak +
    ' ' + sLineBreak +
    '  ChecaConexao; ' + sLineBreak +
    ' ' + sLineBreak +
    '  try ' + sLineBreak +
    '    // cria as tabelas ' + sLineBreak;

    //adiciona scripts de criação das tabelas
    while not q.EOF do begin
      lTabela := TUtilCommon.ScriptTableToFields( q.FieldByName('script_tabela').AsString );

      if lTabela.Count >0 then begin
        s := s + '    Connection.ExecuteDirect(' + sLineBreak;

        for i := 0 to lTabela.Count -1 do begin
          if (i>0 ) and (i <= (lTabela.Count -1)) then s := s + ' + ' + sLineBreak;
           s := s + '    ' + QuotedStr( lTabela[i] );
        end;

        s := s + sLineBreak + '    ); ' + sLineBreak;
      end;

      lTabela.Free;

      if q.FieldByName('primary_key').AsString <> '' then
        s := s + '    Connection.ExecuteDirect(''CREATE INDEX IF NOT EXISTS idx_' +
                      q.FieldByName('tabela').AsString + ' ON ' + q.FieldByName('tabela').AsString + ' (' +
                      q.FieldByName('primary_key').AsString + '); ''); ' + sLineBreak;

      s := s + ' ' + sLineBreak;

      q.Next
    end;

    s := s +
    '  except ' + sLineBreak +
    '  end; ' + sLineBreak +
    'end; ' + sLineBreak +
    ' ' + sLineBreak;
  end;

  s := s +
  'procedure TDMServer.Desconectar; ' + sLineBreak +
  '// desconecta do banco de dados ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if Connection.Connected then ' + sLineBreak +
  '       Connection.Disconnect; ' + sLineBreak +
  '  except ' + sLineBreak +
  '    on e: Exception do ' + sLineBreak +
  '      FMsgErro := e.Message; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TDMServer.IsConnected: Boolean; ' + sLineBreak +
  '//Está conectado ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Result := Connection.Connected; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.ChecaConexao; ' + sLineBreak +
  '// se a conexão não estiver aberta, então tenta conectar no servidor/banco ' + sLineBreak +
  'begin ' + sLineBreak +
  '   FMsgErro := ''''; ' + sLineBreak +
  ' ' + sLineBreak +
  '   try ' + sLineBreak +
  '     if not Connection.Connected then ' + sLineBreak +
  '       Reconectar; ' + sLineBreak +
  '   except ' + sLineBreak +
  '    on e: Exception do ' + sLineBreak +
  '      FMsgErro := e.Message; ' + sLineBreak +
  '   end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.Reconectar; ' + sLineBreak +
  '//reconectar ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if Connection.Connected then Connection.Disconnect; ' + sLineBreak +
  '    Conectar; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionPrepare; ' + sLineBreak +
  '//inicia o transatction ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Connection.AutoCommit := False; ' + sLineBreak +
  '  if not Connection.InTransaction then ' + sLineBreak +
  '    Connection.StartTransaction; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionCommit; ' + sLineBreak +
  '//comita o transaction ' + sLineBreak +
  'begin ' + sLineBreak +
  '  if Connection.InTransaction then ' + sLineBreak +
  '    Connection.Commit; ' + sLineBreak +
  '  Connection.AutoCommit := True; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionRollback; ' + sLineBreak +
  '//rolback do transaction ' + sLineBreak +
  'begin ' + sLineBreak +
  '  if Connection.InTransaction then ' + sLineBreak +
  '    Connection.Rollback; ' + sLineBreak +
  '  Connection.AutoCommit := True; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TDMServer.NewQuery(): TZQuery; ' + sLineBreak +
  '// retorna a instância de uma nova query ' + sLineBreak +
  'begin ' + sLineBreak +
  '  ChecaConexao; ' + sLineBreak +
  ' ' + sLineBreak +
  '  Result := TZQuery.Create(nil); ' + sLineBreak +
  ' ' + sLineBreak +
  '  if FMsgErro.IsEmpty then begin ' + sLineBreak +
  '    try ' + sLineBreak +
  '      Result.Connection := Connection; ' + sLineBreak +
  '      Result.Close; ' + sLineBreak +
  '      Result.SQL.Clear; ' + sLineBreak +
  '    except ' + sLineBreak +
  '      on e: Exception do ' + sLineBreak +
  '        FMsgErro := e.Message; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.GetVersao; ' + sLineBreak +
  '//obtém a versão do servidor sql ' + sLineBreak +
  'var ' + sLineBreak +
  '  lSql, lNome: string; ' + sLineBreak +
  'begin ' + sLineBreak +
  '  FVersao := ''''; ' + sLineBreak;

  lVersaoQuery := '';
  lVersaoNome  := '';

  if AProtocolo.Contains('sqlite') then begin
    lVersaoQuery := 'SELECT sqlite_version() as versao ';
    lVersaoNome := 'SQLite: ';
  end;
  if AProtocolo.Contains('firebird') then begin
    lVersaoQuery := 'SELECT rdb$get_context(''SYSTEM'', ''ENGINE_VERSION'') AS versao FROM rdb$database ';
    lVersaoNome := 'Firebird: ';
  end;
  if AProtocolo.Contains('mariadb') then begin
    lVersaoQuery := 'select version() as versao ';
    lVersaoNome := 'MariaDB: ';
  end;
  if AProtocolo.Contains('mysql') then begin
    lVersaoQuery := 'select version() as versao ';
    lVersaoNome := 'MySQL: ';
  end;
  if AProtocolo.Contains('postgresql') then begin
    lVersaoQuery := 'select version() as versao ';
  end;
  if AProtocolo.Contains('mssql') then begin
    lVersaoQuery := 'select @@version as versao ';
  end;
  if AProtocolo.Contains('oracle') then begin
    lVersaoQuery := 'SELECT banner as versao FROM v$version ';
  end;

  s := s +
  '  lSql  := ''' + lVersaoQuery + '''; ' + sLineBreak +
  '  lNome := ''' + lVersaoNome  + '''; ' + sLineBreak +
  ' ' + sLineBreak +
  '  if lSql <> '''' then begin ' + sLineBreak +
  '    try ' + sLineBreak +
  '      with NewQuery() do begin ' + sLineBreak +
  '        SQL.Add( lSql ); ' + sLineBreak +
  '        Open; ' + sLineBreak +
  ' ' + sLineBreak +
  '        if RecordCount > 0 then ' + sLineBreak +
  '           FVersao := lNome + FieldByName(''versao'').AsString; ' + sLineBreak +
  ' ' + sLineBreak +
  '        Close; ' + sLineBreak +
  '      end; ' + sLineBreak +
  '    except ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TDMServer.LastInsertedID(APrimaryKey, ATable: string): Integer; ' + sLineBreak +
  '// retorna o último ID inserido, independente da tabela ' + sLineBreak +
  '// sqlite: select last_insert_rowid() as id;' + sLineBreak +
  '// mysql/mariadb: SELECT LAST_INSERT_ID() as id;' + sLineBreak +
  'begin ' + sLineBreak +
  '  Result := 0; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    with NewQuery() do begin ' + sLineBreak;

  case AProtocolo of
    'mysql', 'mariadb':
      s := s + '      SQL.Add(''SELECT LAST_INSERT_ID() as id ''); ' + sLineBreak;
    'sqlite':
      s := s + '      SQL.Add(''select last_insert_rowid() as id ''); ' + sLineBreak;
  else {oracle, postgresql, mssql, firebird}
    s := s + '      SQL.Add(Format(''select max(%s) as id from %s '', [APrimaryKey, ATable])); ' + sLineBreak;
  end;

  s := s +
  '      Open; ' + sLineBreak +
  ' ' + sLineBreak +
  '      if RecordCount > 0 then ' + sLineBreak +
  '         Result := FieldByName(''id'').AsInteger; ' + sLineBreak +
  ' ' + sLineBreak +
  '      Close; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.LerConfig; ' + sLineBreak +
  '//ler configurações do servidor ' + sLineBreak +
  'var ' + sLineBreak +
  '  ArqINI: TIniFile; ' + sLineBreak +
  '  FArquivoINI: String; ' + sLineBreak +
  '  cr: TCriptografa; ' + sLineBreak +
  'begin ' + sLineBreak +
  '  FArquivoINI := ExtractFileDir( ParamStr(0) ) + PathDelim + ''' + AINIFileName + '''; ' + sLineBreak +
  '  ArqINI := TIniFile.Create(FArquivoINI); ' + sLineBreak +
  ' ' + sLineBreak +
  '  FHost      := ''''; ' + sLineBreak +
  '  FPorta     := 0; ' + sLineBreak +
  '  FProtocolo := ''''; ' + sLineBreak +
  '  FBanco     := ''''; ' + sLineBreak +
  '  FUsername  := ''''; ' + sLineBreak +
  '  FSenha     := ''''; ' + sLineBreak +
  '  FOdbc      := ''''; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    FHost      := ArqINI.ReadString(''dbinfo'',''server'', ''''); ' + sLineBreak +
  '    FPorta     := ArqINI.ReadInteger(''dbinfo'',''port'', 0); ' + sLineBreak +
  '    FProtocolo := ArqINI.ReadString(''dbinfo'',''protocol'', ''''); ' + sLineBreak +
  '    FBanco     := ArqINI.ReadString(''dbinfo'',''db'', ''''); ' + sLineBreak +
  '    FUsername  := ArqINI.ReadString(''dbinfo'',''user'', ''''); ' + sLineBreak +
  '    FSenha     := ArqINI.ReadString(''dbinfo'',''password'', ''''); ' + sLineBreak +
  '    FOdbc      := ArqINI.ReadString(''dbinfo'',''odbc'', ''''); ' + sLineBreak +
  ' ' + sLineBreak +
  '    if (ArqINI.ReadString(''dbinfo'',''encrypt'', ''false'') = ''true'') then begin ' + sLineBreak +
  '      cr := TCriptografa.Create(); ' + sLineBreak +
  '      FUsername := cr.Decrypt(FUsername); ' + sLineBreak +
  '      FSenha := cr.Decrypt(FSenha); ' + sLineBreak +
  '      cr.Free; ' + sLineBreak +
  '    end; ' + sLineBreak +
  ' ' + sLineBreak +
  '  finally ' + sLineBreak +
  '    ArqINI.Free; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'end. ' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaDataModule + 'dm.server.pas', s);

  // FORM .LFM
  s :=
  'object DMServer: TDMServer ' + sLineBreak +
  '  OnCreate = DataModuleCreate ' + sLineBreak +
  '  OnDestroy = DataModuleDestroy ' + sLineBreak +
  '  OldCreateOrder = False ' + sLineBreak +
  '  Height = 193 ' + sLineBreak +
  '  HorizontalOffset = 403 ' + sLineBreak +
  '  VerticalOffset = 250 ' + sLineBreak +
  '  Width = 268 ' + sLineBreak +
  '  object Connection: TZConnection ' + sLineBreak +
  '    ControlsCodePage = cCP_UTF8 ' + sLineBreak +
  '    DisableSavepoints = False ' + sLineBreak +
  '    Port = 0 ' + sLineBreak +
  '    Left = 60 ' + sLineBreak +
  '    Top = 36 ' + sLineBreak +
  '  end ' + sLineBreak +
  'end ' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaDataModule + 'dm.server.lfm', s);

  s := '';
  q.Close;
  q.Free;
  t.Free;
end;

class procedure TUtilCommon.GerarDatamoduleMSSQL(APastaDataModule, AINIFileName: string);
//cria o datamodule especifico para o sqlserver
var
  s: string;
begin
  // .PAS
  s :=
  'unit DM.Server;  ' + sLineBreak +
  '  ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+}  ' + sLineBreak +
  '  ' + sLineBreak +
  'interface  ' + sLineBreak +
  '  ' + sLineBreak +
  'uses  ' + sLineBreak +
  '  Classes, SysUtils, FileUtil, DB, SQLDB, MSSQLConn, IniFiles; ' + sLineBreak +
  '  ' + sLineBreak +
  'type  ' + sLineBreak +
  '  ' + sLineBreak +
  '  { TDMServer }  ' + sLineBreak +
  '  ' + sLineBreak +
  '  TDMServer = class(TDataModule) ' + sLineBreak +
  '    Connection: TMSSQLConnection; ' + sLineBreak +
  '    Transaction: TSQLTransaction; ' + sLineBreak +
  '    procedure DataModuleCreate(Sender: TObject);  ' + sLineBreak +
  '    procedure DataModuleDestroy(Sender: TObject);  ' + sLineBreak +
  '  private  ' + sLineBreak +
  '    FMsgErro, FVersao: string;  ' + sLineBreak +
  '    FPathDLL, FPathBanco, FHost: String;  ' + sLineBreak +
  '    FProtocolo, FBanco, FUsername, FSenha, FOdbc: String;  ' + sLineBreak +
  '    FPorta: Integer;  ' + sLineBreak +
  '    FCriarTabelas: Boolean;  ' + sLineBreak +
  '    procedure LerConfig; ' + sLineBreak +
  '    procedure GetVersao; ' + sLineBreak +
  '  public  ' + sLineBreak +
  '    property GetMsgErro: string read FMsgErro;  ' + sLineBreak +
  '    property GetVersaoServidor: string read FVersao; ' + sLineBreak +
  '    procedure Conectar;  ' + sLineBreak +
  '    procedure Desconectar;  ' + sLineBreak +
  '    procedure Reconectar;  ' + sLineBreak +
  '    procedure ChecaConexao;  ' + sLineBreak +
  '    procedure TransactionCommit; ' + sLineBreak +
  '    procedure TransactionCommitRetaining; ' + sLineBreak +
  '    procedure TransactionRollback;  ' + sLineBreak +
  '    function IsConnected: Boolean;  ' + sLineBreak +
  '    function NewQuery(): TSQLQuery; ' + sLineBreak +
  '  end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'var  ' + sLineBreak +
  '  DMServer: TDMServer;  ' + sLineBreak +
  '  ' + sLineBreak +
  'implementation  ' + sLineBreak +
  '  ' + sLineBreak +
  ' uses  ' + sLineBreak +
  '   Util.Criptografia;  ' + sLineBreak +
  '  ' + sLineBreak +
  '{$R *.lfm}  ' + sLineBreak +
  '  ' + sLineBreak +
  '{ TDMServer }  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.DataModuleCreate(Sender: TObject);  ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Connection.Transaction := Transaction; ' + sLineBreak +
  '  Transaction.DataBase   := Connection; ' + sLineBreak +
  '  Conectar;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.DataModuleDestroy(Sender: TObject);  ' + sLineBreak +
  '// desconecta do banco de daddos ao destruir este módulo  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  Desconectar;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.Conectar;  ' + sLineBreak +
  '//estabelece a conexão  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  LerConfig;  ' + sLineBreak +
  '  FPathBanco := ExtractFileDir( ParamStr(0) ) + PathDelim;  ' + sLineBreak +
  '  FPathDLL   := FPathBanco; //windows  ' + sLineBreak +
  '  FMsgErro   := ''''; ' + sLineBreak +
  '  FVersao    := ''''; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    Desconectar; ' + sLineBreak +
  ' ' + sLineBreak +
  '    with Connection do begin  ' + sLineBreak +
  '      HostName     := FHost + '':'' + IntToStr(FPorta); ' + sLineBreak +
  '      DatabaseName := FBanco; ' + sLineBreak +
  '      UserName     := FUsername; ' + sLineBreak +
  '      Password     := FSenha; ' + sLineBreak +
  '  ' + sLineBreak +
  '      {$IFDEF WINDOWS} ' + sLineBreak +
  '      //No windows: dblib.dll, libiconv.dll e msvcr100.dll' + sLineBreak +
  '      //driver: libsybdb-5.dll ou ntwdblib.dll ou dblib.dll ou libsybdb.so (linux) ou libsybdb.dylib (macos) ' + sLineBreak +
  '      //Database := ''Provider=SQLOLEDB.1;Persist Security Info=True;Data Source='' + p.HostServidor +'',''+ p.Porta + ''; Initial Catalog='' + p.BancoDados+ ''; User ID='' +  p.Username + '';password='' + p.Senha; ' + sLineBreak +
  '      //Protocol := ''ado''; ' + sLineBreak +
  '      {$ENDIF} ' + sLineBreak +
  '  ' + sLineBreak +
  '      Connected := True; ' + sLineBreak +
  '      GetVersao; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  except  ' + sLineBreak +
  '    on E: Exception do  ' + sLineBreak +
  '      FMsgErro := E.Message; ' + sLineBreak +
  '  end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.Desconectar;  ' + sLineBreak +
  '// desconecta do banco de dados  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  try  ' + sLineBreak +
  '    if Connection.Connected then  ' + sLineBreak +
  '      Connection.Connected := False; ' + sLineBreak +
  '  except  ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'function TDMServer.IsConnected: Boolean;  ' + sLineBreak +
  '//Está conectado  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  Result := Connection.Connected;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.ChecaConexao;  ' + sLineBreak +
  '// se a conexão não estiver aberta, então tenta conectar no servidor/banco  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '   FMsgErro := '''';  ' + sLineBreak +
  '  ' + sLineBreak +
  '   try  ' + sLineBreak +
  '     if not Connection.Connected then  ' + sLineBreak +
  '       Reconectar;  ' + sLineBreak +
  '   except  ' + sLineBreak +
  '    on e: Exception do  ' + sLineBreak +
  '      FMsgErro := e.Message;  ' + sLineBreak +
  '   end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.Reconectar;  ' + sLineBreak +
  '//reconectar  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  try  ' + sLineBreak +
  '    Desconectar; ' + sLineBreak +
  '    Conectar;  ' + sLineBreak +
  '  except  ' + sLineBreak +
  '  end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionCommit;  ' + sLineBreak +
  '//comita o transaction  ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if not Connection.Transaction.Active then ' + sLineBreak +
  '      Connection.Transaction.Active := True; ' + sLineBreak +
  '    Connection.Transaction.Commit; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionCommitRetaining; ' + sLineBreak +
  '//comita o transaction ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if not Connection.Transaction.Active then ' + sLineBreak +
  '      Connection.Transaction.Active := True; ' + sLineBreak +
  '    Connection.Transaction.CommitRetaining; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.TransactionRollback;  ' + sLineBreak +
  '//rolback do transaction  ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if Connection.Transaction.Active then ' + sLineBreak +
  '      Connection.Transaction.Rollback; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'function TDMServer.NewQuery: TSQLQuery; ' + sLineBreak +
  '// retorna a instância de uma nova query  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  ChecaConexao;  ' + sLineBreak +
  '  ' + sLineBreak +
  '  Result := TSQLQuery.Create(nil); ' + sLineBreak +
  '  ' + sLineBreak +
  '  if FMsgErro.IsEmpty then begin  ' + sLineBreak +
  '    try  ' + sLineBreak +
  '      Result.DataBase := Connection; ' + sLineBreak +
  '      Result.Transaction := Transaction; ' + sLineBreak +
  '      Result.Close;  ' + sLineBreak +
  '      Result.SQL.Clear;  ' + sLineBreak +
  '    except  ' + sLineBreak +
  '      on e: Exception do  ' + sLineBreak +
  '        FMsgErro := e.Message;  ' + sLineBreak +
  '    end;  ' + sLineBreak +
  '  end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.LerConfig;  ' + sLineBreak +
  '//ler configurações do servidor  ' + sLineBreak +
  'var  ' + sLineBreak +
  '  ArqINI: TIniFile;  ' + sLineBreak +
  '  FArquivoINI: String;  ' + sLineBreak +
  '  cr: TCriptografa;  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  FArquivoINI := ExtractFileDir( ParamStr(0) ) + PathDelim + '''+ AINIFileName + ''';  ' + sLineBreak +
  '  ArqINI := TIniFile.Create(FArquivoINI);  ' + sLineBreak +
  '  ' + sLineBreak +
  '  FHost      := '''';  ' + sLineBreak +
  '  FPorta     := 0;  ' + sLineBreak +
  '  FProtocolo := '''';  ' + sLineBreak +
  '  FBanco     := '''';  ' + sLineBreak +
  '  FUsername  := '''';  ' + sLineBreak +
  '  FSenha     := '''';  ' + sLineBreak +
  '  FOdbc      := '''';  ' + sLineBreak +
  '  ' + sLineBreak +
  '  try  ' + sLineBreak +
  '    FHost      := ArqINI.ReadString(''dbinfo'',''server'', '''');  ' + sLineBreak +
  '    FPorta     := ArqINI.ReadInteger(''dbinfo'',''port'', 0);  ' + sLineBreak +
  '    FProtocolo := ArqINI.ReadString(''dbinfo'',''protocol'', '''');  ' + sLineBreak +
  '    FBanco     := ArqINI.ReadString(''dbinfo'',''db'', '''');  ' + sLineBreak +
  '    FUsername  := ArqINI.ReadString(''dbinfo'',''user'', '''');  ' + sLineBreak +
  '    FSenha     := ArqINI.ReadString(''dbinfo'',''password'', '''');  ' + sLineBreak +
  '    FOdbc      := ArqINI.ReadString(''dbinfo'',''odbc'', '''');  ' + sLineBreak +
  '  ' + sLineBreak +
  '    if (ArqINI.ReadString(''dbinfo'',''encrypt'', ''false'') = ''true'') then begin  ' + sLineBreak +
  '      cr := TCriptografa.Create();  ' + sLineBreak +
  '      FUsername := cr.Decrypt(FUsername);  ' + sLineBreak +
  '      FSenha := cr.Decrypt(FSenha);  ' + sLineBreak +
  '      cr.Free;  ' + sLineBreak +
  '    end;  ' + sLineBreak +
  '  ' + sLineBreak +
  '  finally  ' + sLineBreak +
  '    ArqINI.Free;  ' + sLineBreak +
  '  end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.GetVersao; ' + sLineBreak +
  '//obtém a versão do servidor sql ' + sLineBreak +
  'begin ' + sLineBreak +
  '  FVersao := ''''; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    with NewQuery() do begin ' + sLineBreak +
  '      SQL.Add(''select @@version as versao;''); ' + sLineBreak +
  '      Open; ' + sLineBreak +
  ' ' + sLineBreak +
  '      if RecordCount > 0 then ' + sLineBreak +
  '        FVersao := FieldByName(''versao'').AsString; ' + sLineBreak +
  ' ' + sLineBreak +
  '      Close; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  '  ' + sLineBreak +
  'end.  ' + sLineBreak +
  ' ' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaDataModule + 'dm.server.pas', s);
  s := '';

  // FORM .LFM

  s :=
  'object DMServer: TDMServer ' + sLineBreak +
  '  OnCreate = DataModuleCreate ' + sLineBreak +
  '  OnDestroy = DataModuleDestroy ' + sLineBreak +
  '  OldCreateOrder = False ' + sLineBreak +
  '  Height = 193 ' + sLineBreak +
  '  HorizontalOffset = 403 ' + sLineBreak +
  '  VerticalOffset = 250 ' + sLineBreak +
  '  Width = 268 ' + sLineBreak +
  '  object Connection: TMSSQLConnection ' + sLineBreak +
  '    Connected = False ' + sLineBreak +
  '    LoginPrompt = False ' + sLineBreak +
  '    KeepConnection = False ' + sLineBreak +
  '    Transaction = Transaction ' + sLineBreak +
  '    Left = 80 ' + sLineBreak +
  '    Top = 79 ' + sLineBreak +
  '  end ' + sLineBreak +
  '  object Transaction: TSQLTransaction ' + sLineBreak +
  '    Active = False ' + sLineBreak +
  '    Database = Connection ' + sLineBreak +
  '    Left = 168 ' + sLineBreak +
  '    Top = 80 ' + sLineBreak +
  '  end ' + sLineBreak +
  'end ' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaDataModule + 'dm.server.lfm', s);

  s := '';
end;


end.

