unit Util.GeraSwagger;

// Gera a documentação da API - Swagger

{$mode ObjFPC}{$H+}

interface

uses
   Classes, SysUtils, StrUtils, ExtCtrls,
   DB, SQLDB, ZDataset, fpjson, DateUtils, Math,
   Service.Projeto, Service.RestApi,
   Service.Tabela, Service.Campo,
   Util.SwaggerGen, Util.PostmanGen;

type

  { TUtilGeraSwagger }

  TUtilGeraSwagger = class
  private
    Swagger: TSwaggerDocument;
    Schema: TSwaggerSchema;
    Route: TSwaggerRoute;

    FTitle, FHeader1, FHeader2, FHeader3, FFooter1, FFooter2: string;
    FListaTabelasID: string;
    FErroMsg: String;

    procedure AjustaRota(qry: TZQuery; APrefixo: string; out ATag: string; out ARota: string; out ADescricaoRota: string);
    function AddResponseSuccess: string;
    procedure CriaRotaAuth;
    procedure CriaRotaGet(qry: TZQuery; ADataObjetoOutput, AGroupRoutes, APrefixo: String);
    procedure CriaRotaGetList(qry: TZQuery; ADataObjetoOutput, AGroupRoutes, APrefixo: String);
    procedure CriaRotaPatch(qry: TZQuery; ADataObjetoInput, AGroupRoutes, APrefixo: String);
    procedure CriaRotaPost(qry: TZQuery; ADataObjetoInput, AGroupRoutes, APrefixo: String);
    procedure CriaRotaPut(qry: TZQuery; ADataObjetoInput, AGroupRoutes, APrefixo: String);
    procedure CriaRotaDelete(qry: TZQuery; AGroupRoutes, APrefixo: String);
    procedure ExportToPostman(const ASwagger: TSwaggerDocument;
      const AProjeto: TServiceRestApi; const APastaDoc: string);
    function GenerateExampleJSON(ASwagger: TSwaggerDocument; const ASchemaName: String): String;
    procedure GeraIndex(AHost, AVersaoCurta, APathDoc: string);
    procedure SchemaObjeto(qry: TZQuery; ASchemaName: string; AQdeCampos: Integer; AExcluirPrimayKey, AIsInput: Boolean);
    procedure SchemaObjetoPage(qry: TZQuery; ASchemaName: string; AExcluirPrimayKey: Boolean);
  public
    function GeraDocumento(const Projeto: TServiceRestApi; AListaTabelasID, AVersaoCurta, APastaDoc, APastaRelease: string): Boolean;
    property GetErroMsg: String read FErroMsg;
  end;

implementation

uses
  Util.ProjetoCommon;

{ TUtilGeraSwagger }

function TUtilGeraSwagger.GeraDocumento(const Projeto: TServiceRestApi;
  AListaTabelasID, AVersaoCurta, APastaDoc, APastaRelease: string): Boolean;
// gera arquivo de informações da api para importação pelo programa Topazzio Rest API
var
  st: TServiceTabela;
  sc: TServiceCampo;
  tabelas, campos: TZQuery;
  docPathNome, lGroupRoutes, lDataInput, lDataOutput,
    lDataObjetoListOutput: String;
begin
  Result := False;
  FErroMsg := '';
  FListaTabelasID := AListaTabelasID;
  docPathNome := APastaDoc + PathDelim + 'swagger.json';

  Swagger := TSwaggerDocument.Create;

  try
    st := TServiceTabela.Create( Projeto.IdProjeto );
    tabelas := st.QueryTabelas( FListaTabelasID.Trim, True ); //tabelas

    if tabelas.RecordCount > 0 then begin
      FTitle := Projeto.ApiTitulo;
      FHeader1 := Projeto.ApiHeader1;
      FHeader2 := Projeto.ApiHeader2;
      FHeader3 := Projeto.ApiHeader3;
      FFooter1 := Projeto.ApiFooter1;
      FFooter2 := Projeto.ApiFooter2;

      // cria o index.html
      GeraIndex(Projeto.ApiHost + ':' + Projeto.ApiPorta, AVersaoCurta, APastaDoc);

      // cria o swagger.jon

      Swagger.Title := ''; // Nome da API
      Swagger.Description := Projeto.ApiDescricao;
      Swagger.Version := '2.0.0';

      // cria a rota de autenticação
      CriaRotaAuth;

      // demais rotas
      while not tabelas.EOF do begin
        if tabelas.FieldByName('for_auth').AsInteger = 0 then begin // rota comum
          sc := TServiceCampo.Create( tabelas.FieldByName('idtabela').AsInteger );
          campos := sc.QueryCampos; // campos da tabela

          if (campos.RecordCount > 0) and
             (campos.FieldByName('criar_api').AsInteger = 1) and
             (campos.FieldByName('chave_primaria').AsInteger = 1) then
          begin

            lGroupRoutes := campos.FieldByName('nome_objeto').AsString;
            lDataInput := lGroupRoutes + 'Input';
            lDataOutput := lGroupRoutes;
            lDataObjetoListOutput := lGroupRoutes + 'Page';

            // schemas deste endpoint (input e output)
            SchemaObjeto(campos, lDataInput, 0, True, True);   // entrada de dados (POST, PUT)
            SchemaObjeto(campos, lDataOutput, 0, False, False); // retorno de dados (GET)
            SchemaObjetoPage(campos, lDataObjetoListOutput, False); // retorno de dados (GET List)

            // endpoints

            // GET
            CriaRotaGet(campos, lDataOutput, lGroupRoutes, Projeto.ApiVersao);

            // GET PAGE
            if campos.FieldByName('api_get').AsInteger = 1 then
              CriaRotaGetList(campos, lDataObjetoListOutput, lGroupRoutes, Projeto.ApiVersao);

            // POST
            if campos.FieldByName('api_post').AsInteger = 1 then
              CriaRotaPost(campos, lDataInput, lGroupRoutes, Projeto.ApiVersao);

            // PUT
            if campos.FieldByName('api_put').AsInteger = 1 then
              CriaRotaPut(campos, lDataInput, lGroupRoutes, Projeto.ApiVersao);

            // PATCH
            if campos.FieldByName('api_patch').AsInteger = 1 then
              CriaRotaPatch(campos, lDataInput, lGroupRoutes, Projeto.ApiVersao);

            // DELETE
            if campos.FieldByName('api_delete').AsInteger = 1 then
              CriaRotaDelete(campos, lGroupRoutes, Projeto.ApiVersao);

          end;

          campos.Close;
          campos.Free;
          sc.Free;
        end;

        // próxima tabela
        tabelas.Next;
      end;

      try
        { GERA O ARQUIVO SWAGGER }
        Swagger.SaveToFile(docPathNome);
        Result := True;

        { GERA O ARQUIVO POSTMAN }
        ExportToPostman(Swagger, Projeto, APastaRelease);
      finally
      end;
    end;

    tabelas.Close;
    tabelas.Free;
    st.Free;
  finally
    Swagger.Free;
  end;
end;

procedure TUtilGeraSwagger.CriaRotaAuth;
// rota padrão de autenticação
begin
  { SCHEMA AUTH }

  // Input
  Schema := TSwaggerSchema.Create;
  Schema.Name := 'LoginInput';
  Schema.AddProperty('username', 'string', '', True);
  Schema.AddProperty('password', 'string', 'password', True);

  // adiciona à lista de schemas
  Swagger.AddSchema(Schema);

  // Output
  Schema := TSwaggerSchema.Create;
  Schema.Name := 'TokenOutput';
  Schema.AddProperty('id', 'integer', '', False);
  Schema.AddProperty('name', 'string', '', False);
  Schema.AddProperty('exep', 'integer', '', False);
  Schema.AddProperty('token', 'string', '', False);

  // adiciona à lista de schemas
  Swagger.AddSchema(Schema);

  { POST /login }
  Route := TSwaggerRoute.Create;
  Route.Path := '/login';
  Route.Method := 'POST';
  Route.Summary := 'Autentica um usuário e retorna um token JWT';
  Route.Tag := 'Auth';
  Route.Secure := False;
  Route.RequestSchema := 'LoginInput';

  // repostas da rota
  Route.AddResponse('200', 'Token gerado com sucesso', 'TokenOutput');
  Route.AddResponse('401', 'authentication failed or missing data', '');

  // adiciona à lista de rotas
  Swagger.AddRoute(Route);
end;

procedure TUtilGeraSwagger.CriaRotaGet(qry: TZQuery; ADataObjetoOutput, AGroupRoutes, APrefixo: String);
// Rota GET
var
  lTag, lRota, lDescricaoRota: string;
begin
  AjustaRota(qry, APrefixo, lTag, lRota, lDescricaoRota);

  Route := TSwaggerRoute.Create;
  Route.Path := lRota + '/{id}'; // '/api/v1/produto/{id}';
  Route.Method := 'GET';
  Route.Summary := 'Obtém dados do registro'; // lDescricaoRota;
  Route.Tag := AGroupRoutes;
  Route.Secure := True;

  // parâmetros da requisição
  Route.AddParameter('id', 'path', 'integer', True, 'Código do registro a ser consultado', '1');

  // respostas da requisição
  Route.AddResponse('200', 'Ok', ADataObjetoOutput); // modelo de dados da resposta
  Route.AddResponse('400', 'Invalid request', '', AddResponseSuccess);
  Route.AddResponse('401', 'Unauthorized', '');

  Swagger.AddRoute(Route);
end;

procedure TUtilGeraSwagger.CriaRotaGetList(qry: TZQuery; ADataObjetoOutput, AGroupRoutes, APrefixo: String);
// Rota GET List com Paginação
var
  lTag, lRota, lDescricaoRota: string;
begin
  AjustaRota(qry, APrefixo, lTag, lRota, lDescricaoRota);

  Route := TSwaggerRoute.Create;
  Route.Path := lRota + '?page={page}&limit={limit}';
  Route.Method := 'GET';
  Route.Summary := 'Obtém lista de registros';
  Route.Tag := AGroupRoutes;
  Route.Secure := True;

  // parâmetros da requisição
  Route.AddParameter('page', 'query', 'integer', True, 'Número da página que deseja recuperar', '1');
  Route.AddParameter('limit', 'query', 'integer', True, 'Quantidade de itens por página', '5');
  Route.AddParameter('search', 'query', 'string', False, 'Termo da pesquisa (opcional)');

  // respostas da requisição
  Route.AddResponse('200', 'Ok', ADataObjetoOutput); // modelo de dados da resposta
  Route.AddResponse('401', 'Unauthorized', '');

  Swagger.AddRoute(Route);
end;

procedure TUtilGeraSwagger.CriaRotaPost(qry: TZQuery; ADataObjetoInput, AGroupRoutes, APrefixo: String);
// Rota Post
var
  lTag, lRota, lDescricaoRota: string;
begin
  AjustaRota(qry, APrefixo, lTag, lRota, lDescricaoRota);

  Route := TSwaggerRoute.Create;
  Route.Path := lRota;
  Route.Method := 'POST';
  Route.Summary := 'Cria produto';
  Route.Tag := AGroupRoutes;
  Route.Secure := True;
  Route.RequestSchema := ADataObjetoInput;

  // respostas da requisição
  Route.AddResponse('201', 'Record created');
  Route.AddResponse('400', 'Invalid request');
  Route.AddResponse('401', 'Unauthorized');

  Swagger.AddRoute(Route);
end;

procedure TUtilGeraSwagger.CriaRotaPut(qry: TZQuery; ADataObjetoInput, AGroupRoutes, APrefixo: String);
// Rota Put
var
  lTag, lRota, lDescricaoRota: string;
begin
  AjustaRota(qry, APrefixo, lTag, lRota, lDescricaoRota);

  Route := TSwaggerRoute.Create;
  Route.Path := lRota + '/{id}'; // '/api/v1/produto/{id}';
  Route.Method := 'PUT';
  Route.Summary := 'Alterar dados do registro indicado'; // lDescricaoRota;
  Route.Tag := AGroupRoutes;
  Route.Secure := True;
  Route.RequestSchema := ADataObjetoInput;

  // parâmetros da requisição
  Route.AddParameter('id', 'path', 'integer', True, 'Código do registro a ser alterado');

  // respostas da requisição
  Route.AddResponse('200', 'Record updated', '', AddResponseSuccess);
  Route.AddResponse('400', 'Invalid request', '');
  Route.AddResponse('401', 'Unauthorized', '');

  Swagger.AddRoute(Route);
end;

procedure TUtilGeraSwagger.CriaRotaPatch(qry: TZQuery; ADataObjetoInput, AGroupRoutes, APrefixo: String);
// Rota Patch
var
  lTag, lRota, lDescricaoRota: string;
begin
  AjustaRota(qry, APrefixo, lTag, lRota, lDescricaoRota);

  Route := TSwaggerRoute.Create;
  Route.Path := lRota + '/{id}'; // '/api/v1/produto/{id}';
  Route.Method := 'PATCH';
  Route.Summary := 'Alterar dados do registro indicado'; // lDescricaoRota;
  Route.Tag := AGroupRoutes;
  Route.Secure := True;
  Route.RequestSchema := ADataObjetoInput;

  // parâmetros da requisição
  Route.AddParameter('id', 'path', 'integer', True, 'Código do registro a ser alterado');

  // respostas da requisição
  Route.AddResponse('200', 'Record updated', '', AddResponseSuccess);
  Route.AddResponse('400', 'Invalid request', '');
  Route.AddResponse('401', 'Unauthorized', '');

  Swagger.AddRoute(Route);
end;

procedure TUtilGeraSwagger.CriaRotaDelete(qry: TZQuery; AGroupRoutes, APrefixo: String);
// Rota Delete
var
  lTag, lRota, lDescricaoRota: string;
begin
  AjustaRota(qry, APrefixo, lTag, lRota, lDescricaoRota);

  Route := TSwaggerRoute.Create;
  Route.Path := lRota + '/{id}'; // '/api/v1/produto/{id}';
  Route.Method := 'DELETE';
  Route.Summary := 'Deleta o registro indicado'; // lDescricaoRota;
  Route.Tag := AGroupRoutes;
  Route.Secure := True;

  // parâmetros da requisição
  Route.AddParameter('id', 'path', 'integer', True, 'Código do registro a ser alterado');

  // respostas da requisição
  Route.AddResponse('200', 'Record deleted', '', AddResponseSuccess);
  Route.AddResponse('400', 'Invalid request', '');
  Route.AddResponse('401', 'Unauthorized', '');

  Swagger.AddRoute(Route);
end;

procedure TUtilGeraSwagger.SchemaObjeto(qry: TZQuery; ASchemaName: string;
  AQdeCampos: Integer; AExcluirPrimayKey, AIsInput: Boolean);
// Esquema de dados
var
  lCount: Integer;
  lCampo, lCampoAlias, lcampoTipo, lFormat: string;
  bCampoAceito, bChavePrimaria, bRequerido, bIsEmail,
    bChaveEstrangeira: Boolean;
begin
  Schema := TSwaggerSchema.Create;
  Schema.Name := ASchemaName;

  (*
    Common Types and Formats
    The following table summarizes the standard data types and their common formats used in OpenAPI 3.0:

    Type     Format       Description
    -------  -----------  -----------
    integer  int32        Signed 32-bit integer.
             int64        Signed 64-bit integer (long).
    number   float        Floating-point number.
             double       Double-precision floating-point number.
    string   date         Full-date as defined by RFC3339 (e.g., 2024-05-23).
             date-time    Date-time as defined by RFC3339 (e.g., 2024-05-23T12:00:00Z).
             password     A hint for UIs to obscure the input.
             byte         Base64-encoded characters.
             binary       Any sequence of octets (used for file uploads).
             email, uuid  Specifically formatted strings.
    boolean  None         A true/false value.
    object   None         A JSON object containing named properties.
    array    None         A collection of items (requires an items field).
  *)

  lCount := 0;
  qry.First;
  while not qry.EOF do begin
    lCampo := qry.FieldByName('campo').AsString;
    lCampoAlias := qry.FieldByName('campo_alias').AsString;
    if Trim(lCampoAlias) = '' then lCampoAlias := lcampo;
    lcampoTipo := qry.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    bChavePrimaria := (qry.FieldByName('chave_primaria').AsInteger = 1);
    bChaveEstrangeira := qry.FieldByName('chave_estrangeira').AsInteger = 1;
    bRequerido := (qry.FieldByName('requerido').AsInteger = 1); //campo obrigatório
    bIsEmail := UpperCase(Trim(qry.FieldByName('campo_especial').AsString)).Contains('EMAIL');

    bCampoAceito := True;

    case lcampoTipo.ToLower of
      'boolean':
        begin
          lcampoTipo := 'boolean';
          lFormat := '';
        end;
      'string':
        begin
          lcampoTipo := 'string';
          lFormat := '';
          if bIsEmail then lFormat := 'email';
        end;
      'integer':
        begin
          lcampoTipo := 'integer';
          lFormat := 'int32'; // int64
        end;
      'currency':
        begin
          lcampoTipo := 'number';
          lFormat := 'float';
        end;
      'double':
        begin
          lcampoTipo := 'number';
          lFormat := 'double';
        end;
      'tdatetime':
        begin
          lcampoTipo := 'string';
          lFormat := 'date-time'; // date
        end;
      'timage':
        begin
          bCampoAceito := False;
          lcampoTipo := 'string';
          lFormat := 'byte'; // binary
        end;
      else
        begin
          lcampoTipo := 'string';
          lFormat := '';
          if bIsEmail then lFormat := 'email';
        end;
    end;

    if AExcluirPrimayKey and bChavePrimaria then bCampoAceito := False;

    if bCampoAceito then begin
      lCount := lCount + 1;
      if (AQdeCampos > 0) and (lCount > AQdeCampos) then Break;

      Schema.AddProperty(lCampoAlias.ToLower, lcampoTipo, lFormat, bRequerido);

      if bChaveEstrangeira and not AIsInput then
        Schema.AddProperty(lCampoAlias.ToLower + '_value', 'string', '', False);
    end; // if

    qry.Next;
  end; //while

  // adiciona à lista de schemas
  Swagger.AddSchema(Schema);
end;

procedure TUtilGeraSwagger.SchemaObjetoPage(qry: TZQuery; ASchemaName: string; AExcluirPrimayKey: Boolean);
// modelo da saída de paginação
var
  lCount: Integer;
  lCampo, lCampoAlias, lcampoTipo, lFormat: string;
  bCampoAceito, bChavePrimaria, bRequerido, bIsEmail, bIncluirNaLista,
    bChaveEstrangeira: Boolean;
begin
  Schema := TSwaggerSchema.Create;
  Schema.Name := ASchemaName;

  Schema.AddProperty('page', 'integer', 'int32', False);
  Schema.AddProperty('per_page', 'integer', 'int32', False);
  Schema.AddProperty('total_pages', 'integer', 'int32', False);
  Schema.AddProperty('total_records', 'integer', 'int32', False);
  Schema.AddRef('data', ASchemaName + 'Itens', False);

  // adiciona à lista de schemas
  Swagger.AddSchema(Schema);

  // cria um schema para os itens da lista
  Schema := TSwaggerSchema.Create;
  Schema.Name := ASchemaName + 'Itens';

  lCount := 0;
  qry.First;
  while not qry.EOF do begin
    lCampo := qry.FieldByName('campo').AsString;
    lCampoAlias := qry.FieldByName('campo_alias').AsString;
    if Trim(lCampoAlias) = '' then lCampoAlias := lcampo;
    lcampoTipo := qry.FieldByName('tipo_fp').AsString; //Integer, string, Double, Currency, TDateTime, TImage
    bChavePrimaria := (qry.FieldByName('chave_primaria').AsInteger = 1);
    bRequerido := (qry.FieldByName('requerido').AsInteger = 1); //campo obrigatório
    bIncluirNaLista := qry.FieldByName('incluir_na_grid').AsInteger = 1;
    bChaveEstrangeira := qry.FieldByName('chave_estrangeira').AsInteger = 1;
    bIsEmail := UpperCase(Trim(qry.FieldByName('campo_especial').AsString)).Contains('EMAIL');
    bCampoAceito := True;

    case lcampoTipo.ToLower of
      'boolean':
        begin
          lcampoTipo := 'boolean';
          lFormat := '';
        end;
      'string':
        begin
          lcampoTipo := 'string';
          lFormat := '';
          if bIsEmail then lFormat := 'email';
        end;
      'integer':
        begin
          lcampoTipo := 'integer';
          lFormat := 'int32'; // int64
        end;
      'currency':
        begin
          lcampoTipo := 'number';
          lFormat := 'float';
        end;
      'double':
        begin
          lcampoTipo := 'number';
          lFormat := 'double';
        end;
      'tdatetime':
        begin
          lcampoTipo := 'string';
          lFormat := 'date-time'; // date
        end;
      'timage':
        begin
          bCampoAceito := False;
          lcampoTipo := 'string';
          lFormat := 'byte'; // binary
        end;
      else begin
        lcampoTipo := 'string';
        lFormat := '';
        if bIsEmail then lFormat := 'email';
      end;
    end;

    if AExcluirPrimayKey and bChavePrimaria then bCampoAceito := False;

    if bCampoAceito and bIncluirNaLista then begin
      Schema.AddProperty(lCampoAlias.ToLower, lcampoTipo, lFormat, bRequerido);

      if bChaveEstrangeira then
        Schema.AddProperty(lCampoAlias.ToLower + '_value', 'string', '', bRequerido);
    end;

    qry.Next;
  end; //while

  // adiciona à lista de schemas
  Swagger.AddSchema(Schema);
end;

procedure TUtilGeraSwagger.AjustaRota(qry: TZQuery; APrefixo: string; out ATag: string; out ARota: string; out ADescricaoRota: string);
var
  lRota, lEndPoint, lDescricao: string;
begin
  qry.First;

  lRota := Trim(qry.FieldByName('api_rota').AsString);
  if LeftStr(lRota, 1) = '/' then lRota := lRota.Substring(1);
  if RightStr(lRota, 1) = '/' then lRota := lRota.Substring(0, lRota.Length-1);

   // caminho completo do endpoint
  lEndPoint := StringReplace('/' + Trim(lRota), '//', '/', [rfReplaceAll]);
  while RightStr(lEndPoint, 1) = '/' do
    lEndPoint := LeftStr(lEndPoint, Length(lEndPoint)-1);

  // adiciona o prefixo: /api/v1/produto
  lEndPoint := APrefixo + lEndPoint;

  // Descrição do endpoint
  lDescricao := Trim(qry.FieldByName('descricao').AsString);
  if lDescricao = '' then lDescricao := 'Detalhes desta rota';

  ATag := UpperCase(Copy(lRota, 1, 1)) + Copy(lRota, 2, Length(lRota));
  ARota := lEndPoint;
  ADescricaoRota := lDescricao;
end;

function TUtilGeraSwagger.AddResponseSuccess: string;
begin
  Result := TJSONObject.Create([
    'type', 'object',
    'properties',
    TJSONObject.Create([
      'success',
      TJSONObject.Create([
        'type', 'boolean'
      ]),
      'message',
      TJSONObject.Create([
        'type', 'string'
      ])
    ])
  ]).AsJSON;
end;

procedure TUtilGeraSwagger.GeraIndex(AHost, AVersaoCurta, APathDoc: string);
// cria o index.html do swagger
var
  s, sHostVersao: string;
begin
  sHostVersao := AHost + '/' + AVersaoCurta; // http://localhost:8283/v1
  s :=
  '<!DOCTYPE html>' + sLineBreak +
  '<html>' + sLineBreak +
  '<head>' + sLineBreak +
  '  <meta charset="UTF-8">' + sLineBreak +
  '  <title>SWAGGER - ' + FTitle + '</title> ' + sLineBreak +
  '  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist/swagger-ui.css">' + sLineBreak +
  '  <style>' + sLineBreak +
  '    .container-one {  ' + sLineBreak +
  '      width: 70px;  ' + sLineBreak +
  '      height: 90%;  ' + sLineBreak +
  '      float: left;  ' + sLineBreak +
  '      align-content: center;  ' + sLineBreak +
  '      border-radius: 5px;  ' + sLineBreak +
  '      font-size: 14px;  ' + sLineBreak +
  '      text-align: center;  ' + sLineBreak +
  '      color: #fff;  ' + sLineBreak +
  '    }' + sLineBreak +
  '    .container-two {  ' + sLineBreak +
  '      margin-left: 90px;              ' + sLineBreak +
  '      height: 90%;  ' + sLineBreak +
  '      align-content: center;  ' + sLineBreak +
  '    }' + sLineBreak +
  '    .mb-4 {' + sLineBreak +
  '      margin-bottom:1.1rem!important' + sLineBreak +
  '    }' + sLineBreak +
  '    header {  ' + sLineBreak +
  '      height: 140px; ' + sLineBreak +
  '      margin-top: 5px;  ' + sLineBreak +
  '      padding: 10px;  ' + sLineBreak +
  '      background-color: #343a40;  ' + sLineBreak +
  '      color: white;  ' + sLineBreak +
  '      text-align: center;  ' + sLineBreak +
  '      border-radius: 5px;  ' + sLineBreak +
  '    }  ' + sLineBreak +
  '    header h1 {  ' + sLineBreak +
  '      text-decoration: none;  ' + sLineBreak +
  '      color: white;  ' + sLineBreak +
  '    }  ' + sLineBreak +
  '    footer {  ' + sLineBreak +
  '      margin-top: 50px;  ' + sLineBreak +
  '      padding: 10px;  ' + sLineBreak +
  '      background-color: #343a40;  ' + sLineBreak +
  '      color: white;  ' + sLineBreak +
  '      text-align: center;  ' + sLineBreak +
  '      border-radius: 5px;  ' + sLineBreak +
  '    }    ' + sLineBreak +
  '    footer a {  ' + sLineBreak +
  '      color: #fff;  ' + sLineBreak +
  '      text-decoration: none;  ' + sLineBreak +
  '    }  ' + sLineBreak +
  '    footer a:hover {  ' + sLineBreak +
  '      text-decoration: underline;  ' + sLineBreak +
  '    } ' + sLineBreak +
  '  </style>' + sLineBreak +
  '</head>' + sLineBreak +
  '<body>' + sLineBreak +
  ' <header class="mb-4"> ' + sLineBreak +
  '    <div class="container-one" style="height:140px; vertical-align:middle;"> ' + sLineBreak +
  '      <img src="/images/apidoc.png" width="128" height="128" border="0" alt="Logo">' + sLineBreak +
  '    </div>' + sLineBreak +
  '    <div class="container-two">' + sLineBreak +
  '      <h1>' + FHeader1 + '</h1> ' + sLineBreak +
  '      <p>' + FHeader2 + '</p> ' + sLineBreak +
  '      <p>' + FHeader3 + '</p> ' + sLineBreak +
  '    </div>' + sLineBreak +
  ' </header> ' + sLineBreak +
  '' + sLineBreak +
  ' <section> ' + sLineBreak +
  '   <div id="swagger-ui"></div>' + sLineBreak +
  ' </section> ' + sLineBreak +
  ' ' + sLineBreak +
  ' <footer> ' + sLineBreak +
  '   <p>' + FFooter1 + '</p> ' + sLineBreak +
  '   <p>' + FFooter2 + '</p> ' + sLineBreak +
  '   <font style="font-size:10px;">Criado via TOPAZZIO - ' + FormatDateTime('dd/mm/yyyy hh:nn:ss', now) + '</font>' + sLineBreak +
  ' </footer>' + sLineBreak +
  ' ' + sLineBreak +
  ' <script src="https://unpkg.com/swagger-ui-dist/swagger-ui-bundle.js"></script>' + sLineBreak +
  '' + sLineBreak +
  ' <script>' + sLineBreak +
  '   window.onload = function() {' + sLineBreak +
  '     // Inicializa o Swagger apontando para o seu arquivo' + sLineBreak +
  '     window.ui = SwaggerUIBundle({' + sLineBreak +
  '       url: "' + sHostVersao + '/swagger/swagger.json", ' + sLineBreak +
  '       dom_id: ''#swagger-ui'',' + sLineBreak +
  '       deepLinking: true,' + sLineBreak +
  '       presets: [' + sLineBreak +
  '                SwaggerUIBundle.presets.apis' + sLineBreak +
  '                ]' + sLineBreak +
  '     });' + sLineBreak +
  '   }; ' + sLineBreak +
  '</script>' + sLineBreak +
  '</body>' + sLineBreak +
  '</html>' + sLineBreak;

  TUtilCommon.SalvarArquivo(APathDoc + PathDelim + 'index.html' , s);
  s := '';
end;

procedure TUtilGeraSwagger.ExportToPostman(const ASwagger: TSwaggerDocument;
  const AProjeto: TServiceRestApi; const APastaDoc: string);
// gera o arquivo .json para importação no Postman
var
  LCollection: TPostmanCollection;
  LSwaggerRoute: TSwaggerRoute;
  LParam: TSwaggerParameter;
  LReq: TPostmanRequest;
  I, J: Integer;
  lHost: string;
begin
  LCollection := TPostmanCollection.Create;
  LCollection.Name := AProjeto.ApiTitulo; // ASwagger.Title;

  lHost := AProjeto.ApiHost + ':' + AProjeto.ApiPorta;

  for I := 0 to ASwagger.GetRoutes.Count - 1 do
  begin
    LSwaggerRoute := TSwaggerRoute( ASwagger.GetRoutes[I]);

    LReq := TPostmanRequest.Create;
    LReq.Name := LSwaggerRoute.Path; // LSwaggerRoute.Summary;
    LReq.Method := UpperCase(LSwaggerRoute.Method);
    LReq.Url := lHost + LSwaggerRoute.Path;
    LReq.Host := AProjeto.ApiHost;
    LReq.Port := AProjeto.ApiPorta;
    LReq.Description := LSwaggerRoute.Summary;

    { AUTH }

    if LSwaggerRoute.Secure then
      LReq.BearerToken := ''; //'{{token}}';

    { PARAMETERS }

    for J := 0 to LSwaggerRoute.GetParameters.Count - 1 do
    begin
      LParam := TSwaggerParameter( LSwaggerRoute.GetParameters[J]);

      if SameText(LParam.InType, 'query') then
      begin
        LReq.AddQueryParam(
          LParam.Name,
          LParam.DefaultValue,
          LParam.Description
        );
      end;
    end;

    { REQUEST BODY }

    if LSwaggerRoute.RequestSchema <> '' then
    begin
      LReq.Body :=
        GenerateExampleJSON(
          ASwagger,
          LSwaggerRoute.RequestSchema
        );

      LReq.AddHeader(
        'Content-Type',
        'application/json'
      );
    end;

    LCollection.AddRequest(LReq);
  end;

  // salva o arquivo
  try
    LCollection.SaveToFile(APastaDoc + PathDelim + 'API.postman_collection.json');
  finally
    LCollection.Free;
  end;
end;

function TUtilGeraSwagger.GenerateExampleJSON(ASwagger: TSwaggerDocument;const ASchemaName: String): String;
var
  LSchema: TSwaggerSchema;
  Prop: TSwaggerSchemaProperty;
  Obj: TJSONObject;
  I, J: Integer;
begin
  Obj := TJSONObject.Create;

  try

    for I := 0 to ASwagger.GetSchemas.Count - 1 do
    begin
      LSchema := TSwaggerSchema(ASwagger.GetSchemas[I]);

      if SameText(LSchema.Name, ASchemaName) then
      begin

        for J := 0 to LSchema.GetProperties.Count - 1 do
        begin
          Prop := TSwaggerSchemaProperty(LSchema.GetProperties[J]);

          if Prop.ExampleValue <> '' then
          begin

            if Prop.DataType = 'integer' then
              Obj.Add(
                Prop.Name,
                StrToIntDef(
                  Prop.ExampleValue,
                  0
                )
              )

            else
            if Prop.DataType = 'number' then
              Obj.Add(
                Prop.Name,
                StrToFloatDef(
                  Prop.ExampleValue,
                  0
                )
              )

            else
            if Prop.DataType = 'boolean' then
              Obj.Add(
                Prop.Name,
                SameText(
                  Prop.ExampleValue,
                  'true'
                )
              )

            else
              Obj.Add(
                Prop.Name,
                Prop.ExampleValue
              );
          end
          else
          begin

            if Prop.DataType = 'integer' then
              Obj.Add(
                Prop.Name,
                0
              )

            else
            if Prop.DataType = 'number' then
              Obj.Add(
                Prop.Name,
                0
              )

            else
            if Prop.DataType = 'boolean' then
              Obj.Add(
                Prop.Name,
                False
              )

            else
              Obj.Add(
                Prop.Name,
                ''
              );
          end;
        end;

        Break;
      end;
    end;

    Result := Obj.FormatJSON;
  finally
    Obj.Free;
  end;
end;

end.

