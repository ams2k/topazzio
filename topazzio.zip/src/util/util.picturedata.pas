unit Util.PictureData;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Graphics, ExtCtrls, Math,
  BGRABitmap, BGRABitmapTypes;

type

  { TUtilPictureData }

  TUtilPictureData = class
    public
      class function StreamToHexFormatted(Stream: TStream): string;
      class function BitmapToPNGStreamBGRA(ABitmap: TBitmap; ASize: Integer): TMemoryStream;
      class function ImageToHex(AImage: TImage; ASize: Integer): string;
  end;

implementation

{ TUtilPictureData }

class function TUtilPictureData.StreamToHexFormatted(Stream: TStream): string;
const
  HexChars: array[0..15] of Char = '0123456789ABCDEF';
  LINE_SIZE = 64;
var
  Buffer: array[0..4095] of Byte;
  ReadCount, i: Integer;
  Line: string;
begin
  Result := '';
  Stream.Position := 0;
  Line := '';

  repeat
    ReadCount := Stream.Read(Buffer, SizeOf(Buffer));
    for i := 0 to ReadCount - 1 do
    begin
      Line := Line +
        HexChars[Buffer[i] shr 4] +
        HexChars[Buffer[i] and $0F];

      if Length(Line) = LINE_SIZE then
      begin
        Result := Result + '        ' + Line + LineEnding;
        Line := '';
      end;
    end;
  until ReadCount = 0;

  if Line <> '' then
    Result := Result + '        ' + Line + LineEnding;
end;

class function TUtilPictureData.BitmapToPNGStreamBGRA(ABitmap: TBitmap; ASize: Integer): TMemoryStream;
var
  src, resized: TBGRABitmap;
begin
  Result := TMemoryStream.Create;

  src := TBGRABitmap.Create(ABitmap);
  try
    src.ResampleFilter := rfBestQuality;

    resized := src.Resample(ASize, ASize) as TBGRABitmap;
    try
      resized.SaveToStreamAsPng(Result);
      Result.Position := 0;
    finally
      resized.Free;
    end;
  finally
    src.Free;
  end;
end;

class function TUtilPictureData.ImageToHex(AImage: TImage; ASize: Integer): string;
var
  OrigPic: TPicture;
  BinStream: TMemoryStream;
  TxtStream: TStringStream;
  PNGStream: TMemoryStream;
begin
  if not Assigned(AImage.Picture.Graphic) then
    raise Exception.Create('Invalid image');

  ASize := EnsureRange(ASize, 1, 1024);

  OrigPic := TPicture.Create;
  BinStream := TMemoryStream.Create;
  TxtStream := TStringStream.Create('');
  try
    // backup
    OrigPic.Assign(AImage.Picture);

    // gera PNG redimensionado com qualidade
    PNGStream := BitmapToPNGStreamBGRA(AImage.Picture.Bitmap, ASize);
    try
      AImage.Picture.LoadFromStream(PNGStream);
    finally
      PNGStream.Free;
    end;

    // serializa como Lazarus (.lfm)
    BinStream.WriteComponent(AImage);
    BinStream.Position := 0;

    ObjectBinaryToText(BinStream, TxtStream);

    // extrai apenas Picture.Data
    var S := TxtStream.DataString;
    var p1 := Pos('Picture.Data = {', S);
    var p2 := Pos('}', S);

    if (p1 > 0) and (p2 > p1) then
      Result := Copy(S, p1, p2 - p1 + 1)
    else
      Result := S;

  finally
    // restaura original
    AImage.Picture.Assign(OrigPic);

    TxtStream.Free;
    BinStream.Free;
    OrigPic.Free;
  end;
end;

end.

