unit View.TabelaUnica;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, EditExt;

type

  { TfrmTabelaUnica }

  TfrmTabelaUnica = class(TForm)
    edtCampoPesquisa: TEditExt;
    edtChavePrimaria: TEditExt;
    edtEntrada: TMemo;
    Label1: TLabel;
    Label4: TLabel;
    Label5: TLabel;
  private

  public

  end;

var
  frmTabelaUnica: TfrmTabelaUnica;

implementation

{$R *.lfm}

end.

