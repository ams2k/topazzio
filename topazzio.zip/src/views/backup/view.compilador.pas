unit View.Compilador;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  EditExt, ButtonPlus, CircularProgressBar, MaskedEditPlus,
  IniFiles, Process, XMLRead, DOM, XmlReader;

type

  { TCompilacaoThread }

  TCompilacaoThread = class(TThread)
    // procedure a ser executada em background no Form
    ExecuteProcedure: procedure of object;
    // procedure de retorno no Form quando terminar a execução
    CallBackEndProcess: procedure(AStatus: integer) of object;
    // procedure de atualização no Form
    CallBackUpdateLog: procedure(AMsg: string) of object;
    protected
      procedure Execute; override;
    private
      FMensagem: string;
      FStatus: Integer;
      procedure CallEndProcess;
      procedure CallUpdateLog;
    public
      constructor Create(CreateSuspended: boolean);
      procedure UpdateLog(AMsg: string);
      procedure EndProcess(AStatus: integer);
  end;

  { TBuildModeInfo }
  TBuildModeInfo = record
    Name: string;       // linux, windows
    Executavel: string; // path e nome do executável
    TargetOS: string;   // linux, win32, win64
    TargetCPU: string;  // x86_64, i386
  end;

  { TfrmCompilador }

  TfrmCompilador = class(TForm)
    btnCompilar: TButtonPlus;
    btnExecutar: TButtonPlus;
    ComboBoxModes: TComboBox;
    cpbProcessando: TCircularProgressBar;
    lblLazBuild: TLabel;
    edtPathLazBuild: TMaskedEditPlus;
    MemoLog: TMemo;
    lblLogCompilacao: TLabel;
    lblModoCompilacao: TLabel;
    panTop: TPanel;
    ShapeCompilacao: TShape;
    procedure btnCompilarClick(Sender: TObject);
    procedure btnExecutarClick(Sender: TObject);
    procedure edtPathLazBuildExit(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
  private
    bCompilando: Boolean;
    FProjeto_IsAPI: Boolean;
    FThread: TCompilacaoThread;
    FExecutavel: String;
    FBuildModes: array of TBuildModeInfo;
    FArquivoINI: string;
    FProjeto_Nome: string;
    FProjeto_Path: string;
    FPathRelease: string;
    procedure Ini_Ler;
    procedure Ini_Gravar;
    procedure LerProjeto;
    procedure Progresso(AValue: Boolean);
    function LerArquivoLPI(APathFile: String): String;
    procedure Compilacao_Init;
    procedure Compilacao_UpdateLog(AMsg: string);
    procedure Compilacao_End(AStatus: integer);
    procedure AjustaIdioma;
    procedure ExecutarProjeto_Window;
    procedure ExecutarProjeto_Terminal;
  public
    property Projeto_IsAPI: Boolean read FProjeto_IsAPI write FProjeto_IsAPI;
    property Projeto_Path: string read FProjeto_Path write FProjeto_Path;
    property PathRelease: string read FPathRelease write FPathRelease;
    property Projeto_Nome: string read FProjeto_Nome write FProjeto_Nome;
  end;

var
  frmCompilador: TfrmCompilador;

implementation

uses
  Util.Idioma, Util.Funcoes;

{$R *.lfm}

{ TCompilacaoThread }

constructor TCompilacaoThread.Create(CreateSuspended: boolean);
begin
  FreeOnTerminate := True; //não necessita usar .Free neste objeto
  inherited Create(CreateSuspended);
end;

procedure TCompilacaoThread.Execute;
begin
  // chama a procedure onde o código em background será executado
  ExecuteProcedure;
end;

procedure TCompilacaoThread.EndProcess(AStatus: integer);
begin
  FStatus := AStatus;
  Synchronize(@CallEndProcess); // sincroniza a thread com a procedure no Form
end;

procedure TCompilacaoThread.CallEndProcess;
begin
  CallBackEndProcess(FStatus); //chama a procedure lá no Form
end;

procedure TCompilacaoThread.UpdateLog(AMsg: string);
begin
  FMensagem := AMsg;
  Synchronize(@CallUpdateLog); //sincroniza a thread com a procedure no Form
end;

procedure TCompilacaoThread.CallUpdateLog;
begin
  CallBackUpdateLog(FMensagem); //chama a procedure lá no Form
end;

{ TfrmCompilador }

procedure TfrmCompilador.FormShow(Sender: TObject);
begin
  FArquivoINI := 'build_config.ini';
  btnExecutar.Enabled := False;
  Ini_Ler;
  LerProjeto;
end;

procedure TfrmCompilador.btnCompilarClick(Sender: TObject);
//compila o projeto
begin
  if bCompilando then Exit;

  //path do lazbuild
  if not DirectoryExists(edtPathLazBuild.Text) then begin
    ShowMessage( ViewCompilador.LazBuildMessage );
    Exit;
  end;

  //target da compilação
  if ComboBoxModes.ItemIndex < 0 then begin
    ShowMessage( ViewCompilador.BotaoCompilarMensagem1 );
    Exit;
  end;

  bCompilando := True;
  Ini_Gravar;
  Progresso(True);
  MemoLog.Lines.Clear;
  btnCompilar.Enabled := True;
  ShapeCompilacao.Pen.Color := Color;

  FThread := TCompilacaoThread.Create(True);
  FThread.ExecuteProcedure   := @Compilacao_Init; //onde inicia a compilação em background
  FThread.CallBackUpdateLog  := @Compilacao_UpdateLog; //onde atualiza o campo MemoLog
  FThread.CallBackEndProcess := @Compilacao_End; // onde finaliza o processo
  FThread.Start;
end;

procedure TfrmCompilador.btnExecutarClick(Sender: TObject);
//executa o projeto compilado
begin
  if FExecutavel = '' then Exit;

  if not FileExists(FExecutavel) then begin
    ShowMessage(ViewCompilador.BotaoExecutarMensagem1 + sLineBreak + FExecutavel);
    Exit;
  end;

  if Projeto_IsAPI then
    ExecutarProjeto_Terminal
  else
    ExecutarProjeto_Window;
end;

procedure TfrmCompilador.edtPathLazBuildExit(Sender: TObject);
begin
  if RightStr(edtPathLazBuild.Text, 1) = PathDelim then
    edtPathLazBuild.Text := LeftStr(edtPathLazBuild.Text, Length(edtPathLazBuild.Text) -1);
end;

procedure TfrmCompilador.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  if bCompilando then begin
    CanClose := False;
    ShowMessage( ViewCompilador.Mensagem5 );
  end;
end;

procedure TfrmCompilador.FormCreate(Sender: TObject);
begin
  panTop.Color := Funcoes.MenuCor;
  Color := Funcoes.MenuCorSelecionado;
  AjustaIdioma;
end;

procedure TfrmCompilador.Ini_Ler;
//leitura do arquivo de configuração
var
  ArqINI: TIniFile;
begin
  ArqINI := TIniFile.Create(FArquivoINI);

  try
    edtPathLazBuild.text := ArqINI.ReadString('LAZBUILD','path', '');
  finally
    ArqINI.Free;
  end;
end;

procedure TfrmCompilador.Ini_Gravar;
//salva dados no arquivo de configuração
var
  ArqINI: TIniFile;
begin
  ArqINI := TIniFile.Create(FArquivoINI);

  try
    ArqINI.WriteString('LAZBUILD','path', Trim(edtPathLazBuild.Text));
  finally
    ArqINI.Free;
  end;
end;

procedure TfrmCompilador.LerProjeto;
//leitura do arquivo do projeto (.lpi)
var
  Doc: TXMLDocument;
  LStringStream: TStringStream;
  bm: TBuildModeInfo;
  ProjectNode, ModesNode, ItemNode, Node, CompilerOptions: TDOMNode;
  i: Integer;
  XMLString, LFileName: string;
  bLerStream: Boolean;
begin
  ComboBoxModes.Items.Clear;
  SetLength(FBuildModes, 0);
  bLerStream  := True;
  FExecutavel := '';
  LFileName   := FProjeto_Path + FProjeto_Nome.ToLower + '.lpi';

  if not FileExists(LFileName) then begin
    ShowMessage( ViewCompilador.Mensagem1 );
    Exit;
  end;

  if bLerStream then begin
    //lê de um stream a partir de um XML em formato string
    XMLString := LerArquivoLPI(LFileName);
    LStringStream := TStringStream.Create(XMLString);
    ReadXMLFile(Doc, LStringStream);
  end
  else begin
    // obtém um xml de um arquivo
    ReadXMLFile(Doc, LFileName); //lê o arquivo
  end;

  try
    ProjectNode := Doc.DocumentElement.FindNode('ProjectOptions');

    //if Assigned(ProjectNode) then
    //begin
    //  Node := ProjectNode.FindNode('General');
    //  if Assigned(Node) then
    //  begin
    //    Node := Node.FindNode('TargetFileName');
    //    if Assigned(Node) then
    //    begin
    //      Executavel := Node.TextContent;
    //      LabelExe.Caption := 'Executável: ' + Executavel;
    //    end;
    //  end;
    //end;

    // buscar BuildModes
    ModesNode := ProjectNode.FindNode('BuildModes');
    if Assigned(ModesNode) then begin

      for i := 0 to ModesNode.ChildNodes.Count - 1 do begin
        ItemNode := ModesNode.ChildNodes[i];

        if ItemNode.NodeName = 'Item' then begin
          bm.Name := String(ItemNode.Attributes.GetNamedItem('Name').NodeValue);
          CompilerOptions := nil;
          CompilerOptions := ItemNode.FindNode('CompilerOptions');

          if Assigned(CompilerOptions) then begin
            { Target / Filename }
            ItemNode := CompilerOptions.FindNode('Target');
            if Assigned(ItemNode) then begin
              Node := ItemNode.FindNode('Filename');
              bm.Executavel := '';

              if Assigned(Node) then //and Node.HasAttributes then
                bm.Executavel := String(Node.Attributes.GetNamedItem('Value').NodeValue);
            end;

            { CodeGeneration }
            ItemNode := CompilerOptions.FindNode('CodeGeneration');
            if Assigned(ItemNode) then begin
              Node := ItemNode.FindNode('TargetOS');
              bm.TargetOS := '';
              bm.TargetCPU := '';

              if Assigned(Node) then //and Node.HasAttributes then
                bm.TargetOS := String(Node.Attributes.GetNamedItem('Value').NodeValue);

              Node := ItemNode.FindNode('TargetCPU');
              if Assigned(Node) then //and Node.HasAttributes then
                bm.TargetCPU := String(Node.Attributes.GetNamedItem('Value').NodeValue);
            end;

          end; //CompilerOptions

          SetLength(FBuildModes, Length(FBuildModes)+1);
          FBuildModes[High(FBuildModes)] := bm;

          ComboBoxModes.Items.Add(bm.Name + ' [ os=' + bm.TargetOS + '  cpu=' + bm.TargetCPU + ' ]');
        end;
      end; //for

    end;

    // fallback se não tiver build modes
    if ComboBoxModes.Items.Count = 0 then begin
      ComboBoxModes.Items.Add('Default');
      ComboBoxModes.ItemIndex := 0;
    end
    else
      ComboBoxModes.ItemIndex := 0;

  finally
    if Assigned(LStringStream) then LStringStream.Free;
    Doc.Free;
  end;
end;

procedure TfrmCompilador.Progresso(AValue: Boolean);
begin
  cpbProcessando.Visible  := AValue;
  cpbProcessando.Infinite := AValue;
end;

function TfrmCompilador.LerArquivoLPI(APathFile: String): String;
//cria um xml a partir dos dados do arquivo .lpi
var
  lArquivo: TextFile;
  sTexto, dados, temp: String;
  i, j: Integer;
begin
  Result := '';
  dados := '';
  temp := '';
  i := 0;

  if FileExists(APathFile) then begin

    AssignFile(lArquivo, APathFile);
    Reset(lArquivo);

    try
      while not EOF(lArquivo) do begin
        sTexto := '';
        ReadLn (lArquivo, sTexto);

        if i > 0 then
          dados := dados + sLineBreak;

        dados := dados + sTexto;
        inc(i);
      end;
    finally
       CloseFile(lArquivo);
    end;

    {
      Tem <CompilerOptions> for do <BuildModes> ?
      Se sim, remove do local atual e o coloca dentro de <BuildModes><Item> ... </Item>
    }

    j := 0;
    i := dados.IndexOf('</ProjectOptions>', j);
    if i > 0 then begin
      Result := dados.Substring(0, i + 17);
      j := i + 17;
      i := dados.IndexOf('<CompilerOptions>', j);
      if i > 0 then begin
         j := i;
         i := dados.IndexOf('</CompilerOptions>', j);
         if i > 0 then begin
           Result := Result + dados.Substring(i + 18);
           temp := dados.Substring(j, i-j+18);

           i := Result.IndexOf('<Item Name=', 0);
           if i > 0 then begin
             i := Result.IndexOf('Default="True"', i);
             if i >0 then begin
               i := Result.IndexOf('/>', i);
               if i > 0 then
                 Result := Result.Substring(0, i) + '>' + sLineBreak +
                           temp + sLineBreak + '</Item>' + sLineBreak +
                           Result.Substring(i+3);
             end;
           end;
         end;
      end else { XML está formatado corretamente }
        Result := dados;
    end;
  end;

  dados := '';
  temp := '';
end;

procedure TfrmCompilador.Compilacao_Init;
// compilação do projeto
// opt/fpcupdeluxe/lazarus/lazbuild --os=linux --ws=gtk2 --cpu=x86_64 my_app_name.lpi
// ou
// opt/fpcupdeluxe/lazarus/lazbuild --build-mode=Linux my_app_name.lpi
// ou
// opt/fpcupdeluxe/lazarus/lazbuild --build-mode=Windows my_app_name.lpi
// ou
// c:\lazarus\lazbuild --build-mode=Windows my_app_name.lpi
var
  Proc: TProcess;
  Line: string;
  BytesRead: LongInt;
  LBuffer: array[0..2048] of byte;
  ModoSelecionado, LFileName: string;
  LOS, LCPU: string;
begin
  LFileName := FProjeto_Path + FProjeto_Nome.ToLower + '.lpi';
  ModoSelecionado := FBuildModes[ComboBoxModes.ItemIndex].Name;
  FExecutavel     := FProjeto_Path + FBuildModes[ComboBoxModes.ItemIndex].Executavel;
  LOS  := FBuildModes[ComboBoxModes.ItemIndex].TargetOS;
  LCPU := FBuildModes[ComboBoxModes.ItemIndex].TargetCPU;

  Proc := TProcess.Create(nil);

  try
    Proc.Executable := Trim(edtPathLazBuild.Text + PathDelim + 'lazbuild ');
    Proc.Parameters.Add('--build-mode=' + ModoSelecionado);
    //Proc.Parameters.Add('--os=' + LOS);
    //Proc.Parameters.Add('--cpu=' + LCPU);
    Proc.Parameters.Add(LFileName); // arquivo .lpi
    Proc.Options := [poUsePipes, poNoConsole];
    Proc.ShowWindow := swoShow;

    FThread.UpdateLog(ViewCompilador.Mensagem2 + ' lazbuild ( modo: --os=' + LOS + '  --cpu=+ ' + LCPU + ' )...');

    Proc.Execute;

    while Proc.Running do begin
      BytesRead := Proc.Output.Read(LBuffer, SizeOf(LBuffer));

      if BytesRead > 0 then begin
        SetString(Line, PChar(@LBuffer), BytesRead);

        FThread.UpdateLog(Line); // atualiza o log
      end;

      Sleep(20);
    end;

    FThread.EndProcess(Proc.ExitStatus); // fim do processo
  finally
    Proc.Free;
  end;
end;

procedure TfrmCompilador.Compilacao_UpdateLog(AMsg: string);
// atualiza o log no MemoLog
begin
  MemoLog.Lines.Add(AMsg);
  MemoLog.SelStart := Length(MemoLog.Text);
  MemoLog.SelLength := 0;
  Application.ProcessMessages;
end;

procedure TfrmCompilador.Compilacao_End(AStatus: integer);
// finalizou a compilação
begin
  bCompilando := False;
  if AStatus = 0 then begin
    ShapeCompilacao.Pen.Color := $0078E01E;
    MemoLog.Lines.Add( ViewCompilador.Mensagem3 );
    btnExecutar.Enabled := True;
  end
  else begin
    ShapeCompilacao.Pen.Color := $005454DD;
    MemoLog.Lines.Add( ViewCompilador.Mensagem4 );
    btnExecutar.Enabled := False;
  end;

  btnCompilar.Enabled := True;
  Progresso(False);
end;

procedure TfrmCompilador.AjustaIdioma;
//exibe no idioma selecionado
begin
  panTop.Caption := ViewCompilador.Titulo;
  lblLazBuild.Caption := ViewCompilador.LazBuildLabel;
  lblModoCompilacao.Caption := ViewCompilador.ModoCompilacaoLabel;
  btnCompilar.Caption := ViewCompilador.BotaoCompilarText;
  btnExecutar.Caption := ViewCompilador.BotaoExecutarText;
  lblLogCompilacao.Caption := ViewCompilador.LogCompilacaoLabel;
end;

procedure TfrmCompilador.ExecutarProjeto_Window;
// executa o programa compilado em Janela
var
  AProcess: TProcess;
begin
  //ExecuteProcess(FExecutavel, '', [])
  AProcess := TProcess.Create(nil);
  try
    AProcess.Executable := FExecutavel;
    AProcess.Options := [poDetached]; // não bloqueia, totalmente independente
    AProcess.Execute;
  finally
    AProcess.Free;
  end;
end;

procedure TfrmCompilador.ExecutarProjeto_Terminal;
// executa o programa compilado em Janela
var
  Proc: TProcess;
begin
  Proc := TProcess.Create(nil);
  try
    {$IFDEF WINDOWS}
      // No Windows - abre o CMD
      Proc.Executable := 'cmd.exe';
      Proc.Parameters.Add('/K');           // /K mantém o terminal aberto
      // Proc.Parameters.Add('/C');        // /C executa e fecha depois

      Proc.Parameters.Add(FExecutavel);   // ou o caminho completo
      // Exemplo com parâmetros:
      // Proc.Parameters.Add('C:\caminho\meuapp.exe -param1 teste');

    {$ELSE}
      // No Linux
      Proc.Executable := 'konsole';     // | konsole | gnome-terminal | xterm | xfce4-terminal |
      Proc.Parameters.Add('-e');        // | -e      | --             | -e    | -x             |
      Proc.Parameters.Add(FExecutavel); // /home/usuario/projetos/lazarus/api/api-nome
    {$ENDIF}

    Proc.Options := Proc.Options + [poNoConsole]; // importante em alguns casos
    Proc.Execute;
  finally
    Proc.Free;
  end;
end;

end.

