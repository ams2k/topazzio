unit View.Projeto;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ButtonPlus;

type

  { TfrmProjeto }

  TfrmProjeto = class(TForm)
    btnGerarCrud: TButtonPlus;
  private

  public

  end;

var
  frmProjeto: TfrmProjeto;

implementation

{$R *.lfm}

end.

