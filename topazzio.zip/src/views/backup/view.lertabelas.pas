unit View.LerTabelas;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs;

type
  TfrmLerTabelas = class(TForm)
  private

  public

  end;

var
  frmLerTabelas: TfrmLerTabelas;

implementation

{$R *.lfm}

end.

