unit View.Splash;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls;

type

  { TfrmSplash }

  TfrmSplash = class(TForm)
    Image1: TImage;
    imgLogo: TImage;
    lblTitulo: TLabel;
    lblTitulo2: TLabel;
    lblVersao: TLabel;
    lblCriador: TLabel;
    lblSubTitulo: TLabel;
    Shape1: TShape;
    Timer1: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  private

  public

  end;

var
  frmSplash: TfrmSplash;

implementation

uses
  Util.Idioma, Util.Funcoes;

{$R *.lfm}

{ TfrmSplash }

procedure TfrmSplash.Timer1Timer(Sender: TObject);
begin
  Self.Close;
end;

procedure TfrmSplash.FormCreate(Sender: TObject);
begin
  Shape1.Brush.Color := Funcoes.MenuCor;
  lblTitulo.Caption := ProjetoInfo.Titulo;
  lblSubTitulo.Caption := ProjetoInfo.SubTitulo;
  lblVersao.Caption := ProjetoInfo.Versao(False);
end;

end.

