unit View.Controle;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  DateTimePicker, EditExt;

type

  { TfrmControle }

  TfrmControle = class(TForm)
    chkCriarFormPesquisa: TCheckBox;
    chkCriarGrid: TCheckBox;
    edtBanco: TEditExt;
    edtNomeProjeto: TEditExt;
    edtSenha: TEditExt;
    edtUsuario: TEditExt;
    imgBanco: TImage;
    Label10: TLabel;
    Label11: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label9: TLabel;
    radFireBird: TRadioButton;
    radMySql: TRadioButton;
    radOracleSql: TRadioButton;
    radPostgreSql: TRadioButton;
    radSQLite: TRadioButton;
    radSQLSever: TRadioButton;
  private

  public

  end;

var
  frmControle: TfrmControle;

implementation

{$R *.lfm}

end.

