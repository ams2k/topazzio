unit View.EditarTabela;

// permite editar dados da tabela e campos

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, StrUtils, Forms, Controls, Graphics, Dialogs, ExtCtrls, StdCtrls,
  DBGridPlus, LabelPlus, ButtonPlus, CheckBoxPlus, MaskedEditPlus,
  DBGrids, DB, Grids, DividerBevel;

type

  { TfrmEditarTabela }

  TfrmEditarTabela = class(TForm)
    btnTabela_Excluir: TButtonPlus;
    btnCampo_Excluir: TButtonPlus;
    btnTabela_Novo: TButtonPlus;
    btnCampo_Novo: TButtonPlus;
    btnTabela_Salvar: TButtonPlus;
    btnCampo_Salvar: TButtonPlus;
    cboCampoEspecial: TComboBox;
    chkCampo_RemoverMascara: TCheckboxPlus;
    chkCampo_IsMonetario: TCheckboxPlus;
    chkCampo_IsForeignKey: TCheckboxPlus;
    chkCampo_IsRequerido: TCheckboxPlus;
    chkCampo_IsPrimaryKey: TCheckboxPlus;
    chkCampo_IncruirNaListaDbGrid: TCheckboxPlus;
    chkCampo_ExcluirDoInsertUpdate: TCheckboxPlus;
    chkCampo_RptSomatorio: TCheckboxPlus;
    chkCampo_AceitaNull: TCheckboxPlus;
    chkTabela_API_Delete: TCheckboxPlus;
    chkTabela_API_Put: TCheckboxPlus;
    chkTabela_API_Post: TCheckboxPlus;
    chkTabela_API_Patch: TCheckboxPlus;
    chkTabela_IsForAuth: TCheckboxPlus;
    chkTabela_CriarFormPesquisa: TCheckboxPlus;
    chkTabela_CriarGrid: TCheckboxPlus;
    cboObjetos: TComboBox;
    chkTabela_CriarReport: TCheckboxPlus;
    chkTabela_CriarApi: TCheckboxPlus;
    chkTabela_API_Get: TCheckboxPlus;
    dgTabelas: TDBGridPlus;
    dgCampos: TDBGridPlus;
    DividerBevel1: TDividerBevel;
    edtCampos_Descricao: TMaskedEditPlus;
    edtCampo_ID: TEdit;
    edtCampo_NomeCampoAlias: TMaskedEditPlus;
    edtTabela_ID: TEdit;
    edtTabela_ApiRota: TMaskedEditPlus;
    grpTabelaApi: TGroupBox;
    imgBancoProjeto: TImage;
    lblCamposEspecial: TLabel;
    lblCamposDescricao: TLabel;
    lblCamposFieldAlias: TLabel;
    lblTabelasApiRota: TLabel;
    lblTipoDadoHelp: TLabel;
    lblCamposOrdem: TLabel;
    lblTabelasNome: TLabel;
    lblTabelasNomeObjeto: TLabel;
    lblTabelasPreparadas: TLabel;
    lblTabelasScript: TLabel;
    lblCamposTabela: TLabel;
    lblCamposField: TLabel;
    lblCamposObjeto: TLabel;
    lblCamposTamanho: TLabel;
    lblCamposTipoLazarus: TLabel;
    lblCamposTipo: TLabel;
    lblCamposComponente: TLabel;
    lblTabelasDescricao: TLabel;
    lblCampos_TabelaFK: TLabel;
    lblCampos_FonteDadosFK: TLabel;
    lblCampos_CodigoFK: TLabel;
    lblCampos_CampoTextoFK: TLabel;
    lblCampos_ComboAlternativo: TLabel;
    lblCampo_NomeTabela: TLabel;
    lblCamposPrecisao: TLabel;
    lblCamposEscala: TLabel;
    lblTabelasDados: TLabelPlus;
    lblCamposDados: TLabelPlus;
    lblMenuCampos: TLabelPlus;
    lblMenuTabelas: TLabelPlus;
    edtCampos_ComboCampoValores: TMemo;
    lblTabelasPreparadasQde: TLabel;
    lblCamposTabelaQde: TLabel;
    edtPesquisa: TMaskedEditPlus;
    edtTabela_NomeTabela: TMaskedEditPlus;
    edtTabela_Objeto: TMaskedEditPlus;
    edtTabela_Descricao: TMaskedEditPlus;
    edtCampo_Pesquisa: TMaskedEditPlus;
    edtCampo_NomeCampo: TMaskedEditPlus;
    edtCampo_Objeto: TMaskedEditPlus;
    edtCampo_Ordem: TMaskedEditPlus;
    edtCampo_Tipo: TMaskedEditPlus;
    edtCampo_MaxLength: TMaskedEditPlus;
    edtCampo_Precisao: TMaskedEditPlus;
    edtCampo_Escala: TMaskedEditPlus;
    edtCampos_TipoFP: TMaskedEditPlus;
    edtCampos_TabelaFK: TMaskedEditPlus;
    edtCampos_CampoCodigoFK: TMaskedEditPlus;
    edtCampos_CampoTextoFK: TMaskedEditPlus;
    edtTabela_Script: TMemo;
    NotebookTabelas: TNotebook;
    PageCampos: TPage;
    PageTabelas: TPage;
    panBotoes: TPanel;
    panCampos_DadosExternos: TPanel;
    panTop: TPanel;
    Shape1: TShape;
    procedure btnCampo_SalvarClick(Sender: TObject);
    procedure btnCampo_ExcluirClick(Sender: TObject);
    procedure btnCampo_NovoClick(Sender: TObject);
    procedure btnTabela_ExcluirClick(Sender: TObject);
    procedure btnTabela_NovoClick(Sender: TObject);
    procedure btnTabela_SalvarClick(Sender: TObject);
    procedure cboObjetosChange(Sender: TObject);
    procedure chkCampo_IsForeignKeyChange(Sender: TObject);
    procedure chkCampo_IsPrimaryKeyChange(Sender: TObject);
    procedure chkTabela_CriarApiChange(Sender: TObject);
    procedure chkTabela_IsForAuthChange(Sender: TObject);
    procedure dgCamposCellClick(Column: TColumn);
    procedure dgTabelasCellClick(Column: TColumn);
    procedure edtCampos_CampoCodigoFKExit(Sender: TObject);
    procedure edtCampos_CampoTextoFKExit(Sender: TObject);
    procedure edtCampos_ComboCampoValoresEnter(Sender: TObject);
    procedure edtCampos_ComboCampoValoresExit(Sender: TObject);
    procedure edtCampos_TabelaFKExit(Sender: TObject);
    procedure edtCampo_ObjetoExit(Sender: TObject);
    procedure edtCampo_OrdemExit(Sender: TObject);
    procedure edtCampo_PesquisaChange(Sender: TObject);
    procedure edtPesquisaChange(Sender: TObject);
    procedure edtTabela_ApiRotaEnter(Sender: TObject);
    procedure edtTabela_ApiRotaExit(Sender: TObject);
    procedure edtTabela_ObjetoExit(Sender: TObject);
    procedure edtTabela_ScriptEnter(Sender: TObject);
    procedure edtTabela_ScriptExit(Sender: TObject);
    procedure FormClose(Sender: TObject; var CloseAction: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure lblMenuCamposClick(Sender: TObject);
    procedure lblMenuCamposMouseEnter(Sender: TObject);
    procedure lblMenuCamposMouseLeave(Sender: TObject);
    procedure lblMenuTabelasClick(Sender: TObject);
    procedure lblMenuTabelasMouseEnter(Sender: TObject);
    procedure lblMenuTabelasMouseLeave(Sender: TObject);
    procedure lblTipoDadoHelpClick(Sender: TObject);
  private
    FAtualizarGrid: Boolean;
    FIdProjeto: Integer;
    FIdTabela: Integer;
    FOpcoesMenuDefaultColor, FOpcoesMenuOverColor, FOpcoesMenuSelectedColor: TColor;
    procedure CampoEspecial;
    function CapitalizaTexto(AValue: String): String;
    procedure MenuOpcoesColor;
    function RemoveFieldUnderscore(AValue: String): String;
    function TemChavePrimaria: Boolean;
    procedure Tabelas_CarregaGrid;
    procedure Tabelas_LimparCampos;
    procedure Tabelas_Ler(AIdTabela: Integer);
    procedure Tabelas_Salvar(AIdTabela: Integer);
    procedure Tabelas_Excluir(AIdTabela: Integer);
    procedure Campos_CarregaGrid;
    procedure Campos_LimparCampos;
    procedure Campos_Ler(AIdCampo: Integer);
    procedure Campos_Salvar(AIdCampo: Integer);
    procedure Campos_Excluir(AIdCampo: Integer);
    procedure AjustaIdioma;
    function ValidaTipoFPC(): Boolean;
  public
    property IdProjeto: Integer read FIdProjeto write FIdProjeto;
    property AtualizarGrid: Boolean read FAtualizarGrid;
  end;

var
  frmEditarTabela: TfrmEditarTabela;

implementation

uses
  Service.Tabela,
  Service.Campo,
  Util.Funcoes,
  Util.MessagePopup,
  Util.ValidacaoCampos,
  Util.Idioma;

{$R *.lfm}

{ TfrmEditarTabela }

procedure TfrmEditarTabela.FormClose(Sender: TObject; var CloseAction: TCloseAction);
begin
  if not dgCampos.Data_IsEmpty and (dgCampos.DataSource.DataSet<>nil) then dgCampos.DataSource.DataSet.Close;
  if not dgTabelas.Data_IsEmpty and (dgTabelas.DataSource.DataSet<>nil) then dgTabelas.DataSource.DataSet.Close;
end;

procedure TfrmEditarTabela.FormCreate(Sender: TObject);
begin
  panBotoes.Color := Funcoes.MenuCor;
  PageTabelas.Color := Funcoes.MenuCorSelecionado;
  PageCampos.Color := Funcoes.MenuCorSelecionado;
  AjustaIdioma;
end;

procedure TfrmEditarTabela.FormShow(Sender: TObject);
begin
  FIdTabela := 0;
  NotebookTabelas.PageIndex := 0;
  FOpcoesMenuDefaultColor := Funcoes.MenuCor;
  FOpcoesMenuOverColor := Funcoes.MenuCorHover;
  FOpcoesMenuSelectedColor:= Funcoes.MenuCorSelecionado;
  FAtualizarGrid := False;

  lblMenuTabelasClick(lblMenuTabelas);
  Tabelas_LimparCampos;

  if IdProjeto > 0 then
    Tabelas_CarregaGrid;
end;

procedure TfrmEditarTabela.dgTabelasCellClick(Column: TColumn);
begin
 if (dgTabelas.DataSource <> nil) and (dgTabelas.DataSource.DataSet.RecordCount > 0) then
   Tabelas_Ler( dgTabelas.Columns.Items[0].Field.AsInteger );
end;

procedure TfrmEditarTabela.edtCampos_CampoCodigoFKExit(Sender: TObject);
begin
  if Trim(edtCampos_CampoCodigoFK.Text) <> '' then edtCampos_ComboCampoValores.Clear;
  if (Trim(edtCampos_CampoCodigoFK.Text) <> '') and
     (Trim(edtCampos_TabelaFK.Text) = '') then
     edtCampos_CampoCodigoFK.Clear;
end;

procedure TfrmEditarTabela.edtCampos_CampoTextoFKExit(Sender: TObject);
begin
  if Trim(edtCampos_CampoTextoFK.Text) <> '' then edtCampos_ComboCampoValores.Clear;
  if (Trim(edtCampos_CampoTextoFK.Text) <> '') and
     (Trim(edtCampos_TabelaFK.Text) = '') then
     edtCampos_CampoTextoFK.Clear;
end;

procedure TfrmEditarTabela.edtCampos_ComboCampoValoresEnter(Sender: TObject);
begin
  Funcoes.EditBackColor(Sender, True);
end;

procedure TfrmEditarTabela.edtCampos_ComboCampoValoresExit(Sender: TObject);
begin
  Funcoes.EditBackColor(Sender, False);
  if Trim(edtCampos_ComboCampoValores.Text) <> '' then begin
    edtCampos_TabelaFK.Clear;
    edtCampos_CampoCodigoFK.Clear;
    edtCampos_CampoTextoFK.Clear;
  end;
end;

procedure TfrmEditarTabela.edtCampos_TabelaFKExit(Sender: TObject);
begin
  if Trim(edtCampos_TabelaFK.Text) <> '' then edtCampos_ComboCampoValores.Clear;
end;

procedure TfrmEditarTabela.edtCampo_ObjetoExit(Sender: TObject);
begin
  if Trim(edtCampo_Objeto.Text) = '' then
     edtCampo_Objeto.Text := Trim(edtCampo_NomeCampo.Text);
  edtCampo_Objeto.Text := RemoveFieldUnderscore( edtCampo_Objeto.Text ) ;
end;

procedure TfrmEditarTabela.edtCampo_OrdemExit(Sender: TObject);
var
  lOrdem: Integer;
begin
  lOrdem := StrToIntDef(edtCampo_Ordem.Text, 0);
  if lOrdem < 1 then edtCampo_Ordem.Text := '1';
  if chkCampo_IsPrimaryKey.Checked then
     edtCampo_Ordem.Text := '1';
  if not chkCampo_IsPrimaryKey.Checked and (lOrdem = 1) then
     edtCampo_Ordem.Text := '2';
end;

procedure TfrmEditarTabela.edtCampo_PesquisaChange(Sender: TObject);
begin
  lblCamposTabelaQde.Caption := '0';
  if (dgCampos.DataSource = nil) or (dgCampos.DataSource.DataSet = nil) then Exit;

  with dgCampos.DataSource.DataSet do begin
    FilterOptions := [foCaseInsensitive]; //Uses DB
    Filtered := False;
    Filter   := 'campo like ' + QuotedStr('*' + edtCampo_Pesquisa.Text + '*');
    Filtered := True;
  end;

  if (dgCampos.DataSource <> nil) and (dgCampos.DataSource.DataSet <> nil) then
    lblCamposTabelaQde.Caption := dgCampos.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmEditarTabela.btnTabela_SalvarClick(Sender: TObject);
//alterar a tabela
begin
  if StrToIntDef(edtTabela_ID.Text, 0) < 1 then begin
    ShowPopupMessage(self, ViewEditarTabela.MenuTabelaBotaoSalvarMensagem1, mptWarning);
    Exit;
  end;

  if QuestionDlg(QuestionDialog.Titulo, ViewEditarTabela.MenuTabelaBotaoSalvarMensagem2, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
     exit;

  if (edtTabela_ApiRota.Text) = '' then
    edtTabela_ApiRota.Text := '/' + LowerCase( edtTabela_Objeto.Text );

  Tabelas_Salvar( StrToIntDef(edtTabela_ID.Text, 0) );
end;

procedure TfrmEditarTabela.cboObjetosChange(Sender: TObject);
begin
  panCampos_DadosExternos.Enabled := (Trim(cboObjetos.Text) = 'TComboBox');

  if (Trim(cboObjetos.Text) = 'TComboBox') then begin
    chkCampo_IsPrimaryKey.Checked := False;
    chkCampo_IsForeignKey.Checked := False;
    edtCampos_ComboCampoValores.Enabled := True;
  end;
end;

procedure TfrmEditarTabela.chkCampo_IsPrimaryKeyChange(Sender: TObject);
begin
  if chkCampo_IsPrimaryKey.Checked then begin
    cboObjetos.ItemIndex := 0;
    chkCampo_IsForeignKey.Checked := False;
  end
  else
    cboObjetos.ItemIndex := 0;
end;

procedure TfrmEditarTabela.chkTabela_CriarApiChange(Sender: TObject);
begin
  if not chkTabela_CriarApi.Checked then begin
    chkTabela_API_Get.Checked := False;
    chkTabela_API_Post.Checked := False;
    chkTabela_API_Put.Checked := False;
    chkTabela_API_Patch.Checked := False;
    chkTabela_API_Delete.Checked := False;
    edtTabela_ApiRota.Text := '';
  end;
end;

procedure TfrmEditarTabela.chkTabela_IsForAuthChange(Sender: TObject);
begin
  CampoEspecial;
end;

procedure TfrmEditarTabela.chkCampo_IsForeignKeyChange(Sender: TObject);
begin
  if chkCampo_IsForeignKey.Checked then begin
    cboObjetos.ItemIndex := 0;
    chkCampo_IsPrimaryKey.Checked := False;
    panCampos_DadosExternos.Enabled := True;
    edtCampos_ComboCampoValores.Enabled := False;
  end
  else
    cboObjetos.ItemIndex := 0;
end;

procedure TfrmEditarTabela.dgCamposCellClick(Column: TColumn);
begin
  if (dgCampos.DataSource <> nil) and (dgCampos.DataSource.DataSet.RecordCount > 0) then
    Campos_Ler( dgCampos.Columns.Items[0].Field.AsInteger );
end;

procedure TfrmEditarTabela.btnTabela_ExcluirClick(Sender: TObject);
//excluir a tabela
begin
  if StrToIntDef(edtTabela_ID.Text, 0) < 1 then begin
    ShowPopupMessage(self, ViewEditarTabela.MenuTabelaBotaoExcluirMensagem1, mptWarning);
    Exit;
  end;

  if QuestionDlg(QuestionDialog.Titulo, ViewEditarTabela.MenuTabelaBotaoExcluirMensagem2, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
     exit;

  Tabelas_Excluir( StrToIntDef(edtTabela_ID.Text, 0) );
end;

procedure TfrmEditarTabela.btnCampo_SalvarClick(Sender: TObject);
//salva o campo
var
  v: TUtilValidacaoCampos;
  msg: string;
begin
  //tipos primitivos do fpc / outros aceitos
  //if (Pos(LowerCase(edtCampos_TipoFP.Text), 'string,integer,double,currency,boolean,tdatetime,timage') = 0) then begin
  if not ValidaTipoFPC() then begin
    ShowMessage( ViewEditarTabela.MenuCampoBotaoSalvarMensagem18 +
                 'string' + sLineBreak +
                 'integer' + sLineBreak +
                 'double' + sLineBreak +
                 'currency' + sLineBreak +
                 'boolean' + sLineBreak +
                 'tdatetime' + sLineBreak +
                 'timage');
    edtCampos_TipoFP.SetFocus;
    Exit;
  end;

  if (chkCampo_IsPrimaryKey.Checked) then begin
    if TemChavePrimaria then begin
      ShowPopupMessage(self, ViewEditarTabela.MenuCampoBotaoSalvarMensagem1, mptWarning);
      Exit;
    end;
    if chkCampo_ExcluirDoInsertUpdate.Checked then begin
      ShowPopupMessage(self, ViewEditarTabela.MenuCampoBotaoSalvarMensagem2, mptWarning);
      Exit;
    end;
  end;

  if (chkCampo_IsRequerido.Checked) and (chkCampo_ExcluirDoInsertUpdate.Checked) then begin
    ShowPopupMessage(self, ViewEditarTabela.MenuCampoBotaoSalvarMensagem3, mptWarning);
    Exit;
  end;

  if (chkCampo_IncruirNaListaDbGrid.Checked) and (chkCampo_ExcluirDoInsertUpdate.Checked) then begin
    ShowPopupMessage(self, ViewEditarTabela.MenuCampoBotaoSalvarMensagem4, mptWarning);
    Exit;
  end;

  if (LowerCase(cboObjetos.Text) = 'tcombobox') or (chkCampo_IsForeignKey.Checked) then begin
    if (Trim(edtCampos_TabelaFK.Text) = '') and
       (Trim(edtCampos_CampoCodigoFK.Text) = '') and
       (Trim(edtCampos_CampoTextoFK.Text) = '') and
       (Trim(edtCampos_ComboCampoValores.Text) = '') then
         cboObjetos.Text := 'TEdit';
  end;

  if (LowerCase(edtCampos_TipoFP.Text) = 'boolean') then
       cboObjetos.ItemIndex := 2; //TCheckBox

  // aceita TCheckBox se for Integer
  if (LowerCase(cboObjetos.Text) = 'tcheckbox') and (Pos(LowerCase(edtCampos_TipoFP.Text), 'integer,boolean') = 0) then
    cboObjetos.Text := 'TEdit';

  if chkCampo_IsPrimaryKey.Checked or chkCampo_IsForeignKey.Checked then
    chkCampo_RptSomatorio.Checked := False;

  //campo somatório no report
  if chkCampo_RptSomatorio.Checked and (Pos(LowerCase(edtCampos_TipoFP.Text), 'integer,currency,double,float') = 0) then
    chkCampo_RptSomatorio.Checked := False;

  if chkCampo_RptSomatorio.Checked and not chkCampo_IncruirNaListaDbGrid.Checked then
    chkCampo_RptSomatorio.Checked := False;

  //checa os campos requeridos de preenchimento
  v := TUtilValidacaoCampos.Create(PageCampos);
  msg := v.Message;
  v.Free;
  if msg <> '' then begin
    msg += sLineBreak + sLineBreak + ViewEditarTabela.MenuCampoBotaoSalvarMensagem5;
    if QuestionDlg(ViewEditarTabela.MenuCampoBotaoSalvarMensagem6, msg, mtConfirmation, [mrYes, ViewEditarTabela.MenuCampoBotaoSalvarMensagem7, mrNo, ViewEditarTabela.MenuCampoBotaoSalvarMensagem8, 'IsDefault'], '') <> mrYes then
      Exit;
  end;

  //confirma as informações ?
  if StrToIntDef(edtCampo_ID.Text, 0) < 1 then
    msg := ViewEditarTabela.MenuCampoBotaoSalvarMensagem9
  else
    msg := ViewEditarTabela.MenuCampoBotaoSalvarMensagem10;

  if QuestionDlg(ViewEditarTabela.MenuCampoBotaoSalvarMensagem11, msg, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
    exit;

  Campos_Salvar( StrToIntDef(edtCampo_ID.Text, 0) );
end;

procedure TfrmEditarTabela.btnCampo_ExcluirClick(Sender: TObject);
//excluir o campo
begin
  if StrToIntDef(edtCampo_ID.Text, 0) < 1 then begin
    ShowPopupMessage(self, ViewEditarTabela.MenuCampoBotaoSalvarMensagem12, mptWarning);
    Exit;
  end;

  if QuestionDlg(QuestionDialog.Titulo, ViewEditarTabela.MenuCampoBotaoSalvarMensagem13, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
     exit;

  Campos_Excluir( StrToIntDef(edtCampo_ID.Text, 0) );
end;

procedure TfrmEditarTabela.btnCampo_NovoClick(Sender: TObject);
//novo campo
begin
  Campos_LimparCampos;
end;

procedure TfrmEditarTabela.btnTabela_NovoClick(Sender: TObject);
//limpar campos
begin
  Tabelas_LimparCampos;
end;

procedure TfrmEditarTabela.edtPesquisaChange(Sender: TObject);
begin
  lblTabelasPreparadasQde.Caption := '0';
  if (dgTabelas.DataSource = nil) or (dgTabelas.DataSource.DataSet = nil) then Exit;

  try
    with dgTabelas.DataSource.DataSet do begin
      FilterOptions := [foCaseInsensitive]; //Uses DB
      Filtered := False;
      Filter   := 'tabela like ' + QuotedStr('*' + edtPesquisa.Text + '*'); //não funciona com TSQLQuery
      Filtered := True;
    end;
  except
  end;

  if (dgTabelas.DataSource <> nil) and (dgTabelas.DataSource.DataSet <> nil) then
    lblTabelasPreparadasQde.Caption := dgTabelas.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmEditarTabela.edtTabela_ApiRotaEnter(Sender: TObject);
begin
  if Trim(edtTabela_ApiRota.Text) = '' then
    edtTabela_ApiRota.Text := '/' + LowerCase( edtTabela_Objeto.Text );
end;

procedure TfrmEditarTabela.edtTabela_ApiRotaExit(Sender: TObject);
begin
  if Trim(edtTabela_ApiRota.Text) = '' then
     edtTabela_ApiRota.Text := '/' + LowerCase( edtTabela_Objeto.Text )
  else
  begin
    try
      while LeftStr(edtTabela_ApiRota.Text, 2) = '//' do
        edtTabela_ApiRota.Text := MidStr(edtTabela_ApiRota.Text, 2, Length(edtTabela_ApiRota.Text)-1);

      while RightStr(edtTabela_ApiRota.Text, 1) = '/' do
        edtTabela_ApiRota.Text := LeftStr(edtTabela_ApiRota.Text, Length(edtTabela_ApiRota.Text)-1);
    except
      edtTabela_ApiRota.Text := '/' + LowerCase( edtTabela_Objeto.Text );
    end;
  end;
end;

procedure TfrmEditarTabela.edtTabela_ObjetoExit(Sender: TObject);
begin
  if Trim(edtTabela_Objeto.Text) = '' then
     edtTabela_Objeto.Text := Trim(edtTabela_NomeTabela.Text);

  edtTabela_Objeto.Text := RemoveFieldUnderscore( edtTabela_Objeto.Text );

  if (edtTabela_ApiRota.Text) = '' then
    edtTabela_ApiRota.Text := '/' + LowerCase( edtTabela_Objeto.Text );
end;

procedure TfrmEditarTabela.edtTabela_ScriptEnter(Sender: TObject);
begin
  Funcoes.EditBackColor(Sender, True);
end;

procedure TfrmEditarTabela.edtTabela_ScriptExit(Sender: TObject);
begin
  Funcoes.EditBackColor(Sender, False);
end;

procedure TfrmEditarTabela.lblMenuCamposClick(Sender: TObject);
begin
  if (StrToIntDef(edtTabela_ID.Text, 0) < 1) then Exit;
  MenuOpcoesColor;
  lblMenuCampos.Tag := 1;
  (Sender as TLabelPlus).Color := FOpcoesMenuSelectedColor;
  NotebookTabelas.Page[1].Show;
end;

procedure TfrmEditarTabela.lblMenuCamposMouseEnter(Sender: TObject);
begin
  (Sender as TLabelPlus).Color := FOpcoesMenuOverColor;
end;

procedure TfrmEditarTabela.lblMenuCamposMouseLeave(Sender: TObject);
begin
  if (Sender as TLabelPlus).Tag = 0 then
    (Sender as TLabelPlus).Color := FOpcoesMenuDefaultColor
  else
    (Sender as TLabelPlus).Color := FOpcoesMenuSelectedColor;
end;

procedure TfrmEditarTabela.lblMenuTabelasClick(Sender: TObject);
begin
  if FIdProjeto < 1 then Exit;
  MenuOpcoesColor;
  lblMenuTabelas.Tag := 1;
  (Sender as TLabelPlus).Color := FOpcoesMenuSelectedColor;
  NotebookTabelas.Page[0].Show;
end;

procedure TfrmEditarTabela.lblMenuTabelasMouseEnter(Sender: TObject);
begin
  (Sender as TLabelPlus).Color := FOpcoesMenuOverColor;
end;

procedure TfrmEditarTabela.lblMenuTabelasMouseLeave(Sender: TObject);
begin
  if (Sender as TLabelPlus).Tag = 0 then
    (Sender as TLabelPlus).Color := FOpcoesMenuDefaultColor
  else
    (Sender as TLabelPlus).Color := FOpcoesMenuSelectedColor;
end;

procedure TfrmEditarTabela.lblTipoDadoHelpClick(Sender: TObject);
begin
  ShowMessage( ViewEditarTabela.MenuCampoBotaoSalvarMensagem18 +
               'string' + sLineBreak +
               'integer' + sLineBreak +
               'double' + sLineBreak +
               'currency' + sLineBreak +
               'boolean' + sLineBreak +
               'tdatetime' + sLineBreak +
               'timage');
end;

procedure TfrmEditarTabela.Tabelas_CarregaGrid;
//obter a lista de tabelas no host
begin
  lblTabelasPreparadasQde.Caption := '0';
  dgTabelas.ClearRows;

  with TServiceTabela.Create( IdProjeto ) do begin
    dgTabelas.DataSource := DataSetTabelas('');
    //Free; // não usar
  end;

  if (dgTabelas.DataSource <> nil) and (dgTabelas.DataSource.DataSet <> nil) then
    lblTabelasPreparadasQde.Caption := dgTabelas.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmEditarTabela.Tabelas_LimparCampos;
//limpa tabela e os campos
begin
  FIdTabela := 0;
  edtTabela_ID.Text := '0';
  edtTabela_NomeTabela.Clear;
  edtTabela_Objeto.Clear;
  edtTabela_Script.Clear;
  edtTabela_Descricao.Clear;
  chkTabela_CriarFormPesquisa.Checked := False;
  chkTabela_CriarGrid.Checked := False;
  chkTabela_CriarReport.Checked := False;
  chkTabela_CriarApi.Checked := False;
  chkTabela_IsForAuth.Checked := False;
  chkTabela_API_Get.Checked := False;
  chkTabela_API_Post.Checked := False;
  chkTabela_API_Put.Checked := False;
  chkTabela_API_Patch.Checked := False;
  chkTabela_API_Delete.Checked := False;
  edtTabela_ApiRota.Clear;

  //CampoEspecial;

  lblMenuTabelasClick(lblMenuTabelas);

  //campos
  lblCampo_NomeTabela.Caption := ViewEditarTabela.MenuCampoTabelaSelecionada('');
  lblCamposTabelaQde.Caption := '0';
  Campos_LimparCampos;
  Campos_CarregaGrid;
end;

procedure TfrmEditarTabela.Tabelas_Ler(AIdTabela: Integer);
//ler dados da tabela
var
  t: TServiceTabela;
begin
  Tabelas_LimparCampos;

  t := TServiceTabela.Create( IdProjeto );

  if t.Ler( AIdTabela ) then begin
    FIdTabela                           := t.IdTabela;
    edtTabela_ID.Text                   := t.IdTabela.ToString ;
    edtTabela_NomeTabela.Text           := t.Tabela;
    edtTabela_Objeto.Text               := t.NomeObjeto;
    edtTabela_Script.Text               := t.ScriptTabela;
    edtTabela_Descricao.Text            := t.Descricao;
    chkTabela_CriarFormPesquisa.Checked := t.CriarFormPesquisa;
    chkTabela_CriarGrid.Checked         := t.CriarDbGridForm;
    chkTabela_CriarReport.Checked       := t.CriarReport;
    chkTabela_IsForAuth.Checked         := t.IsForAuth;
    chkTabela_CriarApi.Checked          := t.CriarApi;
    chkTabela_API_Get.Checked           := t.ApiGet;
    chkTabela_API_Post.Checked          := t.ApiPost;
    chkTabela_API_Put.Checked           := t.ApiPut;
    chkTabela_API_Patch.Checked         := t.ApiPatch;
    chkTabela_API_Delete.Checked        := t.ApiDelete;
    edtTabela_ApiRota.Text              := t.ApiRota;

    lblCampo_NomeTabela.Caption := ViewEditarTabela.MenuCampoTabelaSelecionada( t.Tabela.ToUpper );
    lblMenuTabelasClick(lblMenuTabelas);
    Campos_CarregaGrid;
  end else
    ShowPopupMessage(self, t.GetErro, mptWarning);

  t.Free;
end;

procedure TfrmEditarTabela.Tabelas_Salvar(AIdTabela: Integer);
//alterar a tabela
var
  t: TServiceTabela;
begin
  t := TServiceTabela.Create( IdProjeto );
  t.Tabela            := Trim( edtTabela_NomeTabela.Text );
  t.NomeObjeto        := Trim( edtTabela_Objeto.Text );
  t.CriarFormPesquisa := chkTabela_CriarFormPesquisa.Checked;
  t.CriarDbGridForm   := chkTabela_CriarGrid.Checked;
  t.CriarReport       := chkTabela_CriarReport.Checked;
  t.CriarApi          := chkTabela_CriarApi.Checked;
  t.ApiGet            := chkTabela_API_Get.Checked;
  t.ApiPost           := chkTabela_API_Post.Checked;
  t.ApiPut            := chkTabela_API_Put.Checked;
  t.ApiPatch          := chkTabela_API_Patch.Checked;
  t.ApiDelete         := chkTabela_API_Delete.Checked;
  t.ApiRota           := Trim( edtTabela_ApiRota.Text );
  t.ScriptTabela      := Trim( edtTabela_Script.Text );
  t.Descricao         := Trim( edtTabela_Descricao.Text );
  t.IsForAuth         := chkTabela_IsForAuth.Checked;

  if t.Salvar( AIdTabela, True ) > 0 then begin
    lblMenuTabelasClick(lblMenuTabelas);
    FAtualizarGrid := True;
    Tabelas_CarregaGrid;
    ShowPopupMessage(self, ViewEditarTabela.MenuCampoBotaoSalvarMensagem14, mptSuccess);
  end else
    ShowPopupMessage(self, t.GetErro, mptFatal);

  t.Free;
end;

procedure TfrmEditarTabela.Tabelas_Excluir(AIdTabela: Integer);
//excluir a tabela
var
  t: TServiceTabela;
begin
  t := TServiceTabela.Create( IdProjeto );

  if t.Deletar( AIdTabela ) then begin
    ShowPopupMessage(self, ViewEditarTabela.MenuCampoBotaoSalvarMensagem15, mptSuccess);
    Tabelas_LimparCampos;
    Tabelas_CarregaGrid;
    lblMenuTabelasClick(lblMenuTabelas);
    FAtualizarGrid := True;
  end else
    ShowPopupMessage(self, t.GetErro, mptFatal);

  t.Free;
end;

procedure TfrmEditarTabela.Campos_CarregaGrid;
//carrega a grid de campos
begin
  lblCamposTabelaQde.Caption := '0';
  dgCampos.ClearRows;

  with TServiceCampo.Create( FIdTabela ) do begin
    dgCampos.DataSource := DataSetCampos('');
    //Free; // não usar
  end;

  if (dgCampos.DataSource <> nil) and (dgCampos.DataSource.DataSet <> nil) then
    lblCamposTabelaQde.Caption := dgCampos.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmEditarTabela.Campos_LimparCampos;
begin
  Invalidate;
  edtCampo_ID.Text := '0';
  edtCampo_NomeCampo.Clear;
  edtCampo_NomeCampoAlias.Clear;
  edtCampo_Objeto.Clear;
  edtCampo_Ordem.Clear;
  edtCampo_Tipo.Clear;
  edtCampo_MaxLength.Clear;
  edtCampo_Precisao.Clear;
  edtCampo_Escala.Clear;
  edtCampos_TipoFP.Clear;
  cboCampoEspecial.ItemIndex := 0;
  cboObjetos.ItemIndex := 0;
  edtCampos_TabelaFK.Clear;
  edtCampos_CampoCodigoFK.Clear;
  edtCampos_CampoTextoFK.Clear;
  edtCampos_ComboCampoValores.Clear;
  chkCampo_IsPrimaryKey.Checked := False;
  chkCampo_IsForeignKey.Checked := False;
  chkCampo_IsMonetario.Checked  := False;
  chkCampo_IncruirNaListaDbGrid.Checked := False;
  chkCampo_IsRequerido.Checked := False;
  chkCampo_ExcluirDoInsertUpdate.Checked := False;
  chkCampo_RptSomatorio.Checked := False;
  chkCampo_AceitaNull.Checked := False;
  chkCampo_RemoverMascara.Checked := False;
  edtCampos_descricao.Clear;
  panCampos_DadosExternos.Enabled := False;
end;

procedure TfrmEditarTabela.Campos_Ler(AIdCampo: Integer);
//ler dados do campo
var
  c: TServiceCampo;
begin
  Campos_LimparCampos;

  c := TServiceCampo.Create( FIdTabela );

  if c.Ler(AIdCampo) then begin
     edtCampo_ID.Text                        := c.IdCampo.ToString;
     edtCampo_NomeCampo.Text                 := c.Campo;
     edtCampo_NomeCampoAlias.Text            := c.CampoAlias;
     edtCampo_Objeto.Text                    := c.Objeto;
     edtCampo_Ordem.Text                     := c.Ordem.ToString;
     edtCampo_Tipo.Text                      := c.Tipo;
     edtCampo_MaxLength.Text                 := c.Tamanho;
     edtCampo_Precisao.Text                  := c.Precisao;
     edtCampo_Escala.Text                    := c.Escala;
     edtCampos_TipoFP.Text                   := c.TipoFP;
     cboCampoEspecial.Text                   := c.CampoEspecial;
     cboObjetos.Text                         := c.Componente;
     edtCampos_TabelaFK.Text                 := c.FK_Tabela;
     edtCampos_CampoCodigoFK.Text            := c.FK_CampoCodigo;
     edtCampos_CampoTextoFK.Text             := c.FK_CampoTexto;
     edtCampos_ComboCampoValores.Text        := c.ComboLista;
     chkCampo_IsPrimaryKey.Checked           := c.IsChavePrimaria;
     chkCampo_IsForeignKey.Checked           := c.IsChaveEstrangeira;
     chkCampo_IsMonetario.Checked            := c.IsCurrencyField;
     chkCampo_IncruirNaListaDbGrid.Checked   := c.IncluirNaGrid;
     chkCampo_IsRequerido.Checked            := c.IsRequerido;
     chkCampo_ExcluirDoInsertUpdate.Checked  := c.ExcluirDoInsertUpdate;
     chkCampo_RptSomatorio.Checked           := c.Report_Somatorio;
     edtCampos_descricao.Text                := c.Descricao;
     chkCampo_AceitaNull.Checked             := c.AceitaNull;
     chkCampo_RemoverMascara.Checked         := c.RemoverMascara;

     panCampos_DadosExternos.Enabled := ((Trim(cboObjetos.Text) = 'TComboBox') or c.IsChaveEstrangeira);
  end else
    ShowPopupMessage(self, c.GetErro, mptWarning);

  c.Free;
end;

procedure TfrmEditarTabela.Campos_Salvar(AIdCampo: Integer);
//salvar dados do campo
var
  c: TServiceCampo;
begin
  c := TServiceCampo.Create( FIdTabela );

  c.Campo                 := Trim(edtCampo_NomeCampo.Text);
  c.CampoAlias            := Trim(edtCampo_NomeCampoAlias.Text);
  c.Objeto                := Trim(edtCampo_Objeto.Text);
  c.Ordem                 := StrToIntDef(edtCampo_Ordem.Text, 1);
  c.Tipo                  := Trim(edtCampo_Tipo.Text);
  c.Tamanho               := Trim(edtCampo_MaxLength.Text);
  c.Precisao              := Trim(edtCampo_Precisao.Text);
  c.Escala                := Trim(edtCampo_Escala.Text);
  c.TipoFP                := Trim(edtCampos_TipoFP.Text);
  c.CampoEspecial         := Trim(cboCampoEspecial.Text);
  c.Componente            := Trim(cboObjetos.Text);
  c.FK_Tabela             := Trim(edtCampos_TabelaFK.Text);
  c.FK_CampoCodigo        := Trim(edtCampos_CampoCodigoFK.Text);
  c.FK_CampoTexto         := Trim(edtCampos_CampoTextoFK.Text);
  c.ComboLista            := Trim(edtCampos_ComboCampoValores.Text);
  c.IsChavePrimaria       := chkCampo_IsPrimaryKey.Checked;
  c.IsChaveEstrangeira    := chkCampo_IsForeignKey.Checked;
  c.IsCurrencyField       := chkCampo_IsMonetario.Checked;
  c.IncluirNaGrid         := chkCampo_IncruirNaListaDbGrid.Checked;
  c.IsRequerido           := chkCampo_IsRequerido.Checked;
  c.ExcluirDoInsertUpdate := chkCampo_ExcluirDoInsertUpdate.Checked;
  c.Report_Somatorio      := chkCampo_RptSomatorio.Checked;
  c.Descricao             := Trim(edtCampos_descricao.Text); //250
  c.AceitaNull            := chkCampo_AceitaNull.Checked;
  c.RemoverMascara        := chkCampo_RemoverMascara.Checked;

  if c.Salvar(AIdCampo, (AIdCampo>0)) > 0 then begin
    Campos_CarregaGrid;
    ShowPopupMessage(self, ViewEditarTabela.MenuCampoBotaoSalvarMensagem16, mptSuccess);
  end else
    ShowPopupMessage(self, c.GetErro, mptFatal);

  c.Free;
end;

procedure TfrmEditarTabela.Campos_Excluir(AIdCampo: Integer);
//exclusão do campo
var
  c: TServiceCampo;
begin
  c := TServiceCampo.Create( FIdTabela );

  if c.Deletar(AIdCampo) then begin
    Campos_LimparCampos;
    Campos_CarregaGrid;
    ShowPopupMessage(self, ViewEditarTabela.MenuCampoBotaoSalvarMensagem17, mptSuccess);
  end else
    ShowPopupMessage(self, c.GetErro, mptFatal);

  c.Free;
end;

procedure TfrmEditarTabela.MenuOpcoesColor;
//normaliza o menu
var
  cor: TColor;
begin
  if FIdProjeto < 1 then cor := TColor($404040) else cor := clWhite;
  lblMenuTabelas.Color := FOpcoesMenuDefaultColor;
  lblMenuTabelas.Font.Color := cor;
  lblMenuTabelas.Tag := 0;

  if FIdTabela < 1 then cor := TColor($404040) else cor := clWhite;
  lblMenuCampos.Color := FOpcoesMenuDefaultColor;
  lblMenuCampos.Font.Color := cor;
  lblMenuCampos.Tag := 0;
end;

function TfrmEditarTabela.CapitalizaTexto(AValue: String): String;
//Transforma a primeira letra em maiúscula
begin
  if AValue.Length > 1 then
     Result := UpperCase(AValue.Substring(0, 1)) + AValue.Substring(1)
  else
    Result := AValue.ToUpper;
end;

function TfrmEditarTabela.RemoveFieldUnderscore(AValue: String): String;
//remove o underscore entre as palavras: Ex: id_produto --> IdProduto
var
  s: array of string;
  i: Integer;
begin
  Result := Trim(AValue);

  if AValue.IndexOf('_') > 0 then begin
    s := AValue.Split('_');
    Result := '';

    for i := 0 to High(s) do
      Result := Result + CapitalizaTexto( s[i].Trim() );

    SetLength(s, 0);
  end
  else
    Result := CapitalizaTexto( Result );
end;

function TfrmEditarTabela.ValidaTipoFPC(): Boolean;
//valida o tipo de dado aceito
begin
  Result := False;
  case LowerCase(edtCampos_TipoFP.Text) of
    'string': Result := True;
    'integer': Result := True;
    'double': Result := True;
    'currency': Result := True;
    'boolean': Result := True;
    'tdatetime': Result := True;
    'timage': Result := True;
  end;
end;

function TfrmEditarTabela.TemChavePrimaria: Boolean;
//verifica se há chave primária
var
  i, id: integer;
begin
  Result := False;

  if (dgCampos.DataSource = nil) or (dgCampos.DataSource.DataSet.RecordCount < 1) then Exit;

  id := StrToIntDef(edtCampo_ID.Text, 0);

  dgCampos.DataSource.DataSet.First;

  for i := 0 to dgCampos.DataSource.DataSet.RecordCount -1 do begin
    if (dgCampos.DataSource.DataSet.FieldByName('idcampo').AsInteger <> id) and
       (dgCampos.DataSource.DataSet.FieldByName('is_pk').AsString = 'S') then begin
      Result := True;
      Break;
    end;

    dgCampos.DataSource.DataSet.Next;
  end;

  dgCampos.DataSource.DataSet.First;
end;

procedure TfrmEditarTabela.CampoEspecial;
begin
  if not Assigned(cboCampoEspecial) then Exit;

  cboCampoEspecial.Items.Clear;
  cboCampoEspecial.Items.Add('');

  if chkTabela_IsForAuth.Checked then begin
    cboCampoEspecial.Items.Add('AUTH_NAME');
    cboCampoEspecial.Items.Add('AUTH_USERNAME');
    cboCampoEspecial.Items.Add('AUTH_PASSWORD_CLEAR');
    cboCampoEspecial.Items.Add('AUTH_PASSWORD_MD5');
  end
  else begin
    cboCampoEspecial.Items.Add('CPF');
    cboCampoEspecial.Items.Add('CNPJ');
    cboCampoEspecial.Items.Add('CPF_CNPJ');
    cboCampoEspecial.Items.Add('TELEFONE');
    cboCampoEspecial.Items.Add('PERCENTUAL');
    cboCampoEspecial.Items.Add('CEP');
    cboCampoEspecial.Items.Add('LOGRADOURO');
    cboCampoEspecial.Items.Add('NUMERO');
    cboCampoEspecial.Items.Add('COMPLEMENTO');
    cboCampoEspecial.Items.Add('BAIRRO');
    cboCampoEspecial.Items.Add('CIDADE');
    cboCampoEspecial.Items.Add('UF');
  end;
end;

procedure TfrmEditarTabela.AjustaIdioma;
//exibe no idioma selecionado
begin
  panTop.Caption := ViewEditarTabela.Titulo;
  lblMenuTabelas.Caption := ViewEditarTabela.MenuTabelaText;
  lblMenuTabelas.Hint := ViewEditarTabela.MenuTabelaHint;
  lblMenuCampos.Caption := ViewEditarTabela.MenuCampoText;
  lblMenuCampos.Hint := ViewEditarTabela.MenuCampoHint;
  //tabelas
  lblTabelasPreparadas.Caption := ViewEditarTabela.MenuTabelaLabelTabelasPreparadas;
  ViewEditarTabela.MenuTabelaGrid(dgTabelas); // Títulos da grid
  edtPesquisa.Hint := ViewMain.MenuControleEditPesquisa;
  edtPesquisa.Placeholder := ViewMain.MenuControleEditPesquisa;
  lblTabelasDados.Caption := ViewEditarTabela.MenuTabelaLabelDados.ToUpper;
  lblTabelasNome.Caption := ViewEditarTabela.MenuTabelaLabelNomeTabela;
  lblTabelasNomeObjeto.Caption := ViewEditarTabela.MenuTabelaLabelNomeObjeto;
  lblTabelasDescricao.Caption := ViewEditarTabela.MenuTabelaLabelDescricao;
  lblTabelasScript.Caption := ViewEditarTabela.MenuTabelaLabelScript;
  chkTabela_CriarFormPesquisa.Caption := ViewEditarTabela.MenuTabelaCheckCriarFormText;
  chkTabela_CriarFormPesquisa.Hint := ViewEditarTabela.MenuTabelaCheckCriarFormHint;
  chkTabela_CriarGrid.Caption := ViewEditarTabela.MenuTabelaCheckCriarGridText;
  chkTabela_CriarGrid.Hint := ViewEditarTabela.MenuTabelaCheckCriarGridHint;
  chkTabela_CriarReport.Caption := ViewEditarTabela.MenuTabelaCheckCriarReportText;
  chkTabela_CriarReport.Hint := ViewEditarTabela.MenuTabelaCheckCriarReportHint;
  chkTabela_CriarApi.Caption := ViewEditarTabela.MenuTabelaCheckCriarApiText;
  chkTabela_CriarApi.Hint := ViewEditarTabela.MenuTabelaCheckCriarApiHint;
  chkTabela_IsForAuth.Caption := ViewEditarTabela.MenuTabelaCheckIsForAuthText;
  chkTabela_IsForAuth.Hint := ViewEditarTabela.MenuTabelaCheckIsForAuthHint;
  lblTabelasApiRota.Caption := ViewEditarTabela.MenuTabelaLabelApiRotaCaption;
  btnTabela_Salvar.Caption := ViewEditarTabela.MenuTabelaBotaoSalvarText;
  btnTabela_Excluir.Caption := ViewEditarTabela.MenuTabelaBotaoExcluirText;
  btnTabela_Novo.Caption := ViewEditarTabela.MenuTabelaBotaoNovoText;
  //campos
  lblCamposTabela.Caption := ViewEditarTabela.MenuCampoLabelTabelas;
  ViewEditarTabela.MenuCampoGrid(dgCampos);
  edtCampo_Pesquisa.Hint := ViewMain.MenuControleEditPesquisa;
  edtCampo_Pesquisa.Placeholder := ViewMain.MenuControleEditPesquisa;
  lblCamposDados.Caption := ViewEditarTabela.MenuCampoLabelDados.ToUpper;
  lblCamposField.Caption := ViewEditarTabela.MenuCampoLabelFied;
  lblCamposFieldAlias.Caption := ViewEditarTabela.MenuCampoLabelFiedAliasCaption;
  lblCamposFieldAlias.Hint := ViewEditarTabela.MenuCampoLabelFiedAliasHint;
  lblCamposObjeto.Caption := ViewEditarTabela.MenuCampoLabelObjeto;
  lblCamposObjeto.Hint := ViewEditarTabela.MenuCampoLabelObjetoHint;
  lblCamposTipo.Caption := ViewEditarTabela.MenuCampoLabelTipo;
  lblCamposTamanho.Caption := ViewEditarTabela.MenuCampoLabelTamanho;
  lblCamposPrecisao.Caption := ViewEditarTabela.MenuCampoLabelPrecisao;
  lblCamposEscala.Caption := ViewEditarTabela.MenuCampoLabelEscala;
  lblCamposTipoLazarus.Caption := ViewEditarTabela.MenuCampoLabelTipoLazarus;
  lblCamposEspecial.Caption := ViewEditarTabela.MenuCampoLabelCampoEspecial;
  lblCamposComponente.Caption := ViewEditarTabela.MenuCampoLabelComponente;
  lblCamposDescricao.Caption := ViewEditarTabela.MenuCampoLabelDescricao;
  lblCampos_FonteDadosFK.Caption := ViewEditarTabela.MenuCampoLabelFonteDados;
  lblCampos_TabelaFK.Caption := ViewEditarTabela.MenuCampoLabelComboTabela;
  edtCampos_TabelaFK.Placeholder := ViewEditarTabela.MenuCampoLabelComboTabelaExemplo;
  lblCampos_CodigoFK.Caption := ViewEditarTabela.MenuCampoLabelComboCodigo;
  edtCampos_CampoCodigoFK.Placeholder := ViewEditarTabela.MenuCampoLabelComboCodigoExemplo;
  lblCampos_CampoTextoFK.Caption := ViewEditarTabela.MenuCampoLabelComboTexto;
  edtCampos_CampoTextoFK.Placeholder := ViewEditarTabela.MenuCampoLabelComboTextoExemplo;
  lblCampos_ComboAlternativo.Caption := ViewEditarTabela.MenuCampoLabelComboValores;
  edtCampos_ComboCampoValores.Hint := ViewEditarTabela.MenuCampoLabelComboValoresHint;
  chkCampo_IsPrimaryKey.Caption := ViewEditarTabela.MenuCampoCheckChavePrimariaText;
  chkCampo_IsPrimaryKey.Hint := ViewEditarTabela.MenuCampoCheckChavePrimariaHint;
  chkCampo_AceitaNull.Caption := ViewEditarTabela.MenuCampoCheckAceitaNuloText;
  chkCampo_AceitaNull.Hint := ViewEditarTabela.MenuCampoCheckAceitaNuloHint;
  chkCampo_IsForeignKey.Caption := ViewEditarTabela.MenuCampoCheckChaveEstrangeiraText;
  chkCampo_IsForeignKey.Hint := ViewEditarTabela.MenuCampoCheckChaveEstrangeiraHint;
  chkCampo_IsMonetario.Caption := ViewEditarTabela.MenuCampoCheckMonetarioText;
  chkCampo_IsMonetario.Hint := ViewEditarTabela.MenuCampoCheckMonetarioHint;
  chkCampo_ExcluirDoInsertUpdate.Caption := ViewEditarTabela.MenuCampoCheckExcluirCrudText;
  chkCampo_ExcluirDoInsertUpdate.Hint := ViewEditarTabela.MenuCampoCheckExcluirCrudHint;
  chkCampo_IncruirNaListaDbGrid.Caption := ViewEditarTabela.MenuCampoCheckIncluirGridText;
  chkCampo_IncruirNaListaDbGrid.Hint := ViewEditarTabela.MenuCampoCheckIncluirGridHint;
  chkCampo_IsRequerido.Caption := ViewEditarTabela.MenuCampoCheckRequeridoText;
  chkCampo_IsRequerido.Hint := ViewEditarTabela.MenuCampoCheckRequeridoHint;
  chkCampo_RptSomatorio.Caption := ViewEditarTabela.MenuCampoCheckReportSomatorioText;
  chkCampo_RptSomatorio.Hint := ViewEditarTabela.MenuCampoCheckReportSomatorioHint;
  chkCampo_RemoverMascara.Caption := ViewEditarTabela.MenuCampoCheckRemoverMaskText;
  chkCampo_RemoverMascara.Hint := ViewEditarTabela.MenuCampoCheckRemoverMaskHint;
  btnCampo_Salvar.Caption := ViewEditarTabela.MenuCampoBotaoSalvarText;
  btnCampo_Excluir.Caption := ViewEditarTabela.MenuCampoBotaoExcluirText;
  btnCampo_Novo.Caption := ViewEditarTabela.MenuCampoBotaoNovoText;
end;

end.

