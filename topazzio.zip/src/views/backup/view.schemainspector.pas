unit View.SchemaInspector;

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, DB,
  MSSQLConn, SQLDB, ZConnection, ZDataset, Grids, DBGrids, ComCtrls;


type

  { TFormSchemaInspector }

  TFormSchemaInspector = class(TForm)
    BtnLoadTables: TButton;
    BtnDescribe: TButton;
    Button1: TButton;
    ComboTables: TComboBox;
    DBGrid1: TDBGrid;
    MemoSQL: TMemo;
    StatusBar1: TStatusBar;
    ZConnection1: TZConnection;
    ZQuery1: TZQuery;
    ZForeignKeys: TZQuery;
    ZTableList: TZQuery;
    DataSource1: TDataSource;
    procedure BtnDescribeClick(Sender: TObject);
    procedure BtnLoadTablesClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    procedure LoadTables;
    procedure DescribeTable(const TableName: string);
    procedure ShowForeignKeys(const TableName: string);
  end;

var
  FormSchemaInspector: TFormSchemaInspector;

implementation

{$R *.lfm}
procedure TFormSchemaInspector.FormCreate(Sender: TObject);
begin
  //ZConnection1.Protocol := 'sqlite'; // ou 'postgresql', 'mysql', etc.
  //ZConnection1.Database := ExtractFileDir( ParamStr(0) ) + PathDelim + 'apidoc.db';

  //Protocol=firebird;Server=localhost;Database=C:\Firebird\mydatabase.fdb;Port=3050;User=SYSDBA;Password=masterkey;Dialect=3;Charset=NONE
  ZConnection1.Protocol := 'firebird';
  ZConnection1.Database := ExtractFileDir( ParamStr(0) ) + PathDelim + 'quartos.fdb';
  ZConnection1.HostName := '192.168.1.20';
  ZConnection1.User := 'SYSDBA'; //'MARCIO';
  ZConnection1.Password := '123456';// 'masterkey';
  ZConnection1.Port := 3050;
  ZConnection1.Connected := True;
  LoadTables;
end;

procedure TFormSchemaInspector.BtnLoadTablesClick(Sender: TObject);
begin
  LoadTables;
end;

procedure TFormSchemaInspector.Button1Click(Sender: TObject);
var
  s: string;
begin
  // a exibição (MEMO) nos campos é por conta do Lazarus
  s := '';
  ZQuery1.First;
  while not ZQuery1.EOF do begin
    s := s + 'Campo: ' + ZQuery1.FieldByName('name').AsString +
             ', Tipo: ' + ZQuery1.FieldByName('type').AsString +
             ', Default: ' + ZQuery1.FieldByName('dflt_value').AsString +
             ', pk: ' + IntToStr(ZQuery1.FieldByName('pk').AsInteger) +
             sLineBreak;
    ZQuery1.Next;
  end;

  MemoSQL.Clear;
  MemoSQL.Text := s;
end;

procedure TFormSchemaInspector.BtnDescribeClick(Sender: TObject);
begin
  if ComboTables.Text <> '' then
  begin
    DescribeTable(ComboTables.Text);
    //ShowForeignKeys(ComboTables.Text);
  end;
end;

procedure TFormSchemaInspector.LoadTables;
begin
  ComboTables.Items.Clear;
  case ZConnection1.Protocol of
    'sqlite':
      ZTableList.SQL.Text := 'SELECT name FROM sqlite_master WHERE type=''table'' AND name NOT LIKE ''sqlite_%''';
    'postgresql':
      ZTableList.SQL.Text := 'SELECT tablename FROM pg_tables WHERE schemaname = ''public''';
    'mysql', 'mariadb':
      ZTableList.SQL.Text := 'SHOW TABLES';
    'firebird':
      ZTableList.SQL.Text := 'SELECT RDB$RELATION_NAME FROM RDB$RELATIONS WHERE RDB$SYSTEM_FLAG = 0';
    'mssql':
      ZTableList.SQL.Text := 'SELECT name FROM sysobjects WHERE xtype = ''U''';
    'oracle':
      ZTableList.SQL.Text := 'SELECT table_name FROM user_tables';
  else
    raise Exception.Create('SGBD não suportado');
  end;

  ZTableList.Open;
  ComboTables.Items.BeginUpdate;
  ComboTables.Items.Clear;
  while not ZTableList.EOF do
  begin
    ComboTables.Items.Add(Trim(ZTableList.Fields[0].AsString));
    ZTableList.Next;
  end;
  ComboTables.Items.EndUpdate;
  if ComboTables.Items.Count > 0 then
    ComboTables.ItemIndex := 0;
end;

procedure TFormSchemaInspector.DescribeTable(const TableName: string);
begin
  MemoSQL.Clear;
  ZQuery1.Close;

  // retorna create table ...
  // sqlite: SELECT sql FROM sqlite_master WHERE type = 'table' AND name = 'nome_da_tabela';
  // mysql/mariadb: SHOW CREATE TABLE nome_da_tabela;


  case ZConnection1.Protocol of
    'sqlite':
      ZQuery1.SQL.Text := 'PRAGMA table_info(' + TableName + ')';
    'postgresql':
      ZQuery1.SQL.Text :=
        'SELECT column_name, data_type, character_maximum_length, is_nullable, column_default '
        +'FROM information_schema.columns WHERE table_name = ''' + TableName + '''';
    'mysql', 'mariadb':
      ZQuery1.SQL.Text := 'SHOW FULL COLUMNS FROM ' + TableName;
    'firebird':
      ZQuery1.SQL.Text :=
       'select ' +
       'rf.rdb$field_name as column_name, ' +
       'case f.rdb$FIELD_SUB_TYPE ' +
       '  when 1 then ''NUMERIC''' +
       '  when 2 then ''DECIMAL''' +
       '  else ' +
       '   case f.rdb$field_type ' +
       '     when 7 then ''SMALLINT''' +
       '     when 8 then ''INTEGER''' +
       '     when 10 then ''FLOAT''' +
       '     when 12 then ''DATE''' +
       '     when 13 then ''TIME''' +
       '     when 14 then ''CHAR''' +
       '     when 16 then ''BIGINT''' +
       '     when 27 then ''DOUBLE''' +
       '     when 35 then ''TIMESTAMP''' +
       '     when 37 then ''VARCHAR''' +
       '     when 261 then ''BLOB''' +
       '     else ''''' +
       '   end ' +
       'end as data_type, ' +
       'f.rdb$field_length as max_length, ' +
       'f.rdb$field_scale, ' +
       'f.rdb$field_precision, ' +
       'case rf.RDB$NULL_FLAG ' +
       ' when 1 then 0 ' +
       ' else 1 ' +
       'end as is_nullable, ' +
       'COALESCE(rf.RDB$IDENTITY_TYPE, 0) as is_identity ' +
       'from rdb$fields f ' +
       'join rdb$relation_fields rf on rf.rdb$field_source = f.rdb$field_name ' +
       'where rf.rdb$relation_name =  ''' + UpperCase(TableName) + '''';
    'mssql':
      ZQuery1.SQL.Text :=
        'SELECT c.name AS column_name, t.name AS data_type, c.max_length, c.is_nullable, c.is_identity, ' +
        'c.precision, c.scale ' +
        'FROM sys.columns c JOIN sys.types t ON c.user_type_id = t.user_type_id ' +
        'WHERE c.object_id = OBJECT_ID(''dbo.' + TableName + ''')';
    'oracle':
      ZQuery1.SQL.Text :=
        'SELECT column_name, data_type, data_length as max_length, nullable as is_nullable, data_default, ' +
        '0 as precision, 0 as scale ' +
        'FROM user_tab_columns WHERE table_name = ''' + UpperCase(TableName) + '''';
  end;

  try
    ZQuery1.Open;
    DataSource1.DataSet := ZQuery1;
    MemoSQL.Lines.Add('--- Campos ---');
    MemoSQL.Lines.AddStrings(ZQuery1.SQL);
  except
    on E: Exception do
    begin
      ShowMessage('Erro ao descrever tabela: ' + E.Message);
    end;
  end;
end;

procedure TFormSchemaInspector.ShowForeignKeys(const TableName: string);
begin
  ZForeignKeys.Close;
  case ZConnection1.Protocol of
    'sqlite':
      ZForeignKeys.SQL.Text := 'PRAGMA foreign_key_list(' + TableName + ')';
    'postgresql':
      ZForeignKeys.SQL.Text :=
        'SELECT kcu.column_name, ccu.table_name AS foreign_table, ccu.column_name AS foreign_column '
        +'FROM information_schema.table_constraints tc '
        +'JOIN information_schema.key_column_usage kcu ON tc.constraint_name = kcu.constraint_name '
        +'JOIN information_schema.constraint_column_usage ccu ON ccu.constraint_name = tc.constraint_name '
        +'WHERE tc.constraint_type = ''FOREIGN KEY'' AND tc.table_name=''' + TableName + '''';
    'mysql', 'mariadb':
      ZForeignKeys.SQL.Text :=
        'SELECT column_name, referenced_table_name, referenced_column_name '
        +'FROM information_schema.key_column_usage '
        +'WHERE table_name = ''' + TableName + ''' AND referenced_table_name IS NOT NULL';
    'firebird':
      ZForeignKeys.SQL.Text :=
        'SELECT rc.RDB$CONSTRAINT_NAME, sg.RDB$FIELD_NAME, ix.RDB$RELATION_NAME AS referenced_table '
        +'FROM RDB$RELATION_CONSTRAINTS rc '
        +'JOIN RDB$REF_CONSTRAINTS refc ON rc.RDB$CONSTRAINT_NAME = refc.RDB$CONSTRAINT_NAME '
        +'JOIN RDB$INDEX_SEGMENTS sg ON rc.RDB$INDEX_NAME = sg.RDB$INDEX_NAME '
        +'JOIN RDB$INDICES ix ON ix.RDB$INDEX_NAME = refc.RDB$INDEX_NAME '
        +'WHERE rc.RDB$CONSTRAINT_TYPE = ''FOREIGN KEY'' AND rc.RDB$RELATION_NAME = ''' + UpperCase(TableName) + '''';
    'mssql':
      ZForeignKeys.SQL.Text :=
        'SELECT f.name AS fk_name, COL_NAME(fc.parent_object_id, fc.parent_column_id) AS column_name, '
        +'OBJECT_NAME(f.referenced_object_id) AS ref_table, COL_NAME(fc.referenced_object_id, fc.referenced_column_id) AS ref_column '
        +'FROM sys.foreign_keys f '
        +'JOIN sys.foreign_key_columns fc ON f.object_id = fc.constraint_object_id '
        +'WHERE f.parent_object_id = OBJECT_ID(''dbo.' + TableName + ''')';
    'oracle':
      ZForeignKeys.SQL.Text :=
        'SELECT a.column_name, r.table_name AS referenced_table '
        +'FROM user_cons_columns a '
        +'JOIN user_constraints c ON a.constraint_name = c.constraint_name '
        +'JOIN user_constraints r ON r.constraint_name = c.r_constraint_name '
        +'WHERE a.table_name = ''' + UpperCase(TableName) + ''' AND c.constraint_type = ''R''';
  end;

  try
    ZForeignKeys.Open;
    MemoSQL.Lines.Add('');
    MemoSQL.Lines.Add('--- Chaves Estrangeiras ---');
    while not ZForeignKeys.EOF do
    begin
      MemoSQL.Lines.Add(ZForeignKeys.Fields[0].AsString + ' -> ' + ZForeignKeys.Fields[1].AsString);
      ZForeignKeys.Next;
    end;
  except
    on E: Exception do
      MemoSQL.Lines.Add('Erro ao buscar chaves estrangeiras: ' + E.Message);
  end;
end;

end.


