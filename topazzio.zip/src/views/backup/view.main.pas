unit View.Main;

{$mode objfpc}{$H+}

interface

uses
  Classes, SysUtils, Forms, Controls, Graphics, Dialogs, StdCtrls, ExtCtrls,
  ComCtrls, Buttons, rxclock, PanelPlus, ButtonPlus, LabelPlus,
  DBGridPlus, CircularProgressBar, ToggleButtonPlus, CheckBoxPlus,
  MaskedEditPlus, DBGrids, Grids, DBCtrls, ComboEx, ExtDlgs, DB,
  Util.ProjetoCommon, Util.ProjetoLazarus, Util.ProjetoLazarusAPI;

type

  { TfrmMain }

  TfrmMain = class(TForm)
    btnCarregarLogoTipo: TSpeedButton;
    btnControle_Excluir: TButtonPlus;
    btnApi_Excluir: TButtonPlus;
    btnControle_Novo: TButtonPlus;
    btnControle_PathBancoDados: TBitBtn;
    btnControle_Salvar: TButtonPlus;
    btnApi_Salvar: TButtonPlus;
    btnControle_UsarProjeto: TButtonPlus;
    btnApi_Compilar: TButtonPlus;
    btnApi_EditarTabelas: TButtonPlus;
    btnApi_GerarProjeto: TButtonPlus;
    btnExcluirLogoTipo: TSpeedButton;
    btnProjeto_Raiz: TButtonPlus;
    btnProjeto_EditarTabelas: TButtonPlus;
    btnProjeto_Compilar: TButtonPlus;
    btnProjeto_GerarCrud: TButtonPlus;
    btnApi_Raiz: TButtonPlus;
    btnTabelas_Carregar: TButtonPlus;
    btnTabelas_Processar: TButtonPlus;
    btnTabela_Script: TButtonPlus;
    btnTabela_Editar: TButtonPlus;
    chkApi_Boleto: TCheckboxPlus;
    chkApi_GerarServiceClasse: TCheckboxPlus;
    chkApi_Audit: TCheckboxPlus;
    chkTabelas_CriarGrid: TCheckboxPlus;
    chkTabelas_CriarFormPesquisa: TCheckboxPlus;
    btnProjeto_BarraTituloColor: TColorButton;
    btnProjeto_FormColor: TColorButton;
    cboFlags: TComboBoxEx;
    cpbProjeto_Progresso: TCircularProgressBar;
    cpbApi_Progresso: TCircularProgressBar;
    cpbTabelas_Progresso: TCircularProgressBar;
    dgControle_Projetos: TDBGridPlus;
    dgProjeto_Tabelas: TDBGridPlus;
    dgApi_Tabelas: TDBGridPlus;
    dgTabelas: TDBGridPlus;
    edtApi_Footer2: TMaskedEditPlus;
    edtApi_Header1: TMaskedEditPlus;
    edtApi_Header2: TMaskedEditPlus;
    edtApi_Header3: TMaskedEditPlus;
    edtApi_Footer1: TMaskedEditPlus;
    edtApi_IdApi: TEdit;
    edtApi_Nome: TMaskedEditPlus;
    edtApi_Titulo: TMaskedEditPlus;
    edtApi_Versao: TMaskedEditPlus;
    edtApi_Host: TMaskedEditPlus;
    edtControle_IdProjeto: TEdit;
    edtApi_Porta: TMaskedEditPlus;
    edtApi_AdminEmail: TMaskedEditPlus;
    edtApi_AdminNome: TMaskedEditPlus;
    edtApi_Pesquisa: TMaskedEditPlus;
    edtTabela_Script: TMemo;
    imgLogoTipoProjeto: TImage;
    imgListFlags: TImageList;
    imgPix: TImage;
    imgBancoProjeto: TImage;
    imgControle_Banco: TImage;
    imgIcones: TImageList;
    imgLogo: TImage;
    imgListaDB: TImageList;
    imgLogo1: TImage;
    imgProjeto_Padrao: TImage;
    imgProjeto_Refresh: TImage;
    imgApiTabelas_Refresh: TImage;
    imgTabelas_LimparScript: TImage;
    lblApiHeader1: TLabel;
    lblApiHeader2: TLabel;
    lblApiHeader3: TLabel;
    lblApiHeader4: TLabel;
    lblApiHeader5: TLabel;
    lblApiTitulo: TLabel;
    lblApiVersao: TLabel;
    lblApiDescricao: TLabel;
    lblApiHost: TLabel;
    lblApiInformacoes: TLabel;
    lblApiNome: TLabel;
    lblApiPorta: TLabel;
    lblApiAdminEmail: TLabel;
    lblApiAdminNome: TLabel;
    lblMenuAPI: TLabelPlus;
    lblApiTabelas: TLabel;
    lblProjetoLogotipo: TLabel;
    lblProrjetosQde: TLabel;
    lblApiTabelasQde: TLabel;
    lblTabelasQde: TLabel;
    lblControleSenha: TLabel;
    lblControleNomeProjeto: TLabel;
    lblMenuControleGridTitulo: TLabel;
    lblControleDescricaoProjeto: TLabel;
    lblControleHost: TLabel;
    lblControlePorta: TLabel;
    lblProjetoInfoDB: TLabel;
    lblProjetoUsuario: TLabel;
    lblProjetoSenha: TLabel;
    lblTabelasScriptBox: TLabel;
    lblProjetoNomeApp: TLabel;
    lblProjetoDescricao: TLabel;
    Label22: TLabel;
    lblProjetoPorta: TLabel;
    lblProjetoSobre: TLabel;
    lblProjetoHost: TLabel;
    lblTabelasListagemServidor: TLabel;
    lblProjetoFormBar: TLabel;
    lblProjetoTabelasPreparadas: TLabel;
    lblProjetoFormCor: TLabel;
    lblProjetoCorBar: TLabel;
    lblProjetoFormFonte: TLabel;
    lblDescricao: TLabel;
    lblControleSgdb: TLabel;
    lblControleInformacoes: TLabel;
    lblControleSobreProjeto: TLabel;
    lblControleUsuario: TLabel;
    lblTabelasLista: TLabelPlus;
    lblTabelasScript: TLabelPlus;
    lblAutor: TLabel;
    lblAutor1: TLabel;
    lblControle_Database: TLabel;
    lblProjetoPathFile: TLabel;
    lblTabelasPreparadasQde: TLabel;
    lblTabelas_Exemplo: TLabel;
    lblTabelas_Exemplo2: TLabel;
    lblTabelas_Host: TLabelPlus;
    lblTitulo: TLabel;
    lblMenuControle: TLabelPlus;
    lblMenuProjeto: TLabelPlus;
    lblMenuTabelas: TLabelPlus;
    lblTitulo1: TLabel;
    lblTitulo2: TLabel;
    edtControle_Host: TMaskedEditPlus;
    edtControle_Porta: TMaskedEditPlus;
    edtControle_Banco: TMaskedEditPlus;
    edtControle_Usuario: TMaskedEditPlus;
    edtControle_Senha: TMaskedEditPlus;
    edtControle_NomeProjeto: TMaskedEditPlus;
    edtControle_Descricao: TMaskedEditPlus;
    edtControle_Pesquisa: TMaskedEditPlus;
    edtProjeto_Host: TMaskedEditPlus;
    edtProjeto_Porta: TMaskedEditPlus;
    edtProjeto_Banco: TMaskedEditPlus;
    edtProjeto_Usuario: TMaskedEditPlus;
    edtProjeto_Senha: TMaskedEditPlus;
    edtProjeto_NomeProjeto: TMaskedEditPlus;
    edtProjeto_Descricao: TMaskedEditPlus;
    edtProjeto_FonteNome: TMaskedEditPlus;
    edtProjeto_Pesquisa: TMaskedEditPlus;
    edtTabelas_Pesquisa: TMaskedEditPlus;
    edtApi_Descricao: TMemo;
    NotebookOpcoes: TNotebook;
    OpenPictureDialog1: TOpenPictureDialog;
    PageMenuAPI: TPage;
    PageMenuControle: TPage;
    PageMenuProjeto: TPage;
    PageMenuSobre: TPage;
    PageMenuTabelas: TPage;
    panBotoes: TPanel;
    panLogoTipo: TPanel;
    panTop: TPanelPlus;
    radControle_FireBird: TRadioButton;
    radControle_MariaDB: TRadioButton;
    radControle_MySql: TRadioButton;
    radControle_OracleSql: TRadioButton;
    radControle_PostgreSql: TRadioButton;
    radControle_SQLite: TRadioButton;
    radControle_SQLServer: TRadioButton;
    RxClock1: TRxClock;
    btnProjeto_FormFonte: TSpeedButton;
    StatusBar1: TStatusBar;
    tgProjeto_ModerUI: TToggleButtonPlus;
    tgProjeto_ApenasForm: TToggleButtonPlus;
    tgProjeto_ModuloChat: TToggleButtonPlus;
    Timer1: TTimer;
    procedure btnApi_CompilarClick(Sender: TObject);
    procedure btnApi_EditarTabelasClick(Sender: TObject);
    procedure btnApi_GerarProjetoClick(Sender: TObject);
    procedure btnApi_RaizClick(Sender: TObject);
    procedure btnApi_SalvarClick(Sender: TObject);
    procedure btnCarregarLogoTipoClick(Sender: TObject);
    procedure btnControle_ExcluirClick(Sender: TObject);
    procedure btnExcluirLogoTipoClick(Sender: TObject);
    procedure btnProjeto_CompilarClick(Sender: TObject);
    procedure btnProjeto_EditarTabelasClick(Sender: TObject);
    procedure btnProjeto_FormFonteClick(Sender: TObject);
    procedure btnProjeto_RaizClick(Sender: TObject);
    procedure btnTabela_EditarClick(Sender: TObject);
    procedure btnTabela_ScriptClick(Sender: TObject);
    procedure btnApi_ExcluirClick(Sender: TObject);
    procedure btnControle_NovoClick(Sender: TObject);
    procedure btnControle_PathBancoDadosClick(Sender: TObject);
    procedure btnControle_SalvarClick(Sender: TObject);
    procedure btnControle_UsarProjetoClick(Sender: TObject);
    procedure btnProjeto_GerarCrudClick(Sender: TObject);
    procedure btnTabelas_CarregarClick(Sender: TObject);
    procedure btnTabelas_ProcessarClick(Sender: TObject);
    procedure cboFlagsChange(Sender: TObject);
    procedure dgApi_TabelasCellClick(Column: TColumn);
    procedure dgApi_TabelasUserCheckboxState(Sender: TObject; Column: TColumn; var AState: TCheckboxState);
    procedure dgControle_ProjetosCellClick(Column: TColumn);
    procedure dgTabelasCellClick(Column: TColumn);
    procedure dgTabelasUserCheckboxState(Sender: TObject; Column: TColumn; var AState: TCheckboxState);
    procedure dgProjeto_TabelasCellClick(Column: TColumn);
    procedure dgProjeto_TabelasUserCheckboxState(Sender: TObject; Column: TColumn; var AState: TCheckboxState);
    procedure edtApi_DescricaoEnter(Sender: TObject);
    procedure edtApi_DescricaoExit(Sender: TObject);
    procedure edtApi_HostExit(Sender: TObject);
    procedure edtApi_NomeEnter(Sender: TObject);
    procedure edtApi_NomeExit(Sender: TObject);
    procedure edtApi_PesquisaChange(Sender: TObject);
    procedure edtApi_VersaoExit(Sender: TObject);
    procedure edtControle_NomeProjetoExit(Sender: TObject);
    procedure edtControle_PesquisaChange(Sender: TObject);
    procedure edtProjeto_FonteNomeExit(Sender: TObject);
    procedure edtTabelas_PesquisaChange(Sender: TObject);
    procedure edtProjeto_PesquisaChange(Sender: TObject);
    procedure edtTabela_ScriptEnter(Sender: TObject);
    procedure edtTabela_ScriptExit(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure imgApiTabelas_RefreshClick(Sender: TObject);
    procedure imgTabelas_LimparScriptClick(Sender: TObject);
    procedure imgProjeto_RefreshClick(Sender: TObject);
    procedure lblMenuAPIClick(Sender: TObject);
    procedure lblTabelas_Exemplo2Click(Sender: TObject);
    procedure lblTabelas_ExemploClick(Sender: TObject);
    procedure lblMenuControleClick(Sender: TObject);
    procedure LabelOpcoesMouseEnter(Sender: TObject);
    procedure LabelOpcoesMouseLeave(Sender: TObject);
    procedure lblMenuTabelasClick(Sender: TObject);
    procedure lblMenuProjetoClick(Sender: TObject);
    procedure panTopClick(Sender: TObject);
    procedure RadioSQLChange(Sender: TObject);
    procedure RadioSQLSelect(ATipoBanco: TTipoBanco);
    function PegaTipoBanco(): TTipoBanco;
    procedure tgProjeto_ApenasFormChange(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  private
    FOpcoesMenuDefaultColor, FOpcoesMenuOverColor, FOpcoesMenuSelectedColor: TColor;
    FIdProjeto: Integer;
    FProjeto_IdTipoBanco: TTipoBanco;
    FProjetoPastaRaiz: string;
    FControle_IdTipoBanco: TTipoBanco;
    FControle_TipoBanco: String;

    //permite alterar o state do checkbox na célula da grid
    RecList_HostTabelas: TBookmarklist;
    RecList_ProjetoTabelas: TBookmarklist;
    tabelas: TStringList;
    FProjetoListaTabelasID: string;
    FInfoTabelasRetorno: Boolean;
    GerarCrud: TProjetoLazarus;
    FGerarCrudRetorno: Boolean;
    FTabelasHost: TDataSource;

    GerarApi: TProjetoLazarusAPI;
    FApiListaTabelasID: string;
    FApiPastaRaiz: string;
    FApiPastaRelease: string;
    FGerarApiRetorno: Boolean;
    RecList_ApiTabelas: TBookmarklist;

    procedure AjustaIdioma;
    procedure Api_CarregaGrid(APesquisa: String);
    function Api_Salvar(AShowMessage: Boolean): Boolean;
    procedure Api_Excluir;
    procedure Api_Ler;
    procedure Api_Limpar;
    procedure Api_ProcessarCrud_Init;
    procedure Api_ProcessarCrud_End;
    procedure Api_Progresso(AValue: Boolean);

    procedure Controle_Salvar(AIdProjeto: Integer);
    procedure LoadLogotipoFromFile(AFileame: string);
    function RemoveEspacos(AString: String): String;
    procedure ControlaBotoes(AValue: Boolean);
    procedure MenuOpcoesColor;
    procedure Controle_Limpar;
    procedure Controle_Ler(AIdProjeto: Integer);
    procedure Controle_Excluir(AIdProjeto: Integer);
    procedure Controle_Novo;
    procedure Controle_CarregaGrid(APesquisa: String);
    procedure Tabelas_CarregaGrid(APesquisa: String);
    procedure Tabelas_Progresso(AValue: Boolean);
    procedure Tabelas_ProcessaScript_Init;
    procedure Tabelas_ProcessaScript_End;
    procedure Tabelas_ProcessaTabelas_Init;
    procedure Tabelas_ProcessaTabelas_End;
    procedure Tabelas_ProcessaObterTabelas_Init;
    procedure Tabelas_ProcessaObterTabelas_End;

    procedure Projeto_Ler(AIdProjeto: Integer);
    procedure Projeto_Limpar;
    procedure Projeto_CarregaGrid(APesquisa: String);
    procedure Projeto_Progresso(AValue: Boolean);
    procedure Projeto_ProcessarCrud_Init;
    procedure Projeto_ProcessarCrud_End;
  public

  end;

var
  frmMain: TfrmMain;

implementation

uses
  View.EditarTabela,
  View.Splash,
  Service.Projeto,
  Service.InfoTabelas,
  Service.Tabela,
  Service.RestApi,
  Util.EasyThead,
  Util.Funcoes,
  Util.MessagePopup,
  Util.AbrirPastaProjeto,
  Util.Idioma,
  Util.JsonFloat,
  View.Compilador;

var
  InfoTabelas: TServiceInfoTabelas;

{$R *.lfm}

{ TfrmMain }

procedure TfrmMain.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  if not dgControle_Projetos.Data_IsEmpty and (dgControle_Projetos.DataSource.DataSet<>nil) then
    dgControle_Projetos.DataSource.DataSet.Close;

  if not dgTabelas.Data_IsEmpty and (dgTabelas.DataSource.DataSet<>nil) then
    dgTabelas.DataSource.DataSet.Close;

  if not dgProjeto_Tabelas.Data_IsEmpty and (dgProjeto_Tabelas.DataSource.DataSet<>nil) then
    dgProjeto_Tabelas.DataSource.DataSet.Close;

  if Assigned(FTabelasHost) then FTabelasHost.Free;
end;

procedure TfrmMain.FormCreate(Sender: TObject);
begin
  JsonFloatNumber;

  panBotoes.Color := Funcoes.MenuCor;
  PageMenuControle.Color := Funcoes.MenuCorSelecionado;
  PageMenuProjeto.Color := Funcoes.MenuCorSelecionado;
  PageMenuTabelas.Color := Funcoes.MenuCorSelecionado;
  PageMenuAPI.Color := Funcoes.MenuCorSelecionado;
  PageMenuSobre.Color := clGray;
  StatusBar1.Color := Funcoes.MenuCor;
  RxClock1.Color := Funcoes.MenuCor;

  meu_idioma := ArquivoIdioma.LerIdioma;
  cboFlags.ItemIndex := Ord( meu_idioma );
  AjustaIdioma;
  RecList_HostTabelas := TBookmarkList.Create(dgTabelas);
  RecList_ProjetoTabelas := TBookmarkList.Create(dgProjeto_Tabelas);
  RecList_ApiTabelas := TBookmarkList.Create(dgApi_Tabelas);
end;

procedure TfrmMain.FormDestroy(Sender: TObject);
begin
  if Assigned(RecList_HostTabelas) then RecList_HostTabelas.Free;
  if Assigned(RecList_ProjetoTabelas) then RecList_ProjetoTabelas.Free;
  if Assigned(RecList_ApiTabelas) then RecList_ApiTabelas.Free;
end;

procedure TfrmMain.FormShow(Sender: TObject);
var
  f: TfrmSplash;
begin
  f := TfrmSplash.Create(nil);
  f.ShowModal;
  f.Destroy;

  FIdProjeto := 0;
  NotebookOpcoes.PageIndex := 3;
  FOpcoesMenuDefaultColor := Funcoes.MenuCor;
  FOpcoesMenuOverColor := Funcoes.MenuCorHover;
  FOpcoesMenuSelectedColor:= Funcoes.MenuCorSelecionado;
  Controle_CarregaGrid('');
  MenuOpcoesColor;
  Projeto_Limpar;
end;

procedure TfrmMain.btnProjeto_GerarCrudClick(Sender: TObject);
//gerar arquivos do projeto
var
  et: TEasyThread;
  b: TBookMark;
  i, qde, r: Integer;
  msg: String;
begin
  if (dgProjeto_Tabelas.Data_IsEmpty) or (dgProjeto_Tabelas.Data_RowsCount < 1) then
  begin
    ShowPopupMessage(self, ViewMain.MenuProjetoBotaoGerarCrudMensagem1, mptWarning);
    Exit;
  end;

  ControlaBotoes(False);

  qde := 0;
  FProjetoListaTabelasID := '';
  msg := ViewMain.MenuProjetoBotaoGerarCrudMensagem2;

  if RecList_ProjetoTabelas.Count > 0 then
  begin
    r := dgProjeto_Tabelas.Data_RowIndex; //linha atual

    for i := 0 to RecList_ProjetoTabelas.Count -1 do
    begin
      b := RecList_ProjetoTabelas.Items[i]; //array de 4 selementos, o index zero contém o número da linha na grid
      if FProjetoListaTabelasID <> '' then FProjetoListaTabelasID := FProjetoListaTabelasID + ',';
      FProjetoListaTabelasID := FProjetoListaTabelasID + dgProjeto_Tabelas.Data_RowFields( b[0] ).FieldByName('idtabela').AsString ;
      qde += 1;
    end;

    dgProjeto_Tabelas.Data_GoTo( r ); //volta para a linha antiga
  end;

  if qde > 0 then
    msg := ViewMain.MenuProjetoBotaoGerarCrudMensagem3(qde);

  if QuestionDlg(QuestionDialog.Titulo, msg, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
  begin
    ControlaBotoes(True);
    FProjetoListaTabelasID := '';
    Exit;
  end;

  //Inicia o processamento das tabelas
  ControlaBotoes(False);
  Projeto_Progresso(True);
  FProjetoPastaRaiz := '';
  btnProjeto_Raiz.Visible := False;

  et := TEasyThread.Create(True);
  et.ExecuteProcedure  := @Projeto_ProcessarCrud_Init;
  et.CallBackProcedure := @Projeto_ProcessarCrud_End;
  et.Start;
end;

procedure TfrmMain.btnTabelas_CarregarClick(Sender: TObject);
//obter tabelas do banco de dados
var
  et: TEasyThread;
begin
  lblTabelasQde.Caption := '0';
  RecList_HostTabelas.Clear;
  dgTabelas.ClearRows;

  ControlaBotoes(False);
  Tabelas_Progresso(True);

  et := TEasyThread.Create(True);
  et.ExecuteProcedure  := @Tabelas_ProcessaObterTabelas_Init;
  et.CallBackProcedure := @Tabelas_ProcessaObterTabelas_End;
  et.Start;
end;

procedure TfrmMain.btnTabelas_ProcessarClick(Sender: TObject);
//processa a lista de tabelas
var
  et : TEasyThread;
  b: TBookMark;
  SaveBookmark: TBookmark;
  i: Integer;
  l: String;
begin
  if (dgTabelas.Data_IsEmpty) or (dgTabelas.Data_RowsCount < 1) then
  begin
    ShowPopupMessage(self, ViewMain.MenuTabelasBotaoProcessarTabelasMensagem1, mptWarning);
    Exit;
  end;

  ControlaBotoes(False);

  tabelas := TStringList.Create;
  l := '';

  if RecList_HostTabelas.Count > 0 then
  begin
    for i := 0 to RecList_HostTabelas.Count -1 do
    begin
      b := RecList_HostTabelas.Items[i]; //array de 4 selementos
      l := l + '[' + b[0].ToString + '],';
    end;
  end;

  try
    // Salva a posição atual
    SaveBookmark := dgTabelas.DataSource.DataSet.GetBookmark;
    dgTabelas.DataSource.DataSet.DisableControls;
    dgTabelas.DataSource.DataSet.First;

    for i := 0 to dgTabelas.DataSource.DataSet.RecordCount -1 do
    begin
      if l.Length > 0 then
      begin
        if l.IndexOf( '[' + IntToStr(i+1) + '],' ) >= 0 then
          tabelas.Add( dgTabelas.DataSource.DataSet.FieldByName('table_name').AsString );
      end
      else
        tabelas.Add( dgTabelas.DataSource.DataSet.FieldByName('table_name').AsString );

      dgTabelas.DataSource.DataSet.Next;
    end;
  finally
    // Restaura a posição original
    dgTabelas.DataSource.DataSet.GotoBookmark(SaveBookmark);
    dgTabelas.DataSource.DataSet.FreeBookmark(SaveBookmark);
    dgTabelas.DataSource.DataSet.EnableControls;
  end;

  if QuestionDlg(QuestionDialog.Titulo, ViewMain.MenuTabelasBotaoProcessarTabelasMensagem2(tabelas.Count), mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
  begin
    ControlaBotoes(True);
    tabelas.Free;
    Exit;
  end;

  //Inicia o processamento das tabelas
  ControlaBotoes(False);
  Tabelas_Progresso(True);

  et := TEasyThread.Create(True);
  et.ExecuteProcedure  := @Tabelas_ProcessaTabelas_Init;
  et.CallBackProcedure := @Tabelas_ProcessaTabelas_End;
  et.Start;
 end;

procedure TfrmMain.cboFlagsChange(Sender: TObject);
begin
  meu_idioma := TUtilIdiomas( cboFlags.ItemIndex );
  ArquivoIdioma.SalvarIdioma( meu_idioma );
  AjustaIdioma;
end;

procedure TfrmMain.dgControle_ProjetosCellClick(Column: TColumn);
//clique na grid
begin
  if dgControle_Projetos.DataSource.DataSet.RecordCount > 0 then
    Controle_Ler( dgControle_Projetos.Columns.Items[0].Field.AsInteger );
end;

procedure TfrmMain.dgTabelasCellClick(Column: TColumn);
//click na linha ou célula
begin
  // https://wiki.lazarus.freepascal.org/Grids_Reference_Page#Selecting_Records_in_a_DBGrid_using_checkboxes
  if Column.Index = 1 then
    RecList_HostTabelas.CurrentRowSelected := not RecList_HostTabelas.CurrentRowSelected;
end;

procedure TfrmMain.dgTabelasUserCheckboxState(Sender: TObject; Column: TColumn; var AState: TCheckboxState);
// altera o state do checkbox
begin
  if RecList_HostTabelas.CurrentRowSelected then
    AState := cbChecked
  else
    AState := cbUnchecked;
end;

procedure TfrmMain.dgProjeto_TabelasCellClick(Column: TColumn);
begin
  //ShowMessage( dgProjeto_Tabelas.Data_RowFields(1).FieldByName('tabela').AsString ); //primeira linha da grid
  if Column.Index = 3 then
    RecList_ProjetoTabelas.CurrentRowSelected := not RecList_ProjetoTabelas.CurrentRowSelected;
end;

procedure TfrmMain.dgProjeto_TabelasUserCheckboxState(Sender: TObject; Column: TColumn; var AState: TCheckboxState);
// altera o state do checkbox
begin
  if RecList_ProjetoTabelas.CurrentRowSelected then
    AState := cbChecked
  else
    AState := cbUnchecked;
end;

procedure TfrmMain.edtApi_DescricaoEnter(Sender: TObject);
begin
  Funcoes.EditBackColor(Sender, True);
  if Trim(edtApi_Descricao.Text) = '' then
    edtApi_Descricao.Text := edtControle_Descricao.Text;
end;

procedure TfrmMain.edtApi_DescricaoExit(Sender: TObject);
begin
  Funcoes.EditBackColor(Sender, False);
end;

procedure TfrmMain.edtApi_HostExit(Sender: TObject);
var
  lHost: string;
begin
  lHost := Trim(edtApi_Host.Text);
  if Length(lHost) = 0 then Exit;

  if not lHost.StartsWith('http://', True) and
     not lHost.StartsWith('https://', True) then
     edtApi_Host.Text := 'http://' + edtApi_Host.Text;

  while RightStr(edtApi_Host.Text, 1) = '/' do
    edtApi_Host.Text := LeftStr(edtApi_Host.Text, Length(edtApi_Host.Text)-1);
end;

procedure TfrmMain.edtApi_NomeEnter(Sender: TObject);
begin
  if Trim(edtApi_Nome.Text) = '' then
    edtApi_Nome.Text := StringReplace(edtControle_NomeProjeto.Text, 'app_', 'api_', [rfReplaceAll]);
end;

procedure TfrmMain.edtApi_NomeExit(Sender: TObject);
// remove quaiquer espaços em branco
begin
  edtApi_Nome.Text := RemoveEspacos( edtApi_Nome.Text );
end;

procedure TfrmMain.edtApi_PesquisaChange(Sender: TObject);
begin
  lblApiTabelasQde.Caption := '0';
  //Api_CarregaGrid(edtApi_Pesquisa.Text);
  if (dgApi_Tabelas.Data_IsEmpty) or (dgApi_Tabelas.DataSource.DataSet = nil) then Exit;

  with dgApi_Tabelas.DataSource.DataSet do
  begin
    FilterOptions := [foCaseInsensitive]; //Uses DB
    Filtered := False;
    Filter   := 'tabela like ' + QuotedStr('*' + edtApi_Pesquisa.Text + '*');
    Filtered := True;
  end;

  if (dgApi_Tabelas.DataSource <> nil) and (dgApi_Tabelas.DataSource.DataSet <> nil) then
    lblApiTabelasQde.Caption := dgApi_Tabelas.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmMain.edtApi_VersaoExit(Sender: TObject);
begin
  while RightStr(edtApi_Versao.Text, 1) = '/' do
    edtApi_Versao.Text := LeftStr(edtApi_Versao.Text, Length(edtApi_Versao.Text)-1);

  if LeftStr(edtApi_Versao.Text, 1) <> '/' then
    edtApi_Versao.Text := '/' + edtApi_Versao.Text;
end;

procedure TfrmMain.edtControle_NomeProjetoExit(Sender: TObject);
// remove quaiquer espaços em branco
begin
  edtControle_NomeProjeto.Text := RemoveEspacos( edtControle_NomeProjeto.Text );
end;

procedure TfrmMain.edtControle_PesquisaChange(Sender: TObject);
//pesquisa na grid
begin
  lblProrjetosQde.Caption := '0';
  //Controle_CarregaGrid( Trim(edtControle_Pesquisa.Text) );
  if (dgControle_Projetos.Data_IsEmpty) or (dgControle_Projetos.DataSource.DataSet = nil) then Exit;

  with dgControle_Projetos.DataSource.DataSet do
  begin
    FilterOptions := [foCaseInsensitive]; //Uses DB
    Filtered := False;
    Filter   := 'projeto+tipo_banco like ' + QuotedStr('*' + edtControle_Pesquisa.Text + '*');// +
                //' OR tipo_banco like ' + QuotedStr('*' + edtControle_Pesquisa.Text + '*');
    Filtered := True;
  end;

  if (dgControle_Projetos.DataSource <> nil) and (dgControle_Projetos.DataSource.DataSet <> nil) then
    lblProrjetosQde.Caption := dgControle_Projetos.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmMain.edtProjeto_FonteNomeExit(Sender: TObject);
var
  f: array of string;
  s: string;
  i: Integer;
begin
  if Trim(edtProjeto_FonteNome.Text) = '' then
    edtProjeto_FonteNome.Text := 'Sans,default';

  f := Trim(edtProjeto_FonteNome.Text).Split([','], TStringSplitOptions.ExcludeEmpty);
  s := '';

  for i := 0 to High(f) do
  begin
    if s.Length>0 then s := s + ',';
    s := s + f[i];
  end;

  edtProjeto_FonteNome.Text := s;
end;

procedure TfrmMain.edtTabelas_PesquisaChange(Sender: TObject);
//pesquisa na grid
begin
  lblTabelasQde.Caption := '0';
  RecList_HostTabelas.Clear;
  dgTabelas.ClearRows;

  if FProjeto_IdTipoBanco = SQLSERVER then
    btnTabelas_CarregarClick(btnTabelas_Carregar)
  else
  begin
    if (dgTabelas.Data_IsEmpty) or (dgTabelas.DataSource.DataSet = nil) then Exit;

    try
      with dgTabelas.DataSource.DataSet do begin
        FilterOptions := [foCaseInsensitive]; //Uses DB
        Filtered := False;
        Filter   := 'table_name like ' + QuotedStr('*' + Trim(edtTabelas_Pesquisa.Text) + '*');
        Filtered := True;
        lblTabelasQde.Caption := dgTabelas.DataSource.DataSet.RecordCount.ToString;
      end;
    except
    end;
  end;
end;

procedure TfrmMain.edtProjeto_PesquisaChange(Sender: TObject);
begin
  lblTabelasPreparadasQde.Caption := '0';
  //Projeto_CarregaGrid(edtProjeto_Pesquisa.Text);
  if (dgProjeto_Tabelas.Data_IsEmpty) or (dgProjeto_Tabelas.DataSource.DataSet = nil) then Exit;

  with dgProjeto_Tabelas.DataSource.DataSet do
  begin
    FilterOptions := [foCaseInsensitive]; //Uses DB
    Filtered := False;
    Filter   := 'tabela like ' + QuotedStr('*' + edtProjeto_Pesquisa.Text + '*');
    Filtered := True;
  end;

  if (dgProjeto_Tabelas.DataSource <> nil) and (dgProjeto_Tabelas.DataSource.DataSet <> nil) then
    lblTabelasPreparadasQde.Caption := dgProjeto_Tabelas.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmMain.edtTabela_ScriptEnter(Sender: TObject);
begin
  Funcoes.EditBackColor(Sender, True);
end;

procedure TfrmMain.edtTabela_ScriptExit(Sender: TObject);
begin
  Funcoes.EditBackColor(Sender, False);
end;

procedure TfrmMain.btnControle_PathBancoDadosClick(Sender: TObject);
//abrir o path e arquivo de banco de dados
begin
  with TOpenDialog.Create(self) do
  begin
    Caption := ViewMain.MenuControlePathBancoDadosMensagem1;
    Filter := ViewMain.MenuControlePathBancoDadosMensagem2 + ' (*.db;*.fdb;*.sqlite;*.dbf)|*.db;*.fdb;*.sqlite;*.dbf|' + ViewMain.MenuControlePathBancoDadosMensagem3 + ' (*.*)|*.*';
    InitialDir := ExtractFileDir( ParamStr(0) );
    if Execute then
      edtControle_Banco.Text := FileName;
  end;
end;

procedure TfrmMain.btnControle_SalvarClick(Sender: TObject);
begin
if (Trim(edtControle_Host.Text) = '') or (Trim(edtControle_Banco.Text) = '') or
     (Trim(edtControle_Usuario.Text) = '') or (Trim(edtControle_Senha.Text) = '') then
  begin
    case FControle_IdTipoBanco of
      POSTGRE, MYSQL, MARIADB, SQLSERVER, ORACLE:
        begin
          ShowPopupMessage(self, ViewMain.MenuControleSalvarMensagem1, mptWarning);
          Exit;
        end;
    end;
  end;

  if Trim(edtApi_Nome.Text) = '' then
  begin
    ShowPopupMessage(self, ViewMain.MenuControleSalvarMensagem2, mptWarning);
    Exit;
  end;

  Controle_Salvar(FIdProjeto);
end;

procedure TfrmMain.btnControle_ExcluirClick(Sender: TObject);
//excluir o projeto
begin
  if StrToIntDef(edtControle_IdProjeto.Text, 0) < 1 then
  begin
    ShowPopupMessage(self, ViewMain.MenuControleExcluirMensagem1, mptWarning);
    Exit;
  end;

  if QuestionDlg(QuestionDialog.Titulo, ViewMain.MenuControleExcluirMensagem2, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
     exit;

  Controle_Excluir( StrToIntDef(edtControle_IdProjeto.Text, 0) );
end;

procedure TfrmMain.btnTabela_ScriptClick(Sender: TObject);
//processa script de tabela
var
  et: TEasyThread;
begin
  if not (LowerCase(Trim(edtTabela_Script.Text)).StartsWith('create table ', True)) then
  begin
    ShowPopupMessage(self, ViewMain.MenuTabelasBotaoScriptMensagem1, mptWarning);
    Exit;
  end;

  if QuestionDlg(QuestionDialog.Titulo, ViewMain.MenuTabelasBotaoScriptMensagem2, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
    Exit;

  //Inicia o processamento do script de tabela
  ControlaBotoes(False);
  Tabelas_Progresso(True);

  et := TEasyThread.Create(True);
  et.ExecuteProcedure  := @Tabelas_ProcessaScript_Init;
  et.CallBackProcedure := @Tabelas_ProcessaScript_End;
  et.Start;
end;

procedure TfrmMain.btnProjeto_EditarTabelasClick(Sender: TObject);
//editar tabela
var
  f: TfrmEditarTabela;
begin
  if (dgProjeto_Tabelas.Data_IsEmpty) then
  begin
    ShowPopupMessage(self, ViewMain.MenuProjetoBotaoEditarTabelaMensagem1, mptWarning);
    Exit;
  end;

  f := TfrmEditarTabela.Create(self);
  f.IdProjeto := FIdProjeto;
  f.imgBancoProjeto.ImageIndex := imgBancoProjeto.ImageIndex;
  f.ShowModal;

  if f.AtualizarGrid then
    Projeto_CarregaGrid('');

  f.Free;
end;

procedure TfrmMain.btnProjeto_CompilarClick(Sender: TObject);
//tela de compilação do projeto
var
  f: TfrmCompilador;
begin
  f := TfrmCompilador.Create(Self);
  f.Projeto_IsAPI := False;
  f.Projeto_Path := FProjetoPastaRaiz;
  f.Projeto_Nome := Trim(edtProjeto_NomeProjeto.Text);
  f.ShowModal;
  f.Free;
end;

procedure TfrmMain.btnProjeto_FormFonteClick(Sender: TObject);
begin
  with TFontDialog.Create(self) do
  begin
    if Execute then
      edtProjeto_FonteNome.Text := Font.Name;
    Free;
  end;
end;

procedure TfrmMain.btnProjeto_RaizClick(Sender: TObject);
//abre a pasta do projeto criado
begin
  TUtilPastaProjeto.AbrirPastaProjeto(FProjetoPastaRaiz);
end;

procedure TfrmMain.btnTabela_EditarClick(Sender: TObject);
//editar tabela
var
  f: TfrmEditarTabela;
begin
  if (dgProjeto_Tabelas.Data_IsEmpty) then
  begin
    ShowPopupMessage(self, ViewMain.MenuTabelasBotaoEditarMensagem1, mptWarning);
    Exit;
  end;

  f := TfrmEditarTabela.Create(self);
  f.IdProjeto := FIdProjeto;
  f.imgBancoProjeto.ImageIndex := imgBancoProjeto.ImageIndex;
  f.ShowModal;

  if f.AtualizarGrid then
    Projeto_CarregaGrid('');

  f.Free;
end;

procedure TfrmMain.btnControle_NovoClick(Sender: TObject);
//novo projeto
begin
  Controle_Limpar;
end;

procedure TfrmMain.btnControle_UsarProjetoClick(Sender: TObject);
//definir o projeto atual para trabalho
begin
  if StrToIntDef(edtControle_IdProjeto.Text, 0) < 1 then
  begin
    ShowPopupMessage(self, ViewMain.MenuControleUsarProjetoMensagem1, mptWarning);
    Exit;
  end;

  if (FIdProjeto > 0) and (StrToIntDef(edtControle_IdProjeto.Text, 0) <> FIdProjeto) then
  begin
    if QuestionDlg(QuestionDialog.Titulo,ViewMain.MenuControleUsarProjetoMensagem2, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
     exit;
  end;

  FIdProjeto := StrToIntDef(edtControle_IdProjeto.Text, 0);
  MenuOpcoesColor;
  Projeto_Ler(FIdProjeto);

  //click na opção Projeto no menu
  lblMenuProjetoClick(lblMenuProjeto);

  // Rest API
  Api_Ler;
end;

procedure TfrmMain.imgTabelas_LimparScriptClick(Sender: TObject);
begin
  edtTabela_Script.Clear;
  edtTabela_Script.Enabled := True;
end;

procedure TfrmMain.imgProjeto_RefreshClick(Sender: TObject);
begin
  Projeto_CarregaGrid('');
end;

procedure TfrmMain.lblTabelas_Exemplo2Click(Sender: TObject);
//exemplo de script de criação de multiplas tabelas
begin
  edtTabela_Script.Text := TServiceInfoTabelas.GetExemploScript( TTipoBanco.NONE );
end;

procedure TfrmMain.lblTabelas_ExemploClick(Sender: TObject);
//exemplo de script de criação de tabela
begin
  edtTabela_Script.Text := TServiceInfoTabelas.GetExemploScript( FProjeto_IdTipoBanco );
end;

procedure TfrmMain.panTopClick(Sender: TObject);
begin
  MenuOpcoesColor;
  NotebookOpcoes.Page[3].Show;
end;

procedure TfrmMain.lblMenuControleClick(Sender: TObject);
begin
  MenuOpcoesColor;
  lblMenuControle.Tag := 1;
  (Sender as TLabelPlus).Color := FOpcoesMenuSelectedColor;
  NotebookOpcoes.Page[0].Show;
end;

procedure TfrmMain.lblMenuProjetoClick(Sender: TObject);
begin
  if FIdProjeto < 1 then Exit;
  MenuOpcoesColor;
  lblMenuProjeto.Tag := 1;
  (Sender as TLabelPlus).Color := FOpcoesMenuSelectedColor;
  NotebookOpcoes.Page[1].Show;
end;

procedure TfrmMain.lblMenuTabelasClick(Sender: TObject);
begin
  if FIdProjeto < 1 then Exit;
  MenuOpcoesColor;
  lblMenuTabelas.Tag := 1;
  (Sender as TLabelPlus).Color := FOpcoesMenuSelectedColor;
  NotebookOpcoes.Page[2].Show;
end;

procedure TfrmMain.lblMenuAPIClick(Sender: TObject);
begin
  if FIdProjeto < 1 then Exit;
  MenuOpcoesColor;
  lblMenuAPI.Tag := 1;
  (Sender as TLabelPlus).Color := FOpcoesMenuSelectedColor;
  NotebookOpcoes.Page[4].Show;
end;

procedure TfrmMain.LabelOpcoesMouseEnter(Sender: TObject);
begin
  (Sender as TLabelPlus).Color := FOpcoesMenuOverColor;
end;

procedure TfrmMain.LabelOpcoesMouseLeave(Sender: TObject);
begin
  if (Sender as TLabelPlus).Tag = 0 then
    (Sender as TLabelPlus).Color := FOpcoesMenuDefaultColor
  else
    (Sender as TLabelPlus).Color := FOpcoesMenuSelectedColor;
end;

procedure TfrmMain.RadioSQLChange(Sender: TObject);
begin
  if radControle_PostgreSql.Checked then
  begin
    imgControle_Banco.ImageIndex := 0;
    edtControle_Porta.Text := '5432';
    FControle_TipoBanco    := 'postgre';
    FControle_IdTipoBanco  := TTipoBanco.POSTGRE;
  end
  else if radControle_MySql.Checked then
  begin
    imgControle_Banco.ImageIndex := 1;
    edtControle_Porta.Text := '3306';
    FControle_TipoBanco    := 'mysql';
    FControle_IdTipoBanco  := TTipoBanco.MYSQL;
  end
  else if radControle_FireBird.Checked then
  begin
    imgControle_Banco.ImageIndex := 2;
    edtControle_Porta.Text := '3050';
    FControle_TipoBanco    := 'firebird';
    FControle_IdTipoBanco  := TTipoBanco.FIREBIRD;
  end
  else if radControle_SQLite.Checked then
  begin
    imgControle_Banco.ImageIndex := 3;
    edtControle_Porta.Text := '';
    FControle_TipoBanco    := 'sqlite';
    FControle_IdTipoBanco  := TTipoBanco.SQLITE;
  end
  else if radControle_SQLServer.Checked then
  begin
    imgControle_Banco.ImageIndex := 4;
    edtControle_Porta.Text := '1433';
    FControle_TipoBanco    := 'sqlserver';
    FControle_IdTipoBanco  := TTipoBanco.SQLSERVER;
  end
  else if radControle_OracleSql.Checked then
  begin
    imgControle_Banco.ImageIndex := 5;
    edtControle_Porta.Text := '1521';
    FControle_TipoBanco    := 'oracle';
    FControle_IdTipoBanco  := TTipoBanco.ORACLE;
  end
  else if radControle_MariaDB.Checked then
  begin
    imgControle_Banco.ImageIndex := 6;
    edtControle_Porta.Text := '3306';
    FControle_TipoBanco    := 'mariadb';
    FControle_IdTipoBanco  := TTipoBanco.MARIADB;
  end;
end;

procedure TfrmMain.RadioSQLSelect(ATipoBanco: TTipoBanco);
//seleciona o tipo de banco de dados
begin
  case ATipoBanco of
    TTipoBanco.POSTGRE: radControle_PostgreSql.Checked := True;
    TTipoBanco.MYSQL: radControle_MySql.Checked := True;
    TTipoBanco.FIREBIRD: radControle_FireBird.Checked := True;
    TTipoBanco.SQLITE: radControle_SQLite.Checked := True;
    TTipoBanco.SQLSERVER: radControle_SQLServer.Checked := True;
    TTipoBanco.ORACLE: radControle_OracleSql.Checked := True;
    TTipoBanco.MARIADB: radControle_MariaDB.Checked := True;
  end;
end;

function TfrmMain.PegaTipoBanco(): TTipoBanco;
//pega o tipo de banco selecionado
begin
  if radControle_PostgreSql.Checked then
    Result := POSTGRE
  else if radControle_MySql.Checked then
    Result := MYSQL
  else if radControle_FireBird.Checked then
    Result := FIREBIRD
  else if radControle_SQLite.Checked then
    Result := SQLITE
  else if radControle_SQLServer.Checked then
    Result := SQLSERVER
  else if radControle_OracleSql.Checked then
    Result := ORACLE
  else if radControle_MariaDB.Checked then
    Result := MARIADB;
end;

procedure TfrmMain.tgProjeto_ApenasFormChange(Sender: TObject);
begin
  if tgProjeto_ApenasForm.Checked then
    btnProjeto_GerarCrud.Caption := ViewMain.MenuProjetoApenasFormChangeMsg1
  else
    btnProjeto_GerarCrud.Caption := ViewMain.MenuProjetoApenasFormChangeMsg2;
end;

procedure TfrmMain.Timer1Timer(Sender: TObject);
begin
  Application.ProcessMessages;
end;

function TfrmMain.RemoveEspacos(AString: String): String;
// remove quaisquer espaços em branco
begin
  Result := AString.Replace(' ', '', [rfReplaceAll]);
end;

procedure TfrmMain.ControlaBotoes(AValue: Boolean);
//ativa/destiva todos os botões
begin
  //menu
  lblMenuControle.Enabled := AValue;
  lblMenuProjeto.Enabled  := AValue;
  lblMenuTabelas.Enabled  := AValue;

  //controle
  btnControle_Salvar.Enabled         := AValue;
  btnControle_Excluir.Enabled        := AValue;
  btnControle_Novo.Enabled           := AValue;
  btnControle_UsarProjeto.Enabled    := AValue;
  btnControle_PathBancoDados.Enabled := AValue;
  edtControle_Pesquisa.Enabled       := AValue;

  //projeto
  btnProjeto_GerarCrud.Enabled        := AValue;
  imgProjeto_Refresh.Enabled  := AValue;
  edtProjeto_Pesquisa.Enabled := AValue;

  //tabelas
  btnTabelas_Carregar.Enabled     := AValue;
  lblTabelas_Exemplo.Enabled      := AValue;
  imgTabelas_LimparScript.Enabled := AValue;
  btnTabelas_Processar.Enabled    := AValue;
  btnTabela_Script.Enabled        := AValue;

  //Rest Api
  btnApi_Salvar.Enabled := AValue;
  btnApi_Excluir.Enabled := AValue;
  btnApi_GerarProjeto.Enabled := AValue;
  btnApi_Raiz.Enabled := AValue;
  btnApi_Compilar.Enabled := AValue;
  btnApi_EditarTabelas.Enabled := AValue;
  imgApiTabelas_Refresh.Enabled := AValue;
end;

procedure TfrmMain.MenuOpcoesColor;
//normaliza o menu
var
  cor: TColor;
begin
  if FIdProjeto < 1 then cor := TColor($404040) else cor := clWhite;

  lblMenuControle.Color := FOpcoesMenuDefaultColor;
  lblMenuControle.Tag := 0;

  lblMenuProjeto.Color := FOpcoesMenuDefaultColor;
  lblMenuProjeto.Font.Color := cor;
  lblMenuProjeto.Tag := 0;

  lblMenuTabelas.Color := FOpcoesMenuDefaultColor;
  lblMenuTabelas.Font.Color := cor;
  lblMenuTabelas.Tag := 0;

  lblMenuAPI.Color := FOpcoesMenuDefaultColor;
  lblMenuAPI.Font.Color := cor;
  lblMenuAPI.Tag := 0;
end;

procedure TfrmMain.Controle_Limpar;
begin
  FControle_TipoBanco := 'postgre';
  FControle_IdTipoBanco := TTipoBanco.POSTGRE;
  edtControle_IdProjeto.Text := '0';
  edtControle_Host.Clear;
  edtControle_Porta.Text := '5432';
  edtControle_Banco.Clear;
  edtControle_Usuario.Clear;
  edtControle_Senha.Clear;
  edtControle_NomeProjeto.Clear;
  edtControle_Descricao.Clear;
  radControle_PostgreSql.Checked := True;

  Projeto_Limpar;
end;

procedure TfrmMain.Controle_Salvar(AIdProjeto: Integer);
//salva o projeto
var
  c: TServiceProjeto;
begin
  c := TServiceProjeto.Create;
  c.IdTipoBanco  := Ord( FControle_IdTipoBanco );
  c.TipoBanco    := FControle_TipoBanco;
  c.HostServidor := Trim(edtControle_Host.Text);
  c.Porta        := Trim(edtControle_Porta.Text);
  c.BancoDados   := Trim(edtControle_Banco.Text);
  c.Username     := Trim(edtControle_Usuario.Text);
  c.Senha        := Trim(edtControle_Senha.Text);
  c.Projeto      := RemoveEspacos( edtControle_NomeProjeto.Text );
  c.Descricao    := Trim(edtControle_Descricao.Text);

  if c.Salvar(AIdProjeto) > 0 then
  begin
    edtControle_IdProjeto.Text := c.IdProjeto.ToString;
    Controle_CarregaGrid('');
    ShowPopupMessage(self, ViewMain.MenuControleSalvarMensagem3, mptSuccess, mppCenter, mpmExplode);
  end
  else
    ShowPopupMessage(self, c.GetErro, mptFatal, mppCenter, mpmExplode);

  c.Free;
end;

procedure TfrmMain.Controle_Ler(AIdProjeto: Integer);
//ler dados do projeto
begin
  Controle_Limpar;

  with TServiceProjeto.Create do
  begin
    if Ler(AIdProjeto)  then
    begin
      FControle_IdTipoBanco        := TTipoBanco(IdTipoBanco);
      FControle_TipoBanco          := TipoBanco;

      edtControle_IdProjeto.Text   := IdProjeto.ToString;
      edtControle_Host.Text        := HostServidor;
      edtControle_Porta.Text       := Porta;
      edtControle_Banco.Text       := BancoDados;
      edtControle_Usuario.Text     := Username;
      edtControle_Senha.Text       := Senha;
      edtControle_NomeProjeto.Text := Projeto;
      edtControle_Descricao.Text   := Descricao;

      RadioSQLSelect( FControle_IdTipoBanco );
    end
    else
      ShowPopupMessage(self, GetErro, mptFatal);

    Free;
  end;
end;

procedure TfrmMain.Controle_Excluir(AIdProjeto: Integer);
//excluir o projeto
var
  c: TServiceProjeto;
begin
  c := TServiceProjeto.Create;
  if c.Deletar(AIdProjeto) then
  begin
     Controle_Limpar;
     Projeto_Limpar;
     Controle_CarregaGrid('');
  end
  else
    ShowPopupMessage(self, c.GetErro, mptFatal);

  c.Free;
end;

procedure TfrmMain.Controle_Novo;
begin
  Controle_Limpar;
end;

procedure TfrmMain.Controle_CarregaGrid(APesquisa: String);
// carrega a grid com os projetos cadastrados
begin
  lblProrjetosQde.Caption := '0';
  dgControle_Projetos.ClearRows;

  with TServiceProjeto.Create do
  begin
    dgControle_Projetos.DataSource := DataSetProjetos(APesquisa.Trim);
    Free;
  end;

  if (dgControle_Projetos.DataSource <> nil) and (dgControle_Projetos.DataSource.DataSet <> nil) then
    lblProrjetosQde.Caption := dgControle_Projetos.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmMain.Projeto_Ler(AIdProjeto: Integer);
//ler dados do projeto indicado
begin
  Projeto_Limpar;

  with TServiceProjeto.Create do
  begin
    if Ler(AIdProjeto) then
    begin
      Caption := 'TOPAZZIO [ ' + Projeto + ' ]';
      edtProjeto_Host.Text        := HostServidor;
      edtProjeto_Porta.Text       := Porta;
      edtProjeto_Banco.Text       := BancoDados;
      edtProjeto_Usuario.Text     := Username;
      edtProjeto_Senha.Text       := Senha;
      edtProjeto_NomeProjeto.Text := Projeto;
      edtProjeto_Descricao.Text   := Descricao;

      imgBancoProjeto.ImageIndex  := IdTipoBanco;
      FProjeto_IdTipoBanco        := TTipoBanco(IdTipoBanco);

      FProjetoPastaRaiz           := PathProjeto;
      btnProjeto_Raiz.Enabled     := Length(PathProjeto)>0;
      btnProjeto_Compilar.Enabled := Length(PathProjeto)>0;
      btnProjeto_FormColor.ButtonColor        := Form_Cor;
      btnProjeto_BarraTituloColor.ButtonColor := Form_Titulo_CorFundo;
      edtProjeto_FonteNome.Text               := Form_Font_Name;

      //menu ler tabelas
      case FProjeto_IdTipoBanco of
        ORACLE:
          lblTabelas_Host.Caption := HostServidor + ':' + Porta + '/'+ BancoDados;
        SQLITE:
          if BancoDados.LastIndexOf(PathDelim) >= 0 then
            lblTabelas_Host.Caption := BancoDados.Substring(BancoDados.LastIndexOf(PathDelim) +1)
          else
            lblTabelas_Host.Caption := BancoDados;
      else
        lblTabelas_Host.Caption := HostServidor;
      end;

      // logotipo
      if Trim(PathLogotipo) <> '' then
        LoadLogotipoFromFile( PathLogotipo );

      //carega a grid de tabelas preparadas
      Projeto_CarregaGrid('');
    end
    else
      ShowPopupMessage(self, GetErro, mptFatal);

    Free;
  end;
end;

procedure TfrmMain.Projeto_Limpar;
//limpar campos do projeto
begin
  Caption := 'TOPAZZIO';

  edtProjeto_Host.Clear;
  edtProjeto_Porta.Clear;
  edtProjeto_Banco.Clear;
  edtProjeto_Usuario.Clear;
  edtProjeto_Senha.Clear;
  edtProjeto_NomeProjeto.Clear;
  edtProjeto_Descricao.Clear;

  imgBancoProjeto.ImageIndex := -1;
  FProjeto_IdTipoBanco := TTipoBanco.POSTGRE;
  FProjetoPastaRaiz := '';
  btnProjeto_Raiz.Enabled := False;
  btnProjeto_Compilar.Enabled := False;
  dgProjeto_Tabelas.ClearRows;
  lblTabelasPreparadasQde.Caption := '0';
  imgLogoTipoProjeto.Picture.Assign(imgProjeto_Padrao.Picture);

  //menu ler tabelas
  lblTabelas_Host.Caption := '';
  edtTabela_Script.Text := '';
  dgTabelas.ClearRows;
  lblTabelasQde.Caption := '0';

  // Rest API
  Api_Limpar;
end;

procedure TfrmMain.Projeto_CarregaGrid(APesquisa: String);
//carrega tabelas preparadas para o projeto
begin
  lblTabelasPreparadasQde.Caption := '0';
  RecList_ProjetoTabelas.Clear;
  dgProjeto_Tabelas.ClearRows;

  with TServiceTabela.Create(FIdProjeto) do
  begin
    dgProjeto_Tabelas.DataSource := DataSetTabelas(APesquisa);
    Free;
  end;

  if (dgProjeto_Tabelas.DataSource <> nil) and (dgProjeto_Tabelas.DataSource.DataSet <> nil) then
    lblTabelasPreparadasQde.Caption := dgProjeto_Tabelas.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmMain.Projeto_Progresso(AValue: Boolean);
//controle de progresso
begin
   cpbProjeto_Progresso.Visible  := AValue;
   cpbProjeto_Progresso.Infinite := AValue;
end;

procedure TfrmMain.Projeto_ProcessarCrud_Init;
//inicia o processamento de geração do crud do projeto via thread
begin
  GerarCrud := TProjetoLazarus.Create;
  GerarCrud.SetLogoTipo(imgLogoTipoProjeto);
  FGerarCrudRetorno := GerarCrud.GerarProjeto( FIdProjeto, tgProjeto_ModerUI.Checked,
                                               tgProjeto_ApenasForm.Checked, FProjetoListaTabelasID,
                                               btnProjeto_FormColor.ButtonColor, btnProjeto_BarraTituloColor.ButtonColor,
                                               edtProjeto_FonteNome.Text, False, tgProjeto_ModuloChat.Checked);
end;

procedure TfrmMain.Projeto_ProcessarCrud_End;
//fim o processamento de geração do crud do projeto via thread
begin
  ControlaBotoes(True);
  Projeto_Progresso(False);

  if FGerarCrudRetorno then
  begin
    FProjetoPastaRaiz := GerarCrud.GetPastaRaiz;
    btnProjeto_Raiz.Visible := True;

    if not tgProjeto_ApenasForm.Checked then
    begin
      TUtilCommon.SaveAsIcon(imgLogoTipoProjeto, 125, FProjetoPastaRaiz + LowerCase(edtProjeto_NomeProjeto.Text) + '.ico');
      ShowPopupMessage(self, ViewMain.MenuProjetoBotaoGerarCrudMensagem4, mptSuccess);
    end
    else
      ShowPopupMessage(self, ViewMain.MenuProjetoBotaoGerarCrudMensagem5, mptSuccess);
  end else
    ShowPopupMessage(self, GerarCrud.GetErro, mptFatal);

  FProjetoListaTabelasID := '';
  GerarCrud.Free;
end;

procedure TfrmMain.Tabelas_CarregaGrid(APesquisa: String);
//obter a lista de tabelas no host
begin
  RecList_HostTabelas.Clear;
  dgTabelas.ClearRows;
  lblTabelasQde.Caption := '0';
  try
    with TServiceInfoTabelas.Create(FProjeto_IdTipoBanco, FIdProjeto) do
    begin
      dgTabelas.DataSource := DataSetTabelas(APesquisa);
      lblTabelasQde.Caption := dgTabelas.DataSource.DataSet.RecordCount.ToString;
      //Free; // não usar
    end;
  except
  end;
end;

procedure TfrmMain.Tabelas_Progresso(AValue: Boolean);
//controle de progresso
begin
   cpbTabelas_Progresso.Visible  := AValue;
   cpbTabelas_Progresso.Infinite := AValue;
end;

procedure TfrmMain.Tabelas_ProcessaScript_Init;
//inicia o processamento do script de tabela via thread
begin
  InfoTabelas := TServiceInfoTabelas.Create(FProjeto_IdTipoBanco, FIdProjeto);
  InfoTabelas.CriarDBGrid := chkTabelas_CriarGrid.Checked;
  InfoTabelas.CriarFormPesquisa := chkTabelas_CriarFormPesquisa.Checked;
  FInfoTabelasRetorno := InfoTabelas.ProcessaTabelaScript( Trim(edtTabela_Script.Text) );
end;

procedure TfrmMain.Tabelas_ProcessaScript_End;
//fim do processamento do script de tabela via thread
begin
  Tabelas_Progresso(False);
  ControlaBotoes(True);

  if FInfoTabelasRetorno then
  begin
    ShowPopupMessage(self, ViewMain.MenuTabelasBotaoScriptMensagem3, mptWarning);
    Projeto_CarregaGrid('');
  end
  else
    ShowPopupMessage(self, InfoTabelas.GetErro, mptWarning);

  InfoTabelas.Free;
end;

procedure TfrmMain.Tabelas_ProcessaTabelas_Init;
//inicia o processamento das tabelas via thread
begin
  InfoTabelas := TServiceInfoTabelas.Create(FProjeto_IdTipoBanco, FIdProjeto);
  InfoTabelas.CriarDBGrid := chkTabelas_CriarGrid.Checked;
  InfoTabelas.CriarFormPesquisa := chkTabelas_CriarFormPesquisa.Checked;
  FInfoTabelasRetorno := InfoTabelas.ProcessaTabelas( tabelas );
end;

procedure TfrmMain.Tabelas_ProcessaTabelas_End;
//fim do processamento das tabelas via thread
begin
  Tabelas_Progresso(False);
  ControlaBotoes(True);

  if FInfoTabelasRetorno then
  begin
    ShowPopupMessage(self, ViewMain.MenuTabelasBotaoProcessarTabelasMensagem3, mptSuccess);
    Projeto_CarregaGrid('');
  end
  else
    ShowPopupMessage(self, InfoTabelas.GetErro, mptWarning);

  InfoTabelas.Free;
  tabelas.Free;
end;

procedure TfrmMain.Tabelas_ProcessaObterTabelas_Init;
//inicia o processamento obter tabelas via thread
begin
  with TServiceInfoTabelas.Create(FProjeto_IdTipoBanco, FIdProjeto) do
  begin
    FTabelasHost := DataSetTabelas( Trim(edtTabelas_Pesquisa.Text) );
  end;
end;

procedure TfrmMain.Tabelas_ProcessaObterTabelas_End;
//fim do processamento obter tabelas via thread
begin
  lblTabelasQde.Caption := '0';
  RecList_HostTabelas.Clear;
  dgTabelas.ClearRows;

  dgTabelas.DataSource := FTabelasHost;

  if (dgTabelas.DataSource <> nil) and (dgTabelas.DataSource.DataSet <> nil) then
  begin
    dgTabelas.DataSource.DataSet.Last;
    lblTabelasQde.Caption := dgTabelas.DataSource.DataSet.RecordCount.ToString;
    dgTabelas.DataSource.DataSet.First;
  end;

  Tabelas_Progresso(False);
  ControlaBotoes(True);
end;

{ REST API }

procedure TfrmMain.btnApi_EditarTabelasClick(Sender: TObject);
//editar tabela
var
  f: TfrmEditarTabela;
begin
  if (dgApi_Tabelas.Data_IsEmpty) then
  begin
    ShowPopupMessage(self, ViewMain.MenuProjetoBotaoEditarTabelaMensagem1, mptWarning);
    Exit;
  end;

  f := TfrmEditarTabela.Create(self);
  f.IdProjeto := FIdProjeto;
  f.imgBancoProjeto.ImageIndex := imgBancoProjeto.ImageIndex;
  f.ShowModal;

  if f.AtualizarGrid then
    Api_CarregaGrid('');

  f.Free;
end;

procedure TfrmMain.btnApi_CompilarClick(Sender: TObject);
//tela de compilação do projeto
var
  f: TfrmCompilador;
begin
  f := TfrmCompilador.Create(Self);
  f.Projeto_IsAPI := True;
  f.Projeto_Path := FApiPastaRaiz;
  f.PathRelease := FApiPastaRelease;
  f.Projeto_Nome := Trim(edtApi_Nome.Text);
  f.ShowModal;
  f.Free;
end;

procedure TfrmMain.btnApi_GerarProjetoClick(Sender: TObject);
//gerar arquivos do projeto Rest API
var
  et: TEasyThread;
  b: TBookMark;
  i, qde, r: Integer;
  msg: String;
begin
  if not Api_Salvar(False) then Exit;

  if (dgApi_Tabelas.Data_IsEmpty) or (dgApi_Tabelas.Data_RowsCount < 1) then
  begin
    ShowPopupMessage(self, ViewMain.MenuProjetoBotaoGerarCrudMensagem1, mptWarning);
    Exit;
  end;

  ControlaBotoes(False);

  qde := 0;
  FApiListaTabelasID := '';
  msg := ViewMain.MenuProjetoBotaoGerarCrudMensagem2;

  if RecList_ApiTabelas.Count > 0 then
  begin
    r := dgApi_Tabelas.Data_RowIndex; //linha atual

    for i := 0 to RecList_ApiTabelas.Count -1 do
    begin
      b := RecList_ApiTabelas.Items[i]; //array de 4 selementos, o index zero contém o número da linha na grid
      if FApiListaTabelasID <> '' then FApiListaTabelasID := FApiListaTabelasID + ',';
      FApiListaTabelasID := FApiListaTabelasID + dgApi_Tabelas.Data_RowFields( b[0] ).FieldByName('idtabela').AsString ;
      qde += 1;
    end;

    dgApi_Tabelas.Data_GoTo( r ); //volta para a linha antiga
  end;

  if qde > 0 then
    msg := ViewMain.MenuProjetoBotaoGerarCrudMensagem3(qde);

  if QuestionDlg(QuestionDialog.Titulo, msg, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
  begin
    ControlaBotoes(True);
    FApiListaTabelasID := '';
    Exit;
  end;

  //Inicia o processamento das tabelas
  ControlaBotoes(False);
  Api_Progresso(True);
  FApiPastaRaiz := '';
  btnApi_Raiz.Visible := False;

  et := TEasyThread.Create(True);
  et.ExecuteProcedure  := @Api_ProcessarCrud_Init;
  et.CallBackProcedure := @Api_ProcessarCrud_End;
  et.Start;
end;

procedure TfrmMain.btnApi_RaizClick(Sender: TObject);
begin
  TUtilPastaProjeto.AbrirPastaProjeto(FApiPastaRaiz);
end;

procedure TfrmMain.btnApi_SalvarClick(Sender: TObject);
//salvar dados da api
begin
  if (Trim(edtApi_Host.Text) = '') or (Trim(edtApi_Porta.Text) = '') or
     (Trim(edtApi_Nome.Text) = '') or (Trim(edtApi_Descricao.Text) = '') then
  begin
    ShowPopupMessage(self, ViewMain.MenuApiSalvarMensagem1, mptWarning);
    Exit;
  end;

  Api_Salvar(True);
end;

procedure TfrmMain.btnCarregarLogoTipoClick(Sender: TObject);
begin
  with TOpenPictureDialog.Create(self) do begin
    if Execute then
      if FileName<>'' then begin
         LoadLogoTipoFromFile( FileName );
      end;
    Free;
  end;
end;

procedure TfrmMain.btnExcluirLogoTipoClick(Sender: TObject);
begin
  imgLogoTipoProjeto.Picture.Assign(imgProjeto_Padrao.Picture);

  // salva o path do logotipo no banco de dados
  with TServiceProjeto.Create do begin
    SetProjetoPathLogotipo( FIdProjeto, '' );
    Free;
  end;
end;

procedure TfrmMain.btnApi_ExcluirClick(Sender: TObject);
//excluir a API
begin
  if StrToIntDef(edtApi_IdApi.Text, 0) < 1 then
    Exit;

  if QuestionDlg(QuestionDialog.Titulo, ViewMain.MenuApiExcluirMensagem1, mtConfirmation, [mrYes, QuestionDialog.Sim, mrNo, QuestionDialog.Nao, 'IsDefault'], '') <> mrYes then
     exit;

  Api_Excluir;
end;

procedure TfrmMain.imgApiTabelas_RefreshClick(Sender: TObject);
begin
  Api_CarregaGrid('');
end;


procedure TfrmMain.dgApi_TabelasCellClick(Column: TColumn);
begin
  //ShowMessage( dgApi_Tabelas.Data_RowFields(1).FieldByName('tabela').AsString ); //primeira linha da grid
  if Column.Index = 3 then
    RecList_ApiTabelas.CurrentRowSelected := not RecList_ApiTabelas.CurrentRowSelected;
end;

procedure TfrmMain.dgApi_TabelasUserCheckboxState(Sender: TObject; Column: TColumn; var AState: TCheckboxState);
// altera o state do checkbox
begin
  if RecList_ApiTabelas.CurrentRowSelected then
    AState := cbChecked
  else
    AState := cbUnchecked;
end;

procedure TfrmMain.Api_Limpar;
//limpar campos do projeto
begin
  FApiPastaRaiz := '';

  edtApi_IdApi.Text := '0';
  edtApi_Host.Text := 'http://localhost';
  edtApi_Porta.Text := '8083';
  edtApi_Versao.Text := '/api/v1';
  edtApi_AdminNome.Clear;
  edtApi_AdminEmail.Clear;
  edtApi_Nome.Clear;
  edtApi_Titulo.Clear;
  edtApi_Descricao.Clear;
  edtApi_Header1.Clear;
  edtApi_Header2.Clear;
  edtApi_Header3.Clear;
  edtApi_Footer1.Clear;
  edtApi_Footer2.Clear;
  chkApi_GerarServiceClasse.Checked := False;
  chkApi_Audit.Checked := False;
  chkApi_Boleto.Checked := False;

  btnApi_Excluir.Enabled := False;
  btnApi_Raiz.Enabled := False;
  btnApi_Compilar.Enabled := False;
  dgApi_Tabelas.ClearRows;
  lblApiTabelasQde.Caption := '0';
  cpbApi_Progresso.Visible := False;
end;

procedure TfrmMain.Api_Progresso(AValue: Boolean);
begin
  cpbApi_Progresso.Visible  := AValue;
  cpbApi_Progresso.Infinite := AValue;
end;

procedure TfrmMain.Api_Ler;
//ler dados da API
begin
  Api_Limpar;

  with TServiceRestApi.Create(FIdProjeto) do
  begin
    if Ler then
    begin
      edtApi_IdApi.Text      := FIdProjeto.ToString;
      edtApi_Host.Text       := ApiHost;
      edtApi_Porta.Text      := ApiPorta;
      edtApi_Versao.Text     := ApiVersao;
      edtApi_AdminNome.Text  := ApiAdminNome;
      edtApi_AdminEmail.Text := ApiAdminEmail;
      edtApi_Nome.Text       := ApiNome;
      edtApi_Titulo.Text     := ApiTitulo;
      edtApi_Descricao.Text  := ApiDescricao;
      edtApi_Header1.Text    := ApiHeader1;
      edtApi_Header2.Text    := ApiHeader2;
      edtApi_Header3.Text    := ApiHeader3;
      edtApi_Footer1.Text    := ApiFooter1;
      edtApi_Footer2.Text    := ApiFooter2;
      chkApi_GerarServiceClasse.Checked := ApiClasseService;
      chkApi_Audit.Checked   := ApiAudit;
      chkApi_Boleto.Checked  := ApiBoleto;

      FApiPastaRaiz           := ApiPathProjeto;
      btnApi_Excluir.Enabled  := True;
      btnApi_Raiz.Enabled     := Length(FApiPastaRaiz)>0;
      btnApi_Compilar.Enabled := Length(FApiPastaRaiz)>0;
    end;

    Free;
  end;

  //carega a grid de tabelas disponíveis para API
  Api_CarregaGrid('');
end;

function TfrmMain.Api_Salvar(AShowMessage: Boolean): Boolean;
//salva dados API
begin
  Result := False;

  with TServiceRestApi.Create(FIdProjeto) do begin
    ApiHost       := Trim(edtApi_Host.Text);
    ApiPorta      := Trim(edtApi_Porta.Text);
    ApiVersao     := Trim(edtApi_Versao.Text);
    ApiAdminNome  := Trim(edtApi_AdminNome.Text);
    ApiAdminEmail := Trim(edtApi_AdminEmail.Text);
    ApiNome       := Trim(edtApi_Nome.Text);
    ApiTitulo     := Trim(edtApi_Titulo.Text);
    ApiDescricao  := Trim(edtApi_Descricao.Text);
    ApiHeader1    := Trim(edtApi_Header1.Text);
    ApiHeader2    := Trim(edtApi_Header2.Text);
    ApiHeader3    := Trim(edtApi_Header3.Text);
    ApiFooter1    := Trim(edtApi_Footer1.Text);
    ApiFooter2    := Trim(edtApi_Footer2.Text);
    ApiClasseService := chkApi_GerarServiceClasse.Checked;
    ApiAudit         := chkApi_Audit.Checked;
    ApiBoleto        := chkApi_Boleto.Checked;

    if Salvar then begin
      Result := True;
      edtApi_IdApi.Text := FIdProjeto.ToString;
      btnApi_Excluir.Enabled := True;

      //carega a grid de tabelas disponíveis para API
      Api_CarregaGrid('');

      if AShowMessage then
        ShowPopupMessage(self, ViewMain.MenuControleSalvarMensagem3, mptSuccess, mppCenter, mpmExplode);
    end
    else
      ShowPopupMessage(self, GetErro, mptWarning);

    Free;
  end;
end;

procedure TfrmMain.Api_Excluir;
//excluir dados API
begin
  with TServiceRestApi.Create(FIdProjeto) do
  begin
    if Deletar then
    begin
      Api_Limpar;
      Api_CarregaGrid('');
    end
    else
      ShowPopupMessage(self, GetErro, mptWarning);

    Free;
  end;
end;

procedure TfrmMain.Api_CarregaGrid(APesquisa: String);
//carrega tabelas preparadas para o projeto
begin
  lblApiTabelasQde.Caption := '0';
  RecList_ApiTabelas.Clear;
  dgApi_Tabelas.ClearRows;

  with TServiceRestApi.Create(FIdProjeto) do
  begin
    dgApi_Tabelas.DataSource := DataSetTabelas(APesquisa);
    Free;
  end;

  if (dgApi_Tabelas.DataSource <> nil) and (dgApi_Tabelas.DataSource.DataSet <> nil) then
    lblApiTabelasQde.Caption := dgApi_Tabelas.DataSource.DataSet.RecordCount.ToString;
end;

procedure TfrmMain.Api_ProcessarCrud_Init;
//inicia o processamento de geração da API via thread
begin
  GerarApi := TProjetoLazarusApi.Create;
  FGerarApiRetorno := GerarApi.GerarProjeto( FIdProjeto, FApiListaTabelasID );
end;

procedure TfrmMain.Api_ProcessarCrud_End;
//fim o processamento de geração da API via thread
var
  p: TPicture;
begin
  ControlaBotoes(True);
  Api_Progresso(False);

  if FGerarApiRetorno then
  begin
    FApiPastaRaiz := GerarApi.GetPastaRaiz;
    FApiPastaRelease := GerarApi.GetPastaRelease;
    btnApi_Raiz.Visible := True;

    // ícones
    TUtilCommon.SaveAsIcon(imgLogoTipoProjeto, 125, FApiPastaRaiz + LowerCase(edtApi_Nome.Text) + '.ico');
    TUtilCommon.SaveAsIcon(imgLogoTipoProjeto, 125, GerarApi.GetPastaPublicImages + 'logo.png');
    TUtilCommon.SaveAsIcon(imgLogoTipoProjeto, 64, GerarApi.GetPastaPublic + 'favicon.ico');
    TUtilCommon.BitmapToPNGStream(imgLogoTipoProjeto.Picture.Graphic, 128).SaveToFile(GerarApi.GetPastaPublicImages + 'apidoc.png');
    TUtilCommon.SaveAsIcon(imgLogoTipoProjeto, 50, GerarApi.GetPastaPublicImages + 'logo_qr.png');

    // ícones do boleto
    if chkApi_Boleto.Checked then
    begin
      p := TPicture.Create;

      try
        p.Clear;
        p.LoadFromLazarusResource('1');
        p.SaveToFile(GerarApi.GetPastaPublicImages + '1.png');

        p.Clear;
        p.LoadFromLazarusResource('2');
        p.SaveToFile(GerarApi.GetPastaPublicImages + '2.png');

        p.Clear;
        p.LoadFromLazarusResource('3');
        p.SaveToFile(GerarApi.GetPastaPublicImages + '3.png');

        p.Clear;
        p.LoadFromLazarusResource('6');
        p.SaveToFile(GerarApi.GetPastaPublicImages + '6.png');

        p.Clear;
        p.LoadFromLazarusResource('b');
        p.SaveToFile(GerarApi.GetPastaPublicImages + 'b.png');

        p.Clear;
        p.LoadFromLazarusResource('p');
        p.SaveToFile(GerarApi.GetPastaPublicImages + 'p.png');

        p.Clear;
        p.LoadFromLazarusResource('logobb');
        p.SaveToFile(GerarApi.GetPastaPublicImages + 'logobb.png');

        p.Clear;
        p.LoadFromLazarusResource('logobradesco');
        p.SaveToFile(GerarApi.GetPastaPublicImages + 'logobradesco.png');

        p.Clear;
        p.LoadFromLazarusResource('logocaixa');
        p.SaveToFile(GerarApi.GetPastaPublicImages + 'logocaixa.png');

        p.Clear;
        p.LoadFromLazarusResource('logoitau');
        p.SaveToFile(GerarApi.GetPastaPublicImages + 'logoitau.png');

        p.Clear;
        p.LoadFromLazarusResource('logosantander');
        p.SaveToFile(GerarApi.GetPastaPublicImages + 'logosantander.png');

        p.Clear;
        p.LoadFromLazarusResource('logosicoob');
        p.SaveToFile(GerarApi.GetPastaPublicImages + 'logosicoob.png');
      finally
        p.Free;
      end;
    end;

    ShowPopupMessage(self, ViewMain.MenuProjetoBotaoGerarCrudMensagem4, mptSuccess);
  end else
    ShowPopupMessage(self, GerarApi.GetErro, mptFatal);

  FApiListaTabelasID := '';
  GerarApi.Free;
end;

procedure TfrmMain.LoadLogotipoFromFile(AFileame: string);
// carrega o logotipo a partir do arquivo
var
  ex: string;
begin
  ex := Trim(LowerCase(ExtractFileExt( AFileame )));

  if ex <> '.png' then begin
    ShowPopupMessage(self, ViewMain.MenuProjetoCarregarLogoMensagem1, mptFatal);
    Exit;
  end;

  if not FileExists( AFileame ) then begin
    ShowPopupMessage(self, ViewMain.MenuProjetoCarregarLogoMensagem2, mptFatal);
    Exit;
  end;

  imgLogoTipoProjeto.Picture.LoadFromFile( AFileame );

  if (imgLogoTipoProjeto.Picture <> nil) then begin

    if imgLogoTipoProjeto.Picture.Graphic.ClassName <> 'TPortableNetworkGraphic' then begin
      ShowPopupMessage(self, ViewMain.MenuProjetoCarregarLogoMensagem1, mptFatal);
      imgLogoTipoProjeto.Picture.Assign(nil);
      Exit;
    end;

    //if (imgLogoTipoProjeto.Picture.Bitmap.Width > imgLogoTipoProjeto.Width) then
    imgLogoTipoProjeto.Picture.LoadFromStream( TUtilCommon.BitmapToPNGStream(imgLogoTipoProjeto.Picture.Graphic, 256 ) );

    imgLogoTipoProjeto.Stretch := (imgLogoTipoProjeto.Picture.Bitmap.Width > imgLogoTipoProjeto.Width);
  end;

  // salva o path do logotipo no banco de dados
  with TServiceProjeto.Create do begin
    SetProjetoPathLogotipo( FIdProjeto, AFileame );
    Free;
  end;
end;

procedure TfrmMain.AjustaIdioma;
//exibe no idioma selecionado
begin
  //topo da tela
  lblTitulo.Caption := ViewMain.Titulo;
  lblAutor.Caption := ViewMain.SubTitulo;

  //PageMenuSobre
  lblTitulo1.Caption := ViewMain.Titulo;
  lblDescricao.Caption := ViewMain.Descricao;
  lblAutor1.Caption := ViewMain.SubTitulo;

  //Menus
  lblMenuControle.Caption := ViewMain.MenuControle;
  lblMenuControle.Hint := ViewMain.MenuControleHint;
  lblMenuProjeto.Caption := ViewMain.MenuProjeto;
  lblMenuProjeto.Hint := ViewMain.MenuProjetoHint;
  lblMenuTabelas.Caption := ViewMain.MenuTabelas;
  lblMenuTabelas.Hint := ViewMain.MenuTabelasHint;
  lblMenuAPI.Hint := ViewMain.MenuApiHint;

  //Menu: Controle
  lblControleSgdb.Caption := ViewMain.MenuControleLabelSgdb;
  lblControleSgdb.Hint := ViewMain.MenuControleLabelHintSgdb;
  lblMenuControleGridTitulo.Caption := ViewMain.MenuControleLabelGridTitulo;
  lblControleInformacoes.Caption := ViewMain.MenuControleLabelInformacoes;
  lblControleHost.Caption := ViewMain.MenuControleLabelHost;
  lblControlePorta.Caption := ViewMain.MenuControleLabelPorta;
  lblControle_Database.Caption := ViewMain.MenuControleLabelDatabase;
  lblControleUsuario.Caption := ViewMain.MenuControleLabelUsuario;
  lblControleSenha.Caption := ViewMain.MenuControleLabelSenha;
  lblControleSobreProjeto.Caption := ViewMain.MenuControleLabelSobreProjeto;
  lblControleNomeProjeto.Caption := ViewMain.MenuControleLabelSobreNomeProjeto;
  lblControleDescricaoProjeto.Caption := ViewMain.MenuControleLabelSobreDescricao;
  edtControle_Pesquisa.Hint := ViewMain.MenuControleEditPesquisa;
  edtControle_Pesquisa.Placeholder := ViewMain.MenuControleEditPesquisa;
  btnControle_PathBancoDados.Hint := ViewMain.MenuControleBotaoPathDatabaseHint;
  btnControle_Salvar.Caption := ViewMain.MenuControleBotaoSalvarText;
  btnControle_Salvar.Hint := ViewMain.MenuControleBotaoSalvarHint;
  btnControle_Excluir.Caption := ViewMain.MenuControleBotaoExcluirText;
  btnControle_Excluir.Hint := ViewMain.MenuControleBotaoExcluirHint;
  btnControle_Novo.Caption := ViewMain.MenuControleBotaoNovoText;
  btnControle_Novo.Hint := ViewMain.MenuControleBotaoNovoHint;
  btnControle_UsarProjeto.Caption := ViewMain.MenuControleBotaoUsarProjetoText;
  btnControle_UsarProjeto.Hint := ViewMain.MenuControleBotaoUsarProjetoHint;
  ViewMain.MenuControleGridCampos(dgControle_Projetos);

  //Menu: O Projeto
  lblProjetoInfoDB.Caption := ViewMain.MenuControleLabelInformacoes;
  lblProjetoHost.Caption := ViewMain.MenuControleLabelHost;
  lblProjetoPorta.Caption := ViewMain.MenuControleLabelPorta;
  lblProjetoPathFile.Caption := ViewMain.MenuControleLabelDatabase;
  lblProjetoUsuario.Caption := ViewMain.MenuControleLabelUsuario;
  lblProjetoSenha.Caption := ViewMain.MenuControleLabelSenha;
  lblProjetoSobre.Caption := ViewMain.MenuControleLabelSobreProjeto;
  lblProjetoNomeApp.Caption := ViewMain.MenuControleLabelSobreNomeProjeto;
  lblProjetoDescricao.Caption := ViewMain.MenuControleLabelSobreDescricao;
  tgProjeto_ModerUI.Caption := ViewMain.MenuProjetoUsarModernUIText;
  tgProjeto_ModerUI.Hint := ViewMain.MenuProjetoUsarModernUIHint;
  tgProjeto_ApenasForm.Caption := ViewMain.MenuProjetoGerarFormText;
  tgProjeto_ApenasForm.Hint := ViewMain.MenuProjetoGerarFormHint;
  lblProjetoFormBar.Caption := ViewMain.MenuProjetoFormBarrraTitulo;
  lblProjetoFormCor.Caption := ViewMain.MenuProjetoFormCor;
  lblProjetoCorBar.Caption := ViewMain.MenuProjetoCorBarra;
  lblProjetoFormFonte.Caption := ViewMain.MenuProjetoFormFonte;
  btnProjeto_GerarCrud.Caption := ViewMain.MenuProjetoBotaoGerarCrudText;
  btnProjeto_GerarCrud.Hint := ViewMain.MenuProjetoBotaoGerarCrudHint;
  btnProjeto_Raiz.Hint := ViewMain.MenuProjetoBotaoPastaRaiz;
  btnProjeto_Compilar.Caption := ViewMain.MenuProjetoBotaoCompilarText;
  btnProjeto_Compilar.Hint := ViewMain.MenuProjetoBotaoCompilarHint;
  lblProjetoTabelasPreparadas.Caption := ViewMain.MenuProjetoTabelasPreparadas;
  imgProjeto_Refresh.Hint := ViewMain.MenuProjetoTabelasPreparadasRefresh;
  edtProjeto_Pesquisa.Hint := ViewMain.MenuControleEditPesquisa;
  edtProjeto_Pesquisa.Placeholder := ViewMain.MenuControleEditPesquisa;
  btnProjeto_EditarTabelas.Caption := ViewMain.MenuProjetoBotaoEditarTabelasText;
  btnProjeto_EditarTabelas.Hint := ViewMain.MenuProjetoBotaoEditarTabelasHint;
  // ViewMain.MenuProjeto_MenuOpcionalText;
  //ViewMain.MenuProjeto_MenuOpcionalHint;
  tgProjeto_ModuloChat.Caption := ViewMain.MenuProjeto_IncluirModuloChatText;
  tgProjeto_ModuloChat.Hint := ViewMain.MenuProjeto_IncluirModuloChatHint;
  ViewMain.MenuProjetoGridCampos(dgProjeto_Tabelas);
  lblProjetoLogotipo.Caption := ViewMain.MenuProjetoLabelLogoTipoCaption;
  btnCarregarLogoTipo.Hint := ViewMain.MenuProjetoBotaoCarregarLogotipoHint;
  btnExcluirLogoTipo.Hint := ViewMain.MenuProjetoBotaoRemoverLogotipoHint;

  //Menu: Tabelas
  btnTabelas_Carregar.Caption := ViewMain.MenuTabelasBotaoCarregarTabelasText;
  btnTabelas_Carregar.Hint := ViewMain.MenuTabelasBotaoCarregarTabelasHint;
  lblTabelasListagemServidor.Caption := ViewMain.MenuTabelasLabelListagem;
  ViewMain.MenuTabelasGridCampos(dgTabelas);
  edtTabelas_Pesquisa.Hint := ViewMain.MenuControleEditPesquisa;
  edtTabelas_Pesquisa.Placeholder := ViewMain.MenuControleEditPesquisa;
  btnTabela_Editar.Caption := ViewMain.MenuTabelasBotaoEditarText;
  btnTabela_Editar.Hint := ViewMain.MenuTabelasBotaoEditarHint;
  lblTabelasLista.Caption := ViewMain.MenuTabelasLabelListaTabelas.ToUpper;
  chkTabelas_CriarFormPesquisa.Caption := ViewMain.MenuTabelasCheckCriarFormPesquisaText;
  chkTabelas_CriarFormPesquisa.Hint := ViewMain.MenuTabelasCheckCriarFormPesquisaHint;
  chkTabelas_CriarGrid.Caption := ViewMain.MenuTabelasCheckCriarGridText;
  chkTabelas_CriarGrid.Hint := ViewMain.MenuTabelasCheckCriarGridHint;
  btnTabelas_Processar.Caption := ViewMain.MenuTabelasBotaoProcessarTabelasText;
  btnTabelas_Processar.Hint := ViewMain.MenuTabelasBotaoProcessarTabelasHint;
  lblTabelasScript.Caption := ViewMain.MenuTabelasLabelScripts.ToUpper;
  btnTabela_Script.Caption := ViewMain.MenuTabelasBotaoScriptText;
  btnTabela_Script.Hint := ViewMain.MenuTabelasBotaoScriptHint;
  lblTabelasScriptBox.Caption := ViewMain.MenuTabelasScriptBox;
  lblTabelas_Exemplo.Caption := ViewMain.MenuTabelasExemplo1Text;
  lblTabelas_Exemplo.Hint := ViewMain.MenuTabelasExemplo1Hint;
  lblTabelas_Exemplo2.Caption := ViewMain.MenuTabelasExemplo2Text;
  lblTabelas_Exemplo2.Hint := ViewMain.MenuTabelasExemplo2Hint;
  imgTabelas_LimparScript.Hint := ViewMain.MenuTabelasMemoLimpar;

  //Menu: Rest API
  lblApiPorta.Caption := ViewMain.MenuControleLabelPorta;
  lblApiVersao.Caption := ViewMain.MenuApiLabelVersaoCaption;
  lblApiAdminNome.Caption := ViewMain.MenuApiLabelAdminCaption;
  lblApiAdminEmail.Caption := ViewMain.MenuApiLabelAdminEmailCaption;
  lblApiNome.Caption := ViewMain.MenuApiLabelApiNameCaption;
  lblApiTitulo.Caption := ViewMain.MenuApiLabelApiTituloCaption;
  lblApiDescricao.Caption := ViewMain.MenuApiLabelDescricaoCaption;
  btnApi_Salvar.Caption := ViewMain.MenuControleBotaoSalvarText;
  btnApi_Excluir.Caption := ViewMain.MenuControleBotaoExcluirText;
  btnApi_GerarProjeto.Caption := ViewMain.MenuApiBotaoGerarApiCaption;
  btnApi_GerarProjeto.Hint := ViewMain.MenuApiBotaoGerarApiHint;
  btnApi_Raiz.Hint := ViewMain.MenuApiBotaoPastaProjetoHint;
  btnApi_Compilar.Caption := ViewMain.MenuProjetoBotaoCompilarText;
  btnApi_Compilar.Hint := ViewMain.MenuProjetoBotaoCompilarHint;
  btnApi_EditarTabelas.Caption := ViewMain.MenuProjetoBotaoEditarTabelasText;
  btnApi_EditarTabelas.Hint := ViewMain.MenuProjetoBotaoEditarTabelasHint;
  imgApiTabelas_Refresh.Hint := ViewMain.MenuProjetoTabelasPreparadasRefresh;
  edtApi_Pesquisa.Hint := ViewMain.MenuControleEditPesquisa;
  edtApi_Pesquisa.Placeholder := ViewMain.MenuControleEditPesquisa;
  lblApiTabelas.Caption := ViewMain.MenuProjetoTabelasPreparadas;
  chkApi_GerarServiceClasse.Caption := ViewMain.MenuApiCheckBoxGerarServiceClasseCaption;
  chkApi_GerarServiceClasse.Hint := ViewMain.MenuApiCheckBoxGerarServiceClasseHint;
  chkApi_Audit.Caption := ViewMain.MenuApiCheckBoxAuditCaption;
  chkApi_Audit.Hint := ViewMain.MenuApiCheckBoxAuditHint;
  chkApi_Boleto.Caption := ViewMain.MenuApiCheckBoxBoletoCaption;
  chkApi_Boleto.Hint := ViewMain.MenuApiCheckBoxBoletoHint;
  ViewMain.MenuProjetoGridCampos(dgApi_Tabelas);

  if meu_idioma = BR then begin
    chkApi_Boleto.Enabled := True;
  end
  else begin
    chkApi_Boleto.Checked := False;
    chkApi_Boleto.Enabled := False;
  end;
end;

initialization
  {$I ../boleto_images.lrs}

end.

