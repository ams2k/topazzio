unit Service.Projeto;

// Cadastro de dados do projeto

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ZDataset, DB, SQLDB;

type

  { TServiceProjeto }

  TServiceProjeto = class
    private
      FBancoDados: String;
      FDescricao: String;
      FErro: String;
      FForm_Cor: Integer;
      FForm_Font_Name: string;
      FForm_Titulo_CorFundo: Integer;
      FHostServidor: String;
      FIdProjeto: Integer;
      FIdTipoBanco: Integer;
      FNovoIDSql: String;
      FPathProjeto: string;
      FPorta: String;
      FProjeto: String;
      FSenha: String;
      FTipoBanco: String;
      FUsername: String;
    public
      property GetErro: String read FErro;
      property IdProjeto: Integer read FIdProjeto;
      property Projeto: String read FProjeto write FProjeto;
      property Descricao: String read FDescricao write FDescricao;
      property IdTipoBanco: Integer read FIdTipoBanco write FIdTipoBanco;
      property TipoBanco: String read FTipoBanco write FTipoBanco;
      property HostServidor: String read FHostServidor write FHostServidor;
      property Porta: String read FPorta write FPorta;
      property BancoDados: String read FBancoDados write FBancoDados;
      property Username: String read FUsername write FUsername;
      property Senha: String read FSenha write FSenha;
      property NovoID_Sql: String read FNovoIDSql write FNovoIDSql;
      property Form_Cor: Integer read FForm_Cor;
      property Form_Titulo_CorFundo: Integer read FForm_Titulo_CorFundo;
      property Form_Font_Name: string read FForm_Font_Name;
      property PathProjeto: string read FPathProjeto write FPathProjeto;
      function Salvar(AIdProjeto: Integer): Integer;
      function Ler(AIdProjeto: Integer): Boolean;
      function Deletar(AIdProjeto: Integer): Boolean;
      function DataSetProjetos(APesquisa: String): TDataSource;
      function ExisteProjeto(AProjeto, ATipoBanco: String): Integer;
      procedure SetProjetoDefaults(AIdProjeto: Integer; APathProjeto: string; AFormCor: Integer;
                                   AFormFontName: String; AFormTituloCor: Integer);
      procedure SetProjetoDefaultsAPI(AIdProjeto: Integer; APathProjeto: string);
      function VaiUsarFortesReport(AIdProjeto: Integer): Boolean;
  end;

implementation

uses
  DM.Server, Util.Idioma;

{ TServiceProjeto }

function TServiceProjeto.Salvar(AIdProjeto: Integer): Integer;
//salva o projeto, se ainda não existir
begin
  Result := ExisteProjeto(Projeto, TipoBanco);

  if (Result > 0) and (AIdProjeto <> Result) then begin
    FErro := ServiceProjeto.Mensagem1;
    Exit;
  end else
    AIdProjeto := Result;

  with DMServer.NewQuery() do begin
    if AIdProjeto < 1 then begin
      SQL.Add('insert into crud_projeto ');
      SQL.Add('(projeto, descricao, idtipo_banco, tipo_banco, host_servidor, ');
      SQL.Add('porta, banco_dados, username, senha, novo_id_sql) ');
      SQL.Add('values(:projeto, :descricao, :idtipo_banco, :tipo_banco, :host_servidor, ');
      SQL.Add(':porta, :banco_dados, :username, :senha, :novo_id_sql) ');
    end
    else begin
      SQL.Add('update crud_projeto set ');
      SQL.Add('projeto = :projeto, descricao = :descricao, idtipo_banco = :idtipo_banco, ');
      SQL.Add('tipo_banco = :tipo_banco, host_servidor = :host_servidor, porta = :porta, ');
      SQL.Add('banco_dados = :banco_dados, username = :username, senha = :senha, ');
      SQL.Add('novo_id_sql = :novo_id_sql ');
      SQL.Add('where idprojeto = ' + IntToStr(AIdProjeto));
    end;

    ParamByName('projeto').AsString       := Projeto;
    ParamByName('descricao').AsString     := Descricao;
    ParamByName('idtipo_banco').AsInteger := IdTipoBanco;
    ParamByName('tipo_banco').AsString    := TipoBanco;
    ParamByName('host_servidor').AsString := HostServidor;
    ParamByName('porta').AsString         := Porta;
    ParamByName('banco_dados').AsString   := BancoDados;
    ParamByName('username').AsString      := Username;
    ParamByName('senha').AsString         := Senha;
    ParamByName('novo_id_sql').AsString   := NovoID_Sql;

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      if AIdProjeto < 1 then
        Result := DMServer.LastInsertedID
      else
        Result := AIdProjeto;

      FIdProjeto := Result;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := E.Message;
      end;
    end;
  end;
end;

function TServiceProjeto.Ler(AIdProjeto: Integer): Boolean;
//ler dados do projeto
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('select idprojeto, projeto, descricao, idtipo_banco, tipo_banco, ');
    SQL.Add('host_servidor, porta, banco_dados, username, senha, novo_id_sql, ');
    SQL.Add('pathprojeto, form_cor, form_font_name, form_titulo_corfundo ');
    SQL.Add('from crud_projeto ');
    SQL.Add('where idprojeto = ' + IntToStr(AIdProjeto));

    try
      Open;

      if not EOF then begin
        FIdProjeto    := AIdProjeto;
        Projeto       := FieldByName('projeto').AsString;
        Descricao     := FieldByName('descricao').AsString;
        IdTipoBanco   := FieldByName('idtipo_banco').AsInteger;
        TipoBanco     := FieldByName('tipo_banco').AsString;
        HostServidor  := FieldByName('host_servidor').AsString;
        BancoDados    := FieldByName('banco_dados').AsString;
        Porta         := FieldByName('porta').AsString;
        Username      := FieldByName('username').AsString;
        Senha         := FieldByName('senha').AsString;
        NovoID_Sql    := FieldByName('novo_id_sql').AsString;
        PathProjeto   := FieldByName('pathprojeto').AsString;
        FForm_Cor       := FieldByName('form_cor').AsInteger;
        FForm_Font_Name := FieldByName('form_font_name').AsString;
        FForm_Titulo_CorFundo := FieldByName('form_titulo_corfundo').AsInteger;

        Result := True;
      end;

      Close;
    except
      on E: Exception do
        FErro := E.Message;
    end;
  end;
end;

function TServiceProjeto.Deletar(AIdProjeto: Integer): Boolean;
// deleta o projeto e os dados vinculados em crud_table e crud_campo
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('delete from crud_projeto ');
    SQL.Add('where idprojeto = ' + IntToStr(AIdProjeto));

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      Result := True;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := E.Message;
      end;
    end;
  end;
end;

function TServiceProjeto.DataSetProjetos(APesquisa: String): TDataSource;
//dataset de projetos para dbgrid
var
  q: TZQuery;
begin
  FErro := '';
  Result := TDataSource.Create(nil);
  q := DMServer.NewQuery();

  q.SQL.Add('select idprojeto, projeto, tipo_banco ');
  q.SQL.Add('from crud_projeto ');

  if APesquisa.Trim <> '' then begin
    q.SQL.Add('where projeto like :pesquisa ');
    q.ParamByName('pesquisa').AsString := '%' + APesquisa.Trim + '%';
  end;

  q.SQL.Add('order by projeto asc ');

  try
    q.Open;
    Result.DataSet := q;
    // fechar lá no destino/cliente
  except
    on E: Exception do
      FErro := E.Message;
  end;
end;

function TServiceProjeto.ExisteProjeto(AProjeto, ATipoBanco : String): Integer;
//verifica se o projeto já está cadastrado
begin
  Result := 0;

  with DMServer.NewQuery() do begin
    SQL.Add('select idprojeto ');
    SQL.Add('from crud_projeto ');
    SQL.Add('where lower(projeto) = :projeto and lower(tipo_banco) = :tipo_banco ');

    ParamByName('projeto').AsString := LowerCase(AProjeto);
    ParamByName('tipo_banco').AsString := LowerCase(ATipoBanco);

    try
      Open;

      if not EOF then
        Result := FieldByName('idprojeto').AsInteger;

      Close;
    except

    end;
  end;
end;

procedure TServiceProjeto.SetProjetoDefaults(AIdProjeto: Integer; APathProjeto: string; AFormCor: Integer;
                                             AFormFontName: String; AFormTituloCor: Integer);
//salva o path do projeto
begin
  with DMServer.NewQuery() do begin
    SQL.Add('update crud_projeto set ');
    SQL.Add('pathprojeto = :pathprojeto, ');
    SQL.Add('form_cor = :form_cor, ');
    SQL.Add('form_font_name = :form_font_name, ');
    SQL.Add('form_titulo_corfundo = :form_titulo_corfundo ');
    SQL.Add('where idprojeto = :idprojeto ');

    ParamByName('pathprojeto').AsString           := APathProjeto;
    ParamByName('idprojeto').AsInteger            := AIdProjeto;
    ParamByName('form_cor').AsInteger             := AFormCor;
    ParamByName('form_font_name').AsString        := AFormFontName;
    ParamByName('form_titulo_corfundo').AsInteger := AFormTituloCor;

    try
      DMServer.TransactionPrepare;
      ExecSQL;
      DMServer.TransactionCommit;
    except
      on E: Exception do
        DMServer.TransactionRollback;
    end;

    Free;
  end;
end;

procedure TServiceProjeto.SetProjetoDefaultsAPI(AIdProjeto: Integer; APathProjeto: string);
//salva o path do projeto
begin
  with DMServer.NewQuery() do begin
    SQL.Add('update crud_projeto set ');
    SQL.Add('pathprojeto_api = :pathprojeto_api ');
    SQL.Add('where idprojeto = :idprojeto ');

    ParamByName('pathprojeto_api').AsString := APathProjeto;
    ParamByName('idprojeto').AsInteger      := AIdProjeto;

    try
      DMServer.TransactionPrepare;
      ExecSQL;
      DMServer.TransactionCommit;
    except
      on E: Exception do
        DMServer.TransactionRollback;
    end;

    Free;
  end;
end;

function TServiceProjeto.VaiUsarFortesReport(AIdProjeto: Integer): Boolean;
//retorna se usará fortes report
begin
  Result := False;
  with DMServer.NewQuery() do begin
    SQL.Add('select coalesce(count(*),0) as qde ');
    SQL.Add('from crud_campo c ');
    SQL.Add('inner join crud_tabela t on t.idtabela = c.idtabela ');
    SQL.Add('inner join crud_projeto p on p.idprojeto = t.idprojeto ');
    SQL.Add('where c.excluir_do_insert_update = 0 ');
    SQL.Add('and t.criar_report = 1 and c.incluir_na_grid = 1 ');
    SQL.Add('and p.idprojeto = ' + IntToStr(AIdProjeto) );

    Open;

    if not EOF then
      Result := (FieldByName('qde').AsInteger > 0);

    Close;
    Free;
  end;
end;

end.

