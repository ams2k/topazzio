unit Service.InfoTabelas;

// Processa tabelas do banco de dados de origem, informado no projeto
//
// Libs do Oracle: (libclntsh.so, libocci.so)
//   sudo pacman -S yay
//   yay -S oracle-instantclient-basic oracle-instantclient-sdk
//
// Libs do SQL Server (/usr/lib/libsybdb.so)
//   sudo pacman -S freetds
//   sudo ln -s /usr/lib/libsybdb.so.5 /usr/lib/sybdb.so

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ZConnection,DB, SQLDB,  ZDataset, MSSQLConn, Dialogs,
  fpjson, jsonparser, DateUtils, ZDatasetUtils,
  Util.ProjetoCommon, Util.ProjetoLazarus, Util.JsonResult;

type
  { TServiceInfoTabelas }

  TServiceInfoTabelas = class
    private
      FConn: TZConnection;
      FConnSQLServer: TMSSQLConnection;
      FSQLServerTransaction: TSQLTransaction;
      FJson: TJsonResult;
      FJsonArray: TJSONArray;

      FErro: String;
      FTipoBanco: TTipoBanco;
      FIdProjeto: Integer;
      FBancoDados: String;
      FTableName: String;
      FObjectName: String;
      FFieldPrimaryKey: String;
      FScriptTabela: String;

      FCriaDBGrid: Boolean;
      FCriarFormPesquisa: Boolean;
      FPesquisaSelectFieldsCount: Integer;
      FPesquisaSelectFieldsMax: Integer;

      function OnlyNumbers(const S: String): String;
      function ScriptTable_AddField(lColumn_Name, lData_Type, lMaximum_Length,
               lIs_Nullable, lColumn_Default, lNumeric_Precision, lNumeric_Scale,
               lIs_Identity, sFieldTipoFP: String; ARecTotal, ARecAtual: Integer): String;
      function SalvaTabela: Integer;
      procedure SalvaCampos(AIdTabela: Integer);
      function ScriptTable_AddRodape: String;
      function SQLTypeToPascal(const SQLType: string): string;
      function GetTableSQL(ABancoDados, APesquisa: String): String;
      function GetTableFields(ATableName: String): String;
      function GetTableFieldsDetails(ATableName: String): TDataSet;
      function GetFieldNullNumber(AValue: String): String;
      function IsFieldPrimaryKey(AField: String): Boolean;
      function CapitalizaTexto(AValue: String): String;
      function RemoveFieldUnderscore(AValue: String): String;
      function ProcessaTabelaSQL(ATableName: string): Boolean;
      function PesquisaSelectFieldsHasPrimaryKey(ALista, APK: String): Boolean;
      function AnalisaScript(AScript: string): string;
      procedure ConnectionOpen;
      procedure ConnectionClose;
      procedure ConnectionValidate;
      procedure ExtractTableName(AValue: String);
      procedure ExtractFieldDescription(AField: String);
    public
      constructor Create(ATipoBanco: TTipoBanco; AIdProjeto: Integer);
      destructor Destroy; override;
      property GetErro: String read FErro;
      property CriarFormPesquisa: Boolean read FCriarFormPesquisa write FCriarFormPesquisa;
      property CriarDBGrid: Boolean read FCriaDBGrid write FCriaDBGrid;
      function DataSetTabelas(APesquisa: String): TDataSource;
      function ProcessaTabelas(AListTableNames: TStringList): Boolean;
      function ProcessaTabelaScript(ACreateTableScript: string): Boolean;
      class function GetExemploScript(ATipoBanco: TTipoBanco): String;
  end;

implementation

uses
  Service.Projeto, Service.Tabela, Service.Campo, Util.Idioma;

{ TServiceInfoTabelas }

constructor TServiceInfoTabelas.Create(ATipoBanco: TTipoBanco; AIdProjeto: Integer);
//construtor da classe
begin
  FJson      := TJsonResult.New;
  FJsonArray := TJSONArray.Create;

  FTipoBanco := ATipoBanco;
  FIdProjeto := AIdProjeto;

  FBancoDados                := '';
  FTableName                 := '';
  FObjectName                := '';
  FScriptTabela              := '';
  FFieldPrimaryKey           := '';
  FCriaDBGrid                := True;
  FCriarFormPesquisa         := True;
  FPesquisaSelectFieldsCount := 0;
  FPesquisaSelectFieldsMax   := 5;

  ConnectionOpen;
end;

destructor TServiceInfoTabelas.Destroy;
//destrutor da classe
begin
  ConnectionClose;
  inherited Destroy;
end;

function TServiceInfoTabelas.SQLTypeToPascal(const SQLType: string): string;
//converte tipo de dado sql em tipo de dado do freepascal
var
  T: string;
begin
  T := LowerCase(SQLType.Trim);

  if (T = 'primary') or (T = 'constraint') or (T = 'using') or (T.Contains('nextval')) then Exit('');

  if T.Contains('int') or T.Contains('integer') or T.Contains('mediumint') or
     T.Contains('bigint') or T.Contains('smallint') or T.Contains('tinyint') or
     T.Contains('serial') or T.Contains('serial4') or T.Contains('year') then
    Exit('Integer')
  else if T.Contains('char') or T.Contains('character') or T.Contains('text') or T.Contains('varchar') then
    Exit('string')
  else if T.Contains('real') or T.Contains('float') or T.Contains('double') or
     T.Contains('decimal') or T.Contains('number') or T.Contains('numeric') then
     Exit('Double')
  else if T.Contains('money') then
     Exit('Currency')
  else if T.Contains('bool') or T.Contains('boolean') or T.Contains('bit') then
    Exit('Boolean')
  else if T.Contains('datetime') or T.Contains('smalldatetime') or T.Contains('timestamp') or T.Contains('date') or T.Contains('time') then
    Exit('TDateTime')
  else if T.Contains('tinyblob') or T.Contains('mediumblob') or T.Contains('blob') or
    T.Contains('longblob') or T.Contains('image') or T.Contains('binary') or
    T.Contains('varbinary') or T.Contains('bytea') then
    Exit('TImage')
  else
    Exit('string');
end;

function TServiceInfoTabelas.GetTableSQL(ABancoDados, APesquisa: String): String;
//retorna uma conexão do banco de dados
begin
  case FTipoBanco of
    SQLITE:
      begin
        Result := 'SELECT cast(name as varchar(100)) as table_name, 1 as selecao FROM sqlite_master WHERE ';
        if APesquisa <> '' then
          Result := Result + 'name like ' + QuotedStr('%' + APesquisa + '%') + ' and ';
        Result := Result + 'type=''table'' AND name NOT LIKE ''sqlite_%'' order by table_name asc';
      end;
    POSTGRE:
      begin
        Result := 'SELECT tablename as table_name, 1 as selecao FROM pg_tables WHERE ';
        if APesquisa <> '' then
          Result := Result + 'tablename like ' + QuotedStr('%' + APesquisa + '%') + ' and ';
        Result := Result + 'schemaname = ''public'' order by table_name asc ';
      end;
    MYSQL:
      begin //Result := 'SHOW TABLES';
        Result := 'SELECT table_name FROM, 1 as selecao information_schema.tables WHERE ';
        if APesquisa <> '' then
          Result := Result + 'table_name like ' + QuotedStr('%' + APesquisa + '%') + ' and ';
        Result := Result + 'table_schema = ''' + ABancoDados + ''' order by table_name asc ';
      end;
    MARIADB:
      begin
        Result := 'SELECT table_name, 1 as selecao FROM information_schema.tables WHERE ';
        if APesquisa <> '' then
          Result := Result + 'table_name like ' + QuotedStr('%' + APesquisa + '%') + ' and ';
        Result := Result + 'table_schema = ''' + ABancoDados + ''' order by table_name asc ';
      end;
    FIREBIRD:
      begin
        Result := 'SELECT RDB$RELATION_NAME as table_name, 1 as selecao FROM RDB$RELATIONS WHERE ';
        if APesquisa <> '' then
          Result := Result + 'RDB$RELATION_NAME like ' + QuotedStr('%' + APesquisa + '%') + ' and ';
        Result := Result + 'RDB$SYSTEM_FLAG = 0 order by table_name asc';
      end;
    SQLSERVER:
      begin
        Result := 'SELECT name as table_name, 1 as selecao FROM sysobjects WHERE ';
        if APesquisa <> '' then
          Result := Result + 'name like ' + QuotedStr('%' + APesquisa + '%') + ' and ';
        Result := Result + 'xtype = ''U'' order by table_name asc';
      end;
    ORACLE:
      begin
        Result := 'SELECT table_name, 1 as selecao FROM user_tables ';
        if APesquisa <> '' then
          Result := Result + 'where table_name like ' + QuotedStr('%' + APesquisa + '%') + ' and ';
        Result := Result + 'order by table_name asc';
      end
  else
    Result := '';
  end;
end;

function TServiceInfoTabelas.GetTableFields(ATableName: String): String;
//retorna os campos da tabela
begin
  case FTipoBanco of
    SQLITE:     //retorna o create table ...
      Result := 'SELECT sql FROM sqlite_master WHERE type = ''table'' AND name = ''' + ATableName + '''';
      //Result := 'PRAGMA table_info(''' + ATableName + ''') '; //SELECT * FROM PRAGMA_TABLE_INFO('api_rotas');
    POSTGRE: //column_default = nextval('cliente_idcliente_seq'::regclass) (is_identity = YES)
      Result := 'SELECT column_name, ' +               // nome do campo
                'data_type, ' +                        // integer, character varying, numeric, date, blob
                ''''' as column_type, ' +              // null
                'character_maximum_length, ' +         // null, número inteiro
                'is_nullable, ' +                      // YES / NO
                'column_default, ' +                   // 0, null, nextval('cliente_idcliente_seq'::regclass)
                'numeric_precision, ' +                // null, número inteiro
                'numeric_scale, ' +                    // null, número inteiro
                'is_identity ' +                       // YES / NO
                'FROM information_schema.columns ' +
                'WHERE table_name = ''' + ATableName + ''' ';
    MYSQL:
      Result := 'SELECT column_name, ' +               // nome do campo
                'data_type, ' +                        // int, varchar, float, etc
                'column_type, ' +                      // int(11), varchar(50)
                'character_maximum_length, ' +         // null, número inteiro
                'is_nullable, ' +                      // YES / NO
                'column_default, ' +                   // null, número inteiro
                'numeric_precision, ' +                // null, número inteiro
                'numeric_scale, ' +                    // null, número inteiro
                'case column_key ' +
                ' when ''PRI'' then ''YES'' ' +
                ' else ''NO'' ' +
                'end as is_identity ' +                // YES / NO
                'FROM information_schema.columns ' +
                'WHERE table_name = ''' + ATableName + ''' ';
    MARIADB:
      Result := 'SELECT column_name, ' +               // nome do campo
                'data_type, ' +                        // int, varchar, float, etc
                'column_type, ' +                      // int(11), varchar(50)
                'character_maximum_length, ' +         // null, número inteiro
                'is_nullable, ' +                      // YES / NO
                'column_default, ' +                   // null, número inteiro
                'numeric_precision, ' +                // null, número inteiro
                'numeric_scale, ' +                    // null, número inteiro
                'case column_key ' +
                ' when ''PRI'' then ''YES'' ' +
                ' else ''NO'' ' +
                'end as is_identity ' +                // YES / NO
                'FROM information_schema.columns ' +
                'WHERE table_name = ''' + ATableName + ''' ';
    FIREBIRD:
      Result :=
       'select ' +
       'rf.rdb$field_name as column_name, ' +          // nome do campo
       'case f.rdb$FIELD_SUB_TYPE ' +
       '  when 1 then ''NUMERIC''' +
       '  when 2 then ''DECIMAL''' +
       '  else ' +
       '   case f.rdb$field_type ' +
       '     when 7 then ''SMALLINT''' +
       '     when 8 then ''INTEGER''' +
       '     when 10 then ''FLOAT''' +
       '     when 12 then ''DATE''' +
       '     when 13 then ''TIME''' +
       '     when 14 then ''CHAR''' +
       '     when 16 then ''BIGINT''' +
       '     when 27 then ''DOUBLE''' +
       '     when 35 then ''TIMESTAMP''' +
       '     when 37 then ''VARCHAR''' +
       '     when 261 then ''BLOB''' +
       '     else ''''' +
       '   end ' +
       'end as data_type, ' +                               // int, integer, varchar, number, etc
       ''''' as column_type, ' +                            // null
       'f.rdb$field_length as character_maximum_length, ' + // número inteiro (tamanho do campo)
       'case rf.RDB$NULL_FLAG ' +
       ' when 1 then ''YES'' ' +
       ' else ''NO'' ' +
       'end as is_nullable, ' +                             // YES / NO
       ''''' as column_default, ' +                         // null
       'f.rdb$field_precision as numeric_precision, ' +     // null, número inteiro
       'f.rdb$field_scale as numeric_scale, ' +             // null, número inteiro
       'case COALESCE(rf.RDB$IDENTITY_TYPE, 0) ' +
       ' when 0 then ''NO'' ' +
       ' else ''YES'' ' +
       'end as is_identity ' +                              // YES / NO
       'from rdb$fields f ' +
       'join rdb$relation_fields rf on rf.rdb$field_source = f.rdb$field_name ' +
       'where rf.rdb$relation_name =  ''' + UpperCase(ATableName) + ''' ';
    SQLSERVER:
      Result :=
        'SELECT c.name AS column_name, ' +             // nome do campo
        't.name AS data_type, ' +                      // int, integer, varchar, number, etc
        ''''' as column_type, ' +                      // null
        'c.max_length as character_maximum_length, ' + // número inteiro (tamanho do campo)
        'case c.is_nullable ' +
        '  when 1 then ''YES'' ' +
        '  else ''NO'' ' +
        'end as is_nullable, ' +                       // YES / NO
        ''''' as column_default, ' +                   // null
        'c.precision as numeric_precision, ' +         // número inteiro
        'c.scale as numeric_scale, ' +                 // número inteiro
        'case c.is_identity ' +
        '  when 1 then ''YES'' ' +
        '  else ''NO'' ' +
        'end as is_identity ' +                        // YES / NO
        'FROM sys.columns c JOIN sys.types t ON c.user_type_id = t.user_type_id ' +
        'WHERE c.object_id = OBJECT_ID(''dbo.' + ATableName + ''') ';
    ORACLE:
      Result :=
        'SELECT column_name, ' +                       // nome do campo
        'data_type, ' +                                // integer, varchar, number, etc
        ''''' as column_type, ' +                      // null
        'char_length as character_maximum_length, ' +  // número inteiro (tamanho do campo)
        'case nullable '+
        ' when NULL then ''YES'' ' +
        ' when ''Y'' then ''YES'' ' +
        ' when ''N'' then ''NO'' ' +
        ' else ''NO'' ' +
        'end as is_nullable, ' +                       // YES / NO
        'data_default as column_default, ' +           // null
        'data_Precision as numeric_precision, ' +      // null, 0, 10 (Ex: Number(10,2)
        'data_scale as numeric_scale, ' +              // null, 0, 2  (Ex: Number(10,2)
        'identity_column as is_identity ' +            // YES / NO
        'FROM user_tab_columns WHERE table_name = ''' + UpperCase(ATableName) + '''';
    else
      Result := '';
  end;
end;

function TServiceInfoTabelas.GetTableFieldsDetails(ATableName: String): TDataSet;
//retorna um dataset com detalhes dos campos da tabela
var
  q: TZQuery;
  q2: TSQLQuery;
begin
  ConnectionValidate;

  if FTipoBanco = SQLSERVER then begin
    //apenas sqlserver
    q2 := TSQLQuery.Create(nil);

    try
      q2.DataBase := FConnSQLServer;
      q2.SQL.Text := GetTableFields(ATableName);
      q2.Open;

      Result := q2;
    except
      q2.Free;
      raise;
    end;
  end
  else begin
    //todos os outros tipos de bancos de dados
    q := TZQuery.Create(nil);

    try
      q.Connection := FConn;
      q.SQL.Text   := GetTableFields(ATableName);
      q.Open;

      Result := q;
    except
      q.Free;
      raise;
    end;
  end;
end;

function TServiceInfoTabelas.GetFieldNullNumber(AValue: String): String;
// se for null retorn '0'
begin
  if (System.Length(AValue) = 0) then
    Result := '0'
  else
    Result := AValue;
end;

function TServiceInfoTabelas.SalvaTabela: Integer;
//cadastra a tabela
var
  t: TServiceTabela;
begin
  Result := 0;

  if FIdProjeto < 1 then begin
    FErro := InfoTabelas.SalvaTabelaMensagem1;
    Exit;
  end;

  if (FJson.CountPairs < 1) or (FJson.CountPairsArray < 1) then begin
    FErro := InfoTabelas.SalvaTabelaMensagem2;
    Exit;
  end;

  t := TServiceTabela.Create(FIdProjeto);
  t.Tabela              := FTableName;
  t.NomeObjeto          := FObjectName;
  t.CriarDbGridForm     := FCriaDBGrid;
  t.CriarFormPesquisa   := FCriarFormPesquisa;
  t.CriarReport         := (FCriaDBGrid or FCriarFormPesquisa);
  t.ScriptTabela        := FScriptTabela;

  Result := t.Salvar(0, False);

  if Result > 0 then
    SalvaCampos(Result)
  else
    FErro := FErro + t.GetErro + sLineBreak;

  t.Free;
end;

procedure TServiceInfoTabelas.SalvaCampos(AIdTabela: Integer);
//cadastra os campos
var
  i, n: Integer;
  j: TJSONObject;
  ar: TJSONArray;
begin
  if AIdTabela < 1 then begin
    FErro := InfoTabelas.SalvaTabelaMensagem3 + sLineBreak;
    Exit;
  end;

  ar := FJson.GetArrayFromField('fields');

  for i := 0 to ar.Count -1 do begin
    j := TJSONObject( ar.Items[i] );

    with TServiceCampo.Create(AIdTabela) do begin
      Campo           := j.Get('field_name', '');
      CampoAlias      := Campo;
      Tipo            := j.Get('field_type', '');
      Tamanho         := j.Get('field_size', '0');
      Precisao        := j.Get('field_precision', '0');
      Escala          := j.Get('field_scale', '0');
      IsChavePrimaria := j.Get('field_primary_key', false);
      TipoFP          := j.Get('field_type_fp', '');
      Objeto          := j.Get('field_object', '');
      IsCurrencyField := j.Get('field_iscurrency', false);
      Componente      := j.Get('field_componente', 'TEdit');
      IncluirNaGrid   := j.Get('field_incluir_na_grid', false);
      IsRequerido     := j.Get('field_isrequerido', false);
      AceitaNull      := j.Get('field_nullable', false);
      Ordem           := i+1;

      n := Salvar(0, False);

      if n < 1 then
        FErro := FErro + GetErro + sLineBreak;

      Free;
    end;

    j.Free;
  end;

  //ar.Free; //não descomentar (será eliminado automaticamente)
end;

function TServiceInfoTabelas.IsFieldPrimaryKey(AField: String): Boolean;
//verifica se o campo é chave primária
begin
  AField := LowerCase( AField );
  Result := AField.Contains('serial') or AField.Contains('primary key') or AField.Contains('identity') or AField.Contains('auto_increment');
end;

function TServiceInfoTabelas.CapitalizaTexto(AValue: String): String;
//Transforma a primeira letra em maiúscula
begin
  if AValue.Length > 1 then
     Result := UpperCase(AValue.Substring(0, 1)) + AValue.Substring(1)
  else
    Result := AValue.ToUpper;
end;

function TServiceInfoTabelas.RemoveFieldUnderscore(AValue: String): String;
//remove o underscore entre as palavras: Ex: id_produto --> IdProduto
var
  s: array of string;
  i: Integer;
begin
  Result := Trim( AValue );

  if AValue.IndexOf('_') > 0 then begin
    s := AValue.Split(['_'], TStringSplitOptions.ExcludeEmpty);
    Result := '';

    for i := 0 to High(s) do
      Result := Result + CapitalizaTexto( s[i].Trim() );

    SetLength(s, 0);
  end
  else
    Result := CapitalizaTexto( Result );
end;

procedure TServiceInfoTabelas.ConnectionOpen;
//retorna uma conexão
var
  p: TServiceProjeto;
  lPathDLL: String;
begin
  ConnectionClose;
  FErro       := '';
  FBancoDados := '';
  lPathDLL    := ExtractFileDir( ParamStr(0) ) + PathDelim; // DLLs na pasta raiz
  p := TServiceProjeto.Create;

  if p.Ler( FIdProjeto ) then begin
    FBancoDados := p.BancoDados;

    try
      if FTipoBanco = SQLSERVER then begin
        //apenas o sqlserver (diferentão!!)
        FConnSQLServer := TMSSQLConnection.Create(nil);
        FSQLServerTransaction := TSQLTransaction.Create(nil);

        FConnSQLServer.Transaction := FSQLServerTransaction;
        FSQLServerTransaction.DataBase := FConnSQLServer;

        with FConnSQLServer do begin
          LoginPrompt    := False;
          KeepConnection := False;
          HostName       := p.HostServidor + ':' + p.Porta;
          DatabaseName   := p.BancoDados;
          UserName       := p.Username;
          Password       := p.Senha;

          {$IFDEF WINDOWS}
          //driver: libsybdb-5.dll ou ntwdblib.dll ou dblib.dll ou libsybdb.so (linux) ou libsybdb.dylib (macos)
          //Database := 'Provider=SQLOLEDB.1;Persist Security Info=True;Data Source=' + p.HostServidor +','+ p.Porta + '; Initial Catalog=' + p.BancoDados+ '; User ID=' +  p.Username + ';password=' + p.Senha;
          //Protocol := 'ado';
          {$ENDIF}

          Connected := True;
          FSQLServerTransaction.Active := True;
        end;
      end
      else begin
        //todos os outros tipos de bancos de dados
        FConn := TZConnection.Create(nil);

        with FConn do begin
          case TTipoBanco(p.IdTipoBanco) of
            POSTGRE:
              Protocol := 'postgresql';
            MYSQL:
              Protocol := 'mysql';
            FIREBIRD:
              Protocol := 'firebird';
            SQLITE:
              Protocol := 'sqlite';
            ORACLE:
              Protocol := 'oracle';
            MARIADB:
              Protocol := 'mariadb';
          end;

          case TTipoBanco(p.IdTipoBanco) of
            ORACLE:
              //127.0.0.1:1521/xe; // ou outro service_name
              Database := p.HostServidor + ':' + p.Porta + '/' + p.BancoDados;
          else
            HostName := p.HostServidor;
            Port     := StrToIntDef(p.Porta, 0);
            Database := p.BancoDados;
          end;

          User     := p.Username;
          Password := p.Senha;

          {$IFDEF WINDOWS}
            if Protocol.Contains('sqlite') then
              LibraryLocation := lPathDLL + 'sqlite3.dll';
            if Protocol.Contains('firebird') then
              LibraryLocation := lPathDLL + 'fbclient.dll';
            if Protocol.Contains('mariadb') then
              LibraryLocation := lPathDLL + 'libmariadb.dll'; // 32 bits
            if Protocol.Contains('mysql') then
              LibraryLocation := lPathDLL + 'libmysql.dll';  // 32 bits
            if Protocol.Contains('postgresql') then
              LibraryLocation := lPathDLL + 'libpq-15.dll';
          {$ENDIF}

          Connect;
        end;
      end;
    except
      on E: Exception do
        FErro := E.Message;
    end;
  end else
    FErro := p.GetErro;

  p.Free;
end;

procedure TServiceInfoTabelas.ConnectionClose;
//fecha a conexão
begin
  if FTipoBanco = SQLSERVER then begin
    //apenas para o sqlserver
    if Assigned(FConnSQLServer) then begin
      FConnSQLServer.Connected := False;
      FConnSQLServer.Free;
    end;
  end
  else begin
    //todos os outros tipos de bancos de dados
    if Assigned(FConn) then begin
      FConn.Disconnect;
      FConn.Free;
    end;
  end;
end;

procedure TServiceInfoTabelas.ConnectionValidate;
//verifica se a conexão está aberta
begin
  if FTipoBanco = SQLSERVER then begin
    //apenas sql server
    if not Assigned(FConnSQLServer) or not FConnSQLServer.Connected then
      ConnectionOpen;
  end
  else
    //todos os outros tipos de bancos de dados
    if not Assigned(FConn) or not FConn.Connected then
      ConnectionOpen;
end;

procedure TServiceInfoTabelas.ExtractTableName(AValue: String);
//extrai o nome da tabela e nome para o objeto. Ex: TTabelaNome
var
  i: integer;
begin
  if FTableName <> '' then Exit;

  AValue := LowerCase( AValue );

  if AValue.StartsWith('create table ', True) then begin

    i := AValue.IndexOf('(');

    if i > 0 then begin
      AValue := Trim( AValue.Substring(0, i) );
      i := AValue.LastIndexOf(' ');

      if i > 0 then begin
        AValue := Trim( AValue.Substring(i+1) ); // nome da tabela
        FTableName := AValue;

        i := FTableName.IndexOf('.'); //dbo.table_name ou user.table_name
        if i >= 0 then FTableName := Trim(FTableName.Substring(i));

        FObjectName := RemoveFieldUnderscore( FTableName.ToLower );

        FJson.AddPair('table_name', FTableName);
        FJson.AddPair('object_name', FObjectName);
        AValue := '';

        FPesquisaSelectFieldsCount := FPesquisaSelectFieldsCount + 1;
      end;
    end;
  end;
end;

procedure TServiceInfoTabelas.ExtractFieldDescription(AField: String);
//extrai informações do campo
var
  i: integer;
  s: array of string;
  bPrimaryKey, bIsCurrency, bIncluirNaGrid, bRequerido, bAceitaNull: Boolean;
  sFieldName, sFieldTipo, sFieldSize, sFieldPrecision, sFieldScale: String;
  sFieldTipoFP, sFieldObject, sComponente: String;
begin
  AField := LowerCase( AField.Trim );
  bPrimaryKey    := False;
  bIsCurrency    := False;
  bIncluirNaGrid := False;
  bRequerido     := False;
  bAceitaNull    := False;
  sFieldName     := '';
  sFieldTipo     := '';
  sFieldSize     := '0';
  sFieldPrecision:= '0';
  sFieldScale    := '0';
  sFieldTipoFP   := '';
  sFieldObject   := '';
  sComponente    := 'TEdit';

  if not (AField.StartsWith('create table ', True)) and not (AField.StartsWith(')', True)) then begin
    // remover vírgula final
    if AField.EndsWith(',') then
      AField := Copy(AField, 1, Length(AField) - 1);

    //cria um arry
    s := AField.Split([' '], TStringSplitOptions.ExcludeEmpty);

    // aceita nulo
    bAceitaNull := (Pos('not null', AField.ToLower) > 0);

    //remove espaços
    for i := 0 to High(s) do
      s[i] := s[i].Trim();

    //nome do campo
    sFieldName := s[0].Trim;

    if ('primary, constraint, using').IndexOf(sFieldName) >= 0 then Exit;

    //evita campo inválido por causa do split([',']) quando o campo
    //contiver 'number(8,2)' retornando: '2)'
    if sFieldName.Contains(')') then Exit;

    //nome para o objeto
    sFieldObject := RemoveFieldUnderscore( sFieldName.ToLower );

    //checa se este campo é uma chave primária
    bPrimaryKey := IsFieldPrimaryKey( AField );

    if bPrimaryKey then
      bIncluirNaGrid := True;

    //tipo field no sql e seu max_lenght
    sFieldTipo := s[1].Trim;
    i := s[1].IndexOf('(');

    if i > 0 then begin
      // o size está junto ao tipo do campo: Ex: varchar(40)
      sFieldTipo := s[1].Substring(0, i).Trim; //campo: varchar
      sFieldSize := s[1].Substring(i).Trim;    //tamanho (40)
    end else begin
      //o size está separado do tipo do campo:
      //Ex: varchar (40)
      //Ex: numeric (8,2) //field_length e field_scale
      if (High(s) >= 2) and (s[2].IndexOf('(') >= 0) then
        sFieldSize := s[2].Trim;
    end;

    //se por acaso o campo vier com ')' no final, geralmente ocorre
    //se o campo for o último no script
    if sFieldTipo.Contains(')') then begin
      i := sFieldTipo.IndexOf(')');
      if i > 0 then
        sFieldTipo := sFieldTipo.Substring(0,i).trim;
    end;

    //tamanho do campo. Ex: (40) ou (8,2)
    if sFieldSize.Trim <> '' then begin
      i := sFieldSize.IndexOf('(');
      if i >= 0 then begin
        sFieldSize := sFieldSize.Substring(i+1);
        i := sFieldSize.IndexOf(')');

        if i > 0 then begin
          sFieldSize := sFieldSize.Substring(0, i); // 8,2
          i := sFieldSize.IndexOf(',');

          if i > 0 then begin
            sFieldScale := sFieldSize.Substring(i+1);   // 2
            sFieldPrecision := sFieldSize.Substring(0, i); // 8
            sFieldSize := '0';
          end;
        end;
      end;

      sFieldSize      := sFieldSize.Trim;
      sFieldPrecision := sFieldPrecision.Trim;
      sFieldScale     := sFieldScale.Trim;

      sFieldSize      := OnlyNumbers(sFieldSize);
      sFieldPrecision := OnlyNumbers(sFieldPrecision);
      sFieldScale     := OnlyNumbers(sFieldScale);

      if StrToIntDef(sFieldSize, 0) = 0 then sFieldSize := '0';
      if StrToIntDef(sFieldPrecision, 0) = 0 then sFieldPrecision := '0';
      if StrToIntDef(sFieldScale, 0) = 0 then sFieldScale := '0';
    end;

    //tipo field do freepascal
    sFieldTipoFP := SQLTypeToPascal( sFieldTipo );

    //se é chave primária... Força para o tipo integer
    if bPrimaryKey then
       sFieldTipoFP := 'Integer';

    //campo monetário (number, numeric)
    if not (bPrimaryKey) and (sFieldTipo.ToLower.StartsWith('num')) and (StrToIntDef(sFieldPrecision, 0)>0) and (StrToIntDef(sFieldScale, 0)>0) then
      sFieldTipoFP := 'Currency';

    //campo Double
    if (StrToIntDef(sFieldScale, 0) = 0) and ((sFieldTipoFP = 'Double') or (sFieldTipoFP = 'Currency')) then
      sFieldScale := '2';

    // se precisao >0 e escala = 0 ==> Integer
    if (StrToIntDef(sFieldSize, 0) = 0 ) and
       (StrToIntDef(sFieldPrecision, 0) > 0) and
       (StrToIntDef(sFieldScale, 0) = 0) and
       (sFieldName.ToLower.StartsWith('num')) then
         sFieldTipoFP := 'Integer';

    //campo para a lista do dataset ?
    if (sFieldTipoFP.ToLower = 'string') and (StrToIntDef(sFieldSize, 0) > 0) then begin
       bIncluirNaGrid := True;
       bRequerido := True;
    end;

    //outros tipos de dados aceitos para a lista de campos no dbgrid
    if (sFieldTipoFP.ToLower = 'currency') or (sFieldTipoFP.ToLower = 'tdatetime') then
      bIncluirNaGrid := True;

    // contagem de campos no dataset de pesquisa
    if bIncluirNaGrid then begin
      FPesquisaSelectFieldsCount :=  FPesquisaSelectFieldsCount + 1;

      //evita muitos campos na lista do select para a grid
      if FPesquisaSelectFieldsCount > FPesquisaSelectFieldsMax then
        bIncluirNaGrid := False;
    end;

    //pode ser um campo de edição monetária ou percentual ?
    bIsCurrency := (sFieldTipoFP.ToLower = 'currency');

    //tipo de componente a ser utilizado: TEdit, TMemo, TCheckBox, TImage
    sComponente := 'TEdit';
    if (sFieldTipoFP.ToLower.Contains('string')) and (StrToIntDef(sFieldSize, 0)<1) then sComponente := 'TMemo';
    if sFieldTipoFP.Contains('Boolean') then sComponente := 'TCheckBox';
    if sFieldTipoFP.Contains('TImage') then sComponente := 'TImage';
    if sFieldTipoFP.Contains('TDateTime') then sComponente := 'TDateTime';

    //adiciona os dados do campo no array
    if (sFieldName <> '') and (sFieldTipo <> '') then
      FJsonArray.Add(TJsonResult.New
                                .AddPair('field_name', sFieldName)
                                .AddPair('field_type', sFieldTipo)
                                .AddPair('field_size', sFieldSize)
                                .AddPair('field_precision', sFieldPrecision)
                                .AddPair('field_scale', sFieldScale)
                                .AddPair('field_primary_key', bPrimaryKey)
                                .AddPair('field_type_fp', sFieldTipoFP)
                                .AddPair('field_object', sFieldObject)
                                .AddPair('field_iscurrency', bIsCurrency)
                                .AddPair('field_componente', sComponente)
                                .AddPair('field_incluir_na_grid', bIncluirNaGrid)
                                .AddPair('field_isrequerido', bRequerido)
                                .AddPair('field_nullable', bAceitaNull)
                                .GetObject);

  end;
end;

function TServiceInfoTabelas.DataSetTabelas(APesquisa: String): TDataSource;
//retorna uma dataset para uma dbgrid
var
  q : TZQuery;
  q2: TSQLQuery;
begin
  Result := TDataSource.Create(nil);
  ConnectionOpen;
  FErro := '';

  if FTipoBanco = SQLSERVER then begin
    //apenas sqlserver
    if Assigned(FConnSQLServer) and FConnSQLServer.Connected then begin
      q2 := TSQLQuery.Create(nil);
      q2.DataBase := FConnSQLServer;
      q2.SQL.Text := GetTableSQL(FBancoDados, Trim(APesquisa));

      try
        q2.Open;
        Result.DataSet := q2;
      except
        on E: Exception do
          FErro := E.Message;
      end;
    end;
  end
  else begin
    //todos os outros tipos de bancos de dados
    if Assigned(FConn) and FConn.Connected then begin
      q := TZQuery.Create(nil);
      q.Connection := FConn;
      q.SQL.Text   := GetTableSQL(FBancoDados, Trim(APesquisa));

      try
        q.Open;
        Result.DataSet := q;
      except
        on E: Exception do
          FErro := E.Message;
      end;
    end;
  end;
end;

function TServiceInfoTabelas.ProcessaTabelas(AListTableNames: TStringList): Boolean;
//processa a lista de tabelas
var
  i: Integer;
begin
  Result := False;

  if AListTableNames.Count < 1 then begin
    FErro := ViewMain.MenuTabelasInfoTabelasMensagem1;
    Exit;
  end;

  for i := 0 to AListTableNames.Count -1 do
    Result := ProcessaTabelaSQL( AListTableNames[i] );
end;

function TServiceInfoTabelas.ProcessaTabelaSQL(ATableName: string): Boolean;
//cria tabela via sql
var
  q: TDataSet;
  lColumn_Name, lData_Type, sFieldTipoFP, sFieldObject: String;
  lMaximum_Length, lColumn_Default, lIs_Nullable: String;
  lNumeric_Precision, lNumeric_Scale, lIs_Identity: String;
  sComponente: String;
  bIsCurrency, bIncluirNaGrid, bRequerido: Boolean;
  RecTotal, RecAtual: Integer;
begin
  Result                     := False;
  FErro                      := '';
  FTableName                 := ATableName;
  FObjectName                := RemoveFieldUnderscore( ATableName );
  FPesquisaSelectFieldsCount := 0;
  FScriptTabela              := '';
  FFieldPrimaryKey           := '';
  bIsCurrency                := False;
  bIncluirNaGrid             := False;
  bRequerido                 := False;
  sComponente                := 'TEdit';

  q := GetTableFieldsDetails(ATableName);

  if not (q = nil) and (q.RecordCount > 0) then begin
    FErro := '';

    try
      q.First;

      if not q.EOF then begin
        if FTipoBanco = SQLITE then
           Result := ProcessaTabelaScript( q.FieldByName('sql').AsString )
        else begin
          // Dados da tabela
          RecTotal := q.RecordCount;
          RecAtual := 0;
          FJson := TJsonResult.New;
          FJsonArray := TJSONArray.Create;
          FJson.AddPair('table_name', FTableName);
          FJson.AddPair('object_name', FObjectName);

          //inicio do script table
          FScriptTabela := 'create table if not exists ' + FTableName + ' ( ' + sLineBreak;

          q.First;

          while not q.EOF do begin
             RecAtual := RecAtual + 1;
             bIncluirNaGrid := False;
             bRequerido := False;

             // campos da tabela
             lColumn_Name       := q.FieldByName('column_name').AsString; //nome da coluna
             lData_Type         := q.FieldByName('data_type').AsString;   //int, varchar, numeric, etc
             //lColumn_Type       := q.FieldByName('column_type').AsString; //null (na maioria dos casos)
             lMaximum_Length    := GetFieldNullNumber(q.FieldByName('character_maximum_length').AsString); // null, número inteiro
             lIs_Nullable       := UpperCase( q.FieldByName('is_nullable').AsString ); //YES / NO
             lColumn_Default    := q.FieldByName('column_default').AsString; // null, número inteiro, nextval, etc
             lNumeric_Precision := GetFieldNullNumber(q.FieldByName('numeric_precision').AsString); // null, número inteiro
             lNumeric_Scale     := GetFieldNullNumber(q.FieldByName('numeric_scale').AsString); // null, número inteiro
             lIs_Identity       := UpperCase( q.FieldByName('is_identity').AsString ); // YES / NO

             // campo formatado para objeto: (Ex: id_cadastro => IdCadastro)
             sFieldObject := RemoveFieldUnderscore( lColumn_Name.ToLower );

             //tipo field do freepascal
             sFieldTipoFP := SQLTypeToPascal( lData_Type );

             //postgre
             if lColumn_Default.Contains('nextval') then lIs_Identity := 'YES';

             //se é chave primária... Força para o tipo integer
             if lIs_Identity = 'YES' then
               sFieldTipoFP := 'Integer';

             lMaximum_Length    := OnlyNumbers(lMaximum_Length);
             lNumeric_Precision := OnlyNumbers(lNumeric_Precision);
             lNumeric_Scale     := OnlyNumbers(lNumeric_Scale);

             if (lMaximum_Length    = '') then lMaximum_Length    := '0';
             if (lNumeric_Precision = '') then lNumeric_Precision := '0';
             if (lNumeric_Scale     = '') then lNumeric_Scale     := '0';

             // valida a chave primária
             if (FFieldPrimaryKey = '') and (lIs_Identity = 'YES') then begin
               FFieldPrimaryKey := lColumn_Name;
               bIncluirNaGrid := True;
             end;

             //campo monetário
             if (lIs_Identity = 'NO') and (lData_Type.ToLower.StartsWith('num')) and (StrToIntDef(lNumeric_Precision, 0)>0) and (StrToIntDef(lNumeric_Scale, 0)>0) then
               sFieldTipoFP := 'Currency';

             //campo Double
             if (StrToIntDef(lNumeric_Scale, 0) = 0) and ((sFieldTipoFP = 'Double') or (sFieldTipoFP = 'Currency')) then
               lNumeric_Scale := '2';

             // se precisao >0 e escala = 0 ==> Integer
             if (StrToIntDef(lMaximum_Length, 0) = 0 ) and
               (StrToIntDef(lNumeric_Precision, 0) > 0) and
               (StrToIntDef(lNumeric_Scale, 0) = 0) and
               (lData_Type.ToLower.StartsWith('num')) then
                 sFieldTipoFP := 'Integer';

             //campo where para a pesquisa na lista do dataset ?
             if (sFieldTipoFP.ToLower = 'string') and (StrToIntDef(lMaximum_Length, 0) > 0) then begin
               bIncluirNaGrid := True;
               bRequerido := True;
             end;

             //outros tipos de dados aceitos para a lista de campos no dbgrid
             if (sFieldTipoFP.ToLower = 'currency') or (sFieldTipoFP.ToLower = 'tdatetime') then
               bIncluirNaGrid := True;

             // lista (select ...) de campos no dataset de pesquisa
             if bIncluirNaGrid then begin
               FPesquisaSelectFieldsCount :=  FPesquisaSelectFieldsCount + 1;

               //evita muitos campos na lista do select para a grid
               if FPesquisaSelectFieldsCount > FPesquisaSelectFieldsMax then
                 bIncluirNaGrid := False;
             end;

             //tipo de componente a ser utilizado: TEdit, TMemo, TCheckBox, TImage
             sComponente := 'TEdit';
             if (sFieldTipoFP.ToLower.Contains('string')) and (StrToIntDef(lMaximum_Length, 0)<1) then sComponente := 'TMemo';
             if sFieldTipoFP.Contains('Boolean') then sComponente := 'TCheckBox';
             if sFieldTipoFP.Contains('TImage') then sComponente := 'TImage';
             if sFieldTipoFP.Contains('TDateTime') then sComponente := 'TDateTime';

             //campos do script table
             FScriptTabela := FScriptTabela + ScriptTable_AddField(lColumn_Name, lData_Type, lMaximum_Length, lIs_Nullable,
                                                                   lColumn_Default, lNumeric_Precision, lNumeric_Scale,
                                                                   lIs_Identity, sFieldTipoFP, RecTotal, RecAtual);

             //pode ser um campo de edição monetária ou percentual ?
             bIsCurrency := (sFieldTipoFP.ToLower = 'currency');

             //adiciona os dados do campo no array
             if (lColumn_Name <> '') and (lData_Type <> '') then
               FJsonArray.Add(TJsonResult.New
                                         .AddPair('field_name', lColumn_Name)
                                         .AddPair('field_type', lData_Type)
                                         .AddPair('field_size', lMaximum_Length)
                                         .AddPair('field_precision', lNumeric_Precision)
                                         .AddPair('field_scale', lNumeric_Scale)
                                         .AddPair('field_primary_key', (lIs_Identity = 'YES'))
                                         .AddPair('field_type_fp', sFieldTipoFP)
                                         .AddPair('field_object', sFieldObject)
                                         .AddPair('field_iscurrency', bIsCurrency)
                                         .AddPair('field_componente', sComponente)
                                         .AddPair('field_incluir_na_grid', bIncluirNaGrid)
                                         .AddPair('field_isrequerido', bRequerido)
                                         .AddPair('field_nullable', (lIs_Nullable = 'YES'))
                                         .GetObject);

             q.Next;
          end;

          //fechamento do script table
          FScriptTabela := FScriptTabela + ScriptTable_AddRodape;

          //adiciona o array de descrição dos campos
          FJson.AddPairArray('fields', FJsonArray);

          Result := (SalvaTabela > 0);
        end;
      end;

      q.Close;
    Except
      on E: Exception do
        FErro := E.Message;
    end;

    q.Free;
  end;
end;

function TServiceInfoTabelas.PesquisaSelectFieldsHasPrimaryKey(ALista, APK: String): Boolean;
//checa se a chave primária está na lista de campos da pesquisa
var
  l: array of String;
  i: Integer;
begin
  Result := True;

  if Trim(APK) <> '' then begin //chave primária ?
    l := ALista.Split([','], TStringSplitOptions.ExcludeEmpty);
    Result := False;
    for i := 0 to High(l) do
      if Trim(l[i].ToLower) = Trim(APK.ToLower) then Result := True;
  end;
end;

function TServiceInfoTabelas.OnlyNumbers(const S: String): String;
//retorna apenas os dígitos 0..9
var
  c: Char;
begin
  Result := '';
  for c in S do
    if (c in ['0'..'9']) then Result := Result + c;
end;

function TServiceInfoTabelas.ScriptTable_AddField(lColumn_Name, lData_Type, lMaximum_Length, lIs_Nullable,
  lColumn_Default, lNumeric_Precision, lNumeric_Scale, lIs_Identity, sFieldTipoFP: String; ARecTotal, ARecAtual: Integer): String;
// monta o campo conforme suas propriedades (todos STRING)
// lColumn_Name       : column_name              // string
// lData_Type         : data_type                // int, varchar, numeric, etc
// lColumn_Type       : column_type              // null (na maioria dos casos)
// lMaximum_Length    : character_maximum_length // null, número inteiro
// lIs_Nullable       : is_nullable              // YES / NO
// lColumn_Default    : column_default           // null, número inteiro, nextval, etc
// lNumeric_Precision : numeric_precision        // null, número inteiro
// lNumeric_Scale     : numeric_scale            // null, número inteiro
// lIs_Identity       : is_identity              // YES / NO
begin
  //field e data type
  Result := ' ' + lColumn_Name + ' ';

  //auto-increment ?
  if (lIs_Identity = 'YES') then begin
    case FTipoBanco of
      SQLITE:
        Result := Result + 'INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL ';
      POSTGRE:
        Result := Result + 'serial not null ';
      MYSQL:
        Result := Result + 'int(11) NOT NULL AUTO_INCREMENT ';
      MARIADB:
        Result := Result + 'int(11) NOT NULL AUTO_INCREMENT ';
      FIREBIRD:
        Result := Result + 'integer generated by default as identity ';
      SQLSERVER:
        Result := Result + 'int Identity(1,1) NOT NULL ';
      ORACLE:
        Result := Result + 'NUMBER(10) GENERATED ALWAYS AS IDENTITY ';
    else
      Result := Result + 'INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT ';
    end;
  end else begin
    //maxlength, precision e scale
    if (StrToIntDef(lMaximum_Length, 0) > 0) then begin
       if (StrToIntDef(lNumeric_Precision, 0) > 0) then
         Result := Result + lData_Type + '(' + lNumeric_Precision + ',' + lNumeric_Scale + ') ' //precision e scale
       else
         Result := Result + lData_Type + '(' + lMaximum_Length + ') '; //maxlength
    end
    else if (StrToIntDef(lNumeric_Precision, 0) > 0) then
      Result := Result + lData_Type + '(' + lNumeric_Precision + ',' + lNumeric_Scale + ') ' //maxlength
    else
      Result := Result + lData_Type + ' ';  //outros campos

    // aceita null ?
    if (lIs_Nullable = 'NO') then Result := Result + ' NOT NULL ';

    //valor default
    if lColumn_Default <> '' then begin
      if (sFieldTipoFP.ToLower = 'string') then Result := Result + ' default ' + QuotedStr(lColumn_Default) + ' ';
      if (sFieldTipoFP.ToLower = 'integer') or (sFieldTipoFP.ToLower = 'double') then
        Result := Result + ' default ' + lColumn_Default + ' ';
    end;
  end;

  //final
  if ARecAtual < ARecTotal then
    Result := Result + ', ' + sLineBreak;
end;

function TServiceInfoTabelas.ScriptTable_AddRodape: String;
//monta o final do script
begin
  Result:= sLineBreak + '); ';

  case FTipoBanco of
    SQLITE:
      Result := sLineBreak + '); ';
    POSTGRE:
      if FFieldPrimaryKey<>'' then
        Result := ',' + sLineBreak + 'CONSTRAINT ' + FTableName + '_pk PRIMARY KEY (' + FFieldPrimaryKey + ') ' + sLineBreak + '); ';
    MYSQL:
      if FFieldPrimaryKey<>'' then
        Result := ',' + sLineBreak + 'PRIMARY KEY (' + FFieldPrimaryKey + ') ' + sLineBreak +
                  ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; ';
    MARIADB:
      if FFieldPrimaryKey<>'' then
        Result := ',' + sLineBreak + 'PRIMARY KEY (' + FFieldPrimaryKey + ') ' + sLineBreak +
                  ') ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; ';
    FIREBIRD:
      if FFieldPrimaryKey<>'' then
        Result := ',' + sLineBreak + 'CONSTRAINT ' + FTableName + '_PK PRIMARY KEY (' + FFieldPrimaryKey + ') ' + sLineBreak + '); ';
    SQLSERVER:
      Result := sLineBreak + '); ';
    ORACLE:
      if FFieldPrimaryKey<>'' then
        Result := ',' + sLineBreak + 'PRIMARY KEY ("' + FFieldPrimaryKey + '") ' + sLineBreak + '); ';
  end;
end;

function TServiceInfoTabelas.ProcessaTabelaScript(ACreateTableScript: string): Boolean;
//cria tabela via script create table ...
var
  FArrayTabelas: array of string;
  FArrayCampos: array of string;
  c, i, j: Integer;
  s: String;
begin
  Result := False;
  FErro  := '';

  ACreateTableScript   := ACreateTableScript.Replace(#34, '', [rfReplaceAll]); // "
  ACreateTableScript   := ACreateTableScript.Replace('`', '', [rfReplaceAll]); //mysql/mariadb
  ACreateTableScript   := ACreateTableScript.Replace('[', '', [rfReplaceAll]); //sqlserver
  ACreateTableScript   := ACreateTableScript.Replace(']', '', [rfReplaceAll]); //sqlserver
  ACreateTableScript   := LowerCase( Trim(ACreateTableScript) );
  ACreateTableScript   := ACreateTableScript.Replace('create table ', '*create table ');

  //se houver mais de um script de criação de tabela em ACreateTableScript,
  //faz um split para processar individualmente.
  FArrayTabelas := ACreateTableScript.Split(['*'], TStringSplitOptions.ExcludeEmpty);

  for c := 0 to High( FArrayTabelas ) do begin
    s := Trim(FArrayTabelas[c]);
    s := s.Replace(#39, '', [rfReplaceAll]); // '
    s := s.Replace(sLineBreak, '', [rfReplaceAll]);
    s := AnalisaScript(s);
    FArrayCampos := s.Split([','], TStringSplitOptions.ExcludeEmpty);

    FTableName                 := '';
    FObjectName                := '';
    FScriptTabela              := Trim(FArrayTabelas[c]);
    FPesquisaSelectFieldsCount := 0;

    if FArrayCampos[0].StartsWith('create table ', True) then begin

      //limpa dados anteriores
      FJson := TJsonResult.New;
      FJsonArray := TJSONArray.Create;

      for i := 0 to High(FArrayCampos) do begin
        s := FArrayCampos[i].Trim;
        s := s.Replace('!', ',');
        if s = '' then Continue;

        if s.Contains('table ') then begin
          if not s.Contains('exists ') then
            s := StringReplace(s, 'table ', 'table if not exists ', [rfReplaceAll]);

          //descrição da tabela
          ExtractTableName(s);

          j := s.IndexOf('(');

          if j >= 0 then s := s.Substring(j+1).Trim;
        end;

        //descrição dos campos
        ExtractFieldDescription(s);
      end;

      //adiciona o array de descrição dos campos
      FJson.AddPairArray('fields', FJsonArray);

      // cadastra a tabela
      Result := (SalvaTabela > 0);
    end;

    SetLength(FArrayCampos, 0);
  end;

  SetLength(FArrayCampos, 0);
  SetLength(FArrayTabelas, 0);
end;

function TServiceInfoTabelas.AnalisaScript(AScript: string): string;
// prepara o script no caso de number(8,2) quando usar o Split([','], TStringSplitOptions.ExcludeEmpty)
var
  i, j, k, count: integer;
begin
  count  := 0;
  i      := 0;

  while True do begin
     j := LowerCase(AScript).IndexOf('number', i);
     if j < 0 then Break;

     i := j;
     j := LowerCase(AScript).IndexOf('(', i);

     if j >= 0 then begin
       i := j;
       j := LowerCase(AScript).IndexOf(')', i);

       if j > i then begin
         k := LowerCase(AScript).IndexOf(',', i);

         if (k > 0) and (k < j) then begin
            AScript := AScript.Substring(0, k) + '!' + AScript.Substring(k + 1);
            i := k;
         end;
       end;
     end;

     count := count + 1;
     if count > 10 then Break;
  end;

  Result := AScript;
end;

class function TServiceInfoTabelas.GetExemploScript(ATipoBanco: TTipoBanco): String;
//exemplo de script de criação de tabela
begin
  Result := '';

  case ATipoBanco of
    POSTGRE:
      Result :=
      'CREATE TABLE IF NOT EXISTS account( ' + sLineBreak +
      ' user_id    serial PRIMARY KEY, ' + sLineBreak +
      ' username   VARCHAR (50) UNIQUE NOT NULL, ' + sLineBreak +
      ' password   VARCHAR (50) NOT NULL, ' + sLineBreak +
      ' email      VARCHAR (355) UNIQUE NOT NULL, ' + sLineBreak +
      ' created_on TIMESTAMP NOT NULL, ' + sLineBreak +
      ' last_login TIMESTAMP ' + sLineBreak +
      ')';

    MYSQL, MARIADB:
      Result :=
      'CREATE TABLE `produto` ( ' + sLineBreak +
      ' `idproduto` int(11) NOT NULL AUTO_INCREMENT, ' + sLineBreak +
      ' `produto` varchar(50) DEFAULT NULL, ' + sLineBreak +
      ' `qde` int(11) NOT NULL DEFAULT 0, ' + sLineBreak +
      ' `valor_compra` float NOT NULL DEFAULT 0, ' + sLineBreak +
      ' `valor_venda` decimal(8,2) NOT NULL DEFAULT 0.00, ' + sLineBreak +
      ' `foto` longblob DEFAULT NULL, ' + sLineBreak +
      ' PRIMARY KEY (`idproduto`) ' + sLineBreak +
      ') ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci; ';

    FIREBIRD:
      Result :=
      'create TABLE clientes( ' + sLineBreak +
      ' codigo integer generated by default as identity primary key, ' + sLineBreak +
      ' nome varchar(50) not null, ' + sLineBreak +
      ' endereco varchar(50) not null, ' + sLineBreak +
      ' bairro varchar(50) not null, ' + sLineBreak +
      ' cidade varchar(50) not null, ' + sLineBreak +
      ' uf varchar(2) not null, ' + sLineBreak +
      ' cep varchar(10) not null, ' + sLineBreak +
      ' telefone varchar(15) not null, ' + sLineBreak +
      ' constraint uk_nomepessoa unique(nome) using index idx_nome ' + sLineBreak +
      ')';

    SQLITE:
      Result :=
      'CREATE TABLE IF NOT EXISTS fornecedores (' + sLineBreak +
      ' idforn     INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT, ' + sLineBreak +
      ' idtipoforn INTEGER NOT NULL DEFAULT 0, ' + sLineBreak +
      ' nome       VARCHAR (60) COLLATE NOCASE, ' + sLineBreak +
      ' vendedor   VARCHAR (30) COLLATE NOCASE, ' + sLineBreak +
      ' fone       VARCHAR (40), ' + sLineBreak +
      ' ender      VARCHAR (60) COLLATE NOCASE, ' + sLineBreak +
      ' bairro     VARCHAR (30) COLLATE NOCASE, ' + sLineBreak +
      ' cidade     VARCHAR (40) COLLATE NOCASE, ' + sLineBreak +
      ' cep        VARCHAR (10), ' + sLineBreak +
      ' obs        TEXT COLLATE NOCASE ' + sLineBreak +
      ')';

    SQLSERVER:
      Result :=
      'CREATE TABLE [cadastro]( ' + sLineBreak +
      '    [idcadastro] int Identity(1,1) NOT NULL, ' + sLineBreak +
      '    [pessoa] varchar(2), ' + sLineBreak +
      '    [sexo] varchar(1), ' + sLineBreak +
      '    [cpfcnpj] varchar(15), ' + sLineBreak +
      '    [rgie] varchar(15), ' + sLineBreak +
      '    [nome] varchar(40), ' + sLineBreak +
      '    [fone] varchar(12), ' + sLineBreak +
      '    [celular] varchar(12), ' + sLineBreak +
      '    [ender] varchar(40), ' + sLineBreak +
      '    [bairro] varchar(30), ' + sLineBreak +
      '    [cidade] varchar(30), ' + sLineBreak +
      '    [uf] varchar(2), ' + sLineBreak +
      '    [cep] varchar(8), ' + sLineBreak +
      '    [dtcadastro] date NOT NULL, ' + sLineBreak +
      '    [foto] Image ' + sLineBreak +
      ')';

    ORACLE:
      Result :=
      'CREATE TABLE admin_emp ( ' + sLineBreak +
      '  empno NUMBER(10) GENERATED ALWAYS AS IDENTITY, ' + sLineBreak +
      '  ename      VARCHAR2(15) NOT NULL, ' + sLineBreak +
      '  ssn        NUMBER(9) ENCRYPT, ' + sLineBreak +
      '  job        VARCHAR2(10), ' + sLineBreak +
      '  mgr        NUMBER(5), ' + sLineBreak +
      '  hiredate   DATE DEFAULT (sysdate), ' + sLineBreak +
      '  photo      BLOB, ' + sLineBreak +
      '  sal        NUMBER(7,2), ' + sLineBreak +
      '  hrly_rate  NUMBER(7,2) GENERATED ALWAYS AS (sal/2080), ' + sLineBreak +
      '  comm       NUMBER(7,2), ' + sLineBreak +
      '  deptno     NUMBER(3) NOT NULL, ' + sLineBreak +
      '  PRIMARY KEY ("empno") ' + sLineBreak +
      ')';
    NONE:
      Result :=
      'CREATE TABLE cliente ( ' + sLineBreak +
      ' idcli      integer PRIMARY KEY autoincrement, ' + sLineBreak +
      ' nome       VARCHAR(50) NOT NULL, ' + sLineBreak +
      ' idade      integer default 0, ' + sLineBreak +
      ' ender      VARCHAR(50), ' + sLineBreak +
      ' foto       BLOB, ' + sLineBreak +
      ' salario    NUMBER(7,2) ' + sLineBreak +
      '); ' + sLineBreak +
      ' ' + sLineBreak +
      'CREATE TABLE produto ( ' + sLineBreak +
      ' idprod     integer PRIMARY KEY autoincrement, ' + sLineBreak +
      ' produto    VARCHAR(50) NOT NULL, ' + sLineBreak +
      ' qde        integer default 0, ' + sLineBreak +
      ' foto       BLOB, ' + sLineBreak +
      ' valor      NUMBER(7,2) default 0.00 ' + sLineBreak +
      '); ' + sLineBreak +
      ' ' + sLineBreak +
      'create table vendas ( ' + sLineBreak +
      ' idvenda    integer primary key autoincrement, ' + sLineBreak +
      ' idprod     integer not null, ' + sLineBreak +
      ' produto    varchar(50) not null, ' + sLineBreak +
      ' qde        integer default 0, ' + sLineBreak +
      ' valor      number(8,2) default 0.00, ' + sLineBreak +
      ' tag        char(1) ' + sLineBreak +
      '); ';
  end;
end;

end.

