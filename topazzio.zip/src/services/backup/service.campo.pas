unit Service.Campo;

// cadastro de informações de campos

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ZDataset, DB, SQLDB;

type

  { TServiceCampo }

  TServiceCampo = class
    private
      FErro: String;
      FIdCampo: Integer;
      FCampo: String;
      FCampoAlias: String;
      FAceitaNull: Boolean;
      FCampoEspecial: string;
      FDescricao: string;
      FFKTabela: string;
      FFKCampoCodigo: string;
      FFKCampoTexto: string;
      FComboLista: string;
      FComponente: string;
      FCurrencyField: Boolean;
      FEscala: String;
      FExcluirDoInsertUpdate: Boolean;
      FIncluirNaGrid: Boolean;
      FIsChavePrimaria: Boolean;
      FIsChaveEstrangeira: Boolean;
      FIdTabela: Integer;
      FObjeto: String;
      FOrdem: Integer;
      FPrecisao: String;
      FRemoverMascara: Boolean;
      FRequerido: Boolean;
      Frpt_sum: Boolean;
      FTamanho: String;
      FTipo: String;
      FTipoFP: String;
    public
      constructor Create(AIdTabela: Integer);
      property GetErro: String read FErro;
      property IdCampo: Integer read FIdCampo;
      property IdTabela: Integer read FIdTabela;
      property Campo: String read FCampo write FCampo;
      property CampoAlias: String read FCampoAlias write FCampoAlias;
      property Descricao: string read FDescricao write FDescricao;
      property Tipo: String read FTipo write FTipo;
      property AceitaNull: Boolean read FAceitaNull write FAceitaNull;
      property Tamanho: String read FTamanho write FTamanho;
      property Precisao: String read FPrecisao write FPrecisao;
      property Escala: String read FEscala write FEscala;
      property IsChavePrimaria: Boolean read FIsChavePrimaria write FIsChavePrimaria;
      property IsChaveEstrangeira: Boolean read FIsChaveEstrangeira write FIsChaveEstrangeira;
      property TipoFP: String read FTipoFP write FTipoFP;
      property Objeto: String read FObjeto write FObjeto;
      property IsCurrencyField: Boolean read FCurrencyField write FCurrencyField;
      property Componente: string read FComponente write FComponente;
      property FK_Tabela: string read FFKTabela write FFKTabela;
      property FK_CampoCodigo: string read FFKCampoCodigo write FFKCampoCodigo;
      property FK_CampoTexto: string read FFKCampoTexto write FFKCampoTexto;
      property ComboLista: string read FComboLista write FComboLista;
      property IncluirNaGrid: Boolean read FIncluirNaGrid write FIncluirNaGrid;
      property IsRequerido: Boolean read FRequerido write FRequerido;
      property ExcluirDoInsertUpdate: Boolean read FExcluirDoInsertUpdate write FExcluirDoInsertUpdate;
      property Report_Somatorio: Boolean read Frpt_sum write Frpt_sum;
      property Ordem: Integer read FOrdem write FOrdem;
      property RemoverMascara: Boolean read FRemoverMascara write FRemoverMascara;
      property CampoEspecial: string read FCampoEspecial write FCampoEspecial;

      function Salvar(AIdCampo: Integer; AEdicao: Boolean = False): Integer;
      function Ler(AIdCampo: Integer): Boolean;
      function Deletar(AIdCampo: Integer): Boolean;
      function ExisteCampo(ACampo: String): Integer;
      function QueryCampos: TZQuery;
      function DataSetCampos(APesquisa: String): TDataSource;
      function DataSetCamposPesquisa: TZQuery;
  end;


implementation

uses
  DM.Server, Util.Idioma;

{ TServiceCampo }

constructor TServiceCampo.Create(AIdTabela: Integer);
begin
  FIdTabela := AIdTabela;
end;

function TServiceCampo.Salvar(AIdCampo: Integer; AEdicao: Boolean = False): Integer;
//salva o projeto, se ainda não existir
var
  bValidaCampos: Boolean;
begin
  Result := 0;
  bValidaCampos := True;

  if IdTabela < 1 then begin
    FErro := ServiceCampo.Mensagem1;
    Exit;
  end;

  if Trim(campo)  = '' then bValidaCampos := False;
  if Trim(tipo)   = '' then bValidaCampos := False;
  if Trim(TipoFP) = '' then bValidaCampos := False;
  if Trim(Objeto) = '' then bValidaCampos := False;
  if Trim(Componente) = '' then Componente := 'TEdit';
  if IsChavePrimaria then Ordem := 1;

  if not bValidaCampos then begin
    FErro := ServiceCampo.Mensagem2;
    Exit;
  end;

  if not AEdicao then begin
    Result := ExisteCampo(Campo);

    if (Result > 0) then
      Deletar(Result);
  end;

  with DMServer.NewQuery() do begin
    if AIdCampo < 1 then begin
      SQL.Add('INSERT INTO crud_campo ');
      SQL.Add('  (idtabela, campo, campo_alias, tipo, aceita_null, tamanho, precisao, escala, ');
      SQL.Add('  chave_primaria, chave_estrangeira, tipo_fp, objeto, currency_field, componente, ');
      SQL.Add('  fk_tabela, fk_codigo, fk_texto, combo_lista, incluir_na_grid, requerido, ');
      SQL.Add('  excluir_do_insert_update, rpt_sum, ordem, remove_mask, campo_especial, descricao) ');
      SQL.Add('VALUES(');
      SQL.Add('  :idtabela, :campo, :campo_alias, :tipo, :aceita_null, :tamanho, :precisao, :escala, ');
      SQL.Add('  :chave_primaria, :chave_estrangeira, :tipo_fp, :objeto, :currency_field, ');
      SQL.Add('  :componente, :fk_tabela, :fk_codigo, :fk_texto, :combo_lista, :incluir_na_grid, :requerido, ');
      SQL.Add('  :excluir_do_insert_update, :rpt_sum, :ordem, :remove_mask, :campo_especial, :descricao) ');
    end
    else begin
      SQL.Add('UPDATE crud_campo SET ');
      SQL.Add('  idtabela = :idtabela, campo = :campo, campo_alias = :campo_alias, tipo = :tipo, ');
      SQL.Add('  aceita_null = :aceita_null, tamanho = :tamanho, precisao = :precisao, escala = :escala, ');
      SQL.Add('  chave_primaria = :chave_primaria, chave_estrangeira = :chave_estrangeira, ');
      SQL.Add('  tipo_fp = :tipo_fp, objeto = :objeto, currency_field = :currency_field, componente = :componente, ');
      SQL.Add('  fk_tabela = :fk_tabela, fk_codigo = :fk_codigo, fk_texto = :fk_texto, combo_lista = :combo_lista, ');
      SQL.Add('  incluir_na_grid = :incluir_na_grid, requerido = :requerido, ');
      SQL.Add('  excluir_do_insert_update = :excluir_do_insert_update, rpt_sum = :rpt_sum, ordem = :ordem, ');
      SQL.Add('  remove_mask = :remove_mask, campo_especial = :campo_especial, descricao = :descricao ');
      SQL.Add('WHERE idcampo = ' + IntToStr(AIdCampo));
    end;

    if Tamanho  = '' then Tamanho  := '0';
    if Precisao = '' then Precisao := '0';
    if Escala   = '' then Escala   := '0';

    ParamByName('idtabela').AsInteger                 := FIdTabela;
    ParamByName('campo').AsString                     := Campo;
    ParamByName('campo_alias').AsString               := CampoAlias;
    ParamByName('tipo').AsString                      := Tipo;
    ParamByName('aceita_null').AsInteger              := Ord(AceitaNull);
    ParamByName('tamanho').AsString                   := Tamanho;
    ParamByName('precisao').AsString                  := Precisao;
    ParamByName('escala').AsString                    := Escala;
    ParamByName('chave_primaria').AsInteger           := Ord(IsChavePrimaria);
    ParamByName('chave_estrangeira').AsInteger        := Ord(IsChaveEstrangeira);
    ParamByName('tipo_fp').AsString                   := TipoFP;
    ParamByName('objeto').AsString                    := Objeto;
    ParamByName('currency_field').AsInteger           := Ord(IsCurrencyField);
    ParamByName('componente').AsString                := Componente;
    ParamByName('fk_tabela').AsString                 := FK_Tabela;
    ParamByName('fk_codigo').AsString                 := FK_CampoCodigo;
    ParamByName('fk_texto').AsString                  := FK_CampoTexto;
    ParamByName('combo_lista').AsString               := ComboLista;
    ParamByName('incluir_na_grid').AsInteger          := Ord(IncluirNaGrid);
    ParamByName('requerido').AsInteger                := Ord(IsRequerido);
    ParamByName('excluir_do_insert_update').AsInteger := Ord(ExcluirDoInsertUpdate);
    ParamByName('rpt_sum').AsInteger                  := Ord(Report_Somatorio);
    ParamByName('ordem').AsInteger                    := Ordem;
    ParamByName('remove_mask').AsInteger              := Ord(RemoverMascara);
    ParamByName('campo_especial').AsString            := CampoEspecial;
    ParamByName('descricao').AsString                 := Descricao;

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      if AIdCampo < 1 then
        Result := DMServer.LastInsertedID
      else
        Result := AIdCampo;

      FIdCampo := Result;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := Campo + ': ' + E.Message;
      end;
    end;
  end;
end;

function TServiceCampo.Ler(AIdCampo: Integer): Boolean;
//ler dados do campo
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('SELECT ');
    SQL.Add('  idtabela, campo, campo_alias, tipo, aceita_null, tamanho, precisao, ');
    SQL.Add('  escala, chave_primaria, chave_estrangeira, tipo_fp, objeto, ');
    SQL.Add('  currency_field, componente, fk_tabela, fk_codigo, fk_texto, ');
    SQL.Add('  combo_lista, incluir_na_grid, requerido, excluir_do_insert_update, ');
    SQL.Add('  rpt_sum, ordem, remove_mask, campo_especial, descricao ');
    SQL.Add('FROM crud_campo ');
    SQL.Add('WHERE idcampo = ' + IntToStr(AIdCampo));

    try
      Open;

      if not EOF then begin
        FIdCampo              := AIdCampo;
        FIdTabela             := FieldByName('idtabela').AsInteger;
        Campo                 := FieldByName('campo').AsString;
        CampoAlias            := FieldByName('campo_alias').AsString;
        Tipo                  := FieldByName('tipo').AsString;
        AceitaNull            := FieldByName('aceita_null').AsInteger = 1;
        Tamanho               := FieldByName('tamanho').AsString;
        Precisao              := FieldByName('precisao').AsString;
        Escala                := FieldByName('escala').AsString;
        IsChavePrimaria       := FieldByName('chave_primaria').AsInteger = 1;
        IsChaveEstrangeira    := FieldByName('chave_estrangeira').AsInteger = 1;
        TipoFP                := FieldByName('tipo_fp').AsString;
        Objeto                := FieldByName('objeto').AsString;
        IsCurrencyField       := FieldByName('currency_field').AsInteger = 1;
        Componente            := FieldByName('componente').AsString;
        FK_Tabela             := FieldByName('fk_tabela').AsString;
        FK_CampoCodigo        := FieldByName('fk_codigo').AsString;
        FK_CampoTexto         := FieldByName('fk_texto').AsString;
        ComboLista            := FieldByName('combo_lista').AsString;
        IncluirNaGrid         := FieldByName('incluir_na_grid').AsInteger = 1;
        IsRequerido           := FieldByName('requerido').AsInteger = 1;
        ExcluirDoInsertUpdate := FieldByName('excluir_do_insert_update').AsInteger = 1;
        Report_Somatorio      := FieldByName('rpt_sum').AsInteger = 1;
        Ordem                 := FieldByName('ordem').AsInteger;
        RemoverMascara        := FieldByName('remove_mask').AsInteger = 1;
        CampoEspecial         := FieldByName('campo_especial').AsString;
        Descricao             := FieldByName('descricao').AsString;

        if Componente = '' then Componente := 'TEdit';

        Result := True;
      end;

      Close;
    except
      on E: Exception do begin
        FErro := E.Message;
      end;
    end;
  end;
end;

function TServiceCampo.Deletar(AIdCampo: Integer): Boolean;
//deleta o campo
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('DELETE FROM crud_campo ');
    SQL.Add('WHERE idcampo = ' + IntToStr(AIdCampo));

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      Result := True;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := E.Message;
      end;
    end;
  end;
end;

function TServiceCampo.ExisteCampo(ACampo: String): Integer;
//verifica se o campo existe
begin
  Result := 0;

  with DMServer.NewQuery() do begin
    SQL.Add('SELECT idcampo ');
    SQL.Add('FROM crud_campo ');
    SQL.Add('WHERE LOWER(campo) = :campo AND idtabela = :idtabela ');

    ParamByName('campo').AsString     := LowerCase(ACampo);
    ParamByName('idtabela').AsInteger := FIdTabela;

    try
      Open;

      if not EOF then
        Result := FieldByName('idcampo').AsInteger;

      Close;
    except

    end;
  end;
end;

function TServiceCampo.QueryCampos: TZQuery;
//query de campos da tabela do projeto
begin
  Result := DMServer.NewQuery();

  with Result do begin
    SQL.Add('SELECT ');
    SQL.Add('  p.idprojeto, p.projeto, p.tipo_banco, ');
    SQL.Add('  t.idtabela, t.tabela, t.nome_objeto, t.descricao, t.criar_dbgrid_form, ');
    SQL.Add('  t.criar_form_pesquisa, t.criar_report, t.script_tabela, t.for_auth, ');
    SQL.Add('  t.criar_api, t.api_get, t.api_post, t.api_put, t.api_patch, t.api_delete, t.api_rota, ');
    SQL.Add('  c.idcampo, c.campo, c.campo_alias, c.tipo, c.tamanho, c.precisao, c.escala, ');
    SQL.Add('  c.chave_primaria, c.chave_estrangeira, c.tipo_fp, c.objeto, c.currency_field, ');
    SQL.Add('  c.componente, c.fk_tabela, c.fk_codigo, c.fk_texto, c.combo_lista, c.aceita_null, ');
    SQL.Add('  c.remove_mask, c.campo_especial, c.incluir_na_grid, c.requerido, c.rpt_sum, ');
    SQL.Add('  c.descricao AS cmp_descricao, ');
    SQL.Add('  (SELECT COUNT(*) FROM crud_campo WHERE idtabela = c.idtabela AND incluir_na_grid = 1) AS qdeitensgrid, ');
    SQL.Add('  ( '); // tem referência a esta tabela em algum campo de outra tabela ?
    SQL.Add('   SELECT MIN(q.fk_texto) ');
    SQL.Add('   FROM crud_tabela t2 ');
    SQL.Add('   INNER JOIN crud_campo q ON q.idtabela = t2.idtabela ');
    SQL.Add('   WHERE t2.idprojeto = p.idprojeto AND t2.idtabela <> c.idtabela AND q.fk_tabela = t.tabela ');
    SQL.Add('  ) AS campo_estrangeiro ');
    SQL.Add('FROM crud_campo c ');
    SQL.Add('INNER JOIN crud_tabela t ON t.idtabela = c.idtabela ');
    SQL.Add('INNER JOIN crud_projeto p ON p.idprojeto = t.idprojeto ');
    SQL.Add('where c.idtabela = :idtabela AND c.excluir_do_insert_update = 0 ');
    SQL.Add('ORDER BY c.chave_primaria DESC, c.ordem ASC ');

    ParamByName('idtabela').AsInteger := FIdTabela;

    try
      Open;
    except
    end;
  end;
end;

function TServiceCampo.DataSetCampos(APesquisa: String): TDataSource;
//dataset de campos para dbgrid
var
  q: TZQuery;
begin
  FErro := '';
  Result := TDataSource.Create(nil);
  q := DMServer.NewQuery();

  q.SQL.Add('select ');
  q.SQL.Add('idcampo, campo, tipo, componente, ');
  q.SQL.Add('case chave_primaria when 1 then ''S'' else '''' end as is_pk, ');
  q.SQL.Add('case COALESCE(incluir_na_grid, 0) when 1 then ''S'' else '''' end as grid, ');
  q.SQL.Add('case requerido when 1 then ''S'' else '''' end as requerido, ');
  q.SQL.Add('case excluir_do_insert_update when 1 then ''S'' else '''' end as exiu, ');
  q.SQL.Add('ordem ');
  q.SQL.Add('from crud_campo ');
  q.SQL.Add('where idtabela = ' + IntToStr(FIdTabela) + ' ');

  if APesquisa.Trim <> '' then
    q.SQL.Add('and campo like :pesquisa ');

  q.SQL.Add('order by chave_primaria desc, ordem asc ');

  if APesquisa.Trim <> '' then
    q.ParamByName('pesquisa').AsString := '%' + APesquisa.Trim + '%';

  try
    q.Open;
    Result.DataSet := q;
    // fechar lá no destino/cliente
  except
    on E: Exception do
      FErro := E.Message;
  end;
end;

function TServiceCampo.DataSetCamposPesquisa: TZQuery;
// retorna um dataset dos campos selecionados para a pesquisa/grid
begin
  Result := DMServer.NewQuery();

  with Result do begin
    SQL.Add('select ');
    SQL.Add('idcampo, campo, tipo, tamanho, precisao, escala, ');
    SQL.Add('chave_primaria, tipo_fp, objeto, currency_field, componente ');
    SQL.Add('from crud_campo ');
    SQL.Add('where idtabela = ' + IntToStr(FIdTabela) + ' ');
    SQL.Add('and incluir_na_grid = 1 ');
    SQL.Add('order by chave_primaria desc ');

    try
      Open;
    except
    end;
  end;
end;

end.

