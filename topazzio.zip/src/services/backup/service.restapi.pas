unit Service.RestApi;

// controle de dados da API

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ZDataset, DB, SQLDB;

type

  { TServiceRestApi }

  TServiceRestApi = class
    private
      FApiAdminEmail: string;
      FApiAdminNome: string;
      FApiAudit: Boolean;
      FApiClasseService: Boolean;
      FApiDescricao: string;
      FApiFooter1: string;
      FApiFooter2: string;
      FApiHeader1: string;
      FApiHeader2: string;
      FApiHeader3: string;
      FApiHost: string;
      FApiId: Integer;
      FApiNome: string;
      FApiPathProjeto: string;
      FApiPorta: string;
      FApiTitulo: string;
      FApiTotalTabelas: Integer;
      FApiVersao: string;
      FErro: String;
      FIdProjeto: Integer;
      FProj_BancoDados: String;
      FProj_HostServidor: String;
      FProj_IdTipoBanco: Integer;
      FProj_Nome: string;
      FProj_Porta: String;
      FProj_Senha: String;
      FProj_TipoBanco: String;
      FProj_Username: String;
    public
      constructor Create(AIdProjeto: Integer);
      property GetErro: String read FErro;
      property IdProjeto: Integer read FIdProjeto;
      property ApiHost: string read FApiHost write FApiHost;
      property ApiPorta: string read FApiPorta write FApiPorta;
      property ApiVersao: string read FApiVersao write FApiVersao;
      property ApiAdminNome: string read FApiAdminNome write FApiAdminNome;
      property ApiAdminEmail: string read FApiAdminEmail write FApiAdminEmail;
      property ApiNome: string read FApiNome write FApiNome;
      property ApiTitulo: string read FApiTitulo write FApiTitulo;
      property ApiDescricao: string read FApiDescricao write FApiDescricao;
      property ApiHeader1: string read FApiHeader1 write FApiHeader1;
      property ApiHeader2: string read FApiHeader2 write FApiHeader2;
      property ApiHeader3: string read FApiHeader3 write FApiHeader3;
      property ApiFooter1: string read FApiFooter1 write FApiFooter1;
      property ApiFooter2: string read FApiFooter2 write FApiFooter2;
      property ApiClasseService: Boolean read FApiClasseService write FApiClasseService;
      property ApiAudit: Boolean read FApiAudit write FApiAudit;
      property ApiPathProjeto: string read FApiPathProjeto;
      property ApiTotalTabelas: Integer read FApiTotalTabelas;

      { projeto principal }
      property Proj_Nome: string read FProj_Nome write FProj_Nome;
      property Proj_IdTipoBanco: Integer read FProj_IdTipoBanco write FProj_IdTipoBanco;
      property Proj_TipoBanco: String read FProj_TipoBanco write FProj_TipoBanco;
      property Proj_HostServidor: String read FProj_HostServidor write FProj_HostServidor;
      property Proj_Porta: String read FProj_Porta write FProj_Porta;
      property Proj_BancoDados: String read FProj_BancoDados write FProj_BancoDados;
      property Proj_Username: String read FProj_Username write FProj_Username;
      property Proj_Senha: String read FProj_Senha write FProj_Senha;

      function Salvar: Boolean;
      function Ler: Boolean;
      function Deletar: Boolean;
      function DataSetTabelas(APesquisa: String): TDataSource;
      procedure SetApiDefaults(AApiPath: string);
  end;

implementation

uses
  DM.Server, Util.Idioma;

{ TServiceRestApi }

constructor TServiceRestApi.Create(AIdProjeto: Integer);
begin
  FIdProjeto := AIdProjeto;
  FErro := '';

  if AIdProjeto < 1 then
    raise Exception.Create('Project ID não provided');
end;

function TServiceRestApi.Salvar: Boolean;
//salva o projeto, se ainda não existir
var
  bValidaCampos: Boolean;
begin
  Result := False;
  bValidaCampos := True;

  if IdProjeto < 1 then begin
    FErro := ServiceTabela.Mensagem1;
    Exit;
  end;

  if Trim(ApiHost)  = '' then bValidaCampos := False;
  if Trim(ApiPorta) = '' then bValidaCampos := False;
  if Trim(ApiNome)  = '' then bValidaCampos := False;

  if not bValidaCampos then begin
    FErro := ServiceTabela.Mensagem2;
    Exit;
  end;

  Deletar;

  with DMServer.NewQuery() do begin
    SQL.Add('INSERT INTO crud_api ');
    SQL.Add(' (idprojeto, api_host, api_porta, api_versao, api_admin, api_email, ');
    SQL.Add(' api_nome, api_titulo, api_descricao, api_header1, api_header2, api_header3, ');
    SQL.Add(' api_footer1, api_footer2, api_classe_service, api_audit) ');
    SQL.Add('VALUES(:idprojeto, :api_host, :api_porta, :api_versao, :api_admin, :api_email, ');
    SQL.Add(' :api_nome, :api_titulo, :api_descricao, :api_header1, :api_header2, :api_header3, ');
    SQL.Add(' :api_footer1, :api_footer2, :api_classe_service, :api_audit) ');

    ParamByName('idprojeto').AsInteger    := FIdProjeto;
    ParamByName('api_host').AsString      := ApiHost;
    ParamByName('api_porta').AsString     := ApiPorta;
    ParamByName('api_versao').AsString    := LowerCase(ApiVersao);
    ParamByName('api_admin').AsString     := ApiAdminNome;
    ParamByName('api_email').AsString     := ApiAdminEmail;
    ParamByName('api_nome').AsString      := ApiNome;
    ParamByName('api_titulo').AsString    := ApiTitulo;
    ParamByName('api_descricao').AsString := ApiDescricao;
    ParamByName('api_header1').AsString   := ApiHeader1;
    ParamByName('api_header2').AsString   := ApiHeader2;
    ParamByName('api_header3').AsString   := ApiHeader3;
    ParamByName('api_footer1').AsString   := ApiFooter1;
    ParamByName('api_footer2').AsString   := ApiFooter2;
    ParamByName('api_classe_service').AsInteger := Ord(ApiClasseService);
    ParamByName('api_audit').AsInteger    := Ord(ApiAudit);

    try
      DMServer.TransactionPrepare;
      ExecSQL;
      DMServer.TransactionCommit;

      Result := True;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := E.Message;
      end;
    end;

    Free;
  end;
end;

function TServiceRestApi.Ler: Boolean;
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('SELECT ');
    SQL.Add(' a.idprojeto, a.api_host, a.api_porta, a.api_versao, a.api_admin, a.api_email, ');
    SQL.Add(' a.api_nome, a.api_titulo, a.api_descricao, a.api_path, a.api_header1, a.api_header2, a.api_header3, ');
    SQL.Add(' a.api_footer1, a.api_footer2, a.api_classe_service, a.api_audit, ');
    SQL.Add(' p.projeto, p.idtipo_banco, p.tipo_banco, p.host_servidor, p.porta, p.banco_dados, p.username, p.senha, ');
    SQL.Add(' (select COALESCE(COUNT(*), 0) FROM crud_tabela where idprojeto=a.idprojeto AND criar_api=1) as qde_tabelas ');
    SQL.Add('FROM crud_api a ');
    SQL.Add('INNER JOIN crud_projeto p ON p.idprojeto = a.idprojeto ');
    SQL.Add('WHERE a.idprojeto = ' + IntToStr(FIdProjeto));

    try
      Open;

      if not EOF then begin
        FIdProjeto    := FieldByName('idprojeto').AsInteger;
        ApiHost       := FieldByName('api_host').AsString;
        ApiPorta      := FieldByName('api_porta').AsString;
        ApiVersao     := FieldByName('api_versao').AsString;
        ApiAdminNome  := FieldByName('api_admin').AsString;
        ApiAdminEmail := FieldByName('api_email').AsString;
        ApiNome       := FieldByName('api_nome').AsString;
        ApiTitulo     := FieldByName('api_titulo').AsString;
        ApiDescricao  := FieldByName('api_descricao').AsString;
        FApiPathProjeto:= FieldByName('api_path').AsString;
        ApiHeader1 := FieldByName('api_header1').AsString;
        ApiHeader2 := FieldByName('api_header2').AsString;
        ApiHeader3 := FieldByName('api_header3').AsString;
        ApiFooter1 := FieldByName('api_footer1').AsString;
        ApiFooter2 := FieldByName('api_footer2').AsString;
        ApiClasseService := FieldByName('api_classe_service').AsInteger = 1;
        ApiAudit := FieldByName('api_audit').AsInteger = 1;
        FApiTotalTabelas := FieldByName('qde_tabelas').AsInteger;

        { do projeto principal }
        Proj_Nome         := FieldByName('projeto').AsString;
        Proj_IdTipoBanco  := FieldByName('idtipo_banco').AsInteger;
        Proj_TipoBanco    := FieldByName('tipo_banco').AsString;
        Proj_HostServidor := FieldByName('host_servidor').AsString;
        Proj_BancoDados   := FieldByName('banco_dados').AsString;
        Proj_Porta        := FieldByName('porta').AsString;
        Proj_Username     := FieldByName('username').AsString;
        Proj_Senha        := FieldByName('senha').AsString;

        Result := True;
      end;

      Close;
    except
      on E: Exception do begin
        FErro := E.Message;
      end;
    end;

    Free;
  end;
end;

function TServiceRestApi.Deletar: Boolean;
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('delete from crud_api ');
    SQL.Add('where idprojeto = ' + IntToStr(FIdProjeto));

    try
      DMServer.TransactionPrepare;
      ExecSQL;
      DMServer.TransactionCommit;

      Result := True;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := E.Message;
      end;
    end;
  end;
end;

procedure TServiceRestApi.SetApiDefaults(AApiPath: string);
//salva o path do projeto
begin
  with DMServer.NewQuery() do begin
    SQL.Add('UPDATE crud_api SET ');
    SQL.Add(' api_path = :api_path ');
    SQL.Add('WHERE idprojeto = :idprojeto ');

    ParamByName('api_path').AsString := AApiPath;

    try
      DMServer.TransactionPrepare;
      ExecSQL;
      DMServer.TransactionCommit;
    except
      on E: Exception do
        DMServer.TransactionRollback;
    end;

    Free;
  end;
end;

function TServiceRestApi.DataSetTabelas(APesquisa: String): TDataSource;
//dataset de campos para dbgrid
var
  q: TZQuery;
begin
  FErro := '';
  Result := TDataSource.Create(nil);
  q := DMServer.NewQuery();

  q.SQL.Add('SELECT ');
  q.SQL.Add(' t.idtabela, t.tabela, ');
  q.SQL.Add(' (SELECT COUNT(*) FROM crud_campo WHERE idtabela = t.idtabela) AS qdecampos, ');
  q.SQL.Add(' 1 AS selecao ');
  q.SQL.Add('FROM crud_tabela t ');
  q.SQL.Add('WHERE t.idprojeto = ' + IntToStr(FIdProjeto) + ' ');
  q.SQL.Add(' AND t.criar_api = 1 ');

  if APesquisa.Trim <> '' then
    q.SQL.Add('AND t.tabela LIKE :pesquisa ');

  q.SQL.Add('ORDER BY t.tabela ASC ');

  if APesquisa.Trim <> '' then
    q.ParamByName('pesquisa').AsString := '%' + APesquisa.Trim + '%';

  try
    q.Open;
    Result.DataSet := q;
    // fechar lá no destino/cliente
  except
    on E: Exception do
      FErro := E.Message;
  end;
end;

end.

