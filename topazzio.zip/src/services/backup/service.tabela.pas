unit Service.Tabela;

// Cadastro de informações de tabela

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ZDataset, DB, SQLDB;

type

  { TServiceTabela }

  TServiceTabela = class
    private
      FCriarDbGridForm: Boolean;
      FCriarFormPesquisa: Boolean;
      FCriarReport: Boolean;
      FDescricao: string;
      FErro: String;
      FIdProjeto: Integer;
      FIdTabela: Integer;
      FNomeObjeto: String;
      FScriptTabela: String;
      FTabela: String;
    public
      constructor Create(AIdProjeto: Integer);
      property GetErro: String read FErro;
      property IdTabela: Integer read FIdTabela write FIdTabela;
      property IdProjeto: Integer read FIdProjeto;
      property Tabela: String read FTabela write FTabela;
      property NomeObjeto: String read FNomeObjeto write FNomeObjeto;
      property CriarDbGridForm: Boolean read FCriarDbGridForm write FCriarDbGridForm;
      property CriarFormPesquisa: Boolean read FCriarFormPesquisa write FCriarFormPesquisa;
      property CriarReport: Boolean read FCriarReport write FCriarReport;
      property ScriptTabela: String read FScriptTabela write FScriptTabela;
      property Descricao: string read FDescricao write FDescricao;
      function Salvar(AIdTabela: Integer; AEdicao: Boolean = False): Integer;
      function SalvarScript(AIdTabela: Integer; AScript: String): Boolean;
      function Ler(AIdTabela: Integer): Boolean;
      function Deletar(AIdTabela: Integer): Boolean;
      function ExisteTabela(ATabela: String): Integer;
      function QueryTabelas(AListaTabelasID: string): TZQuery;
      function QueryScripts(AListaID: string): TZQuery;
      function DataSetTabelas(APesquisa: String): TDataSource;
  end;

implementation

uses
  DM.Server, Util.Idioma;

{ TServiceTabela }

constructor TServiceTabela.Create(AIdProjeto: Integer);
begin
  FIdProjeto := AIdProjeto;
end;

function TServiceTabela.Salvar(AIdTabela: Integer; AEdicao: Boolean = False): Integer;
//salva o projeto, se ainda não existir
var
  bValidaCampos: Boolean;
begin
  Result := 0;
  bValidaCampos := True;

  if IdProjeto < 1 then begin
    FErro := ServiceTabela.Mensagem1;
    Exit;
  end;

  if Trim(Tabela)     = '' then bValidaCampos := False;
  if Trim(NomeObjeto) = '' then bValidaCampos := False;
  if Trim(Descricao)  = '' then Descricao     := NomeObjeto;
  if not CriarDbGridForm and not CriarFormPesquisa then CriarReport := False;

  if not bValidaCampos then begin
    FErro := ServiceTabela.Mensagem2;
    Exit;
  end;

  if not AEdicao then begin
    Result := ExisteTabela(Tabela);

    if (Result > 0) then begin
      Deletar(Result);
      AIdTabela := 0;
    end;
  end;

  with DMServer.NewQuery() do begin
    if AIdTabela < 1 then begin
      SQL.Add('insert into crud_tabela ');
      SQL.Add('(idprojeto, tabela, nome_objeto, criar_dbgrid_form, criar_form_pesquisa, ');
      SQL.Add('criar_report, script_tabela, descricao) ');
      SQL.Add('values(:idprojeto, :tabela, :nome_objeto, :criar_dbgrid_form, :criar_form_pesquisa, ');
      SQL.Add(':criar_report, :script_tabela, :descricao) ');
    end
    else begin
      SQL.Add('update crud_tabela set ');
      SQL.Add('idprojeto = :idprojeto, tabela = :tabela, nome_objeto = :nome_objeto, ');
      SQL.Add('criar_dbgrid_form = :criar_dbgrid_form, criar_form_pesquisa = :criar_form_pesquisa, ');
      SQL.Add('criar_report = :criar_report, script_tabela = :script_tabela, descricao = :descricao ');
      SQL.Add('where idtabela=' + IntToStr(AIdTabela));
    end;

    ParamByName('idprojeto').AsInteger           := FIdProjeto;
    ParamByName('tabela').AsString               := Tabela;
    ParamByName('nome_objeto').AsString          := NomeObjeto;
    ParamByName('criar_dbgrid_form').AsInteger   := Ord(CriarDbGridForm);
    ParamByName('criar_form_pesquisa').AsInteger := Ord(CriarFormPesquisa);
    ParamByName('criar_report').AsInteger        := Ord(CriarReport);
    ParamByName('script_tabela').AsString        := ScriptTabela;
    ParamByName('descricao').AsString            := Descricao;

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      if AIdTabela < 1 then
        Result := DMServer.LastInsertedID
      else
        Result := AIdTabela;

      FIdTabela := Result;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := Tabela + ': ' + E.Message;
      end;
    end;
  end;
end;

function TServiceTabela.SalvarScript(AIdTabela: Integer; AScript: String): Boolean;
//salva o script da tabela
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('update crud_tabela set ');
    SQL.Add('script_tabela = :script_tabela ');
    SQL.Add('where idtabela=' + IntToStr(AIdTabela));

    ParamByName('script_tabela').AsString := AScript;

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      Result := True;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := E.Message;
      end;
    end;
  end;
end;

function TServiceTabela.Ler(AIdTabela: Integer): Boolean;
//ler dados da tabela
begin
  with DMServer.NewQuery() do begin
    SQL.Add('select ');
    SQL.Add('idprojeto, tabela, nome_objeto, criar_dbgrid_form, criar_form_pesquisa, ');
    SQL.Add('criar_report, script_tabela, descricao ');
    SQL.Add('from crud_tabela ');
    SQL.Add('where idtabela = ' + IntToStr(AIdTabela));

    try
      Open;

      if not EOF then begin
        FIdTabela           := AIdTabela;
        FIdProjeto          := FieldByName('idprojeto').AsInteger;
        Tabela              := FieldByName('tabela').AsString;
        NomeObjeto          := FieldByName('nome_objeto').AsString;
        CriarDbGridForm     := FieldByName('criar_dbgrid_form').AsInteger = 1;
        CriarFormPesquisa   := FieldByName('criar_form_pesquisa').AsInteger = 1;
        CriarReport         := FieldByName('criar_report').AsInteger = 1;
        ScriptTabela        := FieldByName('script_tabela').AsString;
        Descricao           := FieldByName('descricao').AsString;

        Result := True;
      end;

      Close;
    except
      on E: Exception do begin
        FErro := E.Message;
      end;
    end;
  end;
end;

function TServiceTabela.Deletar(AIdTabela: Integer): Boolean;
//deleta a tabela e os campos vinculados
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('delete from crud_tabela ');
    SQL.Add('where idtabela = ' + IntToStr(AIdTabela));

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      Result := True;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := E.Message;
      end;
    end;
  end;
end;

function TServiceTabela.ExisteTabela(ATabela: String): Integer;
//verifica se a tabela já está cadastrada
begin
  Result := 0;

  with DMServer.NewQuery() do begin
    SQL.Add('select idtabela ');
    SQL.Add('from crud_tabela ');
    SQL.Add('where lower(tabela) = :tabela and idprojeto = :idprojeto ');

    ParamByName('tabela').AsString     := LowerCase(ATabela);
    ParamByName('idprojeto').AsInteger := FIdProjeto;

    try
      Open;

      if not EOF then
        Result := FieldByName('idtabela').AsInteger;

      Close;
    except

    end;
  end;
end;

function TServiceTabela.QueryTabelas(AListaTabelasID: string): TZQuery;
//query de tabelas do projeto
begin
  Result := DMServer.NewQuery();

  with Result do begin
    SQL.Add('select ');
    SQL.Add('t.idtabela, t.tabela, t.nome_objeto, t.descricao, ');
    SQL.Add('t.criar_dbgrid_form, t.criar_form_pesquisa, t.criar_report, t.script_tabela, ');
    SQL.Add('(select count(*) from crud_campo where idtabela=t.idtabela and incluir_na_grid=1) as qdeitensgrid, ');
    SQL.Add('(select count(*) from crud_campo where idtabela = t.idtabela and chave_primaria = 1) as chave_primaria ');
    SQL.Add('from crud_tabela t ');
    SQL.Add('where t.idprojeto = :idprojeto ');

    if AListaTabelasID <> '' then
      SQL.Add('and t.idtabela in(' + AListaTabelasID + ') '); // 1,5,20 {lista de IDs das tabelas}

    ParamByName('idprojeto').AsInteger := FIdProjeto;

    try
      Open;
    except
    end;
  end;
end;

function TServiceTabela.QueryScripts(AListaID: string): TZQuery;
//query de scripts das tabelas do projeto
begin
  Result := DMServer.NewQuery();

  with Result do begin
    SQL.Add('select t.tabela, c.campo as primary_key, t.script_tabela ');
    SQL.Add('from crud_tabela t ');
    SQL.Add('left join crud_campo c on c.idtabela=t.idtabela and c.chave_primaria = 1 ');
    SQL.Add('where t.idprojeto = :idprojeto ');

    if AListaID <> '' then
      SQL.Add('and t.idtabela in(' + AListaID + ') ');

    SQL.Add('order by t.tabela asc ');

    ParamByName('idprojeto').AsInteger := FIdProjeto;

    try
      Open;
    except
    end;
  end;
end;

function TServiceTabela.DataSetTabelas(APesquisa: String): TDataSource;
//dataset de tabelas para dbgrid
var
  q: TZQuery;
begin
  FErro := '';
  Result := TDataSource.Create(nil);
  q := DMServer.NewQuery();

  q.SQL.Add('select ');
  q.SQL.Add('t.idtabela, t.tabela, ');
  q.SQL.Add('(select count(*) from crud_campo where idtabela = t.idtabela) as qdecampos, ');
  q.SQL.Add('1 as selecao ');
  q.SQL.Add('from crud_tabela t ');
  q.SQL.Add('where t.idprojeto = ' + IntToStr(FIdProjeto) + ' ');

  if APesquisa.Trim <> '' then
    q.SQL.Add('and t.tabela like :pesquisa ');

  q.SQL.Add('order by t.tabela asc ');

  if APesquisa.Trim <> '' then
    q.ParamByName('pesquisa').AsString := '%' + APesquisa.Trim + '%';

  try
    q.Open;
    Result.DataSet := q;
    // fechar lá no destino/cliente
  except
    on E: Exception do
      FErro := E.Message;
  end;
end;

end.

