unit Service.Tabela;

// Cadastro de informações de tabela

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ZDataset, DB, SQLDB;

type

  { TServiceTabela }

  TServiceTabela = class
    private
      FApiDelete: Boolean;
      FApiGet: Boolean;
      FApiPatch: Boolean;
      FApiPost: Boolean;
      FApiPut: Boolean;
      FApiRota: string;
      FCriarApi: Boolean;
      FCriarDbGridForm: Boolean;
      FCriarFormPesquisa: Boolean;
      FCriarReport: Boolean;
      FDescricao: string;
      FErro: String;
      FIdProjeto: Integer;
      FIdTabela: Integer;
      FIsForAuth: Boolean;
      FNomeObjeto: String;
      FScriptTabela: String;
      FTabela: String;
    public
      constructor Create(AIdProjeto: Integer);
      property GetErro: String read FErro;

      property IdTabela: Integer read FIdTabela write FIdTabela;
      property IdProjeto: Integer read FIdProjeto;
      property Tabela: String read FTabela write FTabela;
      property NomeObjeto: String read FNomeObjeto write FNomeObjeto;
      property CriarDbGridForm: Boolean read FCriarDbGridForm write FCriarDbGridForm;
      property CriarFormPesquisa: Boolean read FCriarFormPesquisa write FCriarFormPesquisa;
      property CriarReport: Boolean read FCriarReport write FCriarReport;
      property CriarApi: Boolean read FCriarApi write FCriarApi;
      property ApiGet: Boolean read FApiGet write FApiGet;
      property ApiPost: Boolean read FApiPost write FApiPost;
      property ApiPut: Boolean read FApiPut write FApiPut;
      property ApiPatch: Boolean read FApiPatch write FApiPatch;
      property ApiDelete: Boolean read FApiDelete write FApiDelete;
      property ApiRota: string read FApiRota write FApiRota;
      property ScriptTabela: String read FScriptTabela write FScriptTabela;
      property Descricao: string read FDescricao write FDescricao;
      property IsForAuth: Boolean read FIsForAuth write FIsForAuth;

      function Salvar(AIdTabela: Integer; AEdicao: Boolean = False): Integer;
      function SalvarScript(AIdTabela: Integer; AScript: String): Boolean;
      function Ler(AIdTabela: Integer): Boolean;
      function Deletar(AIdTabela: Integer): Boolean;
      function ExisteTabela(ATabela: String): Integer;
      function QueryTabelas(AListaTabelasID: string; AIsAPI: Boolean): TZQuery;
      function QueryScripts(AListaID: string): TZQuery;
      function DataSetTabelas(APesquisa: String): TDataSource;
  end;

implementation

uses
  DM.Server, Util.Idioma;

{ TServiceTabela }

constructor TServiceTabela.Create(AIdProjeto: Integer);
begin
  FIdProjeto := AIdProjeto;
end;

function TServiceTabela.Salvar(AIdTabela: Integer; AEdicao: Boolean = False): Integer;
//salva o projeto, se ainda não existir
var
  bValidaCampos: Boolean;
begin
  Result := 0;
  bValidaCampos := True;

  if IdProjeto < 1 then begin
    FErro := ServiceTabela.Mensagem1;
    Exit;
  end;

  if Trim(Tabela)     = '' then bValidaCampos := False;
  if Trim(NomeObjeto) = '' then bValidaCampos := False;
  if Trim(Descricao)  = '' then Descricao     := NomeObjeto;
  if not CriarDbGridForm and not CriarFormPesquisa then CriarReport := False;

  if not bValidaCampos then begin
    FErro := ServiceTabela.Mensagem2;
    Exit;
  end;

  if not AEdicao then begin
    Result := ExisteTabela(Tabela);

    if (Result > 0) then begin
      Deletar(Result);
      AIdTabela := 0;
    end;
  end;

  with DMServer.NewQuery() do begin
    if AIdTabela < 1 then begin
      SQL.Add('INSERT INTO crud_tabela ');
      SQL.Add(' (idprojeto, tabela, nome_objeto, criar_dbgrid_form, criar_form_pesquisa, ');
      SQL.Add(' criar_report, script_tabela, descricao, for_auth, ');
      SQL.Add(' criar_api, api_get, api_post, api_put, api_patch, api_delete, api_rota) ');
      SQL.Add('VALUES(:idprojeto, :tabela, :nome_objeto, :criar_dbgrid_form, :criar_form_pesquisa, ');
      SQL.Add(':criar_report, :script_tabela, :descricao, :for_auth, ');
      SQL.Add(':criar_api, :api_get, :api_post, :api_put, :api_patch, :api_delete, :api_rota) ');
    end
    else begin
      SQL.Add('UPDATE crud_tabela SET ');
      SQL.Add(' idprojeto = :idprojeto, tabela = :tabela, nome_objeto = :nome_objeto, ');
      SQL.Add(' criar_dbgrid_form = :criar_dbgrid_form, criar_form_pesquisa = :criar_form_pesquisa, ');
      SQL.Add(' criar_report = :criar_report, script_tabela = :script_tabela, descricao = :descricao, ');
      SQL.Add(' criar_api = :criar_api, api_get = :api_get, api_post = :api_post, api_put = :api_put, ');
      SQL.Add(' api_patch = :api_patch, api_delete = :api_delete, api_rota = :api_rota, ');
      SQL.Add(' for_auth = :for_auth ');
      SQL.Add('WHERE idtabela=' + IntToStr(AIdTabela));
    end;

    ParamByName('idprojeto').AsInteger           := FIdProjeto;
    ParamByName('tabela').AsString               := Tabela;
    ParamByName('nome_objeto').AsString          := NomeObjeto;
    ParamByName('criar_dbgrid_form').AsInteger   := Ord(CriarDbGridForm);
    ParamByName('criar_form_pesquisa').AsInteger := Ord(CriarFormPesquisa);
    ParamByName('criar_report').AsInteger        := Ord(CriarReport);
    ParamByName('script_tabela').AsString        := ScriptTabela;
    ParamByName('descricao').AsString            := Descricao;
    ParamByName('criar_api').AsInteger           := Ord(CriarApi);
    ParamByName('api_get').AsInteger             := Ord(ApiGet);
    ParamByName('api_post').AsInteger            := Ord(ApiPost);
    ParamByName('api_put').AsInteger             := Ord(ApiPut);
    ParamByName('api_patch').AsInteger           := Ord(ApiPatch);
    ParamByName('api_delete').AsInteger          := Ord(ApiDelete);
    ParamByName('api_rota').AsString             := ApiRota;
    ParamByName('for_auth').AsInteger            := Ord(IsForAuth);

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      if AIdTabela < 1 then
        Result := DMServer.LastInsertedID
      else
        Result := AIdTabela;

      FIdTabela := Result;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := Tabela + ': ' + E.Message;
      end;
    end;

    Free;
  end;
end;

function TServiceTabela.SalvarScript(AIdTabela: Integer; AScript: String): Boolean;
//salva o script da tabela
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('UPDATE crud_tabela SET ');
    SQL.Add(' script_tabela = :script_tabela ');
    SQL.Add('WHERE idtabela=' + IntToStr(AIdTabela));

    ParamByName('script_tabela').AsString := AScript;

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      Result := True;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := E.Message;
      end;
    end;

    Free;
  end;
end;

function TServiceTabela.Ler(AIdTabela: Integer): Boolean;
//ler dados da tabela
begin
  with DMServer.NewQuery() do begin
    SQL.Add('SELECT ');
    SQL.Add(' idprojeto, tabela, nome_objeto, criar_dbgrid_form, criar_form_pesquisa, ');
    SQL.Add(' criar_report, script_tabela, descricao, criar_api, for_auth, ');
    SQL.Add(' api_get, api_post, api_put, api_patch, api_delete, api_rota ');
    SQL.Add('FROM crud_tabela ');
    SQL.Add('WHERE idtabela = ' + IntToStr(AIdTabela));

    try
      Open;

      if not EOF then begin
        FIdTabela           := AIdTabela;
        FIdProjeto          := FieldByName('idprojeto').AsInteger;
        Tabela              := FieldByName('tabela').AsString;
        NomeObjeto          := FieldByName('nome_objeto').AsString;
        CriarDbGridForm     := FieldByName('criar_dbgrid_form').AsInteger = 1;
        CriarFormPesquisa   := FieldByName('criar_form_pesquisa').AsInteger = 1;
        CriarReport         := FieldByName('criar_report').AsInteger = 1;
        ScriptTabela        := FieldByName('script_tabela').AsString;
        Descricao           := FieldByName('descricao').AsString;
        CriarApi            := FieldByName('criar_api').AsInteger = 1;
        ApiGet              := FieldByName('api_get').AsInteger = 1;
        ApiPost             := FieldByName('api_post').AsInteger = 1;
        ApiPut              := FieldByName('api_put').AsInteger = 1;
        ApiPatch            := FieldByName('api_patch').AsInteger = 1;
        ApiDelete           := FieldByName('api_delete').AsInteger = 1;
        ApiRota             := FieldByName('api_rota').AsString;
        IsForAuth           := FieldByName('for_auth').AsInteger = 1;

        Result := True;
      end;

      Close;
    except
      on E: Exception do begin
        FErro := E.Message;
      end;
    end;

    Free;
  end;
end;

function TServiceTabela.Deletar(AIdTabela: Integer): Boolean;
//deleta a tabela e os campos vinculados
begin
  Result := False;

  with DMServer.NewQuery() do begin
    SQL.Add('DELETE FROM crud_tabela ');
    SQL.Add('WHERE idtabela = ' + IntToStr(AIdTabela));

    try
      DMServer.TransactionPrepare;

      ExecSQL;

      DMServer.TransactionCommit;

      Result := True;
    except
      on E: Exception do begin
        DMServer.TransactionRollback;
        FErro := E.Message;
      end;
    end;

    Free;
  end;
end;

function TServiceTabela.ExisteTabela(ATabela: String): Integer;
//verifica se a tabela já está cadastrada
begin
  Result := 0;

  with DMServer.NewQuery() do begin
    SQL.Add('SELECT idtabela ');
    SQL.Add('FROM crud_tabela ');
    SQL.Add('WHERE LOWER(tabela) = :tabela AND idprojeto = :idprojeto ');

    ParamByName('tabela').AsString     := LowerCase(ATabela);
    ParamByName('idprojeto').AsInteger := FIdProjeto;

    try
      Open;

      if not EOF then
        Result := FieldByName('idtabela').AsInteger;

      Close;
    except

    end;

    Free;
  end;
end;

function TServiceTabela.QueryTabelas(AListaTabelasID: string; AIsAPI: Boolean): TZQuery;
//query de tabelas do projeto
begin
  Result := DMServer.NewQuery();

  with Result do begin
    SQL.Add('SELECT ');
    SQL.Add(' t.idtabela, t.tabela, t.nome_objeto, t.descricao, ');
    SQL.Add(' t.criar_dbgrid_form, t.criar_form_pesquisa, t.criar_report, t.script_tabela, t.for_auth, ');
    SQL.Add(' t.criar_api, t.api_get, t.api_post, t.api_put, t.api_patch, t.api_delete, t.api_rota, ');
    SQL.Add(' (SELECT COUNT(*) FROM crud_campo WHERE idtabela = t.idtabela AND incluir_na_grid = 1) AS qdeitensgrid, ');
    SQL.Add(' (SELECT COUNT(*) FROM crud_campo WHERE idtabela = t.idtabela AND chave_primaria = 1) AS chave_primaria ');
    SQL.Add('FROM crud_tabela t ');
    SQL.Add('WHERE t.idprojeto = :idprojeto ');

    if AIsAPI then
      SQL.Add('AND t.criar_api = 1 ');

    if AListaTabelasID <> '' then
      SQL.Add('AND t.idtabela IN(' + AListaTabelasID + ') '); // 1,5,20 {lista de IDs das tabelas}

    SQL.Add('ORDER BY t.tabela ASC ');

    ParamByName('idprojeto').AsInteger := FIdProjeto;

    try
      Open;
    except
    end;
  end;
end;

function TServiceTabela.QueryScripts(AListaID: string): TZQuery;
//query de scripts das tabelas do projeto
begin
  Result := DMServer.NewQuery();

  with Result do begin
    SQL.Add('SELECT ');
    SQL.Add(' t.tabela, c.campo AS primary_key, t.script_tabela ');
    SQL.Add('FROM crud_tabela t ');
    SQL.Add('LEFT JOIN crud_campo c ON c.idtabela = t.idtabela AND c.chave_primaria = 1 ');
    SQL.Add('WHERE t.idprojeto = :idprojeto ');

    if AListaID <> '' then
      SQL.Add('AND t.idtabela IN(' + AListaID + ') ');

    SQL.Add('ORDER BY t.tabela ASC ');

    ParamByName('idprojeto').AsInteger := FIdProjeto;

    try
      Open;
    except
    end;
  end;
end;

function TServiceTabela.DataSetTabelas(APesquisa: String): TDataSource;
//dataset de tabelas para dbgrid
var
  q: TZQuery;
begin
  FErro := '';
  Result := TDataSource.Create(nil);
  q := DMServer.NewQuery();

  q.SQL.Add('SELECT ');
  q.SQL.Add(' t.idtabela, t.tabela, t.api_rota as rota, ');
  q.SQL.Add(' (SELECT COUNT(*) FROM crud_campo WHERE idtabela = t.idtabela) AS qdecampos, ');
  q.SQL.Add(' 1 AS selecao ');
  q.SQL.Add('FROM crud_tabela t ');
  q.SQL.Add('WHERE t.idprojeto = ' + IntToStr(FIdProjeto) + ' ');

  if APesquisa.Trim <> '' then
    q.SQL.Add('AND t.tabela LIKE :pesquisa ');

  q.SQL.Add('ORDER BY t.tabela ASC ');

  if APesquisa.Trim <> '' then
    q.ParamByName('pesquisa').AsString := '%' + APesquisa.Trim + '%';

  try
    q.Open;
    Result.DataSet := q;
    // fechar lá no destino/cliente
  except
    on E: Exception do
      FErro := E.Message;
  end;
end;

end.

