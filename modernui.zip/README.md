# modernui

## Pacotes de componentes visuais

Components Packages for Lazarus / FreePascal

- ButtonPlusPackage: Botão com novo visual.
- ButtonRetroPackage: Botão retrô estilo windows.
- ChasePanelPackage: Painel animado (Marquee Frame).
- CheckboxPlusPackage: Checkbox com visual diferente.
- CircularProgressBarPackage: Progresso circular.
- DBGridPlusPackage: DBGrid com visual moderno, bordas, gradiente.
- EditExtPackage: Edit padrão do Topazzio.
- EditPlusPackage: Edit com Imagem.
- LabelPlusPackage: Label com ícone, bordas e gradiente.
- MaskedEditPlusPackage: Edit com máscaras (cpf, cnpj, telefone, cep, data) e valores monetários.
- PanelPlusPackage: Painel diferentes tipos de bordas e gradiente.
- SplitViewPackage: Componente para criar menu lateral retrátil.
- SplitViewButtonPackage: Botão específico para o SplitViewPackage.
- ToggleButtonPlusPackage: Chequebox no estilo toggle como no celular.
- Pasta Utils: Utilitários para Thread, Imagem (banco de dados), validação de campos, etc.
