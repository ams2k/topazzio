unit Util.ProjetoCommon;

// funções comuns para Util.ProjetoLazarus e Util.ProjetoLazarusAPI

{$mode ObjFPC}{$H+}

interface

uses
  Classes, SysUtils, ExtCtrls, Graphics, Controls, LCLIntf, LCLType, TypInfo, Math,
  ZDataset, BGRABitmap, BGRABitmapTypes, FPImage, FPReadPNG, FPWritePNG, FPImgCanv;

type
  TTipoBanco = (POSTGRE, MYSQL, FIREBIRD, SQLITE, SQLSERVER, ORACLE, MARIADB, ACCESS, NONE);

  TIconDir = packed record
    idReserved: Word;
    idType: Word;
    idCount: Word;
  end;

  TIconDirEntry = packed record
    bWidth: Byte;
    bHeight: Byte;
    bColorCount: Byte;
    bReserved: Byte;
    wPlanes: Word;
    wBitCount: Word;
    dwBytesInRes: DWord;
    dwImageOffset: DWord;
  end;

  { TUtilCommon }

  TUtilCommon = class
  private
    class function GetTabelaAuditagem: string;
    public
      class function CapitalizaTexto(AValue: String): String;
      class function InformacoesLegais: String;
      class function LerArquivo(APathFile: String): String;
      class function GetProtocoloSGDB(ATipoBanco: TTipoBanco): string;
      class function RemoveFieldUnderscore(AValue: String): String;
      class function ScriptTableToFields(AScript: string): TStringList;

      class function ImageToHexPNG(const AImage: TImage; ASize: Integer; AIsRPT: Boolean = False): string;
      class function BitmapToPNGStream(const AGraphic: TGraphic; ASize: Integer): TMemoryStream;
      class function BitmapToPNGStreamRPT(const AGraphic: TGraphic; ASize: Integer): TMemoryStream;
      class function ResizeImagem(const AImage: TImage; AWidth, AHeight: Integer; ABackColor: TColor): TBitmap;
      class procedure SaveAsIcon(const AImage: TImage; ASize: Integer; const AFileName: string; ATransparent: Boolean = False);

      class procedure CriarPasta(APasta: String);
      class procedure SalvarArquivo(APathFilename, AContent: String);
      class procedure GerarDatamodule(AIdProjeto: Integer; AProtocolo,
        AListaTabelasID, APastaDataModule, AINIFileName: string; AAuditar: Boolean);
      class procedure GerarDatamoduleMSSQL(APastaDataModule, AINIFileName: string; AAuditar: Boolean); //exclusivo para sqlserver
      class procedure GerarUtilCriptografia(APastaUtil: string);
      class procedure GerarUtilImagem(APastaUtil: string);
      class procedure GerarServiceApiAudit(APastaService: string; ATipoBanco: TTipoBanco);
  end;

implementation

uses
  Service.Tabela;

{ TUtilCommon }

class function TUtilCommon.CapitalizaTexto(AValue: String): String;
//Transforma a primeira letra em maiúscula
begin
  if AValue.Length > 1 then
     Result := UpperCase(AValue.Substring(0, 1)) + AValue.Substring(1)
  else
    Result := AValue.ToUpper;
end;

class function TUtilCommon.InformacoesLegais: String;
//informações de criação do arquivo
begin
  Result := '{ ' + sLineBreak +
            ' Created by Topazzio at ' + FormatDateTime('yyyy-mm-dd hh:nn:ss', now) + sLineBreak +
            ' Developed by Aldo Márcio Soares  |  ams2kg@gmail.com  |  CopyLeft ' +
            FormatDateTime('yyyy', now) + sLineBreak +
            '} ' + sLineBreak + sLineBreak;
end;

class function TUtilCommon.LerArquivo(APathFile: String): String;
//ler dados do arquivo indicado
var
  lArquivo: TextFile;
  sTexto: String;
  i: Integer;
begin
  Result := '';
  i := 0;

  if FileExists(APathFile) then begin

    AssignFile(lArquivo, APathFile);
    Reset(lArquivo);

    try
       while not EOF(lArquivo) do begin
         sTexto := '';
         ReadLn (lArquivo, sTexto);

         if i > 0 then
           Result := Result + sLineBreak;

         Result := Result + sTexto;
         inc(i);
       end;
    finally
       CloseFile(lArquivo);
    end;
  end;
end;

class function TUtilCommon.GetProtocoloSGDB(ATipoBanco: TTipoBanco): string;
//retorno o protocolo do banco de dados
begin
  case TTipoBanco(ATipoBanco) of
    POSTGRE:
      Result := 'postgresql';
    MYSQL:
      Result := 'mysql';
    FIREBIRD:
      Result := 'firebird';
    SQLITE:
      Result := 'sqlite';
    SQLSERVER:
      Result := 'mssql';
    ORACLE:
      Result := 'oracle';
    MARIADB:
      Result := 'mariadb';
  else
    Result := 'sqlite';
  end;
end;

class function TUtilCommon.RemoveFieldUnderscore(AValue: String): String;
//remove o underscore entre as palavras: Ex: id_produto --> IdProduto
var
  s: array of string;
  i: Integer;
begin
  Result := Trim( AValue );

  if AValue.IndexOf('_') > 0 then begin
    s := AValue.Split(['_'], TStringSplitOptions.ExcludeEmpty);
    Result := '';

    for i := 0 to High(s) do
      Result := Result + TUtilCommon.CapitalizaTexto( s[i].Trim() );

    SetLength(s, 0);
  end
  else
    Result := TUtilCommon.CapitalizaTexto( Result );
end;

class function TUtilCommon.ScriptTableToFields(AScript: string): TStringList;
//pega o script de criação de tabelas e retorna as linhas dos campos
// prepara o script no caso de number(8,2) quando usar o Split([','], TStringSplitOptions.ExcludeEmpty)
var
  FArray: array of string;
  i, j, k, count: integer;
  s: string;
begin
  count  := 0;
  i      := 0;
  s      := '';
  Result := TStringList.Create;

  //checa se é um script de criação de tabela
  i := AScript.ToLower.IndexOf('create table ');
  if i < 0 then Exit;

  //adiciona o if not exists
  i := AScript.ToLower.IndexOf('not exists ');
  if i < 0 then
    AScript := AScript.ToLower.Replace('create table ', 'create table if not exists ');

  //evitar de o primeiro campo ficar na linha do create table
  i := AScript.IndexOf('(');
  if i>0 then
    AScript := AScript.Substring(0, i) + '(,' + AScript.Substring(i+1);

  while True do begin
     j := LowerCase(AScript).IndexOf('number', i);
     if j < 0 then Break;

     i := j;
     j := LowerCase(AScript).IndexOf('(', i);

     if j >= 0 then begin
       i := j;
       j := LowerCase(AScript).IndexOf(')', i);

       if j > i then begin
         k := LowerCase(AScript).IndexOf(',', i);

         if (k > 0) and (k < j) then begin
            AScript := AScript.Substring(0, k) + '!' + AScript.Substring(k + 1);
            i := k;
         end;
       end;
     end;

     count := count + 1;
     if count > 10 then Break;
  end;

  // split das colunas
  AScript := AScript.Replace(sLineBreak, '', [rfReplaceAll]);
  FArray  := AScript.Split([','], TStringSplitOptions.ExcludeEmpty);

  for i := 0 to High(FArray) do begin
    s := FArray[i].Trim;
    if s = '' then Continue;
    s := s.Replace('!', ',');
    if (i > 0) and (i < High(FArray)) then s := s + ',';
    Result.Add(s)
  end;

  SetLength(FArray, 0);
end;

class function TUtilCommon.ImageToHexPNG(const AImage: TImage; ASize: Integer; AIsRPT: Boolean): string;
// Retorna: Picture.Data { ... }
// Obtém o código Hexadecimal que representa uma imagem contida no objeto TImage
var
  lImage: TImage;
  BinStream: TMemoryStream;
  TxtStream: TStringStream;
  Png: TPortableNetworkGraphic;
  i: integer;
begin
  if not Assigned(AImage.Picture.Graphic) then
    raise Exception.Create('Invalid image');

  ASize := EnsureRange(ASize, 1, 2048);

  lImage := TImage.Create(nil);
  Png := TPortableNetworkGraphic.Create;
  BinStream := TMemoryStream.Create;
  TxtStream := TStringStream.Create('');

  try
    if AIsRPT then
      Png.LoadFromStream( BitmapToPNGStreamRPT(AImage.Picture.Graphic, ASize) )
    else
      Png.LoadFromStream( BitmapToPNGStream(AImage.Picture.Graphic, ASize) );

    lImage.Picture.Assign( Png );

    // serializa como o Lazarus (.lfm)
    BinStream.WriteComponent(lImage);
    BinStream.Position := 0;

    ObjectBinaryToText(BinStream, TxtStream);

    Result := TxtStream.DataString;

    i := Pos('Picture.Data', Result);
    if i > 0 then begin
      Result := Copy(Result, i, Length(Result));
      i := Pos('}', Result);
      if i > 0 then begin
        Result := Copy(Result, 1, i);
      end;
    end;

  finally
    TxtStream.Free;
    BinStream.Free;
    lImage.Free;
    Png.Free;
  end;
end;

class procedure TUtilCommon.SaveAsIcon(const AImage: TImage; ASize: Integer; const AFileName: string; ATransparent: Boolean);
// cria um ícone / favicon.ico
var
  Bmp: TBitmap;
  Icon: TIcon;
begin
  if not Assigned(AImage.Picture.Graphic) then
    raise Exception.Create('Invalid image');

  ASize := EnsureRange(ASize, 16, 256);

  Bmp := TBitmap.Create;
  Icon := TIcon.Create;
  try
    Bmp.PixelFormat := pf24bit;

    Bmp.SetSize(ASize, ASize);

    // fundo sólido ou transparente
    if not ATransparent then
      Bmp.Canvas.Brush.Color := clWhite;

    Bmp.Canvas.FillRect(Rect(0,0,ASize,ASize));

    // desenha imagem
    Bmp.Canvas.StretchDraw(
      Rect(0,0,ASize,ASize),
      AImage.Picture.Graphic
    );

    // gera ícone
    Icon.Assign(Bmp);

    // salva no arquivo
    Icon.SaveToFile(AFileName);

  finally
    Icon.Free;
    Bmp.Free;
  end;
end;

class function TUtilCommon.BitmapToPNGStream(const AGraphic: TGraphic; ASize: Integer): TMemoryStream;
// redimensiona o bitmap
var
  src, resized: TBGRABitmap;
begin
  Result := TMemoryStream.Create;

  // cria direto do TGraphic (não do Bitmap)
  src := TBGRABitmap.Create;
  try
    src.Assign(AGraphic);

    src.ResampleFilter := rfBestQuality;

    resized := src.Resample(ASize, ASize) as TBGRABitmap;
    try
      resized.SaveToStreamAsPng(Result);
      Result.Position := 0;
    finally
      resized.Free;
    end;
  finally
    src.Free;
  end;
end;

class function TUtilCommon.BitmapToPNGStreamRPT(const AGraphic: TGraphic;  ASize: Integer): TMemoryStream;
// redimensiona a imagem com fundo branco para uso em relatórios
var
  src, img, resized: TBGRABitmap;
begin
  Result := TMemoryStream.Create;

  // cria bitmap original
  img := TBGRABitmap.Create;
  try
    img.Assign(AGraphic);

    // cria fundo branco
    with TBGRABitmap.Create(img.Width, img.Height, BGRAWhite) do
    try
      // desenha imagem preservando transparência
      PutImage(0, 0, img, dmDrawWithTransparency);

      // redimensiona com qualidade
      ResampleFilter := rfBestQuality;

      resized := Resample(ASize, ASize) as TBGRABitmap;
      try
        // salva PNG SEM alpha
        resized.SaveToStreamAsPng(Result);

        Result.Position := 0;
      finally
        resized.Free;
      end;

    finally
      Free;
    end;

  finally
    img.Free;
  end;
end;

class function TUtilCommon.ResizeImagem(const AImage: TImage; AWidth, AHeight: Integer; ABackColor: TColor): TBitmap;
// redimensiona a imagem
begin
  Result := TBitmap.Create;
  if ABackColor <> clDefault then
    Result.Canvas.Brush.Color := ABackColor;
  Result.PixelFormat := pf24bit;
  Result.SetSize(AWidth, AHeight);
  Result.Canvas.StretchDraw(Rect(0, 0, AWidth, AHeight), AImage.Picture.Graphic);
end;

class procedure TUtilCommon.CriarPasta(APasta: String);
// cria pastas
begin
  APasta := APasta.Replace(PathDelim + PathDelim, PathDelim);// remove (//) barras duplas

  try
    if not DirectoryExists(APasta) then
      CreateDir(APasta);
  except
  end;
end;

class procedure TUtilCommon.SalvarArquivo(APathFilename, AContent: String);
//salva o arquivo informado
var
  docFile: TextFile;
begin
  // deleta o arquivo, se existir
  if FileExists(APathFilename) then
    DeleteFile(APathFilename);

  // Define o arquivo a ser criado
  AssignFile(docFile, APathFilename);

  // Use isso para permitir capturar exceções. Não precisa usar se não quiser.
  {$I+}

  try
    // Cria ou sobrescreve o arquivo
    Rewrite(docFile);

    // grava o conteúdo do arquivo
    WriteLn(docFile, AContent);

    // fecha o arquivo
    CloseFile(docFile);
  except
    //on E: EInOutError do
    // s := 'Erro no arquivo.' + sLineBreak + APathFilename + sLineBreak + E.ClassName + sLineBreak + E.Message;
  end;
end;

class procedure TUtilCommon.GerarDatamodule(AIdProjeto: Integer; AProtocolo, AListaTabelasID,
  APastaDataModule, AINIFileName: string; AAuditar: Boolean);
// cria o datamodule
var
  q: TZQuery;
  t: TServiceTabela;
  s, lVersaoNome, lVersaoQuery: string;
  lTabela: TStringList;
  i: integer;
begin
  // CÓDIGO .PAS
  t := TServiceTabela.Create( AIdProjeto );
  q := t.QueryScripts( AListaTabelasID );

  s :=
  'unit DM.Server; ' + sLineBreak +
  ' ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+} ' + sLineBreak +
  ' ' + sLineBreak +
  'interface ' + sLineBreak +
  ' ' + sLineBreak +
  'uses ' + sLineBreak +
  '  Classes, SysUtils, FileUtil, ZConnection, ZDataset, DB, SQLDB, ZDatasetUtils, IniFiles; ' + sLineBreak +
  ' ' + sLineBreak +
  'type ' + sLineBreak +
  ' ' + sLineBreak +
  '  { TDMServer } ' + sLineBreak +
  ' ' + sLineBreak +
  '  TDMServer = class(TDataModule) ' + sLineBreak +
  '    Connection: TZConnection; ' + sLineBreak +
  '    procedure DataModuleCreate(Sender: TObject); ' + sLineBreak +
  '    procedure DataModuleDestroy(Sender: TObject); ' + sLineBreak +
  '  private ' + sLineBreak +
  '    FAudit: Boolean; ' + sLineBreak +
  '    FMsgErro, FVersao: string; ' + sLineBreak +
  '    FPathDLL, FPathBanco, FHost: String; ' + sLineBreak +
  '    FProtocolo, FBanco, FUsername, FSenha, FOdbc: String; ' + sLineBreak +
  '    FPorta: Integer; ' + sLineBreak +
  '    FCriarTabelas: Boolean; ' + sLineBreak;

  if AProtocolo.Contains('sqlite') then
  s := s +
  '    procedure ChecaTabelas; ' + sLineBreak;

  s := s +
  '    procedure LerConfig; ' + sLineBreak +
  '    procedure GetVersao; ' + sLineBreak;

  if AAuditar then
  s := s +
  '    procedure CreateAuditTable(AProtocol: string); ' + sLineBreak;

  s := s +
  '  public ' + sLineBreak +
  '    property GetMsgErro: string read FMsgErro; ' + sLineBreak +
  '    property GetVersaoServidor: string read FVersao; ' + sLineBreak +
  '    property Audit: Boolean read FAudit; ' + sLineBreak +
  '    property Protocol: string read FProtocolo; ' + sLineBreak +
  '    procedure Conectar; ' + sLineBreak +
  '    procedure Desconectar; ' + sLineBreak +
  '    procedure Reconectar; ' + sLineBreak +
  '    procedure ChecaConexao; ' + sLineBreak +
  '    procedure TransactionPrepare; ' + sLineBreak +
  '    procedure TransactionCommit; ' + sLineBreak +
  '    procedure TransactionRollback; ' + sLineBreak +
  '    function IsConnected: Boolean; ' + sLineBreak +
  '    function LastInsertedID(APrimaryKey, ATable: string): Integer; ' + sLineBreak +
  '    function NewQuery(): TZQuery; ' + sLineBreak +
  '  end; ' + sLineBreak +
  ' ' + sLineBreak +
  'var ' + sLineBreak +
  '  DMServer: TDMServer; ' + sLineBreak +
  ' ' + sLineBreak +
  'implementation ' + sLineBreak +
  ' ' + sLineBreak +
  'uses ' + sLineBreak +
  '  Util.Criptografia';

  if AAuditar then
    s := s + ', Service.ApiAudit';

  s := s +
  ';' + sLineBreak +
  ' ' + sLineBreak +
  '{$R *.lfm} ' + sLineBreak +
  ' ' + sLineBreak +
  '{ TDMServer } ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.DataModuleCreate(Sender: TObject); ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Conectar; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.DataModuleDestroy(Sender: TObject); ' + sLineBreak +
  '// desconecta do banco de daddos ao destruir este módulo ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Desconectar; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.Conectar; ' + sLineBreak +
  '//estabelece a conexão ' + sLineBreak +
  'begin ' + sLineBreak +
  '  FAudit        := False; ' + sLineBreak +
  '  FMsgErro      := ''''; ' + sLineBreak +
  '  FVersao       := ''''; ' + sLineBreak +
  '  LerConfig; ' + sLineBreak +
  '  FPathBanco    := ExtractFileDir( ParamStr(0) ) + PathDelim; ' + sLineBreak +
  '  FPathDLL      := FPathBanco; //windows ' + sLineBreak +
  '  FCriarTabelas := not FileExists( FPathBanco ); ' + sLineBreak +
  ' ' + sLineBreak +
  '  if (FProtocolo.Contains(''sqlite'')) and not (FBanco.Contains(PathDelim)) then ' + sLineBreak +
  '    FBanco := FPathBanco + FBanco; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    with Connection do begin ' + sLineBreak +
  '     HostName   := FHost; ' + sLineBreak +
  '     Protocol   := FProtocolo; ' + sLineBreak;

  if AProtocolo = 'oracle' then
    s := s +
    '     Database   := FHost + '':'' + IntToStr(FPorta) + ''/'' + FBanco; ' + sLineBreak
  else
    s := s +
    '     Database   := FBanco; ' + sLineBreak;

  s := s +
  '     User       := FUsername; ' + sLineBreak +
  '     Password   := FSenha; ' + sLineBreak +
  '     Port       := FPorta; ' + sLineBreak;

  s := s +
  '     AutoCommit := True; ' + sLineBreak +
  ' ' + sLineBreak +
  '     {$IFDEF WINDOWS} ' + sLineBreak +
  '        if Protocol.Contains(''sqlite'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''sqlite3.dll''; ' + sLineBreak +
  '        if Protocol.Contains(''firebird'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''fbclient.dll''; ' + sLineBreak +
  '        if Protocol.Contains(''mariadb'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''libmariadb.dll''; // 32 bits ' + sLineBreak +
  '        if Protocol.Contains(''mysql'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''libmysql.dll'';  // 32 bits ' + sLineBreak +
  '        if Protocol.Contains(''postgresql'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''libpq-15.dll''; ' + sLineBreak +
  '        if Protocol.Contains(''oracle'') then ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''oci.dll''; ' + sLineBreak +
  '        if Protocol.Contains(''mssql'') then ' + sLineBreak +
  '          //driver: libsybdb-5.dll ou ntwdblib.dll ou dblib.dll ou libsybdb.so (linux) ou libsybdb.dylib (macos) ' + sLineBreak +
  '          //Database := ''Provider=SQLOLEDB.1;Persist Security Info=True;Data Source='' + p.HostServidor +'',''+ p.Porta + ''; Initial Catalog='' + p.BancoDados+ ''; User ID='' +  p.Username + '';password='' + p.Senha; ' + sLineBreak +
  '          //Protocol := ''ado''; ' + sLineBreak +
  '          LibraryLocation := FPathDLL + ''dblib.dll''; ' + sLineBreak +
  '     {$ENDIF}  ' + sLineBreak +   ' ' + sLineBreak +
  '     Connect; ' + sLineBreak +
  '     GetVersao; ' + sLineBreak;

  if AAuditar then
  s := s +
  '     CreateAuditTable(FProtocolo.ToLower);' + sLineBreak;

  s := s +
  '    end; ' + sLineBreak +
  ' ' + sLineBreak;

  if AProtocolo.Contains('sqlite') then
    s := s +
    '    ChecaTabelas; ' + sLineBreak;

  s := s +
  '  except ' + sLineBreak +
  '    on E: Exception do ' + sLineBreak +
  '       FMsgErro := E.Message; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak;

  if AProtocolo.Contains('sqlite') then begin
    s := s +
    'procedure TDMServer.ChecaTabelas; ' + sLineBreak +
    '// Cria as tabelas se não existir ' + sLineBreak +
    'begin ' + sLineBreak +
    '  if not FCriarTabelas then Exit; ' + sLineBreak +
    ' ' + sLineBreak +
    '  ChecaConexao; ' + sLineBreak +
    ' ' + sLineBreak +
    '  try ' + sLineBreak +
    '    // cria as tabelas ' + sLineBreak;

    //adiciona scripts de criação das tabelas
    while not q.EOF do begin
      lTabela := TUtilCommon.ScriptTableToFields( q.FieldByName('script_tabela').AsString );

      if lTabela.Count >0 then begin
        s := s + '    Connection.ExecuteDirect(' + sLineBreak;

        for i := 0 to lTabela.Count -1 do begin
          if (i>0 ) and (i <= (lTabela.Count -1)) then s := s + ' + ' + sLineBreak;
           s := s + '    ' + QuotedStr( lTabela[i] );
        end;

        s := s + sLineBreak + '    ); ' + sLineBreak;
      end;

      lTabela.Free;

      if q.FieldByName('primary_key').AsString <> '' then
        s := s + '    Connection.ExecuteDirect(''CREATE INDEX IF NOT EXISTS idx_' +
                      q.FieldByName('tabela').AsString + ' ON ' + q.FieldByName('tabela').AsString + ' (' +
                      q.FieldByName('primary_key').AsString + '); ''); ' + sLineBreak;

      s := s + ' ' + sLineBreak;

      q.Next
    end;

    s := s +
    '  except ' + sLineBreak +
    '  end; ' + sLineBreak +
    'end; ' + sLineBreak +
    ' ' + sLineBreak;
  end;

  s := s +
  'procedure TDMServer.Desconectar; ' + sLineBreak +
  '// desconecta do banco de dados ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if Connection.Connected then ' + sLineBreak +
  '       Connection.Disconnect; ' + sLineBreak +
  '  except ' + sLineBreak +
  '    on e: Exception do ' + sLineBreak +
  '      FMsgErro := e.Message; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TDMServer.IsConnected: Boolean; ' + sLineBreak +
  '//Está conectado ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Result := Connection.Connected; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.ChecaConexao; ' + sLineBreak +
  '// se a conexão não estiver aberta, então tenta conectar no servidor/banco ' + sLineBreak +
  'begin ' + sLineBreak +
  '   FMsgErro := ''''; ' + sLineBreak +
  ' ' + sLineBreak +
  '   try ' + sLineBreak +
  '     if not Connection.Connected then ' + sLineBreak +
  '       Reconectar; ' + sLineBreak +
  '   except ' + sLineBreak +
  '    on e: Exception do ' + sLineBreak +
  '      FMsgErro := e.Message; ' + sLineBreak +
  '   end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.Reconectar; ' + sLineBreak +
  '//reconectar ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if Connection.Connected then Connection.Disconnect; ' + sLineBreak +
  '    Conectar; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionPrepare; ' + sLineBreak +
  '//inicia o transatction ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Connection.AutoCommit := False; ' + sLineBreak +
  '  if not Connection.InTransaction then ' + sLineBreak +
  '    Connection.StartTransaction; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionCommit; ' + sLineBreak +
  '//comita o transaction ' + sLineBreak +
  'begin ' + sLineBreak +
  '  if Connection.InTransaction then ' + sLineBreak +
  '    Connection.Commit; ' + sLineBreak +
  '  Connection.AutoCommit := True; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionRollback; ' + sLineBreak +
  '//rolback do transaction ' + sLineBreak +
  'begin ' + sLineBreak +
  '  if Connection.InTransaction then ' + sLineBreak +
  '    Connection.Rollback; ' + sLineBreak +
  '  Connection.AutoCommit := True; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TDMServer.NewQuery(): TZQuery; ' + sLineBreak +
  '// retorna a instância de uma nova query ' + sLineBreak +
  'begin ' + sLineBreak +
  '  ChecaConexao; ' + sLineBreak +
  ' ' + sLineBreak +
  '  Result := TZQuery.Create(nil); ' + sLineBreak +
  ' ' + sLineBreak +
  '  if FMsgErro.IsEmpty then begin ' + sLineBreak +
  '    try ' + sLineBreak +
  '      Result.Connection := Connection; ' + sLineBreak +
  '      Result.Close; ' + sLineBreak +
  '      Result.SQL.Clear; ' + sLineBreak +
  '    except ' + sLineBreak +
  '      on e: Exception do ' + sLineBreak +
  '        FMsgErro := e.Message; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.GetVersao; ' + sLineBreak +
  '//obtém a versão do servidor sql ' + sLineBreak +
  'var ' + sLineBreak +
  '  lSql, lNome: string; ' + sLineBreak +
  'begin ' + sLineBreak +
  '  FVersao := ''''; ' + sLineBreak;

  lVersaoQuery := '';
  lVersaoNome  := '';

  if AProtocolo.Contains('sqlite') then begin
    lVersaoQuery := 'SELECT sqlite_version() as versao ';
    lVersaoNome := 'SQLite: ';
  end;
  if AProtocolo.Contains('firebird') then begin
    lVersaoQuery := 'SELECT rdb$get_context(''''SYSTEM'''', ''''ENGINE_VERSION'''') AS versao FROM rdb$database ';
    lVersaoNome := 'Firebird: ';
  end;
  if AProtocolo.Contains('mariadb') then begin
    lVersaoQuery := 'select version() as versao ';
    lVersaoNome := 'MariaDB: ';
  end;
  if AProtocolo.Contains('mysql') then begin
    lVersaoQuery := 'select version() as versao ';
    lVersaoNome := 'MySQL: ';
  end;
  if AProtocolo.Contains('postgresql') then begin
    lVersaoQuery := 'select version() as versao ';
  end;
  if AProtocolo.Contains('mssql') then begin
    lVersaoQuery := 'select @@version as versao ';
  end;
  if AProtocolo.Contains('oracle') then begin
    lVersaoQuery := 'SELECT banner as versao FROM v$version ';
  end;

  s := s +
  '  lSql  := ''' + lVersaoQuery + '''; ' + sLineBreak +
  '  lNome := ''' + lVersaoNome  + '''; ' + sLineBreak +
  ' ' + sLineBreak +
  '  if lSql <> '''' then begin ' + sLineBreak +
  '    try ' + sLineBreak +
  '      with NewQuery() do begin ' + sLineBreak +
  '        SQL.Add( lSql ); ' + sLineBreak +
  '        Open; ' + sLineBreak +
  ' ' + sLineBreak +
  '        if RecordCount > 0 then begin ' + sLineBreak +
  '           FVersao := lNome + FieldByName(''versao'').AsString; ' + sLineBreak +
  ' ' + sLineBreak +
  '           if FProtocolo.IndexOf(''postgre'') >= 0 then begin' + sLineBreak +
  '             FVersao := Trim( LeftStr(FVersao, Pos('' on '', FVersao)) );' + sLineBreak +
  '           end;' + sLineBreak +
  '        end; ' + sLineBreak +
  ' ' + sLineBreak +
  '        Close; ' + sLineBreak +
  '      end; ' + sLineBreak +
  '    except ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TDMServer.LastInsertedID(APrimaryKey, ATable: string): Integer; ' + sLineBreak +
  '// retorna o último ID inserido, independente da tabela ' + sLineBreak +
  '// sqlite: select last_insert_rowid() as id;' + sLineBreak +
  '// mysql/mariadb: SELECT LAST_INSERT_ID() as id;' + sLineBreak +
  'begin ' + sLineBreak +
  '  Result := 0; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    with NewQuery() do begin ' + sLineBreak;

  case AProtocolo of
    'mysql', 'mariadb':
      s := s + '      SQL.Add(''SELECT LAST_INSERT_ID() as id ''); ' + sLineBreak;
    'sqlite':
      s := s + '      SQL.Add(''select last_insert_rowid() as id ''); ' + sLineBreak;
  else {oracle, postgresql, mssql, firebird}
    s := s + '      SQL.Add(Format(''select max(%s) as id from %s '', [APrimaryKey, ATable])); ' + sLineBreak;
  end;

  s := s +
  '      Open; ' + sLineBreak +
  ' ' + sLineBreak +
  '      if RecordCount > 0 then ' + sLineBreak +
  '         Result := FieldByName(''id'').AsInteger; ' + sLineBreak +
  ' ' + sLineBreak +
  '      Close; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.LerConfig; ' + sLineBreak +
  '//ler configurações do servidor ' + sLineBreak +
  'var ' + sLineBreak +
  '  ArqINI: TIniFile; ' + sLineBreak +
  '  FArquivoINI: String; ' + sLineBreak +
  '  cr: TCriptografa; ' + sLineBreak +
  'begin ' + sLineBreak +
  '  FArquivoINI := ExtractFileDir( ParamStr(0) ) + PathDelim + ''' + AINIFileName + '''; ' + sLineBreak +
  '  ArqINI := TIniFile.Create(FArquivoINI); ' + sLineBreak +
  ' ' + sLineBreak +
  '  FHost      := ''''; ' + sLineBreak +
  '  FPorta     := 0; ' + sLineBreak +
  '  FProtocolo := ''''; ' + sLineBreak +
  '  FBanco     := ''''; ' + sLineBreak +
  '  FUsername  := ''''; ' + sLineBreak +
  '  FSenha     := ''''; ' + sLineBreak +
  '  FOdbc      := ''''; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    FHost      := ArqINI.ReadString(''dbinfo'',''server'', ''''); ' + sLineBreak +
  '    FPorta     := ArqINI.ReadInteger(''dbinfo'',''port'', 0); ' + sLineBreak +
  '    FProtocolo := ArqINI.ReadString(''dbinfo'',''protocol'', ''''); ' + sLineBreak +
  '    FBanco     := ArqINI.ReadString(''dbinfo'',''db'', ''''); ' + sLineBreak +
  '    FUsername  := ArqINI.ReadString(''dbinfo'',''user'', ''''); ' + sLineBreak +
  '    FSenha     := ArqINI.ReadString(''dbinfo'',''password'', ''''); ' + sLineBreak +
  '    FOdbc      := ArqINI.ReadString(''dbinfo'',''odbc'', ''''); ' + sLineBreak +
  ' ' + sLineBreak +
  '    if (ArqINI.ReadString(''dbinfo'',''encrypt'', ''false'') = ''true'') then begin ' + sLineBreak +
  '      cr := TCriptografa.Create(); ' + sLineBreak +
  '      FUsername := cr.Decrypt(FUsername); ' + sLineBreak +
  '      FSenha := cr.Decrypt(FSenha); ' + sLineBreak +
  '      cr.Free; ' + sLineBreak +
  '    end; ' + sLineBreak +
  ' ' + sLineBreak +
  '  finally ' + sLineBreak +
  '    ArqINI.Free; ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak;

  if AAuditar then begin
    s := s +
    ' ' + sLineBreak +
    TUtilCommon.GetTabelaAuditagem;
  end;

  s := s +
  ' ' + sLineBreak +
  'end. ' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaDataModule + 'dm.server.pas', s);

  // FORM .LFM
  s :=
  'object DMServer: TDMServer ' + sLineBreak +
  '  OnCreate = DataModuleCreate ' + sLineBreak +
  '  OnDestroy = DataModuleDestroy ' + sLineBreak +
  '  OldCreateOrder = False ' + sLineBreak +
  '  Height = 193 ' + sLineBreak +
  '  HorizontalOffset = 403 ' + sLineBreak +
  '  VerticalOffset = 250 ' + sLineBreak +
  '  Width = 268 ' + sLineBreak +
  '  object Connection: TZConnection ' + sLineBreak +
  '    ControlsCodePage = cCP_UTF8 ' + sLineBreak +
  '    DisableSavepoints = False ' + sLineBreak +
  '    Port = 0 ' + sLineBreak +
  '    Left = 60 ' + sLineBreak +
  '    Top = 36 ' + sLineBreak +
  '  end ' + sLineBreak +
  'end ' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaDataModule + 'dm.server.lfm', s);

  s := '';
  q.Close;
  q.Free;
  t.Free;
end;

class procedure TUtilCommon.GerarDatamoduleMSSQL(APastaDataModule, AINIFileName: string; AAuditar: Boolean);
//cria o datamodule especifico para o sqlserver
var
  s: string;
begin
  // .PAS
  s :=
  'unit DM.Server;  ' + sLineBreak +
  '  ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+}  ' + sLineBreak +
  '  ' + sLineBreak +
  'interface  ' + sLineBreak +
  '  ' + sLineBreak +
  'uses  ' + sLineBreak +
  '  Classes, SysUtils, FileUtil, DB, SQLDB, MSSQLConn, IniFiles; ' + sLineBreak +
  '  ' + sLineBreak +
  'type  ' + sLineBreak +
  '  ' + sLineBreak +
  '  { TDMServer }  ' + sLineBreak +
  '  ' + sLineBreak +
  '  TDMServer = class(TDataModule) ' + sLineBreak +
  '    Connection: TMSSQLConnection; ' + sLineBreak +
  '    Transaction: TSQLTransaction; ' + sLineBreak +
  '    procedure DataModuleCreate(Sender: TObject);  ' + sLineBreak +
  '    procedure DataModuleDestroy(Sender: TObject);  ' + sLineBreak +
  '  private  ' + sLineBreak +
  '    FAudit: Boolean; ' + sLineBreak +
  '    FMsgErro, FVersao: string;  ' + sLineBreak +
  '    FPathDLL, FPathBanco, FHost: String;  ' + sLineBreak +
  '    FProtocolo, FBanco, FUsername, FSenha, FOdbc: String;  ' + sLineBreak +
  '    FPorta: Integer;  ' + sLineBreak +
  '    FCriarTabelas: Boolean;  ' + sLineBreak +
  '    procedure LerConfig; ' + sLineBreak +
  '    procedure GetVersao; ' + sLineBreak ;

  if AAuditar then
  s := s +
  '    procedure CreateAuditTable(AProtocol: string); ' + sLineBreak;

  s := s +
  '  public  ' + sLineBreak +
  '    property GetMsgErro: string read FMsgErro;  ' + sLineBreak +
  '    property GetVersaoServidor: string read FVersao; ' + sLineBreak +
  '    property Audit: Boolean read FAudit; ' + sLineBreak +
  '    property Protocol: string read FProtocolo; ' + sLineBreak +
  '    procedure Conectar;  ' + sLineBreak +
  '    procedure Desconectar;  ' + sLineBreak +
  '    procedure Reconectar;  ' + sLineBreak +
  '    procedure ChecaConexao;  ' + sLineBreak +
  '    procedure TransactionPrepare; ' + sLineBreak +
  '    procedure TransactionCommit; ' + sLineBreak +
  '    procedure TransactionCommitRetaining; ' + sLineBreak +
  '    procedure TransactionRollback;  ' + sLineBreak +
  '    function IsConnected: Boolean;  ' + sLineBreak +
  '    function NewQuery(): TSQLQuery; ' + sLineBreak +
  '    function LastInsertedID(APrimaryKey, ATable: string): Integer; ' + sLineBreak +
  '  end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'var  ' + sLineBreak +
  '  DMServer: TDMServer;  ' + sLineBreak +
  '  ' + sLineBreak +
  'implementation  ' + sLineBreak +
  '  ' + sLineBreak +
  'uses ' + sLineBreak +
  '  Util.Criptografia';

  if AAuditar then
    s := s + ', Service.ApiAudit';

  s := s +
  ';' + sLineBreak +
  '  ' + sLineBreak +
  '{$R *.lfm}  ' + sLineBreak +
  '  ' + sLineBreak +
  '{ TDMServer }  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.DataModuleCreate(Sender: TObject);  ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Connection.Transaction := Transaction; ' + sLineBreak +
  '  Transaction.DataBase   := Connection; ' + sLineBreak +
  '  Conectar;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.DataModuleDestroy(Sender: TObject);  ' + sLineBreak +
  '// desconecta do banco de daddos ao destruir este módulo  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  Desconectar;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.Conectar;  ' + sLineBreak +
  '//estabelece a conexão  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  FAudit     := False; ' + sLineBreak +
  '  LerConfig; ' + sLineBreak +
  '  FPathBanco := ExtractFileDir( ParamStr(0) ) + PathDelim;  ' + sLineBreak +
  '  FPathDLL   := FPathBanco; //windows  ' + sLineBreak +
  '  FMsgErro   := ''''; ' + sLineBreak +
  '  FVersao    := ''''; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    Desconectar; ' + sLineBreak +
  ' ' + sLineBreak +
  '    with Connection do begin  ' + sLineBreak +
  '      HostName     := FHost + '':'' + IntToStr(FPorta); ' + sLineBreak +
  '      DatabaseName := FBanco; ' + sLineBreak +
  '      UserName     := FUsername; ' + sLineBreak +
  '      Password     := FSenha; ' + sLineBreak +
  '  ' + sLineBreak +
  '      {$IFDEF WINDOWS} ' + sLineBreak +
  '      //No windows: dblib.dll, libiconv.dll e msvcr100.dll' + sLineBreak +
  '      //driver: libsybdb-5.dll ou ntwdblib.dll ou dblib.dll ou libsybdb.so (linux) ou libsybdb.dylib (macos) ' + sLineBreak +
  '      //Database := ''Provider=SQLOLEDB.1;Persist Security Info=True;Data Source='' + p.HostServidor +'',''+ p.Porta + ''; Initial Catalog='' + p.BancoDados+ ''; User ID='' +  p.Username + '';password='' + p.Senha; ' + sLineBreak +
  '      //Protocol := ''ado''; ' + sLineBreak +
  '      {$ENDIF} ' + sLineBreak +
  '  ' + sLineBreak +
  '      Connected := True; ' + sLineBreak +
  '      GetVersao; ' + sLineBreak;

  if AAuditar then
  s := s +
  '      CreateAuditTable(FProtocolo.ToLower);' + sLineBreak;

  s := s +
  '    end; ' + sLineBreak +
  '  except  ' + sLineBreak +
  '    on E: Exception do  ' + sLineBreak +
  '      FMsgErro := E.Message; ' + sLineBreak +
  '  end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.Desconectar;  ' + sLineBreak +
  '// desconecta do banco de dados  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  try  ' + sLineBreak +
  '    if Connection.Connected then  ' + sLineBreak +
  '      Connection.Connected := False; ' + sLineBreak +
  '  except  ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'function TDMServer.IsConnected: Boolean;  ' + sLineBreak +
  '//Está conectado  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  Result := Connection.Connected;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.ChecaConexao;  ' + sLineBreak +
  '// se a conexão não estiver aberta, então tenta conectar no servidor/banco  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '   FMsgErro := '''';  ' + sLineBreak +
  '  ' + sLineBreak +
  '   try  ' + sLineBreak +
  '     if not Connection.Connected then  ' + sLineBreak +
  '       Reconectar;  ' + sLineBreak +
  '   except  ' + sLineBreak +
  '    on e: Exception do  ' + sLineBreak +
  '      FMsgErro := e.Message;  ' + sLineBreak +
  '   end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.Reconectar;  ' + sLineBreak +
  '//reconectar  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  try  ' + sLineBreak +
  '    Desconectar; ' + sLineBreak +
  '    Conectar;  ' + sLineBreak +
  '  except  ' + sLineBreak +
  '  end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionPrepare; ' + sLineBreak +
  'begin ' + sLineBreak +
  '  // ' + sLineBreak +
  'end;' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionCommit;  ' + sLineBreak +
  '//comita o transaction  ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if not Connection.Transaction.Active then ' + sLineBreak +
  '      Connection.Transaction.Active := True; ' + sLineBreak +
  '    Connection.Transaction.Commit; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.TransactionCommitRetaining; ' + sLineBreak +
  '//comita o transaction ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if not Connection.Transaction.Active then ' + sLineBreak +
  '      Connection.Transaction.Active := True; ' + sLineBreak +
  '    Connection.Transaction.CommitRetaining; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.TransactionRollback;  ' + sLineBreak +
  '//rolback do transaction  ' + sLineBreak +
  'begin ' + sLineBreak +
  '  try ' + sLineBreak +
  '    if Connection.Transaction.Active then ' + sLineBreak +
  '      Connection.Transaction.Rollback; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'function TDMServer.NewQuery: TSQLQuery; ' + sLineBreak +
  '// retorna a instância de uma nova query  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  ChecaConexao;  ' + sLineBreak +
  '  ' + sLineBreak +
  '  Result := TSQLQuery.Create(nil); ' + sLineBreak +
  '  ' + sLineBreak +
  '  if FMsgErro.IsEmpty then begin  ' + sLineBreak +
  '    try  ' + sLineBreak +
  '      Result.DataBase := Connection; ' + sLineBreak +
  '      Result.Transaction := Transaction; ' + sLineBreak +
  '      Result.Close;  ' + sLineBreak +
  '      Result.SQL.Clear;  ' + sLineBreak +
  '    except  ' + sLineBreak +
  '      on e: Exception do  ' + sLineBreak +
  '        FMsgErro := e.Message;  ' + sLineBreak +
  '    end;  ' + sLineBreak +
  '  end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'procedure TDMServer.LerConfig;  ' + sLineBreak +
  '//ler configurações do servidor  ' + sLineBreak +
  'var  ' + sLineBreak +
  '  ArqINI: TIniFile;  ' + sLineBreak +
  '  FArquivoINI: String;  ' + sLineBreak +
  '  cr: TCriptografa;  ' + sLineBreak +
  'begin  ' + sLineBreak +
  '  FArquivoINI := ExtractFileDir( ParamStr(0) ) + PathDelim + '''+ AINIFileName + ''';  ' + sLineBreak +
  '  ArqINI := TIniFile.Create(FArquivoINI);  ' + sLineBreak +
  '  ' + sLineBreak +
  '  FHost      := '''';  ' + sLineBreak +
  '  FPorta     := 0;  ' + sLineBreak +
  '  FProtocolo := '''';  ' + sLineBreak +
  '  FBanco     := '''';  ' + sLineBreak +
  '  FUsername  := '''';  ' + sLineBreak +
  '  FSenha     := '''';  ' + sLineBreak +
  '  FOdbc      := '''';  ' + sLineBreak +
  '  ' + sLineBreak +
  '  try  ' + sLineBreak +
  '    FHost      := ArqINI.ReadString(''dbinfo'',''server'', '''');  ' + sLineBreak +
  '    FPorta     := ArqINI.ReadInteger(''dbinfo'',''port'', 0);  ' + sLineBreak +
  '    FProtocolo := ArqINI.ReadString(''dbinfo'',''protocol'', '''');  ' + sLineBreak +
  '    FBanco     := ArqINI.ReadString(''dbinfo'',''db'', '''');  ' + sLineBreak +
  '    FUsername  := ArqINI.ReadString(''dbinfo'',''user'', '''');  ' + sLineBreak +
  '    FSenha     := ArqINI.ReadString(''dbinfo'',''password'', '''');  ' + sLineBreak +
  '    FOdbc      := ArqINI.ReadString(''dbinfo'',''odbc'', '''');  ' + sLineBreak +
  '  ' + sLineBreak +
  '    if (ArqINI.ReadString(''dbinfo'',''encrypt'', ''false'') = ''true'') then begin  ' + sLineBreak +
  '      cr := TCriptografa.Create();  ' + sLineBreak +
  '      FUsername := cr.Decrypt(FUsername);  ' + sLineBreak +
  '      FSenha := cr.Decrypt(FSenha);  ' + sLineBreak +
  '      cr.Free;  ' + sLineBreak +
  '    end;  ' + sLineBreak +
  '  ' + sLineBreak +
  '  finally  ' + sLineBreak +
  '    ArqINI.Free;  ' + sLineBreak +
  '  end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  ' ' + sLineBreak +
  'procedure TDMServer.GetVersao; ' + sLineBreak +
  '//obtém a versão do servidor sql ' + sLineBreak +
  'var' + sLineBreak +
  '  i: Integer; ' + sLineBreak +
  'begin ' + sLineBreak +
  '  FVersao := ''''; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    with NewQuery() do begin ' + sLineBreak +
  '      SQL.Add(''select @@version as versao;''); ' + sLineBreak +
  '      Open; ' + sLineBreak +
  ' ' + sLineBreak +
  '      if RecordCount > 0 then begin' + sLineBreak +
  '        FVersao := FieldByName(''versao'').AsString; ' + sLineBreak +
  '         i := Pos(''('', FVersao);' + sLineBreak +
  '         if i>0 then' + sLineBreak +
  '           FVersao := Trim(LeftStr(FVersao, i-1));' + sLineBreak +
  '      end; ' + sLineBreak +
  ' ' + sLineBreak +
  '      Close; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TDMServer.LastInsertedID(APrimaryKey, ATable: string): Integer; ' + sLineBreak +
  '// retorna o último ID inserido, independente da tabela ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Result := 0; ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    with NewQuery() do begin ' + sLineBreak +
  '      SQL.Add(Format(''select max(%s) as id from %s '', [APrimaryKey, ATable])); ' + sLineBreak +
  '      Open; ' + sLineBreak +
  ' ' + sLineBreak +
  '      if RecordCount > 0 then ' + sLineBreak +
  '         Result := FieldByName(''id'').AsInteger; ' + sLineBreak +
  ' ' + sLineBreak +
  '      Close; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  except ' + sLineBreak +
  '  end; ' + sLineBreak +
  'end; ' + sLineBreak;

  if AAuditar then begin
    s := s +
    ' ' + sLineBreak +
    TUtilCommon.GetTabelaAuditagem;
  end;

  s := s +
  '  ' + sLineBreak +
  'end.  ' + sLineBreak +
  ' ' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaDataModule + 'dm.server.pas', s);
  s := '';

  // FORM .LFM

  s :=
  'object DMServer: TDMServer ' + sLineBreak +
  '  OnCreate = DataModuleCreate ' + sLineBreak +
  '  OnDestroy = DataModuleDestroy ' + sLineBreak +
  '  OldCreateOrder = False ' + sLineBreak +
  '  Height = 193 ' + sLineBreak +
  '  HorizontalOffset = 403 ' + sLineBreak +
  '  VerticalOffset = 250 ' + sLineBreak +
  '  Width = 268 ' + sLineBreak +
  '  object Connection: TMSSQLConnection ' + sLineBreak +
  '    Connected = False ' + sLineBreak +
  '    LoginPrompt = False ' + sLineBreak +
  '    KeepConnection = False ' + sLineBreak +
  '    Transaction = Transaction ' + sLineBreak +
  '    Left = 80 ' + sLineBreak +
  '    Top = 79 ' + sLineBreak +
  '  end ' + sLineBreak +
  '  object Transaction: TSQLTransaction ' + sLineBreak +
  '    Active = False ' + sLineBreak +
  '    Database = Connection ' + sLineBreak +
  '    Left = 168 ' + sLineBreak +
  '    Top = 80 ' + sLineBreak +
  '  end ' + sLineBreak +
  'end ' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaDataModule + 'dm.server.lfm', s);

  s := '';
end;

class procedure TUtilCommon.GerarUtilCriptografia(APastaUtil: string);
//cria o utilitário de criptografia
var
  s: string;
begin
  s :=
  'unit Util.Criptografia; ' + sLineBreak +
  ' ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '{$mode ObjFPC}{$H+} ' + sLineBreak +
  ' ' + sLineBreak +
  'interface ' + sLineBreak +
  ' ' + sLineBreak +
  'uses ' + sLineBreak +
  '  Classes, SysUtils, base64, md5, BlowFish; ' + sLineBreak +
  ' ' + sLineBreak +
  '// Pode ser necessário instalar a biblioteca DCPcrypt (tem no online package) ' + sLineBreak +
  ' ' + sLineBreak +
  'type ' + sLineBreak +
  ' ' + sLineBreak +
  '  { TCriptografa } ' + sLineBreak +
  ' ' + sLineBreak +
  '  TCriptografa = class ' + sLineBreak +
  '    private ' + sLineBreak +
  '      FKey: string; ' + sLineBreak +
  '    public ' + sLineBreak +
  '      constructor Create(ASecretKey: string = ''key@secret9''); ' + sLineBreak +
  '      function Encrypt(AValueToEncrypt: string): string; ' + sLineBreak +
  '      function Decrypt(AValueToDecrypt: String): string; ' + sLineBreak +
  '      function Encrypt64(AValueToEncrypt: string): string; ' + sLineBreak +
  '      function Decrypt64(AValueToDecrypt: String): string; ' + sLineBreak +
  '      function Encrypt_MD5(const AValue: string): string;' + sLineBreak +
  '      class function new: TCriptografa;  ' + sLineBreak +
  '  end; ' + sLineBreak +
  ' ' + sLineBreak +
  'implementation ' + sLineBreak +
  ' ' + sLineBreak +
  '{ TCriptografa } ' + sLineBreak +
  ' ' + sLineBreak +
  'constructor TCriptografa.Create(ASecretKey: string); ' + sLineBreak +
  'begin ' + sLineBreak +
  '  if Trim(ASecretKey) <> '''' then ' + sLineBreak +
  '    FKey := ASecretKey; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'class function TCriptografa.new: TCriptografa;' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := TCriptografa.Create();' + sLineBreak +
  'end;  ' + sLineBreak +
  ' ' + sLineBreak +
  'function TCriptografa.Encrypt(AValueToEncrypt: string): string; ' + sLineBreak +
  '//criptografa a string em AValue ' + sLineBreak +
  'var ' + sLineBreak +
  '  en: TBlowFishEncryptStream; ' + sLineBreak +
  '  s1: TStringStream; ' + sLineBreak +
  'begin ' + sLineBreak +
  '  s1 := TStringStream.Create(''''); ' + sLineBreak +
  '  en := TBlowFishEncryptStream.Create(FKey, s1); ' + sLineBreak +
  '  en.WriteAnsiString( AValueToEncrypt ); ' + sLineBreak +
  '  en.Free; ' + sLineBreak +
  '  Result := s1.DataString; ' + sLineBreak +
  '  s1.Free; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TCriptografa.Decrypt(AValueToDecrypt: String): string; ' + sLineBreak +
  '//descriptografa a string em AValue ' + sLineBreak +
  'var ' + sLineBreak +
  '  de: TBlowFishDeCryptStream; ' + sLineBreak +
  '  s1: TStringStream; ' + sLineBreak +
  'begin ' + sLineBreak +
  '  s1 := TStringStream.Create( AValueToDecrypt ); ' + sLineBreak +
  '  de := TBlowFishDeCryptStream.Create(FKey, s1); ' + sLineBreak +
  ' ' + sLineBreak +
  '  try ' + sLineBreak +
  '    Result := de.ReadAnsiString; ' + sLineBreak +
  '  except ' + sLineBreak +
  '    Result := AValueToDecrypt; ' + sLineBreak +
  '  end; ' + sLineBreak +
  ' ' + sLineBreak +
  '  de.Free; ' + sLineBreak +
  '  s1.Free; ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TCriptografa.Encrypt64(AValueToEncrypt: string): string; ' + sLineBreak +
  '//criptografa uma string em base64 ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Result := EncodeStringBase64( AValueToEncrypt ); ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TCriptografa.Decrypt64(AValueToDecrypt: String): string; ' + sLineBreak +
  '//descriptografa uma string criptografada em base64 ' + sLineBreak +
  'begin ' + sLineBreak +
  '  Result := DecodeStringBase64( AValueToDecrypt ); ' + sLineBreak +
  'end; ' + sLineBreak +
  ' ' + sLineBreak +
  'function TCriptografa.Encrypt_MD5(const AValue: string): string;' + sLineBreak +
  '// criptografa a senha usando MD5' + sLineBreak +
  'begin' + sLineBreak +
  '  Result := MD5Print(MD5String(AValue));' + sLineBreak +
  'end;' + sLineBreak +
  ' ' + sLineBreak +
  'end. ' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaUtil + 'util.criptografia.pas', s);
  s := '';
end;

class procedure TUtilCommon.GerarUtilImagem(APastaUtil: string);
//cria o utilitário de manipulação de imagem para banco de dados
var
  s: string;
begin
  s :=
  'unit Util.Imagem; ' + sLineBreak +
  ' ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  ' ' + sLineBreak +
  '// Manipulação de imagens (foto) para banco de dados' + sLineBreak +
  '// Requer o Package BGRABitmapPack' + sLineBreak +
  ' ' + sLineBreak +
  '{$mode ObjFPC}{$H+} ' + sLineBreak +
  ' ' + sLineBreak +
  'interface ' + sLineBreak +
  ' ' + sLineBreak +
  'uses ' + sLineBreak +
  '  Classes, SysUtils, Controls, Graphics, ExtCtrls, ZDataset, SQLDB, DB, Math,  ' + sLineBreak +
  '  LCLType, // HBitmap type   ' + sLineBreak +
  '  IntfGraphics, // TLazIntfImage type   ' + sLineBreak +
  '  fpImage, // TFPColor type    ' + sLineBreak +
  '  FPReadJpeg, FPWriteJpeg, // jpg support   ' + sLineBreak +
  '  FPImgCanv, FPWritePNG,' + sLineBreak +
  '  BGRABitmap, BGRABitmapTypes, BGRAGraphics; { Requer o pacote BGRABitmapPack }' + sLineBreak +
  ' ' + sLineBreak +
  '  //https://wiki.freepascal.org/BGRABitmap_tutorial' + sLineBreak +
  ' ' + sLineBreak +
  'type ' + sLineBreak +
  ' ' + sLineBreak +
  '  { TUtilImagem } ' + sLineBreak +
  ' ' + sLineBreak +
  '  TUtilImagem = class' + sLineBreak +
  '  public' + sLineBreak +
  '    { TZQuery: Converte a imagem (BLOB) do banco de dados para bitmap para o TImage }' + sLineBreak +
  '    class procedure GetImage(var AImage: TImage; AQuery: TZQuery; const AFieldName: string);' + sLineBreak +
  '    { TZQuery: Converte o bitmap do TImage para Stream para salvar no banco de dados }' + sLineBreak +
  '    class procedure GetStream(AImage: TImage; var AQuery: TZQuery; const AFieldName: string; ACircularImage: Boolean = False);' + sLineBreak +
  '    { TSQLQuery: Converte a imagem (BLOB) do banco de dados para bitmap para o TImage }' + sLineBreak +
  '    class procedure GetImageSQLQuery(var AImage: TImage; AQuery: TSQLQuery; const AFieldName: string);' + sLineBreak +
  '    { TSQLQuery: Converte o bitmap do TImage para Stream para salvar no banco de dados }' + sLineBreak +
  '    class procedure GetStreamSQLQuery(AImage: TImage; var AQuery: TSQLQuery; const AFieldName: string; ACircularImage: Boolean = False);' + sLineBreak +
  '    { Altera o tamanho do TImage }' + sLineBreak +
  '    class procedure ResizeImagem(var AImage: TImage; w, h: Integer);' + sLineBreak +
  '    { Retorna um bitmap com as dimenões indicadas, a partir do TImage }' + sLineBreak +
  '    class function ResizeBitmap(var AImage: TImage; w, h: Integer): TBitmap;' + sLineBreak +
  '    { Altera o tamanho do TImage }' + sLineBreak +
  '    class procedure ResizeToImageBox(var AImage: TImage);' + sLineBreak +
  '    { Cria uma avatar a partir do Timage }' + sLineBreak +
  '    class procedure CreateAvatarFromImage(var AImage: TImage; ADestSize: Integer );' + sLineBreak +
  '    { Cria um avatar a partir de uma arquivo para o TImage }' + sLineBreak +
  '    class procedure CreateAvatarFromFile(var AImage: TImage; ASourcePath: string; ADestSize: integer);' + sLineBreak +
  '    { Adiciona borda circular à imagem }' + sLineBreak +
  '    class procedure AvatarBorder(var AImage: TImage; ABorderColor: TColor; ABorderWidth: Integer = 4);' + sLineBreak +
  '  end;' + sLineBreak +
  '    ' + sLineBreak +
  'implementation    ' + sLineBreak +
  '    ' + sLineBreak +
  '{ TUtilImagem }    ' + sLineBreak +
  '' + sLineBreak +
  'class procedure TUtilImagem.GetImage(var AImage: TImage; AQuery: TZQuery; const AFieldName: string);' + sLineBreak +
  '//pega a imagem do zquery e joga no TImage' + sLineBreak +
  'var' + sLineBreak +
  '  Stream: TMemoryStream;' + sLineBreak +
  '  Png: TPortableNetworkGraphic;' + sLineBreak +
  'begin' + sLineBreak +
  '  AImage := TImage.Create(nil);' + sLineBreak +
  '  AImage.Picture := nil;' + sLineBreak +
  '' + sLineBreak +
  '  if not AQuery.FieldByName(AFieldName).IsNull then begin' + sLineBreak +
  '    //carrega a foto' + sLineBreak +
  '    Stream := TMemoryStream.Create;' + sLineBreak +
  '    Png := TPortableNetworkGraphic.Create;' + sLineBreak +
  '' + sLineBreak +
  '    try' + sLineBreak +
  '      TBlobField(AQuery.FieldByName(AFieldName)).SaveToStream(Stream);' + sLineBreak +
  '      Stream.Position := 0;' + sLineBreak +
  '' + sLineBreak +
  '      if Stream.Size > 0 then begin' + sLineBreak +
  '        try' + sLineBreak +
  '          Png.LoadFromStream(Stream);' + sLineBreak +
  '          AImage.Picture.Assign(Png);' + sLineBreak +
  '        except //FPImageException - Wrong image format (não é png)' + sLineBreak +
  '          begin' + sLineBreak +
  '            TBlobField(AQuery.FieldByName(AFieldName)).SaveToStream(Stream);' + sLineBreak +
  '            Stream.Position := 0;' + sLineBreak +
  '            if Stream.Size > 0 then' + sLineBreak +
  '              AImage.Picture.Bitmap.LoadFromStream(Stream);' + sLineBreak +
  '          end;' + sLineBreak +
  '        end;' + sLineBreak +
  '' + sLineBreak +
  '        AImage.Transparent := True;' + sLineBreak +
  '      end;' + sLineBreak +
  '    finally' + sLineBreak +
  '      Png.Free;' + sLineBreak +
  '      Stream.Free;' + sLineBreak +
  '    end;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class procedure TUtilImagem.GetStream(AImage: TImage; var AQuery: TZQuery; const AFieldName: string; ACircularImage: Boolean);' + sLineBreak +
  '// converte a imagem do TImage para Stream e carrega no zquery para salvar no banco de dados' + sLineBreak +
  'var' + sLineBreak +
  '  Stream: TMemoryStream;' + sLineBreak +
  '  Source, Resized, Mask: TBGRABitmap;' + sLineBreak +
  '  MinSide, DestSize: integer;' + sLineBreak +
  '  CropRect: TRect;' + sLineBreak +
  'begin' + sLineBreak +
  '  //joga a foto no stream' + sLineBreak +
  '  DestSize := AImage.Picture.Bitmap.Width;' + sLineBreak +
  '  if DestSize = 0 then begin' + sLineBreak +
  '    AQuery.ParamByName(AFieldName).IsNull;' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  ' ' + sLineBreak +
  '  Stream := TMemoryStream.Create;' + sLineBreak +
  '  Source := TBGRABitmap.Create;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    Source.Assign(AImage.Picture.Graphic);' + sLineBreak +
  '' + sLineBreak +
  '    //Crop Quadrado' + sLineBreak +
  '    MinSide := Source.Width;' + sLineBreak +
  '    if Source.Height < MinSide then MinSide := Source.Height;' + sLineBreak +
  '    CropRect := Rect((Source.Width - MinSide) div 2, (Source.Height - MinSide) div 2,' + sLineBreak +
  '                     ((Source.Width - MinSide) div 2) + MinSide, ((Source.Height - MinSide) div 2) + MinSide);' + sLineBreak +
  '' + sLineBreak +
  '    //Redimensionar' + sLineBreak +
  '    Resized := Source.GetPart(CropRect) as TBGRABitmap;' + sLineBreak +
  '    BGRAReplace(Resized, Resized.Resample(DestSize, DestSize));' + sLineBreak +
  '' + sLineBreak +
  '    //Máscara Circular' + sLineBreak +
  '    if ACircularImage then begin' + sLineBreak +
  '      Mask := TBGRABitmap.Create(DestSize, DestSize, BGRAPixelTransparent);' + sLineBreak +
  '      Mask.FillEllipseAntialias(DestSize/2, DestSize/2, DestSize/2, DestSize/2, BGRAWhite);' + sLineBreak +
  '      Resized.ApplyMask(Mask);' + sLineBreak +
  '      Mask.Free;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    //SALVAR DIRETO NO STREAM EM PNG' + sLineBreak +
  '    Resized.SaveToStreamAsPNG(Stream);' + sLineBreak +
  '    Stream.Position := 0;' + sLineBreak +
  '    AQuery.ParamByName(AFieldName).LoadBinaryFromStream(Stream);' + sLineBreak +
  '' + sLineBreak +
  '    Resized.Free;' + sLineBreak +
  '  finally' + sLineBreak +
  '    Source.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '  ' + sLineBreak +
  'class procedure TUtilImagem.GetImageSQLQuery(var AImage: TImage; AQuery: TSQLQuery; const AFieldName: string);  ' + sLineBreak +
  '//pega a imagem do sqlquery e jogo no TImage  ' + sLineBreak +
  'var  ' + sLineBreak +
  '  Stream: TMemoryStream;' + sLineBreak +
  '  Png: TPortableNetworkGraphic;' + sLineBreak +
  'begin  ' + sLineBreak +
  '  AImage := TImage.Create(nil);  ' + sLineBreak +
  '  AImage.Picture := nil; ' + sLineBreak +
  ' ' + sLineBreak +
  '  if not AQuery.FieldByName(AFieldName).IsNull then begin  ' + sLineBreak +
  '    //carrega a foto  ' + sLineBreak +
  '    Stream := TMemoryStream.Create;' + sLineBreak +
  '    Png := TPortableNetworkGraphic.Create;' + sLineBreak +
  '' + sLineBreak +
  '    try  ' + sLineBreak +
  '      TBlobField(AQuery.FieldByName(AFieldName)).SaveToStream(Stream);' + sLineBreak +
  '      Stream.Position := 0;' + sLineBreak +
  '' + sLineBreak +
  '      if Stream.Size > 0 then begin' + sLineBreak +
  '        try' + sLineBreak +
  '          Png.LoadFromStream(Stream);' + sLineBreak +
  '          AImage.Picture.Assign(Png);' + sLineBreak +
  '        except //FPImageException - Wrong image format (não é png)' + sLineBreak +
  '          begin' + sLineBreak +
  '            TBlobField(AQuery.FieldByName(AFieldName)).SaveToStream(Stream);' + sLineBreak +
  '            Stream.Position := 0;' + sLineBreak +
  '            if Stream.Size > 0 then' + sLineBreak +
  '              AImage.Picture.Bitmap.LoadFromStream(Stream);' + sLineBreak +
  '          end;' + sLineBreak +
  '        end;' + sLineBreak +
  '' + sLineBreak +
  '        AImage.Transparent := True;' + sLineBreak +
  '      end;' + sLineBreak +
  '    finally' + sLineBreak +
  '      Png.Free;' + sLineBreak +
  '      Stream.Free;  ' + sLineBreak +
  '    end;  ' + sLineBreak +
  '  end;  ' + sLineBreak +
  'end;  ' + sLineBreak +
  '  ' + sLineBreak +
  'class procedure TUtilImagem.GetStreamSQLQuery(AImage: TImage; var AQuery: TSQLQuery; const AFieldName: string; ACircularImage: Boolean);' + sLineBreak +
  '// converte a imagem do TImage para Stream e carrega no sqlquery  ' + sLineBreak +
  'var  ' + sLineBreak +
  '  Stream: TMemoryStream;' + sLineBreak +
  '  Source, Resized, Mask: TBGRABitmap;' + sLineBreak +
  '  MinSide, DestSize: integer;' + sLineBreak +
  '  CropRect: TRect;' + sLineBreak +
  'begin  ' + sLineBreak +
  '  //joga a foto no stream  ' + sLineBreak +
  '  DestSize := AImage.Picture.Bitmap.Width;' + sLineBreak +
  '  if DestSize = 0 then begin' + sLineBreak +
  '    AQuery.ParamByName(AFieldName).IsNull;' + sLineBreak +
  '    Exit;' + sLineBreak +
  '  end;' + sLineBreak +
  ' ' + sLineBreak +
  '  Stream := TMemoryStream.Create;' + sLineBreak +
  '  Source := TBGRABitmap.Create;' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    Source.Assign(AImage.Picture.Graphic);' + sLineBreak +
  '' + sLineBreak +
  '    //Crop Quadrado' + sLineBreak +
  '    MinSide := Source.Width;' + sLineBreak +
  '    if Source.Height < MinSide then MinSide := Source.Height;' + sLineBreak +
  '    CropRect := Rect((Source.Width - MinSide) div 2, (Source.Height - MinSide) div 2,' + sLineBreak +
  '                     ((Source.Width - MinSide) div 2) + MinSide, ((Source.Height - MinSide) div 2) + MinSide);' + sLineBreak +
  '' + sLineBreak +
  '    //Redimensionar' + sLineBreak +
  '    Resized := Source.GetPart(CropRect) as TBGRABitmap;' + sLineBreak +
  '    BGRAReplace(Resized, Resized.Resample(DestSize, DestSize));' + sLineBreak +
  '' + sLineBreak +
  '    //Máscara Circular' + sLineBreak +
  '    if ACircularImage then begin' + sLineBreak +
  '      Mask := TBGRABitmap.Create(DestSize, DestSize, BGRAPixelTransparent);' + sLineBreak +
  '      Mask.FillEllipseAntialias(DestSize/2, DestSize/2, DestSize/2, DestSize/2, BGRAWhite);' + sLineBreak +
  '      Resized.ApplyMask(Mask);' + sLineBreak +
  '      Mask.Free;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    //SALVAR DIRETO NO STREAM EM PNG' + sLineBreak +
  '    Resized.SaveToStreamAsPNG(Stream);' + sLineBreak +
  '    Stream.Position := 0;' + sLineBreak +
  '    AQuery.ParamByName(AFieldName).LoadFromStream(Stream, ftBlob);' + sLineBreak +
  '' + sLineBreak +
  '    Resized.Free;' + sLineBreak +
  '  finally' + sLineBreak +
  '    Source.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class procedure TUtilImagem.ResizeImagem(var AImage: TImage; w, h: Integer);    ' + sLineBreak +
  '//redimensiona a imagem    ' + sLineBreak +
  'var    ' + sLineBreak +
  '  newBitmap: TBitmap;    ' + sLineBreak +
  'begin    ' + sLineBreak +
  '  if AImage.Picture.Bitmap.Width > 0 then begin    ' + sLineBreak +
  '    newBitmap := TBitmap.Create; ' + sLineBreak +
  '    try ' + sLineBreak +
  '      newBitmap.Canvas.Brush.Color := clWhite; ' + sLineBreak +
  '      newBitmap.PixelFormat := pf24bit; ' + sLineBreak +
  '      newBitmap.SetSize(w, h); ' + sLineBreak +
  ' ' + sLineBreak +
  '      // Desenha a imagem original redimensionada dentro do novo bitmap ' + sLineBreak +
  '      newBitmap.Canvas.StretchDraw( Rect(0, 0, w, h), AImage.Picture.Graphic ); ' + sLineBreak +
  '      AImage.Picture := nil; ' + sLineBreak +
  '      AImage.Picture.Bitmap.Assign(newBitmap); ' + sLineBreak +
  '    finally ' + sLineBreak +
  '      newBitmap.Free; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  end;    ' + sLineBreak +
  'end;    ' + sLineBreak +
  '    ' + sLineBreak +
  'class procedure TUtilImagem.ResizeToImageBox(var AImage: TImage);    ' + sLineBreak +
  '//ajusta a imagem para o tamanho do TImage    ' + sLineBreak +
  'var    ' + sLineBreak +
  '  newBitmap: TBitmap;    ' + sLineBreak +
  'begin    ' + sLineBreak +
  '  if AImage.Picture.Bitmap.Width > 0 then ' + sLineBreak +
  '  begin ' + sLineBreak +
  '    newBitmap := TBitmap.Create; ' + sLineBreak +
  '    try ' + sLineBreak +
  '      newBitmap.Canvas.Brush.Color := clWhite; ' + sLineBreak +
  '      newBitmap.PixelFormat := pf24bit; ' + sLineBreak +
  '      newBitmap.SetSize(AImage.ClientWidth, AImage.ClientHeight); ' + sLineBreak +
  '      newBitmap.Canvas.StretchDraw( AImage.ClientRect, AImage.Picture.Graphic ); ' + sLineBreak +
  '      AImage.Picture := nil; ' + sLineBreak +
  '      AImage.Picture.Bitmap.Assign(newBitmap); ' + sLineBreak +
  '    finally ' + sLineBreak +
  '      newBitmap.Free; ' + sLineBreak +
  '    end; ' + sLineBreak +
  '  end;    ' + sLineBreak +
  'end;   ' + sLineBreak +
  '   ' + sLineBreak +
  'class function TUtilImagem.ResizeBitmap(var AImage: TImage; w, h: Integer): TBitmap;   ' + sLineBreak +
  '//cria uma imagem com as dimensões indicadas   ' + sLineBreak +
  'begin   ' + sLineBreak +
  '  Result := TBitmap.Create;   ' + sLineBreak +
  '  if AImage.Picture.Bitmap.Width > 0 then begin   ' + sLineBreak +
  '    Result.Canvas.Brush.Color := clWhite;   ' + sLineBreak +
  '    Result.PixelFormat := pf24bit;   ' + sLineBreak +
  '    Result.SetSize(w, h);   ' + sLineBreak +
  '    Result.Canvas.StretchDraw( AImage.ClientRect, AImage.Picture.Graphic );   ' + sLineBreak +
  '  end;   ' + sLineBreak +
  'end;   ' + sLineBreak +
  '' + sLineBreak +
  'class procedure TUtilImagem.CreateAvatarFromImage(var AImage: TImage; ADestSize: Integer);' + sLineBreak +
  '//cria um avatar da imagem, no tamanho informado' + sLineBreak +
  '//Requer o pacote BGRABitmapPack' + sLineBreak +
  'var' + sLineBreak +
  '  Source, Resized, Mask: TBGRABitmap;' + sLineBreak +
  '  MinSide: integer;' + sLineBreak +
  '  CropRect: TRect;' + sLineBreak +
  '  lArqruivo: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  if (AImage.Picture.Graphic = nil) or (AImage.Picture.Graphic.Empty) then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  Source := TBGRABitmap.Create;' + sLineBreak +
  '  lArqruivo := ExtractFileDir(ParamStr(0)) + PathDelim + ''avatar0.png'';' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    // Captura a imagem atual do TImage' + sLineBreak +
  '    Source.Assign(AImage.Picture.Graphic);' + sLineBreak +
  '' + sLineBreak +
  '    //Calcular o corte quadrado centralizado (para não achatar a imagem)' + sLineBreak +
  '    MinSide := Source.Width;' + sLineBreak +
  '    if Source.Height < MinSide then MinSide := Source.Height;' + sLineBreak +
  '' + sLineBreak +
  '    CropRect := Rect((Source.Width - MinSide) div 2,' + sLineBreak +
  '                     (Source.Height - MinSide) div 2,' + sLineBreak +
  '                     ((Source.Width - MinSide) div 2) + MinSide,' + sLineBreak +
  '                     ((Source.Height - MinSide) div 2) + MinSide);' + sLineBreak +
  '' + sLineBreak +
  '    //Extrai o quadrado e redimensiona para o tamanho final desejado' + sLineBreak +
  '    Resized := Source.GetPart(CropRect) as TBGRABitmap;' + sLineBreak +
  '    Resized.ResampleFilter := rfBestQuality; // Garante alta velocidade/qualidade' + sLineBreak +
  '    BGRAReplace(Resized, Resized.Resample(ADestSize, ADestSize));' + sLineBreak +
  '' + sLineBreak +
  '    //Cria a máscara circular com Antialiasing' + sLineBreak +
  '    Mask := TBGRABitmap.Create(ADestSize, ADestSize, BGRAPixelTransparent);' + sLineBreak +
  '' + sLineBreak +
  '    // Desenha um elipse preenchido (círculo) na cor opaca' + sLineBreak +
  '    Mask.FillEllipseAntialias(ADestSize/2, ADestSize/2, ADestSize/2, ADestSize/2, BGRAWhite);' + sLineBreak +
  '' + sLineBreak +
  '    //Aplica a máscara (Multiplica o canal Alpha)' + sLineBreak +
  '    Resized.ApplyMask(Mask);' + sLineBreak +
  '' + sLineBreak +
  '    Resized.SaveToFile(lArqruivo);' + sLineBreak +
  '    AImage.Picture := nil;' + sLineBreak +
  '    AImage.Picture.LoadFromFile(lArqruivo);' + sLineBreak +
  '    AImage.Transparent := True;' + sLineBreak +
  '    //Resized.Draw(AImage.Picture.Bitmap.Canvas, 0, 0, True); //desenha direto no TImage' + sLineBreak +
  '    //AImage.Picture.Bitmap.Assign( TBitmap(Resized.Bitmap) );' + sLineBreak +
  '' + sLineBreak +
  '    Mask.Free;' + sLineBreak +
  '    Resized.Free;' + sLineBreak +
  '' + sLineBreak +
  '    try' + sLineBreak +
  '      if FileExists(lArqruivo) then' + sLineBreak +
  '        DeleteFile(lArqruivo);' + sLineBreak +
  '    except' + sLineBreak +
  '    end;' + sLineBreak +
  '  finally' + sLineBreak +
  '    Source.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class procedure TUtilImagem.CreateAvatarFromFile(var AImage: TImage; ASourcePath: string; ADestSize: integer);' + sLineBreak +
  '//cria uma avatar da imagem de uma arquivo' + sLineBreak +
  'var' + sLineBreak +
  '  Source, Resized, Mask: TBGRABitmap;' + sLineBreak +
  '  bmp: TBitmap;' + sLineBreak +
  '  Png: TPortableNetworkGraphic;' + sLineBreak +
  '  MinSide: integer;' + sLineBreak +
  '  CropRect: TRect;' + sLineBreak +
  '  lArqruivo: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  // Carrega a imagem original' + sLineBreak +
  '  Source := TBGRABitmap.Create(ASourcePath);' + sLineBreak +
  '  lArqruivo := ExtractFileDir(ParamStr(0)) + PathDelim + ''avatar0.png'';' + sLineBreak +
  '' + sLineBreak +
  '  try' + sLineBreak +
  '    //Calcular o corte quadrado centralizado (para não achatar a imagem)' + sLineBreak +
  '    MinSide := Source.Width;' + sLineBreak +
  '    if Source.Height < MinSide then MinSide := Source.Height;' + sLineBreak +
  '' + sLineBreak +
  '    CropRect := Rect((Source.Width - MinSide) div 2,' + sLineBreak +
  '                     (Source.Height - MinSide) div 2,' + sLineBreak +
  '                     ((Source.Width - MinSide) div 2) + MinSide,' + sLineBreak +
  '                     ((Source.Height - MinSide) div 2) + MinSide);' + sLineBreak +
  '' + sLineBreak +
  '    //Extrai o quadrado e redimensiona para o tamanho final desejado' + sLineBreak +
  '    Resized := Source.GetPart(CropRect) as TBGRABitmap;' + sLineBreak +
  '    Resized.ResampleFilter := rfBestQuality; // Garante alta velocidade/qualidade' + sLineBreak +
  '    BGRAReplace(Resized, Resized.Resample(ADestSize, ADestSize));' + sLineBreak +
  '' + sLineBreak +
  '    //Cria a máscara circular com Antialiasing' + sLineBreak +
  '    Mask := TBGRABitmap.Create(ADestSize, ADestSize, BGRAPixelTransparent);' + sLineBreak +
  '' + sLineBreak +
  '    // Desenha uma elipse preenchida (círculo) na cor opaca' + sLineBreak +
  '    Mask.FillEllipseAntialias(ADestSize/2, ADestSize/2, ADestSize/2, ADestSize/2, BGRAWhite);' + sLineBreak +
  '' + sLineBreak +
  '    //Aplica a máscara (Multiplica o canal Alpha)' + sLineBreak +
  '    Resized.ApplyMask(Mask);' + sLineBreak +
  '' + sLineBreak +
  '    //Modo 1 - Transferência para o AImage' + sLineBreak +
  '    //Resized.SaveToFile(lArqruivo);' + sLineBreak +
  '    //AImage.Picture.LoadFromFile(lArqruivo);' + sLineBreak +
  '' + sLineBreak +
  '    //Modo 2 - Transferência para o AImage' + sLineBreak +
  '    //Resized.Draw(AImage.Picture.Bitmap.Canvas, 0, 0, True); //desenha direto no TImage' + sLineBreak +
  '' + sLineBreak +
  '    //Modo 3 - Transferência para o AImage' + sLineBreak +
  '    //bmp := Resized.MakeBitmapCopy(clWhite, True);' + sLineBreak +
  '    //AImage.Picture.Bitmap.Assign(bmp);' + sLineBreak +
  '    //bmp.Free;' + sLineBreak +
  '' + sLineBreak +
  '    //Modo 4 - Transferência para o AImage' + sLineBreak +
  '    // Converte de volta para o TImage via PNG' + sLineBreak +
  '    Png := TPortableNetworkGraphic.Create;' + sLineBreak +
  '    try' + sLineBreak +
  '      Png.Assign(Resized);' + sLineBreak +
  '      AImage.Picture.Assign(Png);' + sLineBreak +
  '      AImage.Transparent := True;' + sLineBreak +
  '    finally' + sLineBreak +
  '      Png.Free;' + sLineBreak +
  '    end;' + sLineBreak +
  '' + sLineBreak +
  '    Mask.Free;' + sLineBreak +
  '    Resized.Free;' + sLineBreak +
  '' + sLineBreak +
  '    try' + sLineBreak +
  '      if FileExists(lArqruivo) then' + sLineBreak +
  '        DeleteFile(lArqruivo);' + sLineBreak +
  '    except' + sLineBreak +
  '    end;' + sLineBreak +
  '  finally' + sLineBreak +
  '    Source.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'class procedure TUtilImagem.AvatarBorder(var AImage: TImage; ABorderColor: TColor; ABorderWidth: Integer);' + sLineBreak +
  '//aplica borda na imagem' + sLineBreak +
  'var' + sLineBreak +
  '  lw, lh: Integer;' + sLineBreak +
  'begin' + sLineBreak +
  '  lw := AImage.Picture.Bitmap.Width;' + sLineBreak +
  '  lh := AImage.Picture.Bitmap.Height;' + sLineBreak +
  '' + sLineBreak +
  '  with AImage.Canvas do begin' + sLineBreak +
  '    AntialiasingMode := amOn;' + sLineBreak +
  '    Pen.Style := psSolid;' + sLineBreak +
  '    Pen.Width := ABorderWidth;' + sLineBreak +
  '    Pen.Color := ABorderColor;' + sLineBreak +
  '    Brush.Style := bsClear;' + sLineBreak +
  '    Ellipse(0, 0, lw, lh);' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaUtil + 'util.imagem.pas', s);
  s := '';
end;

class procedure TUtilCommon.GerarServiceApiAudit(APastaService: string; ATipoBanco: TTipoBanco);
var
  s, sQueryTipo: string;
begin
  if ATipoBanco = TTipoBanco.SQLSERVER then
    sQueryTipo := 'TSQLQuery'
  else
    sQueryTipo := 'TZQuery';

  s :=
  'unit Service.ApiAudit;' + sLineBreak +
  ' ' + sLineBreak +
  TUtilCommon.InformacoesLegais +
  '' + sLineBreak +
  '// salva dados para auditoria no métodos Post, Put, Patch e Delete' + sLineBreak +
  '' + sLineBreak +
  '{$mode ObjFPC}{$H+}' + sLineBreak +
  '' + sLineBreak +
  'interface' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  Classes, SysUtils, DB, SQLDB, ZDataset,' + sLineBreak +
  '  Core.HttpContext;' + sLineBreak +
  '' + sLineBreak +
  'type' + sLineBreak +
  '' + sLineBreak +
  '  { TServiceApiAudit }' + sLineBreak +
  '' + sLineBreak +
  '  TServiceApiAudit = class' + sLineBreak +
  '    public' + sLineBreak +
  '      class procedure Log(const ctx: THttpContext; AMethod, ARoute, ATableName, AMessage: string; ASuccess, ARecordId: Integer);' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  'implementation' + sLineBreak +
  '' + sLineBreak +
  'uses' + sLineBreak +
  '  DM.Server, Model.UserInfo;' + sLineBreak +
  '' + sLineBreak +
  '{ TServiceApiAudit }' + sLineBreak +
  '' + sLineBreak +
  'class procedure TServiceApiAudit.Log(const ctx: THttpContext; AMethod, ARoute, ATableName, AMessage: string; ASuccess, ARecordId: Integer);' + sLineBreak +
  'var' + sLineBreak +
  '  Qry: ' + sQueryTipo + ';' + sLineBreak +
  '  u: TModelUserInfo;' + sLineBreak +
  '  user_id: integer;' + sLineBreak +
  '  user_name, user_login, user_agent: string;' + sLineBreak +
  'begin' + sLineBreak +
  '  if not DMServer.Audit then Exit;' + sLineBreak +
  '' + sLineBreak +
  '  u := ctx.UserInformation;' + sLineBreak +
  '  user_id := u.Id;' + sLineBreak +
  '  user_name := u.Name;' + sLineBreak +
  '  user_login := u.Login;' + sLineBreak +
  '' + sLineBreak +
  '  if u.Id < 1 then' + sLineBreak +
  '    user_login := ctx.BasicUsername;' + sLineBreak +
  '' + sLineBreak +
  '  if Trim(user_login) = '''' then begin' + sLineBreak +
  '    user_name := ''unknown'';' + sLineBreak +
  '    user_login := ''unknown'';' + sLineBreak +
  '  end;' + sLineBreak +
  '' + sLineBreak +
  '  user_agent := Trim(ctx.Request.UserAgent);' + sLineBreak +
  '  if user_agent = '''' then user_agent := ''unknown'';' + sLineBreak +
  '' + sLineBreak +
  '  Qry := DMServer.NewQuery();' + sLineBreak +
  '  try' + sLineBreak +
  '    Qry.SQL.Text :=' + sLineBreak +
  '      ''INSERT INTO tpzapi_audit '' +' + sLineBreak +
  '      ''  (date_occurrency, user_id, user_name, user_login, '' +' + sLineBreak +
  '      ''  method, route, table_name, record_id, ip_address, '' +' + sLineBreak +
  '      ''  user_agent, message, success, request_body) '' +' + sLineBreak +
  '      ''VALUES ('' +' + sLineBreak +
  '      ''  :date_occurrency, :user_id, :user_name, :user_login, '' +' + sLineBreak +
  '      ''  :method, :route, :table_name, :record_id, :ip_address, '' +' + sLineBreak +
  '      ''  :user_agent, :message, :success, :request_body); '';' + sLineBreak +
  '' + sLineBreak +
  '    Qry.ParamByName(''date_occurrency'').AsDateTime := Now;' + sLineBreak +
  '    Qry.ParamByName(''user_id'').AsInteger := user_id;' + sLineBreak +
  '    Qry.ParamByName(''user_name'').AsString := user_name;' + sLineBreak +
  '    Qry.ParamByName(''user_login'').AsString := user_login;' + sLineBreak +
  '    Qry.ParamByName(''method'').AsString := AMethod;' + sLineBreak +
  '    Qry.ParamByName(''route'').AsString := ARoute;' + sLineBreak +
  '    Qry.ParamByName(''table_name'').AsString := ATableName;' + sLineBreak +
  '    Qry.ParamByName(''record_id'').AsInteger := ARecordId;' + sLineBreak +
  '    Qry.ParamByName(''ip_address'').AsString := ctx.IPClient;' + sLineBreak +
  '    Qry.ParamByName(''user_agent'').AsString := user_agent;' + sLineBreak +
  '    Qry.ParamByName(''message'').AsString := AMessage;' + sLineBreak +
  '    Qry.ParamByName(''success'').AsInteger := ASuccess;' + sLineBreak +
  '    Qry.ParamByName(''request_body'').AsString := ctx.Body;' + sLineBreak +
  '' + sLineBreak +
  '    Qry.ExecSQL;' + sLineBreak +
  '  finally' + sLineBreak +
  '    Qry.Free;' + sLineBreak +
  '  end;' + sLineBreak +
  'end;' + sLineBreak +
  '' + sLineBreak +
  'end.' + sLineBreak +
  '' + sLineBreak;

  TUtilCommon.SalvarArquivo(APastaService + 'service.apiaudit.pas', s);
  s := '';
end;

class function TUtilCommon.GetTabelaAuditagem: string;
begin
  Result :=
    'procedure TDMServer.CreateAuditTable(AProtocol: string);' + sLineBreak +
    'var' + sLineBreak +
    '  s: string;' + sLineBreak +
    'begin' + sLineBreak +
    '  FAudit := False;' + sLineBreak +
    '  if AProtocol = '''' then Exit;' + sLineBreak +
    '' + sLineBreak +
    '  s := '''';' + sLineBreak +
    '  if AProtocol.Contains(''mssql'') then begin' + sLineBreak +
    '    s := s +' + sLineBreak +
    '      ''IF NOT EXISTS ('' + sLineBreak +' + sLineBreak +
    '      ''    SELECT 1'' + sLineBreak +' + sLineBreak +
    '      ''    FROM sys.objects'' + sLineBreak +' + sLineBreak +
    '      ''    WHERE object_id = OBJECT_ID(N''''dbo.tpzapi_audit'''')'' + sLineBreak +' + sLineBreak +
    '      ''      AND type = ''''U'''''' + sLineBreak +' + sLineBreak +
    '      '')'' + sLineBreak +' + sLineBreak +
    '      ''BEGIN'' + sLineBreak +' + sLineBreak +
    '      '' CREATE TABLE dbo.tpzapi_audit ('' + sLineBreak;' + sLineBreak +
    '  end' + sLineBreak +
    '  else' + sLineBreak +
    '    s := s +' + sLineBreak +
    '      ''CREATE TABLE IF NOT EXISTS tpzapi_audit ('' + sLineBreak;' + sLineBreak +
    '' + sLineBreak +
    '  if AProtocol.Contains(''oracle'') then' + sLineBreak +
    '    s := s + '' idlog           NUMBER(10) GENERATED ALWAYS AS IDENTITY,'' + sLineBreak;' + sLineBreak +
    '' + sLineBreak +
    '  if AProtocol.Contains(''mssql'') then' + sLineBreak +
    '    s := s + '' idlog           BIGINT IDENTITY(1,1) PRIMARY KEY NOT NULL,'' + sLineBreak;' + sLineBreak +
    '' + sLineBreak +
    '  if AProtocol.Contains(''postgresql'') then' + sLineBreak +
    '    s := s + '' idlog           BIGSERIAL PRIMARY KEY,'' + sLineBreak;' + sLineBreak +
    '' + sLineBreak +
    '  if AProtocol.Contains(''mysql'') then' + sLineBreak +
    '    s := s + '' idlog           BIGINT AUTO_INCREMENT PRIMARY KEY,'' + sLineBreak;' + sLineBreak +
    '' + sLineBreak +
    '  if AProtocol.Contains(''mariadb'') then' + sLineBreak +
    '    s := s + '' idlog           BIGINT AUTO_INCREMENT PRIMARY KEY,'' + sLineBreak;' + sLineBreak +
    '' + sLineBreak +
    '  if AProtocol.Contains(''firebird'') then' + sLineBreak +
    '    s := s + '' idlog           INTEGER GENERATED BY DEFAULT AS IDENTITY PRIMARY KEY,'' + sLineBreak;' + sLineBreak +
    '' + sLineBreak +
    '  if AProtocol.Contains(''sqlite'') then' + sLineBreak +
    '    s := s + '' idlog           INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,'' + sLineBreak;' + sLineBreak +
    '' + sLineBreak +
    '  s := s +' + sLineBreak +
    '    '' date_occurrency DATETIME,'' + sLineBreak +' + sLineBreak +
    '    '' user_id         INTEGER,'' + sLineBreak +' + sLineBreak +
    '    '' user_name       VARCHAR(100),'' + sLineBreak +' + sLineBreak +
    '    '' user_login      VARCHAR(50),'' + sLineBreak +' + sLineBreak +
    '    '' method          VARCHAR(10),      -- GET, POST, PUT, DELETE'' + sLineBreak +' + sLineBreak +
    '    '' route           VARCHAR(255),     -- /api/products/10'' + sLineBreak +' + sLineBreak +
    '    '' table_name      VARCHAR(100),     -- products'' + sLineBreak +' + sLineBreak +
    '    '' record_id       INTEGER,          -- 10'' + sLineBreak +' + sLineBreak +
    '    '' ip_address      VARCHAR(45),      -- IPv4/IPv6'' + sLineBreak +' + sLineBreak +
    '    '' user_agent      VARCHAR(500),'' + sLineBreak +' + sLineBreak +
    '    '' message         VARCHAR(100),'' + sLineBreak +' + sLineBreak +
    '    '' success         INTEGER,'' + sLineBreak +' + sLineBreak +
    '    '' request_body    TEXT'';' + sLineBreak +
    '' + sLineBreak +
    ' if AProtocol.Contains(''oracle'') then' + sLineBreak +
    '    s := s + '', '' + sLineBreak +'' PRIMARY KEY ("idlog")'';' + sLineBreak +
    '' + sLineBreak +
    '  s := s +' + sLineBreak +
    '    sLineBreak + '') '';' + sLineBreak +
    '' + sLineBreak +
    '  if AProtocol.Contains(''mssql'') then' + sLineBreak +
    '     s := s + sLineBreak + ''END'';' + sLineBreak +
    '' + sLineBreak +
    '  try' + sLineBreak +
    '    Connection.ExecuteDirect(s);' + sLineBreak +
    '    FAudit := True;' + sLineBreak +
    '' + sLineBreak +
    '    if AProtocol.Contains(''mssql'') then' + sLineBreak +
    '      s :=' + sLineBreak +
    '         ''IF NOT EXISTS ('' + sLineBreak +' + sLineBreak +
    '         ''    SELECT 1'' + sLineBreak +' + sLineBreak +
    '         ''    FROM sys.indexes i'' + sLineBreak +' + sLineBreak +
    '         ''    INNER JOIN sys.tables t'' + sLineBreak +' + sLineBreak +
    '         ''        ON i.object_id = t.object_id'' + sLineBreak +' + sLineBreak +
    '         ''    WHERE t.name = ''''tpzapi_audit'''''' + sLineBreak +' + sLineBreak +
    '         ''      AND i.name = ''''idx_apiaudit'''''' + sLineBreak +' + sLineBreak +
    '         '')'' + sLineBreak +' + sLineBreak +
    '         ''BEGIN'' + sLineBreak +' + sLineBreak +
    '         ''    CREATE INDEX idx_apiaudit'' + sLineBreak +' + sLineBreak +
    '         ''    ON dbo.tpzapi_audit (idlog, date_occurrency, table_name);'' + sLineBreak +' + sLineBreak +
    '         ''END'' + sLineBreak' + sLineBreak +
    '    else' + sLineBreak +
    '      s := ''create index if not exists idx_apiaudit on tpzapi_audit (idlog, date_occurrency, table_name) '';' + sLineBreak +
    '' + sLineBreak +
    '    Connection.ExecuteDirect(s);' + sLineBreak +
    '  except' + sLineBreak +
    '  end;' + sLineBreak +
    'end;' + sLineBreak;
end;

end.

